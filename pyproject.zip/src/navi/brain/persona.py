"""System prompt for Navi.

Composition (top to bottom):
  1. **Tool-use preamble** — the directive that tells the model HOW to call
     tools. Picked from :mod:`navi.brain.calibration`'s ``PROMPT_VARIANTS``
     based on what calibration determined works for the current model.
     Default is the Granite-tuned variant (verbatim from Granite 3.1's chat
     template; the model defers to its RLHF "I'm just text" reflex without it).
  2. **Navi persona** — name + behavior + remember/recall tool nudge.
  3. **Memory index** — first 200 lines of MEMORY.md so saved facts surface.

Per-model variant is persisted under ``settings["model_overrides"][filename]
["system_prompt_variant"]`` whenever calibration's auto-fix loop finds a
working alternative for the loaded model. On next launch the chosen variant
is applied immediately, no re-calibration needed.

If the user has explicitly set ``settings["ui"]["personaPrompt"]``, it
REPLACES preamble + persona — they opted out of auto-tuning.
"""

from __future__ import annotations

from pathlib import Path

# Default tool-use preamble: verbatim from Granite 3.1's chat template.
# This is what calibration's "granite" variant uses, and what we fall back
# to when no per-model override is set.
_TOOL_USE_PREAMBLE_DEFAULT = (
    "You are a helpful AI assistant with access to the following tools. "
    "When a tool is required to answer the user's query, respond with "
    "<|tool_call|> followed by a JSON list of tools used. If a tool does "
    "not exist in the provided list of tools, notify the user that you do "
    "not have the ability to fulfill the request."
)

# Navi-specific persona / behavior — orthogonal to the tool-use framing
# above, so the calibration auto-fix can swap the preamble without losing
# the persona.
#
# IMPORTANT: keep this terse and avoid suggestive nouns ("preferences",
# "facts", "decisions") — small models latch on to them and free-associate
# into fake multi-turn dialogue when the user input is ambiguous (e.g.
# "5+5" was producing a fabricated conversation about email fonts because
# the persona mentioned "preferences" + "remember/recall tools"). Saved
# in feedback_granite_tool_calling.md.
_NAVI_PERSONA = (
    "Your name is Navi. Be concise. Use tools instead of describing them. "
    "Do not output JSON code blocks. Do NOT generate fake multi-turn "
    "dialogue with 'User:' or 'Assistant:' prefixes — answer the user's "
    "actual message directly.\n\n"
    "For multi-step tasks, call ONE tool per turn, wait for its result, "
    "then continue. After completing every step, reply briefly without "
    "proposing follow-ups.\n\n"
    "Use the remember tool only when the user explicitly says to remember "
    "something. Use the recall tool only when the user asks about a "
    "previously saved memory."
)

# Backwards-compat: legacy callers (and tests) still import SYSTEM_PROMPT.
# Equivalent to "default variant + persona" with no memory.
SYSTEM_PROMPT = f"{_TOOL_USE_PREAMBLE_DEFAULT}\n\n{_NAVI_PERSONA}"


def _resolve_preamble() -> str:
    """Pick the tool-use preamble for the currently-loaded model.

    Priority:
      1. ``settings["model_overrides"][filename]["adapter_id"]`` — set by
         calibration's auto-fix when it finds a working family adapter.
      2. Legacy ``system_prompt_variant`` key (migrated to an adapter id).
      3. Filename-based detection via :func:`detect_adapter`.
      4. Default adapter (granite-tuned).
    """
    # Imported lazily so importing this module doesn't pull in the whole
    # adapter / settings stack (helps test isolation).
    from navi.brain.adapters import (
        adapter_by_id,
        default_adapter,
        detect_adapter,
        migrate_legacy_variant,
    )
    from navi.settings.store import load as load_settings

    settings = load_settings()
    model_path = settings.get("model", {}).get("path")
    if model_path:
        filename = Path(model_path).name
        entry = settings.get("model_overrides", {}).get(filename, {})

        # Persisted adapter id (new system)
        adapter_id = entry.get("adapter_id")
        # Legacy migration: settings written by older calibration code
        if adapter_id is None:
            adapter_id = migrate_legacy_variant(entry.get("system_prompt_variant"))

        if adapter_id:
            adapter = adapter_by_id(adapter_id)
            if adapter is not None:
                return adapter.system_prompt

        # No persisted choice — use filename detection
        return detect_adapter(Path(model_path)).system_prompt

    # No model path set yet (fresh install). Fall back to the granite_3
    # adapter — it's what the bundled model uses and what SYSTEM_PROMPT
    # (the legacy constant) corresponds to. NOT the "default" adapter,
    # which is intentionally minimal and would change behavior at first run.
    granite = adapter_by_id("granite_3")
    return granite.system_prompt if granite else default_adapter().system_prompt


def build_system_prompt() -> str:
    """Return the active system prompt.

    Refreshed at the start of every ``submit`` so any newly-saved memories,
    persona changes from the Settings dialog, or calibration auto-fix
    decisions take effect without restart.
    """
    from navi.memory.store import load_index
    from navi.settings.store import load as load_settings

    settings = load_settings()

    # If the user manually customized their persona prompt, use it as-is —
    # they opted out of auto-tuning. Otherwise compose preamble + persona.
    user_override = (settings.get("ui", {}) or {}).get("personaPrompt")
    if user_override:
        base = user_override
    else:
        base = f"{_resolve_preamble()}\n\n{_NAVI_PERSONA}"

    idx = load_index()
    if not idx:
        return base
    return (
        f"{base}\n\n"
        f"## Saved memories (use the `recall` tool for full text)\n\n{idx}"
    )
