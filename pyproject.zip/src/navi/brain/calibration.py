"""Adapter-based calibration for swapped LLMs.

Different model families behave differently — Granite's tool-call format
isn't Llama's, Phi's chat template isn't Qwen's. When the user swaps the
active model, run a small battery of probes so they can immediately see
whether the new model is sane on this app's prompts + tools, instead of
finding out mid-conversation.

Run after every successful model load and on demand via ``/calibrate``.
Emits a :class:`CalibrationReport` summarising what worked and what didn't.

Auto-fix: when the ``tool_call`` probe fails, walks every adapter in
priority order trying each adapter's family-tuned system prompt. The first
adapter whose tool probe passes wins, gets persisted as the override for
this filename, and is applied to the brain's history immediately.

The ``ModelAdapter`` registry lives in :mod:`navi.brain.adapters`. Adapters
own the per-family system prompt + filename detection. The parser registry
in :mod:`navi.brain.parsers` is family-agnostic — it tries every format on
every response, so the only thing the adapter needs to do is nudge the
model toward emitting one of those formats.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from navi.brain.adapters import (
    ADAPTERS,
    ModelAdapter,
    _all_adapters,
    adapter_by_id,
    default_adapter,
    detect_adapter,
)


# ---------------------------------------------------------------------------
# Probe results
# ---------------------------------------------------------------------------


@dataclass
class ProbeResult:
    name: str
    passed: bool
    expected: str
    actual: str
    notes: str = ""


@dataclass
class CalibrationReport:
    adapter_id: str
    adapter_description: str
    adapter_notes: str
    model_filename: str
    probes: list[ProbeResult] = field(default_factory=list)
    # When auto-fix swapped to a different adapter, these record what won.
    fix_adapter_id: str | None = None
    fix_adapter_description: str | None = None

    @property
    def all_passed(self) -> bool:
        return all(p.passed for p in self.probes)

    @property
    def n_passed(self) -> int:
        return sum(1 for p in self.probes if p.passed)

    @property
    def n_total(self) -> int:
        return len(self.probes)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# Maximum response length (in chars) we tolerate for "concise" probes.
# Anything longer means the model is rambling — even if the right answer
# is in there somewhere, real chat usage will be unusable.
_MAX_CONCISE_CHARS = 25


# ---------------------------------------------------------------------------
# Probes (same shapes as before, but now driven by an adapter's system prompt)
# ---------------------------------------------------------------------------


def _stream_to_text(stream_iter, max_tokens_safety: int = 200) -> str:
    parts: list[str] = []
    seen = 0
    for chunk in stream_iter:
        delta = chunk["choices"][0].get("delta", {})
        content = delta.get("content")
        if content:
            parts.append(content)
            seen += 1
            if seen > max_tokens_safety:
                break
    return "".join(parts).strip()


def _stream_to_text_and_tools(stream_iter, max_chunks: int = 200) -> tuple[str, list[dict]]:
    parts: list[str] = []
    tool_acc: dict[int, dict] = {}
    n = 0
    for chunk in stream_iter:
        n += 1
        if n > max_chunks:
            break
        delta = chunk["choices"][0].get("delta", {})
        content = delta.get("content")
        if content:
            parts.append(content)
        for tc in delta.get("tool_calls") or []:
            idx = tc.get("index", 0)
            acc = tool_acc.setdefault(idx, {"name": "", "arguments": ""})
            fn = tc.get("function") or {}
            if fn.get("name"):
                acc["name"] += fn["name"]
            if fn.get("arguments"):
                acc["arguments"] += fn["arguments"]
    return "".join(parts).strip(), [tool_acc[k] for k in sorted(tool_acc)]


def _messages(system_prompt: str, user_prompt: str) -> list[dict[str, str]]:
    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt},
    ]


def _build_full_agent_prompt(adapter: ModelAdapter) -> str:
    """Compose the prompt the agent actually uses in real chat: the
    adapter's system prompt + the Navi persona. Memory index is skipped
    so calibration is reproducible."""
    from navi.brain.persona import _NAVI_PERSONA  # type: ignore[attr-defined]
    return f"{adapter.system_prompt}\n\n{_NAVI_PERSONA}"


def _probe_math(llm, system_prompt: str) -> ProbeResult:
    text = _stream_to_text(llm.create_chat_completion(
        messages=_messages(
            system_prompt,
            "Reply with ONLY the single digit answer, no other text. "
            "What is 2+2?",
        ),
        max_tokens=10,
        temperature=0.0,
        stream=True,
    ))
    has_answer = "4" in text
    is_concise = len(text) <= _MAX_CONCISE_CHARS
    passed = has_answer and is_concise
    why = ""
    if has_answer and not is_concise:
        why = "rambled"
    elif not has_answer:
        why = "wrong"
    return ProbeResult(
        name="math",
        passed=passed,
        expected=f"'4' alone (≤{_MAX_CONCISE_CHARS} chars)",
        actual=text[:500] or "(empty)",
        notes=f"{len(text)} chars{', ' + why if why else ''}",
    )


def _probe_short_reply(llm, system_prompt: str) -> ProbeResult:
    text = _stream_to_text(llm.create_chat_completion(
        messages=_messages(
            system_prompt,
            "Reply with EXACTLY one word and nothing else. The word: hello",
        ),
        max_tokens=20,
        temperature=0.0,
        stream=True,
    ))
    word_count = len(text.split())
    has_hello = "hello" in text.lower()
    is_concise = len(text) <= _MAX_CONCISE_CHARS
    passed = has_hello and word_count <= 2 and is_concise
    return ProbeResult(
        name="follows_format",
        passed=passed,
        expected=f"≤2 words containing 'hello' (≤{_MAX_CONCISE_CHARS} chars)",
        actual=text[:500] or "(empty)",
        notes=f"{word_count} words, {len(text)} chars",
    )


import re as _re

# Role-marker patterns the model uses to fake dialogue. Catches every
# variant we've seen in the wild:
#   "User:"  "Assistant:"   — colon suffix (Llama / Vicuna training data)
#   "[User]" "[Assistant]"  — bracketed (TinyLlama emitted this)
#   "<user>" "<assistant>"  — XML-ish (some chat templates)
#   "USER -" "ASSISTANT >"  — uppercase / unusual punctuation
# Anchored to a word boundary so we don't false-positive on "user_id" etc.
_FAKE_DIALOGUE_RE = _re.compile(
    r"(?:^|\W)(?:\[|<)?\s*(user|assistant|human|ai)\s*[\]:>\-]",
    _re.IGNORECASE,
)


def _has_fake_dialogue(text: str) -> bool:
    """True if the response contains role-marker prefixes that suggest the
    model is fabricating multi-turn dialogue instead of answering."""
    return bool(_FAKE_DIALOGUE_RE.search(text))


def _probe_no_roleplay(llm, system_prompt: str) -> ProbeResult:
    """Catches the failure mode where the model emits FAKE multi-turn
    dialogue with role-marker prefixes when given an ambiguous short prompt.

    Trigger: a short input like '5+5' combined with a persona that mentions
    tools and topics. Small models (Granite 2B, TinyLlama, etc.) latch onto
    persona keywords and free-associate into fabricated conversations.

    Pass conditions:
      * Response contains the actual answer ('10')
      * Response has no role-marker prefixes (User:, [User], <user>, etc.)
      * Response is short (no preamble, no rambling)
    """
    text = _stream_to_text(llm.create_chat_completion(
        messages=_messages(system_prompt, "5+5"),
        max_tokens=60,
        temperature=0.0,
        stream=True,
    ))
    has_answer = "10" in text
    no_roleplay = not _has_fake_dialogue(text)
    is_concise = len(text) <= 60
    passed = has_answer and no_roleplay and is_concise
    why = []
    if not has_answer:
        why.append("no 10")
    if not no_roleplay:
        why.append("fake dialogue")
    if not is_concise:
        why.append("rambled")
    return ProbeResult(
        name="no_roleplay",
        passed=passed,
        expected="contains '10', no fake-dialogue role markers",
        actual=text[:500] or "(empty)",
        notes=f"{len(text)} chars" + (f", {', '.join(why)}" if why else ""),
    )


def _probe_coherence(llm, system_prompt: str) -> ProbeResult:
    """Tests whether the model can ANSWER a simple factual question
    coherently. Catches the 'rambles unrelated training-data dialogue'
    failure mode (the original TinyLlama 5+5 → email-fonts bug).

    More lenient than math/format probes — we accept polite single-
    sentence answers like "The capital of France is Paris." since that
    proves coherence even though it's not minimal. The hard fail
    conditions are: no answer, OR fake dialogue prefixes, OR rambling
    past 80 chars.
    """
    COHERENCE_MAX_CHARS = 80
    text = _stream_to_text(llm.create_chat_completion(
        messages=_messages(
            system_prompt,
            "What is the capital of France? Answer in one short sentence.",
        ),
        max_tokens=30,
        temperature=0.0,
        stream=True,
    ))
    has_paris = "paris" in text.lower()
    is_concise = len(text) <= COHERENCE_MAX_CHARS
    no_roleplay = not _has_fake_dialogue(text)
    passed = has_paris and is_concise and no_roleplay
    why = []
    if not has_paris:
        why.append("no 'Paris'")
    if not is_concise:
        why.append("rambled")
    if not no_roleplay:
        why.append("fake dialogue")
    return ProbeResult(
        name="coherence",
        passed=passed,
        expected=f"contains 'Paris', no fake dialogue (≤{COHERENCE_MAX_CHARS} chars)",
        actual=text[:500] or "(empty)",
        notes=f"{len(text)} chars" + (f", {', '.join(why)}" if why else ""),
    )


def _probe_irrelevance(llm, tools_schema: list[dict], system_prompt: str) -> ProbeResult:
    """Does the model correctly NOT call a tool when none is needed?

    BFCL ('relevance detection') treats this as a core capability — small
    models often blindly fire whatever tool is mentioned in the persona.
    Pass = answers 'Paris' from knowledge AND emits NO tool call.
    """
    if not tools_schema:
        return ProbeResult(
            name="irrelevance", passed=True,
            expected="(no tools registered to test)", actual="(skipped)",
        )
    text, tool_calls = _stream_to_text_and_tools(llm.create_chat_completion(
        messages=_messages(
            system_prompt,
            "What is the capital of France? Reply briefly.",
        ),
        tools=tools_schema,
        tool_choice="auto",
        max_tokens=30,
        temperature=0.0,
        stream=True,
    ))
    from navi.brain.parsers import parse_any_tool_call
    parsed = parse_any_tool_call(text)
    no_tool = not tool_calls and not parsed
    has_paris = "paris" in text.lower()
    is_concise = len(text) <= 80
    passed = no_tool and has_paris and is_concise
    why = []
    if not no_tool:
        called = (
            tool_calls[0]["name"] if tool_calls
            else parsed[0]["function"]["name"] if parsed else "?"
        )
        why.append(f"called {called}")
    if not has_paris:
        why.append("no Paris")
    if not is_concise:
        why.append("rambled")
    return ProbeResult(
        name="irrelevance",
        passed=passed,
        expected="answers 'Paris' from knowledge, no tool call",
        actual=text[:500] or "(empty)",
        notes=f"{len(text)} chars" + (f", {', '.join(why)}" if why else ""),
    )


def _probe_wrong_tool(llm, tools_schema: list[dict], system_prompt: str) -> ProbeResult:
    """Given several tools, does the model pick the RIGHT one?

    We restrict the schema to a few specific tools and ask a question only
    one of them can answer. Pass = the model picks that specific tool.
    """
    # Subset of tools where there's an obvious right answer for the prompt.
    candidate_names = {"read_clipboard", "take_screenshot", "list_dir",
                       "list_windows"}
    subset = [t for t in tools_schema
              if t["function"]["name"] in candidate_names]
    if "read_clipboard" not in {t["function"]["name"] for t in subset}:
        return ProbeResult(
            name="wrong_tool", passed=False,
            expected="read_clipboard tool present",
            actual="(read_clipboard not registered — skipped)",
        )
    text, tool_calls = _stream_to_text_and_tools(llm.create_chat_completion(
        messages=_messages(
            system_prompt,
            "What's currently on my clipboard? Use a tool to find out.",
        ),
        tools=subset,
        tool_choice="auto",
        max_tokens=120,
        temperature=0.0,
        stream=True,
    ))
    from navi.brain.parsers import parse_any_tool_call
    parsed = tool_calls or [
        {"name": c["function"]["name"]}
        for c in (parse_any_tool_call(text) or [])
    ]
    if not parsed:
        return ProbeResult(
            name="wrong_tool", passed=False,
            expected="calls read_clipboard",
            actual=(text[:500] or "(no tool call)") + " …",
        )
    chosen = parsed[0]["name"]
    passed = chosen == "read_clipboard"
    return ProbeResult(
        name="wrong_tool",
        passed=passed,
        expected="calls read_clipboard from a 4-tool subset",
        actual=f"called {chosen}",
    )


def _probe_parallel_calls(llm, tools_schema: list[dict], system_prompt: str) -> ProbeResult:
    """Does the model emit multiple tool calls in one response?

    Phi-4-mini, Granite 4, Qwen support parallel calls natively. Llama 3
    explicitly does not (per Meta docs). This probe is INFORMATIONAL —
    failure isn't catastrophic, just tells the user what to expect.
    """
    candidate = [t for t in tools_schema
                 if t["function"]["name"] in {"read_clipboard", "list_windows"}]
    if len(candidate) < 2:
        return ProbeResult(
            name="parallel_calls", passed=True,
            expected="(needs read_clipboard + list_windows)",
            actual="(skipped)",
        )
    text, tool_calls = _stream_to_text_and_tools(llm.create_chat_completion(
        messages=_messages(
            system_prompt,
            "Read my clipboard AND list my open windows. Use both tools.",
        ),
        tools=candidate,
        tool_choice="auto",
        max_tokens=200,
        temperature=0.0,
        stream=True,
    ))
    from navi.brain.parsers import parse_any_tool_call
    parsed = tool_calls or (parse_any_tool_call(text) or [])
    names = {
        (c.get("name") if "name" in c else c["function"]["name"])
        for c in parsed
    }
    has_both = "read_clipboard" in names and "list_windows" in names
    return ProbeResult(
        name="parallel_calls",
        passed=has_both,
        expected="both read_clipboard AND list_windows in one response",
        actual=f"called: {sorted(names) or '(none)'}",
        notes="(informational — Llama 3 doesn't support parallel)",
    )


def _probe_history_resilience(llm, tools_schema: list[dict], system_prompt: str) -> ProbeResult:
    """With a 3-turn fake history of tool use, can the model still give a
    short clean math answer when asked? Catches the 'history poisoning'
    failure mode where prior bad turns derail the next response.
    """
    history_messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": "What's on my clipboard?"},
        {"role": "assistant", "content":
         '<|tool_call|>[{"name": "read_clipboard", "arguments": {}}]'},
        {"role": "tool", "content": "hello world", "name": "read_clipboard"},
        {"role": "assistant", "content": "Your clipboard says: hello world"},
        {"role": "user", "content": "What is 2+2? Just the digit."},
    ]
    text = _stream_to_text(llm.create_chat_completion(
        messages=history_messages,
        max_tokens=20,
        temperature=0.0,
        stream=True,
    ))
    has_answer = "4" in text
    is_concise = len(text) <= _MAX_CONCISE_CHARS
    no_roleplay = not _has_fake_dialogue(text)
    passed = has_answer and is_concise and no_roleplay
    why = []
    if not has_answer:
        why.append("no 4")
    if not is_concise:
        why.append("rambled")
    if not no_roleplay:
        why.append("fake dialogue")
    return ProbeResult(
        name="history_resilience",
        passed=passed,
        expected="answers '4' concisely after fake history",
        actual=text[:500] or "(empty)",
        notes=f"{len(text)} chars" + (f", {', '.join(why)}" if why else ""),
    )


def _validate_args_against_schema(
    name: str,
    args_json: str,
    tools_schema: list[dict],
) -> tuple[bool, str]:
    """Cheap JSON-schema check: are the args structurally valid for the
    declared tool? Returns ``(ok, reason)``.

    Doesn't pull in jsonschema as a dep — only validates the bits BFCL
    cares about: required keys present, types match where stated. Good
    enough to catch hallucinated arg names and missing-required failures.
    """
    import json as _json
    schema = next(
        (t["function"].get("parameters") for t in tools_schema
         if t["function"]["name"] == name),
        None,
    )
    if schema is None:
        return False, f"no schema for {name}"
    try:
        args = _json.loads(args_json) if isinstance(args_json, str) else args_json
    except _json.JSONDecodeError as exc:
        return False, f"args not valid JSON: {exc}"
    if not isinstance(args, dict):
        return False, f"args not an object (got {type(args).__name__})"
    props = schema.get("properties", {})
    required = schema.get("required", [])
    for req in required:
        if req not in args:
            return False, f"missing required arg {req!r}"
    for k in args:
        if props and k not in props:
            return False, f"hallucinated arg {k!r} (not in schema)"
    # Light type check on declared properties
    for k, v in args.items():
        decl = props.get(k, {}).get("type")
        if decl == "string" and not isinstance(v, str):
            return False, f"{k}: expected string, got {type(v).__name__}"
        if decl == "integer" and not isinstance(v, int):
            return False, f"{k}: expected integer, got {type(v).__name__}"
        if decl == "number" and not isinstance(v, (int, float)):
            return False, f"{k}: expected number, got {type(v).__name__}"
        if decl == "boolean" and not isinstance(v, bool):
            return False, f"{k}: expected boolean, got {type(v).__name__}"
    return True, "ok"


def _probe_tool_call(llm, tools_schema: list[dict], system_prompt: str) -> ProbeResult:
    """Does the model emit a tool call when asked to call one?

    The pass oracle is two-stage:
      1. Structured tool_call OR text-marker parser caught the response
      2. Args validate against the declared tool schema (BFCL-style)
    """
    if not tools_schema:
        return ProbeResult(
            name="tool_call",
            passed=False,
            expected="(no tools registered to test)",
            actual="(skipped)",
        )
    target = "read_clipboard"
    if not any(t["function"]["name"] == target for t in tools_schema):
        target = tools_schema[0]["function"]["name"]
    text, tool_calls = _stream_to_text_and_tools(llm.create_chat_completion(
        messages=_messages(
            system_prompt,
            f"Call the {target} tool right now. "
            "Don't reply with text — just emit the tool call.",
        ),
        tools=tools_schema,
        tool_choice="auto",
        max_tokens=120,
        temperature=0.0,
        stream=True,
    ))

    # Stage 1: did the model emit a tool call we can parse?
    structured_call = next(
        (tc for tc in tool_calls if tc["name"] == target),
        None,
    )
    parsed_via: str | None = None
    parsed_call_args: str = "{}"
    if not structured_call:
        from navi.brain.parsers import PARSERS, parse_any_tool_call
        parsed = parse_any_tool_call(text)
        if parsed and any(c["function"]["name"] == target for c in parsed):
            for p in PARSERS:
                try:
                    if p.detect(text):
                        parsed_via = p.id
                        break
                except Exception:
                    continue
            for c in parsed:
                if c["function"]["name"] == target:
                    parsed_call_args = c["function"]["arguments"]
                    break
    elif structured_call:
        parsed_call_args = structured_call.get("arguments", "{}")

    saw_target = structured_call is not None or parsed_via is not None

    # Stage 2: schema-validate the args (BFCL-style rigor)
    schema_ok = True
    schema_reason = "ok"
    if saw_target:
        schema_ok, schema_reason = _validate_args_against_schema(
            target, parsed_call_args, tools_schema,
        )

    passed = saw_target and schema_ok
    if structured_call and schema_ok:
        actual = f"structured tool_call → {target} (args ✓)"
    elif parsed_via and schema_ok:
        actual = f"text via {parsed_via} → {target} (args ✓)"
    elif saw_target and not schema_ok:
        actual = f"{target} called but bad args: {schema_reason}"
    elif tool_calls:
        actual = f"called {tool_calls[0]['name']} (wrong tool)"
    else:
        actual = (text[:500] or "(empty reply)") + (" …" if len(text) > 80 else "")
    return ProbeResult(
        name="tool_call",
        passed=passed,
        expected=f"calls {target} with schema-valid args",
        actual=actual,
    )


def _run_all_probes(
    llm,
    tools_schema: list[dict],
    system_prompt: str,
) -> list[ProbeResult]:
    out: list[ProbeResult] = []
    probes = (
        ("math", lambda: _probe_math(llm, system_prompt)),
        ("follows_format", lambda: _probe_short_reply(llm, system_prompt)),
        ("coherence", lambda: _probe_coherence(llm, system_prompt)),
        ("no_roleplay", lambda: _probe_no_roleplay(llm, system_prompt)),
        ("history_resilience",
         lambda: _probe_history_resilience(llm, tools_schema, system_prompt)),
        ("tool_call", lambda: _probe_tool_call(llm, tools_schema, system_prompt)),
        ("irrelevance",
         lambda: _probe_irrelevance(llm, tools_schema, system_prompt)),
        ("wrong_tool",
         lambda: _probe_wrong_tool(llm, tools_schema, system_prompt)),
        ("parallel_calls",
         lambda: _probe_parallel_calls(llm, tools_schema, system_prompt)),
    )
    for name, fn in probes:
        try:
            out.append(fn())
        except Exception as exc:  # noqa: BLE001
            out.append(ProbeResult(
                name=name, passed=False,
                expected="(probe ran)", actual=f"exception: {exc}",
            ))
    return out


# ---------------------------------------------------------------------------
# Calibration entrypoint
# ---------------------------------------------------------------------------


def run_calibration(
    llm,
    tools_schema: list[dict],
    model_path: Path,
    initial_adapter_id: str | None = None,
    auto_fix: bool = True,
    verbose: bool = False,
) -> CalibrationReport:
    """Run probes; if tool_call fails and ``auto_fix`` is True, walk other
    adapters' system prompts and pick one whose probe passes.

    Returns a report whose ``fix_adapter_id`` is set to the winning adapter
    when an auto-fix took effect (otherwise None). The CALLER must persist
    that id so subsequent launches start from the working adapter.
    """
    # Pick a starting adapter:
    #   1. Caller-provided id (e.g. persisted from a prior session)
    #   2. The detected family adapter (filename match)
    #   3. The default adapter
    starting_adapter = (
        adapter_by_id(initial_adapter_id) if initial_adapter_id else None
    ) or detect_adapter(model_path)
    starting_prompt = _build_full_agent_prompt(starting_adapter)

    report = CalibrationReport(
        adapter_id=starting_adapter.id,
        adapter_description=starting_adapter.description,
        adapter_notes=starting_adapter.notes,
        model_filename=model_path.name,
    )
    report.probes = _run_all_probes(llm, tools_schema, starting_prompt)

    if not auto_fix or report.all_passed:
        return report
    tool_failed = any(
        p.name == "tool_call" and not p.passed for p in report.probes
    )
    if not tool_failed:
        return report

    # Auto-fix: walk every other adapter in priority order (built-ins
    # plus user plugin adapters), try each prompt against the failing
    # tool probe. First pass wins.
    for adapter in _all_adapters():
        if adapter.id == starting_adapter.id:
            continue
        candidate_prompt = _build_full_agent_prompt(adapter)
        try:
            new_tool_probe = _probe_tool_call(llm, tools_schema, candidate_prompt)
        except Exception:  # noqa: BLE001
            continue
        if new_tool_probe.passed:
            for i, p in enumerate(report.probes):
                if p.name == "tool_call":
                    new_tool_probe.notes = (
                        (new_tool_probe.notes + " " if new_tool_probe.notes else "")
                        + f"(via adapter '{adapter.id}')"
                    )
                    report.probes[i] = new_tool_probe
                    break
            report.fix_adapter_id = adapter.id
            report.fix_adapter_description = adapter.description
            return report

    return report


def format_report_for_chat(report: CalibrationReport, verbose: bool = False) -> str:
    """Render the report as a multi-line chat note.

    ``verbose=True`` shows the full LLM response per probe (up to 500 chars
    captured). Default truncates to 80 chars per probe for compact display.
    """
    lines = [
        f"🧪 calibration · {report.adapter_description}"
        f" ({report.n_passed}/{report.n_total} passed)",
        f"   model: {report.model_filename}",
        f"   adapter: {report.adapter_notes}",
        "",
    ]
    snippet_max = 500 if verbose else 80
    for p in report.probes:
        mark = "✓" if p.passed else "✗"
        actual = p.actual
        if len(actual) > snippet_max:
            actual = actual[:snippet_max] + " …"
        if verbose and "\n" in actual:
            # Indent multi-line responses so the chat panel can render them
            actual = "\n      " + actual.replace("\n", "\n      ")
        line = f"   {mark} {p.name}: {actual}"
        if p.notes:
            line += f"  ({p.notes})"
        lines.append(line)
    if report.fix_adapter_id:
        lines.append("")
        lines.append(
            f"🔧 auto-fix applied: switched to adapter "
            f"'{report.fix_adapter_id}' "
            f"({report.fix_adapter_description}). "
            f"Saved as the default for this model."
        )
    if not report.all_passed:
        lines.append("")
        lines.append(
            "⚠ some probes still failing — this model may misbehave on "
            "reasoning or formatting. Switch via right-click → Model if "
            "the responses are bad."
        )
    return "\n".join(lines)


# Backwards-compat exports — older code referenced detect_profile + ModelProfile
# directly. The adapter layer subsumes them.
detect_profile = detect_adapter
ModelProfile = ModelAdapter
PROFILES = ADAPTERS
