"""Per-family ModelAdapter registry.

Each adapter knows:

* **Filename keywords** that match this model family in a GGUF name.
* The **system prompt** tuned to the format the family was trained on.
* A short user-facing **description** + **notes**.
* (optional) A **preferred parser id** — purely informational; the parser
  registry tries every parser anyway.

Tool schemas are NOT injected by the adapter — llama-cpp-python passes
``tools=[...]`` to the GGUF's chat template, which renders the family's
expected schema slot (Granite's ``available_tools``, Phi's ``<|tool|>``,
etc.) automatically.

Adapter selection priority for a given GGUF:

  1. ``settings.model_overrides[<filename>].adapter_id`` (set by calibration's
     auto-fix on a previous run).
  2. ``detect_adapter(model_path)`` — first adapter whose filename keywords
     match.
  3. The ``"default"`` adapter — minimal, OpenAI-style.

Format references are documented inline + in
``feedback_granite_tool_calling.md``.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ModelAdapter:
    id: str
    description: str
    filename_keywords: tuple[str, ...]
    system_prompt: str
    notes: str
    # Hint only — parser dispatch always tries every parser.
    preferred_parser_id: str | None = None
    # Optional sampling overrides. Some families work better at lower temps
    # (e.g. Phi at 0.2 emits cleaner JSON than at 0.4). Set None to inherit
    # the BrainConfig defaults.
    temperature_override: float | None = None
    top_p_override: float | None = None
    # Substring keywords matched against the GGUF's `general.architecture`
    # and `general.name` metadata fields (read after model load via
    # llm.metadata). Used as a tiebreaker when filename keywords are
    # ambiguous. Lowercase, substring match.
    metadata_keywords: tuple[str, ...] = ()


# ---------------------------------------------------------------------------
# Family-tuned system prompts
# ---------------------------------------------------------------------------

# Granite 3.x: verbatim from IBM Granite 3.1's chat template. Without this
# directive the model defers to RLHF refusals.
_GRANITE_3_PROMPT = (
    "You are a helpful AI assistant with access to the following tools. "
    "When a tool is required to answer the user's query, respond with "
    "<|tool_call|> followed by a JSON list of tools used. If a tool does "
    "not exist in the provided list of tools, notify the user that you do "
    "not have the ability to fulfill the request."
)

# Granite 4.0: new XML format per the official docs.
_GRANITE_4_PROMPT = (
    "You are a helpful AI assistant with access to tools. When you need to "
    "call a tool, respond with one or more tool-call blocks in EXACTLY this "
    "format:\n"
    '<tool_call>{"name": "TOOL_NAME", "arguments": {"ARG": "VALUE"}}</tool_call>\n'
    "Emit one block per call (Granite 4 supports parallel calls — multiple "
    "blocks in one response). Do not include any other text when calling "
    "tools."
)

# Phi-4-mini: official format per Microsoft's HF model card.
# PLURAL marker, paired open+close, JSON ARRAY body even for one call.
_PHI_PROMPT = (
    "You are a helpful AI assistant. You have access to a set of tools "
    "provided by the system. When you need to call one or more tools, your "
    "ENTIRE response must be a single line in this exact format and nothing "
    "else:\n"
    '<|tool_calls|>[{"name": "TOOL_NAME", "arguments": '
    '{"ARG": "VALUE"}}]<|/tool_calls|>\n'
    "The body MUST be a JSON array (use [] even for a single call). Do not "
    "include any preamble, explanation, or commentary before or after the "
    "tool call. After receiving tool results, reply to the user briefly in "
    "plain text without any special markers."
)

# Llama 3.1 / 3.2-small: JSON tool calling. Note 'parameters' (not 'arguments').
_LLAMA_3_JSON_PROMPT = (
    "You are a helpful AI assistant with access to tools. When a tool is "
    "needed, respond with a single JSON object in this exact format and "
    "nothing else:\n"
    '{"name": "TOOL_NAME", "parameters": {"ARG": "VALUE"}}\n'
    "Do not include preamble, code fences, or commentary. After receiving "
    "tool results, reply briefly in plain text."
)

# Llama 3.3 / Llama 3.2-large: pythonic format.
_LLAMA_3_PYTHONIC_PROMPT = (
    "You are a helpful AI assistant with access to tools. When you need to "
    "invoke one or more tools, your ENTIRE response must be a single line in "
    "Python call-list format and nothing else:\n"
    "[tool_name(arg1=value1, arg2=value2)]\n"
    "Use Python literal syntax for argument values (strings in quotes, "
    "lists in brackets, dicts in braces). Multiple calls go in the same "
    "list. Do not include any text outside the brackets."
)

# Qwen 2.5 / Qwen 3: Hermes-style XML.
_QWEN_PROMPT = (
    "You are a helpful AI assistant with access to tools. When a tool is "
    "needed, respond with one or more <tool_call> blocks in EXACTLY this "
    "format:\n"
    '<tool_call>{"name": "TOOL_NAME", "arguments": {"ARG": "VALUE"}}</tool_call>\n'
    "Emit one block per call. Do not include any text when calling tools."
)

# Mistral / Nemo: minimal — trust the chat template's [TOOL_CALLS] handling.
_MISTRAL_PROMPT = (
    "You are a helpful AI assistant with access to tools. Use the available "
    "tools whenever they would help answer the user's request. After a tool "
    "returns, summarize the result for the user briefly in plain text."
)

# Gemma 3: prompt-only tool calling — model has no native tool tokens.
# Recommended Markdown ```tool_code``` block format per Google DevRel.
_GEMMA_3_PROMPT = (
    "You are a helpful AI assistant. When you decide to invoke a tool, "
    "wrap your tool call in a Markdown code block tagged ``tool_code`` "
    "with Python call syntax. Example:\n"
    "```tool_code\n"
    "tool_name(arg1='value1', arg2='value2')\n"
    "```\n"
    "Tool results will come back in a ``tool_output`` block — use them to "
    "either call another tool or generate a friendly final reply. Use only "
    "the tools the system has provided."
)

# TinyLlama 1.1B Chat: aggressively short. Per the docs (Zephyr-style
# template + UltraChat fine-tune + ~12.7% baseline tool accuracy + AST
# benchmarks near 0%), this model can't handle a long preamble. Bare-JSON
# object format is closest to its Llama-2 ancestor's training.
_TINYLLAMA_PROMPT = (
    "You are a helpful assistant. To use a tool, output one line of JSON: "
    '{"name": "tool_name", "arguments": {"key": "value"}}\n'
    "Otherwise reply briefly in plain text. Do not write 'User:' or "
    "'Assistant:' lines."
)

# Default / fallback: minimal generic OpenAI-style.
_DEFAULT_PROMPT = (
    "You are a helpful AI assistant with access to tools. When a tool is "
    "needed, call it using the format your chat template defines. Otherwise "
    "reply concisely in plain text."
)


# ---------------------------------------------------------------------------
# Registry — order = filename-match priority (most specific first)
# ---------------------------------------------------------------------------


ADAPTERS: tuple[ModelAdapter, ...] = (
    ModelAdapter(
        id="granite_4",
        description="IBM Granite 4.0 (XML <tool_call>)",
        filename_keywords=("granite-4", "granite_4"),
        metadata_keywords=("granite-4", "granitemoe"),
        system_prompt=_GRANITE_4_PROMPT,
        notes=(
            "IBM Granite 4.0 — XML-style <tool_call>{...}</tool_call> tags. "
            "Different format from Granite 3.x; calibration starts here for "
            "Granite 4 GGUFs."
        ),
        preferred_parser_id="xml_tool_call_paired",
    ),
    ModelAdapter(
        id="granite_3",
        description="IBM Granite 3.x",
        filename_keywords=("granite-3", "granite_3", "granite"),
        metadata_keywords=("granite",),
        system_prompt=_GRANITE_3_PROMPT,
        notes=(
            "IBM Granite 3.x — native function-calling via <|tool_call|> + "
            "JSON array. This is Navi's tuned target; tool calls and persona "
            "should work out of the box."
        ),
        preferred_parser_id="marker_singular_array",
    ),
    ModelAdapter(
        id="phi",
        description="Microsoft Phi-4-mini / Phi-3",
        filename_keywords=("phi-4", "phi4", "phi-3", "phi3"),
        metadata_keywords=("phi3", "phi-3", "phi4", "phi-4"),
        system_prompt=_PHI_PROMPT,
        notes=(
            "Microsoft Phi-4-mini — uses PLURAL paired markers "
            "<|tool_calls|>[...]<|/tool_calls|> with a JSON array body. "
            "Confirmed from Microsoft's HF model card. Uses temp=0.2 "
            "for cleaner JSON output."
        ),
        preferred_parser_id="marker_plural_paired",
        temperature_override=0.2,
    ),
    # TinyLlama 1.1B — must match BEFORE llama_3_json because a strict
    # filename like `tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf` doesn't contain
    # `llama-3` but DOES contain `tinyllama`.
    ModelAdapter(
        id="tinyllama",
        description="TinyLlama 1.1B Chat (Zephyr-style)",
        filename_keywords=("tinyllama", "tiny-llama", "tiny_llama",
                           "tinycallama"),
        system_prompt=_TINYLLAMA_PROMPT,
        notes=(
            "TinyLlama 1.1B Chat — Zephyr-style template handled by the "
            "GGUF chat template. Inherent limits: ~12.7% baseline "
            "tool-call accuracy (per Berkeley TinyAgent paper) and weak "
            "instruction following at this size. Math / format / coherence "
            "probes will likely fail; that's a model capability issue, "
            "not a prompt issue. For real use, switch to Granite 3.x or "
            "Phi-4-mini, or use a fine-tuned variant like "
            "unclecode/tinyllama-function-call."
        ),
        preferred_parser_id="bare_json_object",
    ),
    # Llama 3.3 / 3.2-larger emit pythonic format — match BEFORE the
    # generic llama_3_json so 3.3 GGUFs are routed correctly.
    ModelAdapter(
        id="llama_3_pythonic",
        description="Meta Llama 3.3 / 3.2-large (Pythonic)",
        filename_keywords=(
            "llama-3.3", "llama3.3", "llama_3.3",
            "llama-3.2-70b", "llama-3.2-90b",
        ),
        system_prompt=_LLAMA_3_PYTHONIC_PROMPT,
        notes=(
            "Llama 3.3 / 3.2-large — pythonic call format "
            "[func(arg=val)]. Per Meta's docs."
        ),
        preferred_parser_id="pythonic_call",
    ),
    ModelAdapter(
        id="llama_3_json",
        description="Meta Llama 3.1 / 3.2-small (JSON)",
        filename_keywords=(
            "llama-3.1", "llama3.1", "llama_3.1",
            "llama-3.2-1b", "llama-3.2-3b", "llama-3.2",
            "llama-3", "llama3",
        ),
        system_prompt=_LLAMA_3_JSON_PROMPT,
        notes=(
            "Llama 3.1 / 3.2-1B / 3.2-3B — JSON {\"name\", \"parameters\"} "
            "format. Note 'parameters' NOT 'arguments' — parser handles both."
        ),
        preferred_parser_id="bare_json_object",
    ),
    ModelAdapter(
        id="qwen_hermes",
        description="Alibaba Qwen 2.5 / 3 (Hermes XML)",
        filename_keywords=("qwen", "qwq"),
        metadata_keywords=("qwen", "qwen2", "qwen3"),
        system_prompt=_QWEN_PROMPT,
        notes=(
            "Qwen 2.5 / 3 — Hermes-style <tool_call>{...}</tool_call>. "
            "Coder variants may emit Markdown JSON instead; calibration "
            "auto-fix will detect and switch if needed."
        ),
        preferred_parser_id="xml_tool_call_paired",
    ),
    ModelAdapter(
        id="mistral",
        description="Mistral / Mixtral / Nemo",
        filename_keywords=("mistral", "mixtral", "nemo"),
        metadata_keywords=("mistral", "mixtral"),
        system_prompt=_MISTRAL_PROMPT,
        notes=(
            "Mistral — uses [TOOL_CALLS] marker. Tool IDs may need to be "
            "9 digits exactly to avoid hallucination (chat-template quirk)."
        ),
        preferred_parser_id="mistral_token",
    ),
    ModelAdapter(
        id="gemma_3",
        description="Google Gemma 2 / 3 (prompt-only)",
        filename_keywords=("gemma-3", "gemma3", "gemma-2", "gemma2", "gemma"),
        metadata_keywords=("gemma", "gemma2", "gemma3"),
        system_prompt=_GEMMA_3_PROMPT,
        notes=(
            "Google Gemma 3 — NO native function-calling tokens. Uses "
            "Markdown ```tool_code``` blocks per Google DevRel's "
            "recommended approach. Tool quality varies."
        ),
        preferred_parser_id="markdown_tool_code",
    ),
    ModelAdapter(
        id="default",
        description="Unknown / generic",
        filename_keywords=(),
        system_prompt=_DEFAULT_PROMPT,
        notes=(
            "Could not identify the model family from the filename. Using "
            "a minimal generic prompt and relying on the chat template + "
            "tolerant parser. Auto-fix will rotate through other adapters "
            "if tool calls don't fire."
        ),
        preferred_parser_id=None,
    ),
)


def detect_adapter(model_path: Path) -> ModelAdapter:
    """Pick the first adapter whose keywords match the model filename.

    User plugin adapters (loaded from ``%APPDATA%/Navi/adapters/``) take
    priority over built-ins so users can override behavior for any GGUF.
    Falls back to the ``"default"`` adapter when nothing matches.
    """
    name = model_path.name.lower()
    for a in _all_adapters():
        if a.id == "default":
            continue
        if any(kw in name for kw in a.filename_keywords):
            return a
    return default_adapter()


def _all_adapters() -> list[ModelAdapter]:
    """Built-in ADAPTERS first, then user plugin adapters appended.

    Plugin adapters live in ``%APPDATA%/Navi/adapters/<name>.json`` —
    each file is a JSON object matching the ModelAdapter schema. Loaded
    fresh on each call (cheap; usually 0-3 files) so changes take effect
    without restart.
    """
    plugins = _load_plugin_adapters()
    return list(ADAPTERS) + plugins


def detect_adapter_with_metadata(
    model_path: Path,
    metadata: dict[str, str] | None = None,
) -> ModelAdapter:
    """Filename-first detection with GGUF metadata as a tiebreaker.

    ``metadata`` is the dict from ``llama_cpp.Llama.metadata`` (the GGUF's
    ``general.architecture`` and ``general.name`` fields are most useful).
    When the filename match is the broad ``default`` adapter but metadata
    keywords match a specific adapter, prefer the specific one.

    Filename match always wins when it picks a non-default adapter.
    Metadata is purely a fallback for ambiguous / renamed GGUFs.
    """
    by_filename = detect_adapter(model_path)
    if by_filename.id != "default" or not metadata:
        return by_filename
    haystack = " ".join(
        str(metadata.get(k, "")).lower()
        for k in ("general.architecture", "general.name", "general.basename")
    )
    if not haystack.strip():
        return by_filename
    for a in _all_adapters():
        if a.id == "default":
            continue
        if any(kw in haystack for kw in a.metadata_keywords):
            return a
    return by_filename


def adapter_by_id(adapter_id: str) -> ModelAdapter | None:
    return next((a for a in _all_adapters() if a.id == adapter_id), None)


def default_adapter() -> ModelAdapter:
    """The fallback adapter (id=``"default"``)."""
    return next(a for a in ADAPTERS if a.id == "default")


# ---------------------------------------------------------------------------
# Migration shim — old `system_prompt_variant` IDs → new adapter IDs
# ---------------------------------------------------------------------------

# Existing settings written by older calibration code use these variant IDs
# under ``model_overrides.<file>.system_prompt_variant``. Map them to the
# closest adapter so users don't lose their auto-fix on first launch.
_LEGACY_VARIANT_TO_ADAPTER: dict[str, str] = {
    "granite": "granite_3",
    "phi": "phi",
    "minimal_native": "default",
    "explicit_format": "default",
    "oneshot_example": "default",
    "bracket_only": "mistral",
}


def migrate_legacy_variant(legacy_id: str | None) -> str | None:
    """Map a stored ``system_prompt_variant`` value to a new ``adapter_id``.

    Returns None if ``legacy_id`` is None or unmapped.
    """
    if legacy_id is None:
        return None
    return _LEGACY_VARIANT_TO_ADAPTER.get(legacy_id)


# ---------------------------------------------------------------------------
# Plugin adapters — JSON files in %APPDATA%/Navi/adapters/
# ---------------------------------------------------------------------------


def user_adapters_dir() -> Path:
    """Where user plugin-adapter JSON files live."""
    import os
    appdata = os.environ.get("APPDATA")
    base = Path(appdata) if appdata else Path.home() / ".config"
    return base / "Navi" / "adapters"


def _load_plugin_adapters() -> list[ModelAdapter]:
    """Discover + load JSON adapter files from the user folder.

    Each file should be a JSON object with fields matching ModelAdapter:
    ``id`` (required, must not collide with built-ins), ``description``,
    ``filename_keywords`` (list[str]), ``system_prompt`` (str), and the
    optional fields (``notes``, ``preferred_parser_id``,
    ``temperature_override``, ``top_p_override``, ``metadata_keywords``).

    Errors in any file are caught + logged; one bad file never breaks the
    rest. Built-in adapter ids are protected — a plugin trying to use the
    id ``"phi"`` (for example) is silently ignored.
    """
    import json
    d = user_adapters_dir()
    if not d.exists():
        return []
    builtin_ids = {a.id for a in ADAPTERS}
    out: list[ModelAdapter] = []
    seen_ids: set[str] = set()
    for f in sorted(d.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            print(f"[adapters] skipping plugin {f.name}: bad JSON ({exc})")
            continue
        if not isinstance(data, dict):
            print(f"[adapters] skipping plugin {f.name}: not a JSON object")
            continue
        adapter_id = data.get("id")
        if not adapter_id or not isinstance(adapter_id, str):
            print(f"[adapters] skipping plugin {f.name}: missing id")
            continue
        if adapter_id in builtin_ids:
            print(
                f"[adapters] skipping plugin {f.name}: id "
                f"{adapter_id!r} collides with a built-in adapter"
            )
            continue
        if adapter_id in seen_ids:
            print(
                f"[adapters] skipping plugin {f.name}: duplicate id "
                f"{adapter_id!r}"
            )
            continue
        try:
            adapter = ModelAdapter(
                id=adapter_id,
                description=data.get("description", adapter_id),
                filename_keywords=tuple(data.get("filename_keywords", ())),
                system_prompt=data.get("system_prompt", ""),
                notes=data.get("notes", ""),
                preferred_parser_id=data.get("preferred_parser_id"),
                temperature_override=data.get("temperature_override"),
                top_p_override=data.get("top_p_override"),
                metadata_keywords=tuple(data.get("metadata_keywords", ())),
            )
        except Exception as exc:  # noqa: BLE001
            print(f"[adapters] skipping plugin {f.name}: {exc}")
            continue
        if not adapter.system_prompt:
            print(f"[adapters] skipping plugin {f.name}: empty system_prompt")
            continue
        seen_ids.add(adapter_id)
        out.append(adapter)
    return out
