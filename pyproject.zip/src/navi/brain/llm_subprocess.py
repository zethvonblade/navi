"""LLM subprocess — runs llama-cpp inference in its own Python process.

The whole reason for this script is the Python GIL: llama-cpp-python's
``create_chat_completion`` holds the GIL during prompt evaluation (the
slow phase for big inputs on CPU). When the LLM lives in the same process
as the Qt GUI, that GIL hold starves the GUI thread — the orb stops
animating, the chat looks frozen, and the app appears crashed even though
the brain is working.

Hosting the LLM in a subprocess fixes this at the source: the subprocess
holds its own GIL, the main process is free to run the GUI smoothly.
Communication is line-delimited JSON over stdin/stdout — simple, no IPC
framework needed.

Protocol
--------
Stdin (main → subprocess):
    {"op": "init", "model_path": "...", "n_ctx": N, "n_threads": N, "n_batch": N}
    {"op": "complete", "messages": [...], "tools": [...] | null,
     "tool_choice": "auto" | null, "max_tokens": N | null,
     "temperature": F | null, "top_p": F | null}
    {"op": "cancel"}             # interrupts an in-flight complete
    {"op": "shutdown"}           # graceful exit

Stdout (subprocess → main):
    {"event": "ready"}                         # after init
    {"event": "chunk", "data": <llama-cpp chunk dict>}
    {"event": "done"}                          # complete finished normally
    {"event": "cancelled"}                     # user cancelled mid-stream
    {"event": "error", "message": "..."}       # exception during op

The reader thread inside the subprocess always processes "cancel" requests
immediately (sets a flag). Other ops are queued and processed serially by
a worker thread, so we never read from an in-flight stream and the reader
can always poll cancel.
"""

from __future__ import annotations

import json
import queue
import sys
import threading
import traceback
from typing import Any


# ---------------------------------------------------------------------------
# Global subprocess state
# ---------------------------------------------------------------------------
_llm: Any = None
_request_queue: queue.Queue[dict[str, Any]] = queue.Queue()
_cancel_flag = threading.Event()
_io_lock = threading.Lock()  # serialize writes to stdout


def _send(obj: dict[str, Any]) -> None:
    """Write one JSON object to stdout, line-delimited, immediately flushed."""
    line = json.dumps(obj, default=str) + "\n"
    with _io_lock:
        sys.stdout.write(line)
        sys.stdout.flush()


# ---------------------------------------------------------------------------
# Reader thread: drains stdin, dispatches cancel immediately, queues others
# ---------------------------------------------------------------------------


def _reader_loop() -> None:
    while True:
        line = sys.stdin.readline()
        if not line:
            # Parent closed stdin — shut down cleanly.
            sys.exit(0)
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            _send({"event": "error", "message": f"bad json from main: {line!r}"})
            continue
        op = req.get("op")
        if op == "cancel":
            _cancel_flag.set()
            continue
        if op == "shutdown":
            sys.exit(0)
        _request_queue.put(req)


# ---------------------------------------------------------------------------
# Worker: runs init / complete serially
# ---------------------------------------------------------------------------


def _do_init(req: dict[str, Any]) -> None:
    global _llm
    from llama_cpp import Llama
    _llm = Llama(
        model_path=req["model_path"],
        n_ctx=int(req["n_ctx"]),
        n_threads=int(req["n_threads"]),
        n_batch=int(req["n_batch"]),
        verbose=False,
    )
    # Surface GGUF metadata (general.architecture, general.name, etc.) so
    # the main process's adapter detection can use it as a tiebreaker for
    # ambiguous filenames. Cheap dict copy — JSON-serialisable strings.
    metadata: dict[str, str] = {}
    try:
        raw_meta = getattr(_llm, "metadata", None) or {}
        for k, v in raw_meta.items():
            try:
                metadata[str(k)] = str(v)
            except Exception:  # noqa: BLE001
                continue
    except Exception:  # noqa: BLE001
        pass
    _send({"event": "ready", "metadata": metadata})


def _do_complete(req: dict[str, Any]) -> None:
    if _llm is None:
        _send({"event": "error", "message": "complete called before init"})
        return
    _cancel_flag.clear()
    kwargs: dict[str, Any] = {
        "messages": req["messages"],
        "stream": True,
    }
    # Optional pass-through fields (only set if present so we honour
    # llama-cpp's own defaults otherwise).
    for k in ("tools", "tool_choice", "max_tokens", "temperature", "top_p"):
        if req.get(k) is not None:
            kwargs[k] = req[k]
    try:
        stream = _llm.create_chat_completion(**kwargs)
        for chunk in stream:
            if _cancel_flag.is_set():
                _send({"event": "cancelled"})
                return
            _send({"event": "chunk", "data": chunk})
        _send({"event": "done"})
    except Exception:
        _send({"event": "error", "message": traceback.format_exc()})


def _worker_loop() -> None:
    while True:
        req = _request_queue.get()
        op = req.get("op")
        if op == "init":
            try:
                _do_init(req)
            except Exception:
                _send({"event": "error", "message": traceback.format_exc()})
        elif op == "complete":
            _do_complete(req)
        else:
            _send({"event": "error", "message": f"unknown op: {op!r}"})


# ---------------------------------------------------------------------------
# Entry
# ---------------------------------------------------------------------------


def main() -> None:
    # Best-effort utf-8 stdout. Don't reconfigure stdin — on Windows that
    # can break readline() on a pipe.
    try:
        sys.stdout.reconfigure(encoding="utf-8", line_buffering=True)  # type: ignore[attr-defined]
    except Exception:
        pass

    # IMPORTANT: pre-import llama_cpp on the MAIN thread. The ctypes DLL
    # load on Windows DEADLOCKS if attempted from a non-main thread first
    # (verified empirically — without this line `_do_init` hangs forever
    # on `from llama_cpp import Llama`). Pre-loading here makes the later
    # import inside the worker thread a no-op cache hit.
    import llama_cpp  # noqa: F401

    reader = threading.Thread(target=_reader_loop, daemon=True, name="llm-subproc-reader")
    worker = threading.Thread(target=_worker_loop, daemon=True, name="llm-subproc-worker")
    reader.start()
    worker.start()
    try:
        reader.join()
    except KeyboardInterrupt:
        sys.exit(0)


if __name__ == "__main__":
    main()
