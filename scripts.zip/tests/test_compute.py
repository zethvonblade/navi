"""Tests for src/navi/tools/compute.py — calc + AST whitelist safety.

Two scopes:

* Happy path: arithmetic produces correct, well-formatted results.
* **Safety: every escape route from the AST whitelist is rejected.**
  These are the tests that matter — the calc tool is risk='safe' (no
  permission prompt) so the whitelist IS the security boundary. If
  someone widens it without understanding why, these tests should fail.
"""

from __future__ import annotations

import math

import pytest

from navi.tools import get_tool
from navi.tools.compute import calc


# ----- registration --------------------------------------------------------


def test_calc_registered_safe() -> None:
    t = get_tool("calc")
    assert t is not None
    # MUST be safe (no permission prompt) — that's the entire reason this
    # tool exists. If you bump the risk you should re-justify.
    assert t.risk == "safe"


# ----- happy path ----------------------------------------------------------


@pytest.mark.parametrize("expr,expected", [
    ("2 + 2", "4"),
    ("2.5 * 40 + 10", "110"),
    ("1000 * 1000", "1,000,000"),       # thousands separators
    ("(3 + 5) * 2", "16"),
    ("2 ** 10", "1,024"),
    ("17 // 5", "3"),
    ("17 % 5", "2"),
    ("-5 + 3", "-2"),
])
def test_calc_arithmetic(expr: str, expected: str) -> None:
    assert calc(expr) == expected


def test_calc_handles_floats() -> None:
    out = calc("0.1 + 0.2")
    # Float result; just checks it parses and returns a string with digits.
    assert "0.3" in out


def test_calc_math_functions() -> None:
    assert calc("sqrt(16)") == "4"
    assert calc("abs(-7)") == "7"
    assert calc("max(1, 2, 3)") == "3"
    # log(100, 10) = 2 — the log function accepts (x, base).
    out = calc("log(100, 10)")
    assert out.startswith("2")


def test_calc_constants() -> None:
    out = calc("pi")
    assert out.startswith("3.14")


# ----- error reporting -----------------------------------------------------


def test_calc_empty_input() -> None:
    assert "required" in calc("")


def test_calc_syntax_error() -> None:
    out = calc("2 +")
    assert out.startswith("Error:")


def test_calc_division_by_zero() -> None:
    assert calc("1 / 0") == "Error: division by zero"


# ----- safety: the AST whitelist is the security boundary -----------------


def test_calc_rejects_arbitrary_name() -> None:
    """Bare names not in the constants whitelist must error, never resolve
    to None or AttributeError."""
    out = calc("undefined_variable + 1")
    assert "not allowed" in out
    assert "undefined_variable" in out


def test_calc_rejects_arbitrary_function() -> None:
    """Functions not in the math whitelist must error."""
    out = calc("print(1)")
    assert "not allowed" in out


def test_calc_rejects_dunder_import() -> None:
    """The classic eval-escape: __import__('os').system('...'). Whitelist
    has no __import__, so this must die at the Name lookup."""
    out = calc("__import__('os')")
    assert "not allowed" in out


def test_calc_rejects_attribute_access() -> None:
    """The other classic: (0).__class__.__bases__ chains. Attribute is
    not in the allowed node list."""
    out = calc("(0).__class__")
    assert "not allowed" in out


def test_calc_rejects_subscript() -> None:
    out = calc("[1, 2, 3][0]")
    # Could die at List or Subscript — either way, must error.
    assert out.startswith("Error:")


def test_calc_rejects_lambda() -> None:
    out = calc("(lambda x: x)(5)")
    assert out.startswith("Error:")


def test_calc_rejects_string_literal() -> None:
    """Constants must be int or float — strings would let format-string
    tricks through."""
    out = calc("'abc'")
    assert "only int/float" in out


def test_calc_rejects_kwargs() -> None:
    out = calc("round(1.5, ndigits=0)")
    assert "keyword arguments" in out


def test_calc_rejects_comparison() -> None:
    """Compare ops aren't whitelisted — calc returns numbers, not bools."""
    out = calc("1 < 2")
    assert out.startswith("Error:")
