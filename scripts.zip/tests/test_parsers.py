"""One test per parser × per canonical format from the model docs.

Every test pins a real format the unified adapter system needs to handle.
If a parser's behavior regresses or a model's docs change and we adapt,
these tests will catch it. References to the upstream docs are inline.
"""

from __future__ import annotations

import json

import pytest

from navi.brain.parsers import (
    PARSERS,
    parse_any_tool_call,
    parse_bare_json_object,
    parse_bracket_pseudo,
    parse_marker_plural_paired,
    parse_marker_singular_array,
    parse_markdown_tool_code,
    parse_mistral_token,
    parse_pythonic_call,
    parse_xml_tool_call_paired,
    text_starts_tool_call,
)


def _name(call: dict) -> str:
    return call["function"]["name"]


def _args(call: dict) -> dict:
    return json.loads(call["function"]["arguments"])


# ---------------------------------------------------------------------------
# parse_marker_plural_paired — Phi-4-mini official format
# ---------------------------------------------------------------------------


def test_phi_canonical_array_with_close() -> None:
    raw = (
        '<|tool_calls|>[{"name": "read_clipboard", '
        '"arguments": {}}]<|/tool_calls|>'
    )
    calls = parse_marker_plural_paired(raw)
    assert calls is not None and len(calls) == 1
    assert _name(calls[0]) == "read_clipboard"


def test_phi_parallel_calls() -> None:
    """Phi-4-mini supports parallel function calls in the array."""
    raw = (
        '<|tool_calls|>['
        '{"name": "a", "arguments": {"x": 1}}, '
        '{"name": "b", "arguments": {"y": 2}}'
        ']<|/tool_calls|>'
    )
    calls = parse_marker_plural_paired(raw)
    assert calls is not None and len(calls) == 2
    assert _name(calls[0]) == "a"
    assert _name(calls[1]) == "b"
    assert _args(calls[0]) == {"x": 1}


def test_phi_with_preamble_text() -> None:
    """Marker buried in prose still gets found."""
    raw = (
        "Sure, let me check that.\n\n"
        '<|tool_calls|>[{"name": "read_clipboard", '
        '"arguments": {}}]<|/tool_calls|>'
    )
    calls = parse_marker_plural_paired(raw)
    assert calls is not None and _name(calls[0]) == "read_clipboard"


def test_phi_returns_none_on_no_marker() -> None:
    assert parse_marker_plural_paired("just talking, no markers") is None


# ---------------------------------------------------------------------------
# parse_marker_singular_array — Granite 3.x
# ---------------------------------------------------------------------------


def test_granite_canonical_array() -> None:
    raw = '<|tool_call|>[{"name": "read_file", "arguments": {"path": "C:/x"}}]'
    calls = parse_marker_singular_array(raw)
    assert calls is not None and len(calls) == 1
    assert _name(calls[0]) == "read_file"
    assert _args(calls[0]) == {"path": "C:/x"}


def test_granite_alternate_marker() -> None:
    raw = '<tool_call>[{"name": "list_windows", "arguments": {}}]'
    calls = parse_marker_singular_array(raw)
    assert calls is not None and _name(calls[0]) == "list_windows"


def test_granite_unwrapped_single_object() -> None:
    """Granite sometimes drops the wrapping [] when there's only one call."""
    raw = '<|tool_call|>{"name": "read_clipboard", "arguments": {}}'
    calls = parse_marker_singular_array(raw)
    assert calls is not None and _name(calls[0]) == "read_clipboard"


def test_granite_handles_trailing_junk() -> None:
    raw = (
        '<|tool_call|>[{"name": "read_clipboard", "arguments": {}}]'
        "\n\nSome trailing chatter."
    )
    calls = parse_marker_singular_array(raw)
    assert calls is not None and len(calls) == 1


def test_granite_with_mid_prose_preamble() -> None:
    """Granite often preambles with apology before the marker."""
    raw = (
        "I apologize for the confusion. Here's how:\n"
        '<tool_call>[{"name": "read_pdf", "arguments": {"path": "x.pdf"}}]'
    )
    calls = parse_marker_singular_array(raw)
    assert calls is not None and _name(calls[0]) == "read_pdf"


# ---------------------------------------------------------------------------
# parse_xml_tool_call_paired — Granite 4 / Qwen Hermes
# ---------------------------------------------------------------------------


def test_xml_paired_single_call() -> None:
    raw = (
        '<tool_call>{"name": "get_weather", '
        '"arguments": {"city": "Boston"}}</tool_call>'
    )
    calls = parse_xml_tool_call_paired(raw)
    assert calls is not None and len(calls) == 1
    assert _name(calls[0]) == "get_weather"


def test_xml_paired_parallel_calls() -> None:
    """Granite 4 / Qwen emit one paired tag per call for parallelism."""
    raw = (
        '<tool_call>{"name": "a", "arguments": {}}</tool_call>\n'
        '<tool_call>{"name": "b", "arguments": {}}</tool_call>'
    )
    calls = parse_xml_tool_call_paired(raw)
    assert calls is not None and len(calls) == 2
    assert _name(calls[0]) == "a"
    assert _name(calls[1]) == "b"


def test_xml_paired_returns_none_when_only_opener() -> None:
    """Just `<tool_call>` without closing tag — handled by singular parser
    instead. Paired parser cleanly returns None."""
    raw = '<tool_call>[{"name": "X", "arguments": {}}]'
    assert parse_xml_tool_call_paired(raw) is None


# ---------------------------------------------------------------------------
# parse_mistral_token — Mistral [TOOL_CALLS]
# ---------------------------------------------------------------------------


def test_mistral_token_format() -> None:
    raw = (
        '[TOOL_CALLS][{"name": "get_weather", '
        '"arguments": {"city": "Paris"}}]'
    )
    calls = parse_mistral_token(raw)
    assert calls is not None and _name(calls[0]) == "get_weather"


def test_mistral_token_with_preamble() -> None:
    raw = (
        "Looking that up.\n[TOOL_CALLS]"
        '[{"name": "search", "arguments": {"q": "x"}}]'
    )
    calls = parse_mistral_token(raw)
    assert calls is not None and _name(calls[0]) == "search"


def test_mistral_token_none_when_absent() -> None:
    assert parse_mistral_token("plain text") is None


# ---------------------------------------------------------------------------
# parse_pythonic_call — Llama 3.3
# ---------------------------------------------------------------------------


def test_pythonic_single_call() -> None:
    raw = "[get_weather(city='Paris', units='metric')]"
    calls = parse_pythonic_call(raw)
    assert calls is not None and len(calls) == 1
    assert _name(calls[0]) == "get_weather"
    assert _args(calls[0]) == {"city": "Paris", "units": "metric"}


def test_pythonic_parallel_calls() -> None:
    raw = "[get_weather(city='Paris'), get_time(zone='UTC')]"
    calls = parse_pythonic_call(raw)
    assert calls is not None and len(calls) == 2
    assert _name(calls[0]) == "get_weather"
    assert _name(calls[1]) == "get_time"


def test_pythonic_with_eot_suffix() -> None:
    raw = "[search(query='hello')]<|eot_id|>"
    calls = parse_pythonic_call(raw)
    assert calls is not None and _name(calls[0]) == "search"


def test_pythonic_complex_arg_types() -> None:
    """Lists, dicts, ints, bools — all literal-evalable."""
    raw = "[run(items=[1,2,3], opts={'verbose': True}, timeout=30)]"
    calls = parse_pythonic_call(raw)
    assert calls is not None
    assert _args(calls[0]) == {"items": [1, 2, 3],
                                "opts": {"verbose": True},
                                "timeout": 30}


def test_pythonic_rejects_positional_args() -> None:
    """Llama emits keyword args only; positional is malformed."""
    raw = "[get_weather('Paris')]"
    assert parse_pythonic_call(raw) is None


def test_pythonic_rejects_non_call() -> None:
    assert parse_pythonic_call("[1, 2, 3]") is None


def test_pythonic_string_with_comma() -> None:
    """Quoted commas in args must not be split incorrectly."""
    raw = "[notify(message='Hello, world')]"
    calls = parse_pythonic_call(raw)
    assert calls is not None
    assert _args(calls[0]) == {"message": "Hello, world"}


# ---------------------------------------------------------------------------
# parse_markdown_tool_code — Gemma 3
# ---------------------------------------------------------------------------


def test_gemma_markdown_tool_code() -> None:
    raw = (
        "Here you go:\n"
        "```tool_code\n"
        "convert(amount=200000.0, currency='USD', new_currency='EUR')\n"
        "```"
    )
    calls = parse_markdown_tool_code(raw)
    assert calls is not None and len(calls) == 1
    assert _name(calls[0]) == "convert"
    assert _args(calls[0]) == {"amount": 200000.0, "currency": "USD",
                                "new_currency": "EUR"}


def test_gemma_no_code_block() -> None:
    assert parse_markdown_tool_code("plain text") is None


# ---------------------------------------------------------------------------
# parse_bracket_pseudo — Granite drift
# ---------------------------------------------------------------------------


def test_bracket_pseudo() -> None:
    raw = (
        'Now, I\'ll type "hello" into Notepad.\n\n'
        '[tool:type_text, arguments: {"text": "hello"}]'
    )
    calls = parse_bracket_pseudo(raw)
    assert calls is not None and _name(calls[0]) == "type_text"
    assert _args(calls[0]) == {"text": "hello"}


def test_bracket_pseudo_none_on_plain_text() -> None:
    assert parse_bracket_pseudo("Just words.") is None
    assert parse_bracket_pseudo("[unrelated brackets]") is None


# ---------------------------------------------------------------------------
# parse_bare_json_object — Llama 3.1 / fallback
# ---------------------------------------------------------------------------


def test_bare_json_with_parameters_key() -> None:
    """Llama 3.1 uses 'parameters' instead of 'arguments'."""
    raw = '{"name": "get_weather", "parameters": {"city": "Paris"}}'
    calls = parse_bare_json_object(raw)
    assert calls is not None
    assert _name(calls[0]) == "get_weather"
    # Normalized to 'arguments' (OpenAI shape) on output
    assert _args(calls[0]) == {"city": "Paris"}


def test_bare_json_with_arguments_key() -> None:
    raw = '{"name": "get_weather", "arguments": {"city": "Paris"}}'
    calls = parse_bare_json_object(raw)
    assert calls is not None and _name(calls[0]) == "get_weather"


def test_bare_json_with_eot_suffix() -> None:
    raw = '{"name": "X", "parameters": {}}<|eot_id|>'
    calls = parse_bare_json_object(raw)
    assert calls is not None and _name(calls[0]) == "X"


def test_bare_json_array() -> None:
    raw = (
        '[{"name": "a", "parameters": {}}, '
        '{"name": "b", "parameters": {}}]'
    )
    calls = parse_bare_json_object(raw)
    assert calls is not None and len(calls) == 2


def test_bare_json_with_preamble() -> None:
    """Model rambles before the JSON."""
    raw = (
        "I'll call that for you.\n"
        '{"name": "search", "parameters": {"q": "test"}}'
    )
    calls = parse_bare_json_object(raw)
    assert calls is not None and _name(calls[0]) == "search"


def test_bare_json_none_on_plain() -> None:
    assert parse_bare_json_object("Hello, world!") is None


# ---------------------------------------------------------------------------
# parse_any_tool_call — dispatcher / priority ordering
# ---------------------------------------------------------------------------


def test_dispatcher_routes_to_correct_parser_phi() -> None:
    raw = '<|tool_calls|>[{"name": "x", "arguments": {}}]<|/tool_calls|>'
    calls = parse_any_tool_call(raw)
    assert calls is not None and _name(calls[0]) == "x"


def test_dispatcher_routes_to_correct_parser_granite() -> None:
    raw = '<|tool_call|>[{"name": "x", "arguments": {}}]'
    calls = parse_any_tool_call(raw)
    assert calls is not None and _name(calls[0]) == "x"


def test_dispatcher_routes_to_correct_parser_pythonic() -> None:
    raw = "[get_time(zone='UTC')]"
    calls = parse_any_tool_call(raw)
    assert calls is not None and _name(calls[0]) == "get_time"


def test_dispatcher_routes_to_correct_parser_mistral() -> None:
    raw = '[TOOL_CALLS][{"name": "x", "arguments": {}}]'
    calls = parse_any_tool_call(raw)
    assert calls is not None and _name(calls[0]) == "x"


def test_dispatcher_routes_to_correct_parser_gemma() -> None:
    raw = "```tool_code\nx()\n```"
    calls = parse_any_tool_call(raw)
    assert calls is not None and _name(calls[0]) == "x"


def test_dispatcher_routes_to_correct_parser_xml() -> None:
    raw = '<tool_call>{"name": "x", "arguments": {}}</tool_call>'
    calls = parse_any_tool_call(raw)
    assert calls is not None and _name(calls[0]) == "x"


def test_dispatcher_returns_none_on_plain_text() -> None:
    assert parse_any_tool_call("Just a normal reply.") is None


def test_dispatcher_plural_marker_does_not_steal_singular() -> None:
    """Critical ordering test: plural parser must not match singular input."""
    raw = '<|tool_call|>[{"name": "single", "arguments": {}}]'
    calls = parse_any_tool_call(raw)
    assert calls is not None and _name(calls[0]) == "single"


def test_dispatcher_singular_marker_does_not_steal_plural() -> None:
    raw = '<|tool_calls|>[{"name": "plural", "arguments": {}}]<|/tool_calls|>'
    calls = parse_any_tool_call(raw)
    assert calls is not None and _name(calls[0]) == "plural"


# ---------------------------------------------------------------------------
# Sniff
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("text", [
    "<|tool_calls|>",
    "<|tool_call|>",
    "<tool_call>",
    "[tool_call]",
    "[TOOL_CALLS]",
    "```tool_code",
    '{"name":"X",',
    '{"function":"X",',
])
def test_sniff_recognizes_known_openers(text: str) -> None:
    assert text_starts_tool_call(text) is True


@pytest.mark.parametrize("text", [
    "Hello, world!",
    "I will help you with that.",
    "[1, 2, 3]",
    "{}",
])
def test_sniff_rejects_plain_text(text: str) -> None:
    assert text_starts_tool_call(text) is False


def test_sniff_handles_leading_whitespace() -> None:
    assert text_starts_tool_call("   <|tool_call|>...") is True


# ---------------------------------------------------------------------------
# Registry sanity
# ---------------------------------------------------------------------------


def test_every_parser_id_is_unique() -> None:
    ids = [p.id for p in PARSERS]
    assert len(ids) == len(set(ids)), f"duplicate parser ids: {ids}"


def test_every_parser_has_description() -> None:
    for p in PARSERS:
        assert p.description and isinstance(p.description, str)


def test_every_parser_returns_openai_shape() -> None:
    """All parsers, when they succeed, MUST return list[OpenAI-shape dict]."""
    samples = [
        '<|tool_calls|>[{"name":"x","arguments":{}}]<|/tool_calls|>',
        '<|tool_call|>[{"name":"x","arguments":{}}]',
        '<tool_call>{"name":"x","arguments":{}}</tool_call>',
        '[TOOL_CALLS][{"name":"x","arguments":{}}]',
        "[x()]",
        "```tool_code\nx()\n```",
        '[tool:x, arguments: {}]',
        '{"name":"x","arguments":{}}',
    ]
    for s in samples:
        result = parse_any_tool_call(s)
        assert result is not None, f"no parser handled {s!r}"
        for call in result:
            assert "id" in call
            assert call.get("type") == "function"
            assert "function" in call
            assert "name" in call["function"]
            assert "arguments" in call["function"]
            assert isinstance(call["function"]["arguments"], str)
            # arguments is JSON-encoded
            json.loads(call["function"]["arguments"])
