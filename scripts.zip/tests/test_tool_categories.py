"""Tests for the tool category system.

The user-facing reason this exists: Granite 2B on CPU takes 162 seconds
to respond to "hello" when all 55 tools are in the schema (measured).
The category system limits the schema to a lean default so cold-eval
stays under ~15 s.

Tests assert:
- Every registered tool has a category that's in KNOWN_CATEGORIES.
- The mapping matches the planned distribution (so a typo in any tool
  file is caught — e.g. accidentally tagging git_status as "core").
- tools_schema(set) filters correctly + always includes core as floor.
"""

from __future__ import annotations

import pytest

from navi.tools import all_tools, tools_schema
from navi.tools._registry import KNOWN_CATEGORIES, categories_in_use


# Expected tool counts per category (from the plan). If you add a tool
# to a category, bump this. If a number drifts unintentionally, the
# parametrized test below catches it.
EXPECTED_COUNTS: dict[str, int] = {
    "core": 12,
    "files": 8,
    "documents": 5,
    "desktop": 6,
    "shell": 1,
    "code": 9,
    "git": 9,
    "image": 1,
    "automation": 4,
}


# ----- registry shape ----------------------------------------------------


def test_total_tool_count() -> None:
    assert len(all_tools()) == sum(EXPECTED_COUNTS.values()) == 55


def test_every_tool_has_a_category() -> None:
    for t in all_tools():
        assert t.category, f"{t.name}: empty category"


def test_every_category_is_known() -> None:
    """No typos like 'fle' or 'documnts'. Caught at import via @tool's
    `if category not in KNOWN_CATEGORIES: raise`, but assert here too
    so the test surface is explicit."""
    for t in all_tools():
        assert t.category in KNOWN_CATEGORIES, (
            f"{t.name}: category {t.category!r} not in KNOWN_CATEGORIES "
            f"({sorted(KNOWN_CATEGORIES)})"
        )


@pytest.mark.parametrize("cat,expected_count", list(EXPECTED_COUNTS.items()))
def test_expected_distribution(cat: str, expected_count: int) -> None:
    """The plan's per-category counts must match reality. If a tool
    moves between categories or a new one is added/removed, update
    EXPECTED_COUNTS — don't loosen this test."""
    actual = sum(1 for t in all_tools() if t.category == cat)
    assert actual == expected_count, (
        f"category {cat!r}: expected {expected_count}, got {actual}. "
        "Update EXPECTED_COUNTS or fix the tool's category= argument."
    )


def test_categories_in_use_matches_expected() -> None:
    assert set(categories_in_use()) == set(EXPECTED_COUNTS)


# ----- tools_schema filtering --------------------------------------------


def test_schema_unfiltered_returns_all() -> None:
    """None means 'no filter' — used by tests + /tools all."""
    assert len(tools_schema()) == 55


def test_schema_core_only_is_lean() -> None:
    """The whole point. Lean schema ≈ 12 tools, ~6 KB serialized — keeps
    Granite 2B's cold prompt eval bounded on CPU."""
    schema = tools_schema({"core"})
    assert len(schema) == EXPECTED_COUNTS["core"]
    import json
    serialized = len(json.dumps(schema))
    assert serialized < 12_000, (
        f"core schema is {serialized} chars — should be ≤ ~10 KB to keep "
        "prompt eval fast. Trim a description or move a tool out of core."
    )


def test_schema_filter_includes_named_categories() -> None:
    schema = tools_schema({"core", "git"})
    names = {item["function"]["name"] for item in schema}
    # Every git tool should be present.
    git_names = {t.name for t in all_tools() if t.category == "git"}
    assert git_names <= names
    # Every core tool too (always included).
    core_names = {t.name for t in all_tools() if t.category == "core"}
    assert core_names <= names
    # files tools should NOT be present.
    file_names = {t.name for t in all_tools() if t.category == "files"}
    assert not (file_names & names)


def test_schema_empty_set_still_includes_core() -> None:
    """Disabling everything would break recall/datetime/calc and confuse
    the LLM. 'core' is the unconditional floor."""
    schema = tools_schema(set())
    names = {item["function"]["name"] for item in schema}
    core_names = {t.name for t in all_tools() if t.category == "core"}
    assert core_names == names, "core tools missing when set is empty"


def test_unknown_category_raises_at_registration() -> None:
    """Defense against typos: registering with a bad category should
    fail at import-time (here we simulate via the decorator directly)."""
    from navi.tools._registry import tool
    with pytest.raises(ValueError, match="unknown tool category"):
        @tool(name="probe_bad_cat", description="x", category="not-a-real-cat")
        def _bad() -> str:
            return ""
