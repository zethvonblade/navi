"""Tests for SettingsDialog UI behavior.

The bug being guarded against: ``_on_save`` used to emit `saved` BEFORE
calling ``self.accept()``. The slot for `saved` (PetWindow's
``_apply_settings``) is a Qt direct connection that runs SYNCHRONOUSLY
inside the same call stack — so the dialog couldn't close until the
entire install + brain-reload chain finished. Users perceived this as
"settings dialog stuck behind the install dialog."

Post-fix order: accept() first, then emit. The dialog gets its
close-event into the queue before the slot's heavy work begins.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from PySide6.QtWidgets import QDialog

from navi.settings import ui as settings_ui


@pytest.fixture
def stubbed_save(monkeypatch):
    """Don't write to the real settings.json during this test."""
    calls: list[dict] = []
    monkeypatch.setattr(settings_ui, "save_settings",
                        lambda s: calls.append(s) or Path("."))
    return calls


def test_on_save_accepts_before_emitting(qapp, stubbed_save) -> None:
    """REGRESSION: assert that when the `saved` signal fires, the dialog
    has ALREADY been accept()'d. If this fails, the slot will run before
    the dialog closes — exactly the bug that made the install dialog
    appear stuck."""
    from navi.settings.ui import SettingsDialog

    dlg = SettingsDialog()
    seen_results: list[int] = []
    dlg.saved.connect(lambda _settings: seen_results.append(dlg.result()))

    # Drive _on_save directly; we don't need to actually click anything.
    dlg._on_save()

    assert len(seen_results) == 1, "saved should have fired exactly once"
    assert seen_results[0] == QDialog.DialogCode.Accepted, (
        f"dialog.result() was {seen_results[0]} when `saved` fired — "
        "expected Accepted (1). The accept() must run BEFORE saved.emit() "
        "or the dialog stays open while the slot does heavy work, "
        "creating the perceived 'stuck dialog' bug."
    )
    # And settings should still have been saved.
    assert len(stubbed_save) == 1


def test_on_save_writes_settings_before_emitting(qapp, stubbed_save) -> None:
    """save_settings still runs before the signal — slot should see
    fresh disk state if it reloads settings."""
    from navi.settings.ui import SettingsDialog

    dlg = SettingsDialog()
    order: list[str] = []
    monkeypatch_save = settings_ui.save_settings  # already stubbed
    # Replace AGAIN so we can record order across save+emit.
    settings_ui.save_settings = lambda s: order.append("save")
    try:
        dlg.saved.connect(lambda _: order.append("emit"))
        dlg._on_save()
    finally:
        settings_ui.save_settings = monkeypatch_save

    assert order == ["save", "emit"]
