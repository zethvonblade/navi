"""Tests for git_ops tools.

Real git operations against a tmp_path repo (no subprocess mocking).
We discovered the ``ast.unparse`` problem precisely because we ran the
real thing — same logic applies here. Per-test fixture spins up a repo
with ``git init`` + author config + an initial committed file so each
test starts from a known clean baseline.

Tests are skipped if ``git`` isn't on PATH (CI may not have it; dev
machines do).
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest

from navi.tools import all_tools, get_tool
from navi.tools.git_ops import (
    git_add,
    git_branch_create,
    git_branch_list,
    git_checkout,
    git_commit,
    git_diff,
    git_init,
    git_log,
    git_status,
)


# ----- skip if git missing -------------------------------------------------


pytestmark = pytest.mark.skipif(
    shutil.which("git") is None,
    reason="git is not on PATH; tests need a real git binary",
)


# ----- fixtures ------------------------------------------------------------


@pytest.fixture
def repo(tmp_path: Path) -> Path:
    """Spin up a fresh git repo with author config + an initial commit
    on `main`. Returns the absolute repo path."""
    subprocess.run(["git", "init", "-b", "main", str(tmp_path)],
                   check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.email", "test@navi.local"],
                   check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "config", "user.name", "Navi Tests"],
                   check=True, capture_output=True)
    (tmp_path / "README.md").write_text("seed\n")
    subprocess.run(["git", "-C", str(tmp_path), "add", "README.md"],
                   check=True, capture_output=True)
    subprocess.run(["git", "-C", str(tmp_path), "commit", "-m", "seed"],
                   check=True, capture_output=True)
    return tmp_path


# ----- registration --------------------------------------------------------


@pytest.mark.parametrize("name,risk", [
    ("git_status", "safe"),
    ("git_diff", "safe"),
    ("git_log", "safe"),
    ("git_branch_list", "safe"),
    ("git_init", "medium"),
    ("git_branch_create", "medium"),
    ("git_checkout", "medium"),
    ("git_add", "medium"),
    ("git_commit", "medium"),
])
def test_registered_with_expected_risk(name: str, risk: str) -> None:
    names = {t.name for t in all_tools()}
    assert name in names
    t = get_tool(name)
    assert t is not None
    assert t.risk == risk, (
        f"{name} risk should be {risk!r} per the plan; got {t.risk!r}"
    )


# ----- read-only tools -----------------------------------------------------


def test_status_clean_repo_shows_branch(repo: Path) -> None:
    out = git_status(str(repo))
    assert "## main" in out


def test_status_dirty_repo_shows_modified(repo: Path) -> None:
    (repo / "README.md").write_text("changed\n")
    (repo / "new.txt").write_text("new\n")
    out = git_status(str(repo))
    assert " M README.md" in out
    assert "?? new.txt" in out


def test_diff_unstaged(repo: Path) -> None:
    (repo / "README.md").write_text("changed\n")
    out = git_diff(str(repo))
    assert "README.md" in out
    assert "-seed" in out
    assert "+changed" in out


def test_diff_staged(repo: Path) -> None:
    (repo / "README.md").write_text("changed\n")
    subprocess.run(["git", "-C", str(repo), "add", "README.md"],
                   check=True, capture_output=True)
    # Unstaged diff should now be empty.
    assert git_diff(str(repo)).strip() in ("", "(no output)")
    staged = git_diff(str(repo), staged=True)
    assert "+changed" in staged


def test_log_oneline_default_count(repo: Path) -> None:
    # Add 12 commits so we can test the cap.
    for i in range(12):
        (repo / f"f{i}.txt").write_text(str(i))
        subprocess.run(["git", "-C", str(repo), "add", f"f{i}.txt"],
                       check=True, capture_output=True)
        subprocess.run(["git", "-C", str(repo), "commit", "-m", f"commit {i}"],
                       check=True, capture_output=True)
    out = git_log(str(repo))  # default 10
    # Should have exactly 10 lines.
    lines = [ln for ln in out.splitlines() if ln.strip()]
    assert len(lines) == 10


def test_log_respects_max_count(repo: Path) -> None:
    out = git_log(str(repo), max_count=1)
    lines = [ln for ln in out.splitlines() if ln.strip()]
    assert len(lines) == 1
    assert "seed" in out


def test_log_rejects_zero_max_count(repo: Path) -> None:
    assert "must be >= 1" in git_log(str(repo), max_count=0)


def test_branch_list_shows_current_with_star(repo: Path) -> None:
    out = git_branch_list(str(repo))
    assert "* main" in out


# ----- git_init ------------------------------------------------------------


def test_init_creates_git_dir(tmp_path: Path) -> None:
    out = git_init(str(tmp_path))
    assert (tmp_path / ".git").exists()
    assert "Initialized" in out or "Reinitialized" in out


def test_init_refuses_existing_repo(repo: Path) -> None:
    out = git_init(str(repo))
    assert "already a git repository" in out


def test_init_refuses_protected_path(tmp_path: Path, monkeypatch) -> None:
    """Even if the user grants permission, the seatbelt prevents an LLM
    from `git init C:\\Windows`."""
    from navi.tools import filesystem
    monkeypatch.setattr(filesystem, "_is_protected_path", lambda p: True)
    out = git_init(str(tmp_path))
    assert "protected" in out
    assert not (tmp_path / ".git").exists()


def test_init_rejects_relative_path() -> None:
    assert "must be absolute" in git_init("relative/dir")


def test_init_rejects_missing_path(tmp_path: Path) -> None:
    assert "does not exist" in git_init(str(tmp_path / "ghost"))


# ----- git_branch_create ---------------------------------------------------


def test_branch_create_default_checks_out(repo: Path) -> None:
    git_branch_create(str(repo), "feat/foo")
    out = git_status(str(repo))
    assert "## feat/foo" in out


def test_branch_create_no_checkout(repo: Path) -> None:
    git_branch_create(str(repo), "feat/bar", checkout=False)
    out = git_branch_list(str(repo))
    assert "feat/bar" in out
    # Still on main.
    assert git_status(str(repo)).startswith("## main")


def test_branch_create_refuses_duplicate(repo: Path) -> None:
    git_branch_create(str(repo), "feat/x")
    out = git_branch_create(str(repo), "feat/x")
    assert "already exists" in out


def test_branch_create_rejects_empty_name(repo: Path) -> None:
    assert "branch name is required" in git_branch_create(str(repo), "")


# ----- git_checkout (the critical safety test) -----------------------------


def test_checkout_clean_tree_succeeds(repo: Path) -> None:
    git_branch_create(str(repo), "side", checkout=False)
    git_checkout(str(repo), "side")
    assert git_status(str(repo)).startswith("## side")


def test_checkout_dirty_tree_refuses_without_force(repo: Path) -> None:
    """Without this guard, git_checkout silently abandons uncommitted
    edits. This is THE safety test for git_checkout."""
    git_branch_create(str(repo), "side", checkout=False)
    (repo / "README.md").write_text("uncommitted change\n")
    out = git_checkout(str(repo), "side")
    assert "uncommitted changes" in out
    # Still on main; the change is still there.
    assert git_status(str(repo)).startswith("## main")
    assert (repo / "README.md").read_text() == "uncommitted change\n"


def test_checkout_dirty_tree_force_discards(repo: Path) -> None:
    git_branch_create(str(repo), "side", checkout=False)
    (repo / "README.md").write_text("doomed\n")
    git_checkout(str(repo), "side", force=True)
    # On the new branch and the change was discarded.
    assert git_status(str(repo)).startswith("## side")
    assert (repo / "README.md").read_text() == "seed\n"


def test_checkout_rejects_empty_branch(repo: Path) -> None:
    assert "branch is required" in git_checkout(str(repo), "")


# ----- git_add + git_commit -----------------------------------------------


def test_add_then_commit_full_cycle(repo: Path) -> None:
    (repo / "notes.txt").write_text("hello\n")
    add_out = git_add(str(repo), ["notes.txt"])
    assert "Staged" in add_out or add_out.strip() == "(no output)" or "notes.txt" in add_out

    commit_out = git_commit(str(repo), "Add notes.txt")
    assert "Add notes.txt" in commit_out or "main" in commit_out

    log_out = git_log(str(repo), max_count=1)
    assert "Add notes.txt" in log_out


def test_add_dot_stages_everything(repo: Path) -> None:
    (repo / "a.txt").write_text("a")
    (repo / "b.txt").write_text("b")
    git_add(str(repo), ["."])
    out = git_status(str(repo))
    assert "A  a.txt" in out
    assert "A  b.txt" in out


def test_add_rejects_empty_paths(repo: Path) -> None:
    assert "paths is required" in git_add(str(repo), [])
    assert "non-empty" in git_add(str(repo), ["", " "])


def test_commit_rejects_nothing_staged(repo: Path) -> None:
    out = git_commit(str(repo), "nothing here")
    assert "nothing staged" in out


def test_commit_rejects_empty_message(repo: Path) -> None:
    (repo / "x.txt").write_text("x")
    git_add(str(repo), ["x.txt"])
    assert "message is required" in git_commit(str(repo), "")


# ----- shared validation ---------------------------------------------------


def test_status_rejects_relative_path() -> None:
    assert "must be absolute" in git_status("relative/path")


def test_status_rejects_non_repo(tmp_path: Path) -> None:
    out = git_status(str(tmp_path))
    assert "not a git repository" in out


def test_diff_rejects_non_repo(tmp_path: Path) -> None:
    assert "not a git repository" in git_diff(str(tmp_path))


# ----- git missing ---------------------------------------------------------


def test_git_missing_returns_install_help(repo: Path, monkeypatch) -> None:
    """Patch subprocess.Popen to raise FileNotFoundError just for the
    git command. Must surface the friendly install message."""
    import navi.tools.git_ops as g

    real_popen = subprocess.Popen

    def fake_popen(cmd, *args, **kwargs):
        if cmd and cmd[0] == "git":
            raise FileNotFoundError(2, "no git")
        return real_popen(cmd, *args, **kwargs)

    monkeypatch.setattr(g.subprocess, "Popen", fake_popen)
    out = git_status(str(repo))
    assert "not found on PATH" in out
    assert "https://git-scm.com" in out


# ----- scaffold auto-init integration -------------------------------------


def test_scaffold_project_auto_inits_git(tmp_path: Path, monkeypatch) -> None:
    """End-to-end: scaffold + git_init_on_scaffold=True (the default)
    should produce a repo with one commit."""
    # Make sure git author config is available (the auto-init commit
    # would otherwise fail on a fresh CI machine).
    monkeypatch.setenv("GIT_AUTHOR_NAME", "Navi Tests")
    monkeypatch.setenv("GIT_AUTHOR_EMAIL", "test@navi.local")
    monkeypatch.setenv("GIT_COMMITTER_NAME", "Navi Tests")
    monkeypatch.setenv("GIT_COMMITTER_EMAIL", "test@navi.local")

    from navi.tools.scaffold import scaffold_project
    out = scaffold_project(
        stack_id="python-cli",
        project_name="autogit",
        dest_path=str(tmp_path),
    )
    project = tmp_path / "autogit"
    assert (project / ".git").exists(), out
    assert "git: initialized" in out
    log = git_log(str(project), max_count=5)
    assert "Initial scaffold (python-cli)" in log


def test_scaffold_project_skips_git_when_disabled(tmp_path: Path,
                                                  isolated_navi_dirs: Path) -> None:
    """With git_init_on_scaffold=False in settings, no .git/ should
    appear after scaffolding."""
    from navi.settings.store import load, save
    s = load()
    s.setdefault("scaffold", {})["git_init_on_scaffold"] = False
    save(s)

    from navi.tools.scaffold import scaffold_project
    scaffold_project(
        stack_id="python-cli",
        project_name="nogit",
        dest_path=str(tmp_path),
    )
    assert not (tmp_path / "nogit" / ".git").exists()
