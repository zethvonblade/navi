"""Tests for the ModelAdapter registry + filename detection."""

from __future__ import annotations

from pathlib import Path

import pytest

from navi.brain.adapters import (
    ADAPTERS,
    ModelAdapter,
    adapter_by_id,
    default_adapter,
    detect_adapter,
    migrate_legacy_variant,
)


# ----- registry sanity -----------------------------------------------------


def test_adapters_registry_non_empty() -> None:
    assert len(ADAPTERS) >= 5  # at minimum: granite_3, phi, llama, qwen, default


def test_every_adapter_has_required_fields() -> None:
    for a in ADAPTERS:
        assert isinstance(a, ModelAdapter)
        assert a.id and isinstance(a.id, str)
        assert a.description and isinstance(a.description, str)
        assert a.system_prompt and isinstance(a.system_prompt, str)
        assert isinstance(a.notes, str)
        assert isinstance(a.filename_keywords, tuple)


def test_adapter_ids_unique() -> None:
    ids = [a.id for a in ADAPTERS]
    assert len(ids) == len(set(ids)), f"duplicate adapter ids: {ids}"


def test_default_adapter_is_present_and_has_no_keywords() -> None:
    default = default_adapter()
    assert default.id == "default"
    assert default.filename_keywords == ()


def test_adapter_by_id_returns_match() -> None:
    a = adapter_by_id("phi")
    assert a is not None and a.id == "phi"


def test_adapter_by_id_returns_none_for_unknown() -> None:
    assert adapter_by_id("not-a-real-id") is None


# ----- filename detection -------------------------------------------------


@pytest.mark.parametrize("filename, expected_id", [
    # Granite
    ("granite-3.1-2b-instruct-Q4_K_M.gguf", "granite_3"),
    ("granite-3.3-8b-instruct.gguf", "granite_3"),
    ("granite-4.0-micro-Q4.gguf", "granite_4"),
    # Phi
    ("Phi-4-mini-instruct-Q4_K_M.gguf", "phi"),
    ("microsoft_Phi-4-mini-instruct-GGUF.gguf", "phi"),
    ("phi-3-mini-4k-instruct.gguf", "phi"),
    # Llama
    ("Llama-3.1-8B-Instruct-Q4_K_M.gguf", "llama_3_json"),
    ("Llama-3.2-3B-Instruct.gguf", "llama_3_json"),
    ("Llama-3.3-70B-Instruct.gguf", "llama_3_pythonic"),
    # Qwen
    ("Qwen2.5-7B-Instruct.gguf", "qwen_hermes"),
    ("Qwen3-8B.gguf", "qwen_hermes"),
    ("qwq-32b.gguf", "qwen_hermes"),
    # Mistral
    ("Mistral-7B-Instruct-v0.3.gguf", "mistral"),
    ("Mixtral-8x7B-Instruct.gguf", "mistral"),
    ("Mistral-Nemo-Instruct-2407.gguf", "mistral"),
    # Gemma
    ("gemma-3-12b-it-Q4_K_M.gguf", "gemma_3"),
    ("gemma-2-2b-it.gguf", "gemma_3"),
    # TinyLlama gets its own dedicated adapter (Zephyr template + tiny
    # capacity → needs an aggressively-short prompt). Must NOT match
    # llama_3_json by accident.
    ("tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf", "tinyllama"),
    ("Tiny-Llama-1.1b.gguf", "tinyllama"),
    # Unknown
    ("some-random-fancy-model.gguf", "default"),
])
def test_detect_adapter_filenames(filename: str, expected_id: str) -> None:
    assert detect_adapter(Path("models") / filename).id == expected_id


def test_detect_granite_4_takes_precedence_over_granite_3() -> None:
    """Specificity ordering: granite-4 file should NOT match granite_3."""
    a = detect_adapter(Path("models/granite-4.0-micro.gguf"))
    assert a.id == "granite_4"


def test_detect_llama_pythonic_takes_precedence_over_json() -> None:
    """Llama 3.3 must route to pythonic, not the broader llama_3_json."""
    a = detect_adapter(Path("models/Llama-3.3-70B-Instruct.gguf"))
    assert a.id == "llama_3_pythonic"


# ----- legacy migration ---------------------------------------------------


@pytest.mark.parametrize("legacy, new_id", [
    ("granite", "granite_3"),
    ("phi", "phi"),
    ("minimal_native", "default"),
    ("explicit_format", "default"),
    ("oneshot_example", "default"),
    ("bracket_only", "mistral"),
])
def test_migrate_legacy_variant(legacy: str, new_id: str) -> None:
    assert migrate_legacy_variant(legacy) == new_id


def test_migrate_legacy_variant_none_returns_none() -> None:
    assert migrate_legacy_variant(None) is None


def test_migrate_legacy_variant_unknown_returns_none() -> None:
    assert migrate_legacy_variant("never-existed") is None


# ----- system prompt format checks (per-family training assumptions) -----


def test_phi_adapter_uses_plural_markers() -> None:
    """Phi was trained with PLURAL paired markers per Microsoft's docs."""
    p = adapter_by_id("phi")
    assert p is not None
    assert "<|tool_calls|>" in p.system_prompt
    assert "<|/tool_calls|>" in p.system_prompt


def test_granite_3_adapter_uses_singular_marker() -> None:
    g = adapter_by_id("granite_3")
    assert g is not None
    assert "<|tool_call|>" in g.system_prompt


def test_granite_4_adapter_uses_xml_tags() -> None:
    g = adapter_by_id("granite_4")
    assert g is not None
    assert "<tool_call>" in g.system_prompt
    assert "</tool_call>" in g.system_prompt


def test_llama_json_adapter_uses_parameters_key() -> None:
    """Llama JSON format uses 'parameters' not 'arguments' per Meta docs."""
    a = adapter_by_id("llama_3_json")
    assert a is not None
    assert "parameters" in a.system_prompt.lower()


def test_llama_pythonic_adapter_describes_call_syntax() -> None:
    a = adapter_by_id("llama_3_pythonic")
    assert a is not None
    assert "tool_name(" in a.system_prompt or "func" in a.system_prompt.lower()


def test_qwen_adapter_uses_xml_tool_call() -> None:
    a = adapter_by_id("qwen_hermes")
    assert a is not None
    assert "<tool_call>" in a.system_prompt


def test_gemma_adapter_uses_tool_code_block() -> None:
    a = adapter_by_id("gemma_3")
    assert a is not None
    assert "tool_code" in a.system_prompt


def test_tinyllama_adapter_uses_bare_json_format() -> None:
    """TinyLlama has ~12.7% baseline tool-call accuracy (Berkeley TinyAgent
    paper). Adapter must use the simplest possible format — bare JSON
    object that our `bare_json_object` parser handles — and a SHORT prompt
    (TinyLlama can't follow long instructions)."""
    a = adapter_by_id("tinyllama")
    assert a is not None
    assert a.preferred_parser_id == "bare_json_object"
    assert '"name"' in a.system_prompt
    # Aggressively short — the whole point of this adapter
    assert len(a.system_prompt) < 300, (
        f"TinyLlama prompt is {len(a.system_prompt)} chars — too long. "
        "Tiny model can't follow long instructions."
    )
    # Should NOT use the heavy markers other families use
    assert "<|tool_calls|>" not in a.system_prompt
    assert "<tool_call>" not in a.system_prompt
