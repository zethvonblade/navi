"""Tests for add_python_import.

Critical assertion: comments and formatting in untouched regions must
be byte-identical after the splice (Plan-agent fix #2 — guards against
``ast.unparse`` regressing into the codebase).
"""

from __future__ import annotations

import ast
from pathlib import Path

import pytest

from navi.tools import get_tool
from navi.tools.code_edit import add_python_import


# ----- registration --------------------------------------------------------


def test_add_python_import_registered_high() -> None:
    t = get_tool("add_python_import")
    assert t is not None
    assert t.risk == "high", "writes executable code; must gate on permission"


# ----- happy path ----------------------------------------------------------


def test_adds_plain_import_to_empty_file(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("")
    out = add_python_import(str(f), "os")
    assert "Added" in out
    assert "import os" in f.read_text()


def test_adds_from_import(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("")
    out = add_python_import(str(f), "pathlib", names="Path")
    assert "from pathlib import Path" in f.read_text()


def test_adds_after_existing_imports(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("import sys\nimport os\n\ndef main():\n    pass\n")
    add_python_import(str(f), "json")
    text = f.read_text()
    # New import lands after the LAST existing import, before the def.
    json_idx = text.index("import json")
    def_idx = text.index("def main")
    assert json_idx < def_idx
    assert text.index("import os") < json_idx


def test_adds_after_module_docstring_when_no_imports(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text('"""Module docstring."""\n\ndef main():\n    pass\n')
    add_python_import(str(f), "os")
    text = f.read_text()
    # Import must come after the docstring, before the def.
    assert text.index('"""') < text.index("import os") < text.index("def main")


# ----- idempotency ---------------------------------------------------------


def test_idempotent_plain_import(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("import os\n")
    out = add_python_import(str(f), "os")
    assert "no-op" in out
    # File unchanged.
    assert f.read_text() == "import os\n"


def test_idempotent_from_import(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("from pathlib import Path, PurePath\n")
    out = add_python_import(str(f), "pathlib", names="Path")
    assert "no-op" in out


def test_extends_from_import_with_new_name(tmp_path: Path) -> None:
    """If `Path` is already imported but we add `Path, PurePath`, only
    PurePath is missing — current impl emits a NEW from-line. That's
    valid but not collapsed; document the behavior so it's intentional."""
    f = tmp_path / "x.py"
    f.write_text("from pathlib import Path\n")
    add_python_import(str(f), "pathlib", names="Path, PurePath")
    text = f.read_text()
    # PurePath must be importable from somewhere.
    parsed = ast.parse(text)
    imports = [n for n in parsed.body if isinstance(n, ast.ImportFrom)]
    all_names = {a.name for n in imports for a in n.names}
    assert "PurePath" in all_names


# ----- the critical safety test (Plan-agent fix #2) ----------------------


def test_preserves_comments_and_formatting(tmp_path: Path) -> None:
    """If we ever regress to ast.unparse, this fails immediately. The
    only line that may differ from the original is the inserted import;
    everything else must be byte-identical."""
    original = (
        '"""Module docstring."""\n'
        "\n"
        "# A leading comment about the import.\n"
        "import sys\n"
        "\n"
        "# A comment between blocks.\n"
        "MY_CONSTANT = 'literal'  # inline comment\n"
        "\n"
        "\n"
        "def existing(   ):  # weird whitespace preserved\n"
        "    return 'unchanged'\n"
    )
    f = tmp_path / "x.py"
    f.write_text(original)
    add_python_import(str(f), "os")
    new_text = f.read_text()
    # All original lines must still appear, in order, byte-identical.
    for line in original.splitlines():
        assert line in new_text, (
            f"Line lost or mutated by add_python_import: {line!r} — "
            "this looks like an ast.unparse regression."
        )
    # And the new import is present.
    assert "import os" in new_text


# ----- validation / error cases -------------------------------------------


def test_rejects_relative_path() -> None:
    out = add_python_import("relative/x.py", "os")
    assert "must be absolute" in out


def test_rejects_missing_file(tmp_path: Path) -> None:
    out = add_python_import(str(tmp_path / "ghost.py"), "os")
    assert "does not exist" in out


def test_rejects_non_py_extension(tmp_path: Path) -> None:
    f = tmp_path / "x.txt"
    f.write_text("")
    out = add_python_import(str(f), "os")
    assert "not a Python file" in out


def test_rejects_target_with_syntax_error(tmp_path: Path) -> None:
    f = tmp_path / "broken.py"
    original = "def x("
    f.write_text(original)
    out = add_python_import(str(f), "os")
    assert "not valid Python" in out
    assert f.read_text() == original  # untouched


def test_rejects_empty_module(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("")
    out = add_python_import(str(f), "")
    assert "module is required" in out
