from __future__ import annotations

import json
from pathlib import Path

import pytest

from navi.perms import engine as perms_engine
from navi.settings import store


@pytest.fixture
def tmp_settings(tmp_path: Path, monkeypatch) -> Path:  # type: ignore[no-untyped-def]
    target = tmp_path / "settings.json"
    # Patch BOTH names — store.py imports settings_path directly, so the
    # name in store's namespace is independent from perms.engine's.
    monkeypatch.setattr(perms_engine, "settings_path", lambda: target)
    monkeypatch.setattr(store, "settings_path", lambda: target)
    return target


def test_bootstraps_when_missing(tmp_settings: Path) -> None:
    s = store.load()
    assert tmp_settings.exists()
    assert s["defaultMode"] == "default"
    assert "permissions" in s
    assert s["ui"]["orbSize"] == 240
    assert s["ui"]["personaPrompt"] is None
    assert s["model"]["path"] is None


def test_deep_merge_preserves_user_overrides(tmp_settings: Path) -> None:
    tmp_settings.parent.mkdir(parents=True, exist_ok=True)
    tmp_settings.write_text(
        json.dumps(
            {
                "defaultMode": "plan",
                "ui": {"orbSize": 320},
                # Note: missing personaPrompt and model section
            }
        ),
        encoding="utf-8",
    )
    s = store.load()
    # User overrides win
    assert s["defaultMode"] == "plan"
    assert s["ui"]["orbSize"] == 320
    # Defaults fill in the gaps
    assert s["ui"]["personaPrompt"] is None
    assert s["model"]["path"] is None
    assert "permissions" in s


def test_save_round_trip(tmp_settings: Path) -> None:
    s = store.load()
    s["ui"]["orbSize"] = 280
    s["ui"]["personaPrompt"] = "You are a custom Navi."
    store.save(s)

    reloaded = store.load()
    assert reloaded["ui"]["orbSize"] == 280
    assert reloaded["ui"]["personaPrompt"] == "You are a custom Navi."


def test_corrupted_file_falls_back_to_defaults(tmp_settings: Path) -> None:
    tmp_settings.parent.mkdir(parents=True, exist_ok=True)
    tmp_settings.write_text("{ not valid json", encoding="utf-8")
    s = store.load()
    assert s["defaultMode"] == "default"
    assert s["ui"]["orbSize"] == 240


def test_deep_merge_helper() -> None:
    base = {"a": 1, "b": {"c": 2, "d": 3}}
    over = {"b": {"c": 99}, "e": 5}
    merged = store.deep_merge(base, over)
    assert merged == {"a": 1, "b": {"c": 99, "d": 3}, "e": 5}
    # base unchanged
    assert base == {"a": 1, "b": {"c": 2, "d": 3}}


def test_persona_override_in_system_prompt(tmp_settings: Path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    """build_system_prompt() honors a persona override from settings."""
    # Isolate the memory store too — build_system_prompt reads it as well.
    from navi.memory import store as memory_store

    monkeypatch.setattr(memory_store, "memory_dir", lambda: tmp_settings.parent / "_mem")

    s = store.load()
    s["ui"]["personaPrompt"] = "You are a pirate Navi. Arr."
    store.save(s)

    from navi.brain.persona import build_system_prompt
    out = build_system_prompt()
    assert "pirate Navi" in out
