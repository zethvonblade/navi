from __future__ import annotations

import pytest

from navi.pet.skins import REGISTRY, available_skins, get_skin
from navi.pet.skins._base import Skin


def test_all_skins_registered() -> None:
    names = set(REGISTRY.keys())
    # Built-ins must always be present. User-folder skins (loaded from
    # %APPDATA%/Navi/skins/) may add more — that's fine.
    assert {"classic", "jarvis", "cortana", "tactical", "plasma"}.issubset(names)


def test_get_skin_returns_instance() -> None:
    s = get_skin("jarvis")
    assert isinstance(s, Skin)
    assert s.name == "jarvis"


def test_get_skin_falls_back_to_default() -> None:
    s = get_skin("does-not-exist")
    assert s.name == "classic"


def test_available_skins_returns_name_description_pairs() -> None:
    for name, desc in available_skins():
        assert isinstance(name, str) and name
        assert isinstance(desc, str) and desc


def test_skin_field_in_settings_defaults() -> None:
    from navi.settings.store import full_defaults
    s = full_defaults()
    assert s["ui"]["skin"] == "classic"
