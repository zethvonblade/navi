"""Tests for the run_python tool.

Real subprocess invocations against tmp_path — no mocking. The tool
mirrors run_powershell's pattern (timeout + tree-kill + output cap).
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

from navi.tools import get_tool
from navi.tools.runtime import _resolve_interpreter, run_python


# ----- registration --------------------------------------------------------


def test_registered_high_risk() -> None:
    t = get_tool("run_python")
    assert t is not None
    assert t.risk == "high", "writes & runs arbitrary code; must gate on permission"


# ----- interpreter resolution --------------------------------------------


def test_resolve_falls_back_to_sys_executable_without_venv(tmp_path: Path) -> None:
    """No venv in cwd → use Navi's own python."""
    assert _resolve_interpreter(tmp_path) == sys.executable


def test_resolve_picks_dot_venv_when_present(tmp_path: Path) -> None:
    """If <cwd>/.venv exists, use its python — common project convention."""
    venv = tmp_path / ".venv" / ("Scripts" if sys.platform == "win32" else "bin")
    venv.mkdir(parents=True)
    fake_python = venv / ("python.exe" if sys.platform == "win32" else "python")
    fake_python.write_text("")  # existence is what's checked
    assert _resolve_interpreter(tmp_path) == str(fake_python)


# ----- happy path ---------------------------------------------------------


def test_run_python_basic_print(tmp_path: Path) -> None:
    out = run_python("print('hello from run_python')", str(tmp_path))
    assert "hello from run_python" in out
    assert "interpreter" in out  # interpreter note is appended


def test_run_python_arithmetic(tmp_path: Path) -> None:
    out = run_python("print(2 + 2)", str(tmp_path))
    assert "4" in out


def test_run_python_uses_cwd(tmp_path: Path) -> None:
    """Verify the interpreter actually starts in the requested cwd."""
    out = run_python("import os; print(os.getcwd())", str(tmp_path))
    # On Windows tmp paths can have case differences; normalize.
    assert str(tmp_path).lower() in out.lower()


# ----- error cases --------------------------------------------------------


def test_run_python_nonzero_exit_surfaces_stderr(tmp_path: Path) -> None:
    out = run_python("raise ValueError('boom')", str(tmp_path))
    assert "Exit 1" in out
    assert "ValueError" in out
    assert "boom" in out


def test_run_python_rejects_relative_cwd() -> None:
    out = run_python("print(1)", "relative/path")
    assert "must be absolute" in out


def test_run_python_rejects_missing_cwd(tmp_path: Path) -> None:
    out = run_python("print(1)", str(tmp_path / "ghost"))
    assert "does not exist" in out


def test_run_python_rejects_empty_code(tmp_path: Path) -> None:
    out = run_python("", str(tmp_path))
    assert "must not be empty" in out


def test_run_python_rejects_protected_cwd(tmp_path: Path, monkeypatch) -> None:
    """Defense-in-depth — even with the user's permission, refuse to
    set cwd to a system path."""
    from navi.tools import filesystem
    monkeypatch.setattr(filesystem, "_is_protected_path", lambda p: True)
    out = run_python("print(1)", str(tmp_path))
    assert "protected system path" in out


# ----- timeout ------------------------------------------------------------


def test_run_python_timeout(tmp_path: Path) -> None:
    """Sleep longer than the timeout; must return a clean timeout error
    and tree-kill the process group (don't hang)."""
    out = run_python("import time; time.sleep(10)", str(tmp_path), timeout_s=2)
    assert "timed out" in out
