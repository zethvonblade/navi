from __future__ import annotations

from pathlib import Path

import pytest

from navi.memory import store


@pytest.fixture
def tmp_memory_dir(tmp_path: Path, monkeypatch) -> Path:  # type: ignore[no-untyped-def]
    monkeypatch.setattr(store, "memory_dir", lambda: tmp_path)
    return tmp_path


def test_slugify_basic() -> None:
    assert store.slugify("Dark mode preference") == "dark_mode_preference"
    assert store.slugify("I prefer DARK mode!") == "i_prefer_dark_mode"
    assert store.slugify("") == "untitled"
    assert store.slugify("   ") == "untitled"


def test_slugify_truncates_long() -> None:
    out = store.slugify("a" * 100)
    assert len(out) <= 60


def test_save_creates_file_and_index(tmp_memory_dir: Path) -> None:
    p = store.save_memory(
        title="Dark mode preference",
        description="prefers dark mode in all apps",
        type="user",
        content="The user prefers dark mode for every application.",
    )
    assert p.exists()
    assert p.name == "user_dark_mode_preference.md"

    text = p.read_text(encoding="utf-8")
    assert "name: Dark mode preference" in text
    assert "type: user" in text
    assert "prefers dark mode" in text

    idx = (tmp_memory_dir / "MEMORY.md").read_text(encoding="utf-8")
    assert "Dark mode preference" in idx
    assert p.name in idx


def test_save_replaces_existing_index_entry(tmp_memory_dir: Path) -> None:
    store.save_memory(title="X", description="first", type="user", content="A")
    store.save_memory(title="X", description="second", type="user", content="B")

    idx = (tmp_memory_dir / "MEMORY.md").read_text(encoding="utf-8")
    # Only one line for this file should be present
    matches = [ln for ln in idx.splitlines() if "user_x.md" in ln]
    assert len(matches) == 1
    assert "second" in matches[0]


def test_invalid_type_rejected(tmp_memory_dir: Path) -> None:
    with pytest.raises(ValueError):
        store.save_memory(title="X", description="x", type="garbage", content="x")


def test_search_finds_relevant(tmp_memory_dir: Path) -> None:
    store.save_memory(
        title="Coffee preference",
        description="black, no sugar",
        type="user",
        content="The user drinks coffee black with no sugar.",
    )
    store.save_memory(
        title="Lunch routine",
        description="usually salads",
        type="user",
        content="The user typically has salad for lunch.",
    )
    hits = store.search("what coffee do I drink")
    assert hits, "Expected at least one hit"
    top_score, top_mem = hits[0]
    assert top_mem.name == "Coffee preference"


def test_search_returns_empty_when_no_overlap(tmp_memory_dir: Path) -> None:
    store.save_memory(
        title="Coffee", description="drinks black coffee", type="user", content="black."
    )
    assert store.search("favorite color of car") == []


def test_load_index_returns_none_when_missing(tmp_memory_dir: Path) -> None:
    assert store.load_index() is None


def test_load_index_after_save(tmp_memory_dir: Path) -> None:
    store.save_memory(title="X", description="hook", type="user", content="body")
    idx = store.load_index()
    assert idx is not None
    assert "X" in idx
    assert "hook" in idx
