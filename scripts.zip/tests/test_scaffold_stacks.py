"""Tests for the scaffold stack registry shape + tool registration."""

from __future__ import annotations

import pytest

from navi.scaffold.stacks import (
    DEFAULT_STACK_ID,
    STACKS,
    StackSpec,
    get_spec,
    list_stacks,
)
from navi.tools import all_tools, get_tool


# ----- registry shape ------------------------------------------------------


def test_stacks_registered() -> None:
    assert "python-cli" in STACKS
    assert "python-pytest-lib" in STACKS


@pytest.mark.parametrize("stack_id,spec", list(STACKS.items()))
def test_every_spec_has_required_fields(stack_id: str, spec: StackSpec) -> None:
    """If any of these go missing the renderer or persona injection
    breaks. Keep the contract enforced."""
    assert spec.id == stack_id, f"{stack_id}: id field mismatch"
    assert spec.label, f"{stack_id}: label is required"
    assert spec.language == "python", (
        f"{stack_id}: only python stacks ship in v1; if you add another "
        "language update test_persona_stack_context to cover injection."
    )
    assert spec.description, f"{stack_id}: description is required"
    assert spec.template_dir.is_dir(), (
        f"{stack_id}: template_dir {spec.template_dir} does not exist on disk. "
        "Did you forget to bundle the templates/ tree?"
    )
    assert spec.style_guide and len(spec.style_guide) > 50, (
        f"{stack_id}: style_guide should be a substantive sentence — "
        "it's injected into the system prompt."
    )
    if spec.lint_cmd:
        assert spec.lint_cmd[0] == "ruff", (
            f"{stack_id}: only ruff is wired for lint in v1"
        )


def test_default_stack_id_is_none() -> None:
    """Per design, no default stack — user picks explicitly via /stack use
    or /new dialog."""
    assert DEFAULT_STACK_ID is None


def test_get_spec_returns_none_on_unknown() -> None:
    assert get_spec("not-a-real-stack") is None
    assert get_spec(None) is None
    assert get_spec("") is None


def test_get_spec_returns_named_spec() -> None:
    for sid, spec in STACKS.items():
        assert get_spec(sid) is spec


def test_list_stacks_stable_order() -> None:
    pairs = list_stacks()
    assert {sid for sid, _ in pairs} == set(STACKS.keys())


# ----- tool registration ---------------------------------------------------


@pytest.mark.parametrize("name,risk", [
    ("list_stacks", "safe"),
    ("scaffold_project", "high"),
    ("lint_python", "safe"),
    ("format_python", "medium"),
])
def test_scaffold_tools_registered(name: str, risk: str) -> None:
    assert name in {t.name for t in all_tools()}
    t = get_tool(name)
    assert t is not None
    assert t.risk == risk, (
        f"{name}: risk should be {risk!r} per the plan; got {t.risk!r}"
    )
