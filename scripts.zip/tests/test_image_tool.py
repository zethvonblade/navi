"""Tests for the image-generation tool + first-run install path.

We don't have ``diffusers`` installed in the test environment (and don't
want to download a 12 GB model just to test), so these tests focus on:

* Tool registration shape
* Argument validation (prompt required, paths absolute)
* The friendly install-help message when the model isn't present
* Default output path resolution
* Tool risk classification
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from navi.image import client as image_client
from navi.image.client import ImageClient, ImageError
from navi.tools import all_tools, get_tool
from navi.tools.image_gen import _default_output_path, generate_image


# ----- registration --------------------------------------------------------


def test_generate_image_tool_registered() -> None:
    names = {t.name for t in all_tools()}
    assert "generate_image" in names


def test_generate_image_is_medium_risk() -> None:
    """Image gen returns a file path the user might not want — gate it
    behind a permission ask, not silent allow."""
    t = get_tool("generate_image")
    assert t is not None
    assert t.risk == "medium"


def test_generate_image_schema_required_prompt() -> None:
    t = get_tool("generate_image")
    assert t is not None
    assert "prompt" in t.parameters["properties"]
    assert "prompt" in t.parameters["required"]


def test_generate_image_schema_optional_path() -> None:
    t = get_tool("generate_image")
    assert t is not None
    assert "output_path" in t.parameters["properties"]
    assert "output_path" not in t.parameters["required"]


# ----- argument validation -------------------------------------------------


def test_empty_prompt_is_rejected() -> None:
    out = generate_image(prompt="")
    assert "prompt is required" in out.lower()


def test_whitespace_only_prompt_is_rejected() -> None:
    out = generate_image(prompt="   \n\t  ")
    assert "prompt is required" in out.lower()


def test_relative_output_path_is_rejected() -> None:
    out = generate_image(prompt="a cat", output_path="relative/path.png")
    assert "must be absolute" in out


# ----- default output path -------------------------------------------------


def test_default_output_path_is_under_appdata() -> None:
    p = _default_output_path()
    assert p.is_absolute()
    assert p.suffix == ".png"
    # parent dir should be created on demand
    assert p.parent.exists()


def test_default_output_path_uses_navi_generated_subdir() -> None:
    p = _default_output_path()
    parts = p.parts
    assert "Navi" in parts
    assert "generated" in parts


# ----- first-run install help ---------------------------------------------


def test_diffusers_missing_returns_install_help(monkeypatch, tmp_path) -> None:
    """When the image client raises diffusers_missing, the tool should
    surface a friendly install message — not the raw stack trace."""

    class _FakeClient:
        def generate(self, **kwargs):
            raise ImageError(
                "diffusers_missing",
                "test: diffusers not installed",
            )

    monkeypatch.setattr(image_client, "get_image_client",
                        lambda: _FakeClient())
    out_path = tmp_path / "out.png"
    out = generate_image(prompt="a sunset over mountains",
                         output_path=str(out_path.resolve()))
    assert "Image generation isn't set up yet" in out
    assert "pip install diffusers" in out
    # Help text is built from the model registry — should mention the
    # default model id at minimum.
    assert "flux-schnell" in out


def test_model_not_found_returns_install_help(monkeypatch, tmp_path) -> None:
    class _FakeClient:
        def generate(self, **kwargs):
            raise ImageError(
                "model_not_found",
                "test: model dir doesn't exist",
            )

    monkeypatch.setattr(image_client, "get_image_client",
                        lambda: _FakeClient())
    out = generate_image(prompt="a cat",
                         output_path=str((tmp_path / "x.png").resolve()))
    assert "Image generation isn't set up yet" in out
    assert "install_image_model.py" in out


def test_other_image_error_surfaces_kind(monkeypatch, tmp_path) -> None:
    """A non-install error (e.g. CUDA OOM) should NOT show install help —
    that would be misleading. Show the actual failure."""

    class _FakeClient:
        def generate(self, **kwargs):
            raise ImageError("generate_failed", "CUDA out of memory")

    monkeypatch.setattr(image_client, "get_image_client",
                        lambda: _FakeClient())
    out = generate_image(prompt="a cat",
                         output_path=str((tmp_path / "x.png").resolve()))
    assert "Image generation isn't set up yet" not in out
    assert "generate_failed" in out
    assert "CUDA out of memory" in out


# ----- ImageError shape ----------------------------------------------------


def test_image_error_has_kind_and_message() -> None:
    err = ImageError("model_not_found", "where is it?")
    assert err.kind == "model_not_found"
    assert err.message == "where is it?"
    assert "where is it?" in str(err)
