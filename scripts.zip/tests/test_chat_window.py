"""Regression tests for ChatWindow streaming + tool-result rendering.

The bug being guarded against: ``assistant_finished()`` selects from
``_stream_start_position`` to End and ``removeSelectedText()``,
replacing the selection with a markdown-rendered version of the stream
buffer. If a tool result (e.g. an image) was inserted into the chat
between ``assistant_started()`` and ``assistant_finished()``, it landed
inside that selection and got wiped — image showed for "a few seconds"
during the agent loop, then vanished when the post-tool reply finished.

These tests simulate the exact signal sequence the brain emits during
an image-generation turn and assert the image survives.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from navi.pet import chat_window as chat_window_mod
from navi.pet.chat_window import ChatWindow


@pytest.fixture
def chat(qapp, tmp_path: Path, monkeypatch) -> ChatWindow:
    """Build a ChatWindow with an isolated history file so the test
    doesn't read or scribble on the user's real chat_history.html."""
    monkeypatch.setattr(
        chat_window_mod, "_chat_history_path",
        lambda: tmp_path / "chat_history.html",
    )
    w = ChatWindow()
    return w


# ----- the actual bug -----------------------------------------------------


def test_image_survives_post_tool_streaming(chat: ChatWindow) -> None:
    """Reproduce the image-disappears bug.

    Sequence: user submit → assistant_started → tool call (image gen)
    → tool result (image) → post-tool text streams → assistant_finished.

    Before the fix, assistant_finished's selection-and-delete wiped
    every <img> tag inserted by show_tool_result. This test fails on
    the old code and passes on the fix.
    """
    chat.append_user("draw me a cat")
    chat.assistant_started()
    chat.show_tool_call("generate_image", {"prompt": "a cat"}, "user-allowed")
    chat.show_tool_result(
        "generate_image",
        "Image generated: file:///C:/Users/test/navi_20260504-141500.png",
    )
    # Then the model's textual reply streams in token-by-token.
    chat.append_token("Here's ")
    chat.append_token("your ")
    chat.append_token("cat!")
    chat.assistant_finished()

    html = chat._history.toHtml()
    assert "navi_20260504-141500.png" in html, (
        "Image was wiped by assistant_finished's selection-and-delete — "
        "the bug we're fixing has regressed."
    )
    # Post-tool reply should also be rendered (markdown HTML, plain text fine).
    assert "Here's your cat!" in html


def test_tool_call_indicator_survives_post_tool_streaming(chat: ChatWindow) -> None:
    """Same root cause: the '⚙ generate_image …' indicator was also
    inside the wiped range. Verify it now survives too."""
    chat.append_user("draw me a cat")
    chat.assistant_started()
    chat.show_tool_call("generate_image", {"prompt": "a cat"}, "user-allowed")
    chat.show_tool_result(
        "generate_image",
        "Image generated: file:///C:/test.png",
    )
    chat.append_token("done")
    chat.assistant_finished()

    html = chat._history.toHtml()
    assert "generate_image" in html
    assert "⚙" in html


def test_pre_tool_streamed_text_is_preserved(chat: ChatWindow) -> None:
    """If the model streams text BEFORE calling a tool ('Sure, let me
    draw that…'), that text must also survive the rebuild — the
    _close_stream_block helper renders it in place when a tool result
    arrives."""
    chat.append_user("draw me a cat")
    chat.assistant_started()
    # Pre-tool narration.
    chat.append_token("Sure, ")
    chat.append_token("let me draw that.")
    # Now tool fires.
    chat.show_tool_call("generate_image", {"prompt": "a cat"}, "user-allowed")
    chat.show_tool_result(
        "generate_image",
        "Image generated: file:///C:/test.png",
    )
    # Post-tool reply.
    chat.append_token("Here you go!")
    chat.assistant_finished()

    html = chat._history.toHtml()
    assert "Sure, let me draw that." in html
    assert "C:/test.png" in html
    assert "Here you go!" in html


def test_plain_streaming_without_tools_still_works(chat: ChatWindow) -> None:
    """Sanity check: the fix must not break the no-tool happy path."""
    chat.append_user("hello")
    chat.assistant_started()
    chat.append_token("Hi there!")
    chat.assistant_finished()

    html = chat._history.toHtml()
    assert "Hi there!" in html


def test_image_in_first_assistant_turn(chat: ChatWindow, tmp_path: Path) -> None:
    """Edge case: image arrives as the very first thing in the assistant
    turn with no streamed text before it."""
    chat.append_user("draw a cat")
    chat.assistant_started()
    chat.show_tool_result(
        "generate_image",
        "Image generated: file:///C:/early.png",
    )
    chat.assistant_finished()

    html = chat._history.toHtml()
    assert "early.png" in html
