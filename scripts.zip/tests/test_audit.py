from __future__ import annotations

import json
from pathlib import Path

from navi.perms import audit


def test_audit_appends_jsonl(tmp_path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    log = tmp_path / "audit.jsonl"
    monkeypatch.setattr(audit, "audit_path", lambda: log)

    audit.append(
        tool="read_file",
        args={"path": "C:/x.txt"},
        risk="low",
        decision="allowed",
        result="hello world",
    )
    audit.append(
        tool="run_powershell",
        args={"command": "Get-Process"},
        risk="high",
        decision="user-allowed",
        result="long output…",
    )

    lines = log.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 2
    e1 = json.loads(lines[0])
    assert e1["tool"] == "read_file"
    assert e1["decision"] == "allowed"
    assert e1["risk"] == "low"
    assert e1["args"] == {"path": "C:/x.txt"}
    assert "result_preview" in e1
    assert "ts" in e1 and "iso" in e1


def test_audit_truncates_huge_args(tmp_path, monkeypatch) -> None:  # type: ignore[no-untyped-def]
    log = tmp_path / "audit.jsonl"
    monkeypatch.setattr(audit, "audit_path", lambda: log)

    audit.append(
        tool="write_file",
        args={"path": "C:/big.txt", "content": "x" * 5000},
        risk="medium",
        decision="user-allowed",
    )
    entry = json.loads(log.read_text(encoding="utf-8"))
    assert len(entry["args"]["content"]) < 600
    assert "[+" in entry["args"]["content"]


def test_audit_swallows_filesystem_errors(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.setattr(audit, "audit_path", lambda: Path("Z:/no/such/dir/audit.jsonl"))
    # Should not raise
    audit.append(tool="x", args={}, risk="low", decision="allowed")
