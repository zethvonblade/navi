"""Tests for the wheel installer's worker-thread validation + offload cache.

The bug being guarded against:
- Pre-fix, `validate_llama_cpp_loadable` and `gpu_offload_supported` ran
  via `subprocess.run(...)` synchronously on the GUI thread, freezing the
  Qt event loop for 5-30 seconds. The user reported the "GPU support
  installed" dialog appearing stuck after a CPU→GPU switch.
- Post-fix, validate runs INSIDE WheelInstaller.run() so the GUI never
  sees the freeze, and gpu_offload_supported is wrapped in a cache so
  the subprocess only runs once per process (until a wheel install
  invalidates it).
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from navi.brain import wheel_installer as wi
from navi.brain.wheel_installer import (
    WheelInstaller,
    gpu_offload_supported_cached,
    invalidate_offload_cache,
)


@pytest.fixture(autouse=True)
def _reset_offload_cache():
    """Each test starts with a fresh cache."""
    invalidate_offload_cache()
    yield
    invalidate_offload_cache()


def _fake_proc(stdout_lines: list[str], rc: int) -> MagicMock:
    """Build a Popen-shaped mock with iterable stdout + a rc."""
    proc = MagicMock()
    proc.stdout = iter([line + "\n" if not line.endswith("\n") else line
                        for line in stdout_lines])
    proc.wait.return_value = rc
    proc.poll.return_value = rc
    return proc


# ----- WheelInstaller validates inside the worker thread -----------------


def test_run_validates_after_successful_pip(qapp) -> None:
    """The bug: validate USED to run on the GUI thread after WheelInstaller
    finished. Now it must run INSIDE run() before emitting finished."""
    finished_payloads: list[tuple[bool, str]] = []
    proc = _fake_proc(["Successfully installed llama-cpp-python-0.3.4"], rc=0)

    with patch.object(wi.subprocess, "Popen", return_value=proc) as popen_mock, \
         patch.object(wi, "validate_llama_cpp_loadable",
                      return_value=(True, "")) as validate_mock:
        worker = WheelInstaller(target="cuda")
        worker.finished.connect(lambda ok, msg: finished_payloads.append((ok, msg)))
        worker.run()

    assert popen_mock.called, "pip subprocess should have been launched"
    assert validate_mock.called, (
        "validate must run INSIDE the worker (regression: it used to run on "
        "the GUI thread after finished, freezing 5-30s)"
    )
    assert finished_payloads == [(True, "Install + load OK")]


def test_run_emits_failure_when_wheel_wont_load(qapp) -> None:
    """Pip succeeds but DLLs won't load (e.g. CUDA toolkit missing) →
    finished should carry the failure + load error."""
    finished_payloads: list[tuple[bool, str]] = []
    proc = _fake_proc(["Successfully installed llama-cpp-python-0.3.4"], rc=0)

    with patch.object(wi.subprocess, "Popen", return_value=proc), \
         patch.object(wi, "validate_llama_cpp_loadable",
                      return_value=(False, "ImportError: cudart64_12.dll not found")):
        worker = WheelInstaller(target="cuda")
        worker.finished.connect(lambda ok, msg: finished_payloads.append((ok, msg)))
        worker.run()

    assert len(finished_payloads) == 1
    ok, msg = finished_payloads[0]
    assert ok is False
    assert "won't load" in msg
    assert "cudart64_12.dll" in msg


def test_run_emits_failure_when_pip_fails(qapp) -> None:
    """Pip itself fails → no validate call, finished carries the rc."""
    finished_payloads: list[tuple[bool, str]] = []
    proc = _fake_proc(["ERROR: Could not find a version"], rc=1)

    with patch.object(wi.subprocess, "Popen", return_value=proc), \
         patch.object(wi, "validate_llama_cpp_loadable") as validate_mock:
        worker = WheelInstaller(target="cuda")
        worker.finished.connect(lambda ok, msg: finished_payloads.append((ok, msg)))
        worker.run()

    assert validate_mock.called is False, (
        "validate should NOT run when pip itself failed — that subprocess "
        "would just fail again and waste 5-30s"
    )
    assert finished_payloads == [(False, "pip exited with code 1")]


# ----- gpu_offload_supported_cached --------------------------------------


def test_cache_calls_underlying_once() -> None:
    """First call hits the subprocess; subsequent calls return cached."""
    with patch.object(wi, "gpu_offload_supported", return_value=True) as raw:
        assert gpu_offload_supported_cached() is True
        assert gpu_offload_supported_cached() is True
        assert gpu_offload_supported_cached() is True
        assert raw.call_count == 1, (
            f"underlying gpu_offload_supported called {raw.call_count} times; "
            "must be cached after the first call to avoid the GUI-thread freeze"
        )


def test_cache_caches_false_too() -> None:
    """Caching False means we don't re-spawn subprocess just because
    the user has CPU build. Common case — must be fast on every check."""
    with patch.object(wi, "gpu_offload_supported", return_value=False) as raw:
        assert gpu_offload_supported_cached() is False
        assert gpu_offload_supported_cached() is False
        assert raw.call_count == 1


def test_invalidate_forces_recheck() -> None:
    """After invalidation (e.g. post-install) the next call re-runs the
    underlying subprocess so a freshly-installed wheel is correctly
    detected."""
    with patch.object(wi, "gpu_offload_supported", side_effect=[False, True]) as raw:
        assert gpu_offload_supported_cached() is False
        invalidate_offload_cache()
        assert gpu_offload_supported_cached() is True
        assert raw.call_count == 2
