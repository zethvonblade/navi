"""Tests for the image-gen model registry + GPU placement policy.

Two scopes:

* ``models.py`` — every spec has the fields the subprocess relies on,
  the default id resolves, lookups are stable.
* ``subprocess._place_pipeline`` — the VRAM-tier decision table is the
  fix for the GTX 5090 falling back to CPU. Mock torch + the pipeline
  to verify the right placement call is made for each tier without
  needing diffusers installed.
"""

from __future__ import annotations

import sys
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

from navi.image import models as image_models
from navi.image.models import DEFAULT_MODEL_ID, MODELS, ModelSpec, get_spec


# ----- registry ------------------------------------------------------------


def test_default_model_id_resolves_to_a_real_spec() -> None:
    assert DEFAULT_MODEL_ID in MODELS
    assert isinstance(MODELS[DEFAULT_MODEL_ID], ModelSpec)


def test_get_spec_falls_back_to_default_on_unknown() -> None:
    assert get_spec("definitely-not-a-real-model") is MODELS[DEFAULT_MODEL_ID]
    assert get_spec(None) is MODELS[DEFAULT_MODEL_ID]


def test_get_spec_returns_named_spec_when_present() -> None:
    for mid, spec in MODELS.items():
        assert get_spec(mid) is spec


@pytest.mark.parametrize("model_id,spec", list(MODELS.items()))
def test_every_spec_has_required_fields(model_id: str, spec: ModelSpec) -> None:
    """If any of these go missing the subprocess will crash at init —
    keep the contract enforced."""
    assert spec.hf_id and "/" in spec.hf_id, f"{model_id}: bad hf_id"
    assert spec.local_dir, f"{model_id}: empty local_dir"
    assert spec.pipeline_cls.endswith("Pipeline"), \
        f"{model_id}: pipeline_cls should look like 'XxxPipeline'"
    assert spec.size_gb > 0
    assert spec.default_steps > 0
    assert spec.guidance_scale >= 0
    assert isinstance(spec.supports_negative_prompt, bool)
    assert spec.license, f"{model_id}: license string is required"


def test_only_apache_or_mit_models_in_registry() -> None:
    """Per feedback_tech_preferences: commercial-clean Apache/MIT only.
    OpenRAIL doesn't qualify even though it permits commercial use."""
    for mid, spec in MODELS.items():
        lic = spec.license.lower()
        assert "apache" in lic or "mit" in lic, (
            f"{mid} has license {spec.license!r} — only Apache/MIT belong "
            "in this registry per project licensing posture."
        )


def test_list_models_returns_stable_ordered_pairs() -> None:
    pairs = image_models.list_models()
    assert pairs[0][0] == next(iter(MODELS))
    assert {mid for mid, _ in pairs} == set(MODELS.keys())


# ----- placement policy ----------------------------------------------------


def _fake_torch(cuda_available: bool, vram_gb: float | None = None):
    """Build a stand-in for the ``torch`` module covering only the bits
    ``_place_pipeline`` touches."""
    cuda = SimpleNamespace(
        is_available=lambda: cuda_available,
        get_device_properties=lambda i: SimpleNamespace(
            total_memory=int((vram_gb or 0) * (1024 ** 3)),
        ),
    )
    return SimpleNamespace(cuda=cuda)


@pytest.fixture
def patch_torch(monkeypatch):
    """Inject a fake ``torch`` module into sys.modules so the subprocess's
    ``import torch`` inside _place_pipeline picks it up."""
    def _apply(cuda_available: bool, vram_gb: float | None = None):
        monkeypatch.setitem(
            sys.modules, "torch",
            _fake_torch(cuda_available, vram_gb),
        )
    return _apply


def test_place_pipeline_cpu_pref_stays_on_cpu(patch_torch) -> None:
    patch_torch(cuda_available=True, vram_gb=32)
    from navi.image.subprocess import _place_pipeline

    pipeline = MagicMock()
    device, vram = _place_pipeline(pipeline, "cpu")
    assert device == "cpu"
    assert vram is None
    pipeline.to.assert_not_called()
    pipeline.enable_model_cpu_offload.assert_not_called()


def test_place_pipeline_no_cuda_falls_back_to_cpu(patch_torch) -> None:
    patch_torch(cuda_available=False)
    from navi.image.subprocess import _place_pipeline

    pipeline = MagicMock()
    device, vram = _place_pipeline(pipeline, "auto")
    assert device == "cpu"
    assert vram is None
    pipeline.to.assert_not_called()


def test_place_pipeline_high_vram_uses_full_gpu(patch_torch) -> None:
    """The bug being fixed: GTX 5090 (32 GB) was getting cpu_offload
    instead of full GPU placement, killing performance."""
    patch_torch(cuda_available=True, vram_gb=32)
    from navi.image.subprocess import _place_pipeline

    pipeline = MagicMock()
    device, vram = _place_pipeline(pipeline, "auto")
    assert device == "cuda:0"
    assert vram == pytest.approx(32, abs=0.5)
    pipeline.to.assert_called_once_with("cuda")
    pipeline.enable_model_cpu_offload.assert_not_called()


def test_place_pipeline_mid_vram_uses_offload(patch_torch) -> None:
    patch_torch(cuda_available=True, vram_gb=12)
    from navi.image.subprocess import _place_pipeline

    pipeline = MagicMock()
    device, vram = _place_pipeline(pipeline, "auto")
    assert "offload" in device
    pipeline.enable_model_cpu_offload.assert_called_once()
    pipeline.to.assert_not_called()


def test_place_pipeline_low_vram_uses_sequential_offload(patch_torch) -> None:
    patch_torch(cuda_available=True, vram_gb=6)
    from navi.image.subprocess import _place_pipeline

    pipeline = MagicMock()
    device, vram = _place_pipeline(pipeline, "auto")
    assert "sequential" in device
    pipeline.enable_sequential_cpu_offload.assert_called_once()
    pipeline.enable_model_cpu_offload.assert_not_called()
    pipeline.to.assert_not_called()


def test_place_pipeline_cuda_offload_pref_forces_offload_even_on_big_gpu(
    patch_torch,
) -> None:
    """Escape hatch for users hitting OOM despite plenty of VRAM."""
    patch_torch(cuda_available=True, vram_gb=32)
    from navi.image.subprocess import _place_pipeline

    pipeline = MagicMock()
    device, vram = _place_pipeline(pipeline, "cuda_offload")
    assert "offload" in device
    pipeline.enable_model_cpu_offload.assert_called_once()
    pipeline.to.assert_not_called()
