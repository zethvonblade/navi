"""Tests for add_python_function and add_python_class.

Both share the same _add_toplevel_block implementation, so the tests
mirror each other. Critical assertion (same as imports): existing
content must be preserved verbatim.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from navi.tools import get_tool
from navi.tools.code_edit import add_python_class, add_python_function


# ----- registration --------------------------------------------------------


@pytest.mark.parametrize("name", ["add_python_function", "add_python_class"])
def test_registered_high(name: str) -> None:
    t = get_tool(name)
    assert t is not None
    assert t.risk == "high"


# ----- add_python_function -------------------------------------------------


def test_appends_function_to_empty_file(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("")
    out = add_python_function(str(f), "def hello() -> str:\n    return 'hi'\n")
    assert "Added function 'hello'" in out
    assert "def hello()" in f.read_text()


def test_appends_function_after_existing_content(tmp_path: Path) -> None:
    """Existing code must be byte-identical; new function appended."""
    original = (
        '"""Mod."""\n'
        "\n"
        "import os\n"
        "\n"
        "# Hand-tuned spacing here.\n"
        "def existing():\n"
        "    return 1\n"
    )
    f = tmp_path / "x.py"
    f.write_text(original)
    add_python_function(str(f), "def added() -> int:\n    return 2\n")
    new_text = f.read_text()
    assert original in new_text, "original content was mutated"
    assert "def added" in new_text
    assert new_text.index("def existing") < new_text.index("def added")


def test_accepts_async_function(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("")
    out = add_python_function(
        str(f), "async def fetch(url: str) -> str:\n    return url\n"
    )
    assert "Added function 'fetch'" in out


def test_rejects_invalid_python(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("")
    out = add_python_function(str(f), "def broken(:")
    assert "not valid Python" in out
    assert f.read_text() == ""  # untouched


def test_rejects_multiple_top_level_defs(tmp_path: Path) -> None:
    """The contract: source must contain EXACTLY one top-level function.
    Two defs in one snippet would be ambiguous and could shadow."""
    f = tmp_path / "x.py"
    f.write_text("")
    out = add_python_function(
        str(f),
        "def a():\n    return 1\n\ndef b():\n    return 2\n",
    )
    assert "exactly one" in out
    assert f.read_text() == ""


def test_rejects_non_function_source(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("")
    out = add_python_function(str(f), "x = 1")
    assert "exactly one" in out


def test_rejects_duplicate_function_name(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("def hello():\n    return 1\n")
    out = add_python_function(
        str(f), "def hello() -> str:\n    return 'different'\n"
    )
    assert "already exists" in out
    # File untouched.
    assert "return 1" in f.read_text()
    assert "return 'different'" not in f.read_text()


# ----- add_python_class ----------------------------------------------------


def test_appends_class_to_empty_file(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("")
    out = add_python_class(
        str(f),
        "class Widget:\n    def __init__(self) -> None:\n        self.x = 0\n",
    )
    assert "Added class 'Widget'" in out
    assert "class Widget" in f.read_text()


def test_class_rejects_function_source(tmp_path: Path) -> None:
    """add_python_class must reject a def — they have separate tools."""
    f = tmp_path / "x.py"
    f.write_text("")
    out = add_python_class(str(f), "def not_a_class():\n    pass\n")
    assert "exactly one" in out
    assert "class" in out


def test_class_rejects_duplicate_name(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("class Widget:\n    pass\n")
    out = add_python_class(str(f), "class Widget:\n    pass\n")
    assert "already exists" in out


# ----- shared safety guarantees --------------------------------------------


def test_function_rejects_relative_path() -> None:
    out = add_python_function("rel/x.py", "def f(): pass\n")
    assert "must be absolute" in out


def test_function_rejects_missing_file(tmp_path: Path) -> None:
    out = add_python_function(str(tmp_path / "ghost.py"), "def f(): pass\n")
    assert "does not exist" in out


def test_function_rejects_target_with_syntax_error(tmp_path: Path) -> None:
    f = tmp_path / "broken.py"
    original = "def x("
    f.write_text(original)
    out = add_python_function(str(f), "def added(): pass\n")
    assert "not valid Python" in out
    assert f.read_text() == original
