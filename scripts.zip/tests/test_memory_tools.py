from __future__ import annotations

from pathlib import Path

import pytest

from navi.memory import store
from navi.tools import get_tool


@pytest.fixture
def tmp_memory_dir(tmp_path: Path, monkeypatch) -> Path:  # type: ignore[no-untyped-def]
    monkeypatch.setattr(store, "memory_dir", lambda: tmp_path)
    return tmp_path


def test_remember_then_recall_roundtrip(tmp_memory_dir: Path) -> None:
    remember = get_tool("remember")
    recall = get_tool("recall")
    assert remember is not None and recall is not None

    out = remember.func(
        title="Dark mode",
        content="The user prefers dark mode in every application.",
        type="user",
    )
    assert "Saved memory" in out

    # Query must share lexical tokens with the stored content — pure keyword
    # search (no embeddings yet). Semantic matches like 'theme' -> 'mode'
    # would need bge-small-en-v1.5 + sqlite-vec, deferred to v2.
    hit = recall.func(query="what dark mode setting did I prefer?")
    assert "Dark mode" in hit
    assert "dark mode" in hit.lower()


def test_recall_empty_when_no_memory(tmp_memory_dir: Path) -> None:
    recall = get_tool("recall")
    assert recall is not None
    out = recall.func(query="anything at all")
    assert "No memories matched" in out


def test_remember_rejects_bad_type(tmp_memory_dir: Path) -> None:
    remember = get_tool("remember")
    assert remember is not None
    out = remember.func(title="X", content="x", type="not-a-real-type")
    assert "Error" in out
