from __future__ import annotations

import json

from navi.brain.worker import _parse_granite_tool_calls


def test_parses_canonical_tool_call() -> None:
    raw = (
        "<|tool_call|>"
        '[{"name": "read_file", "arguments": {"path": "C:/x.txt"}}]'
    )
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    c = calls[0]
    assert c["function"]["name"] == "read_file"
    assert json.loads(c["function"]["arguments"]) == {"path": "C:/x.txt"}


def test_parses_tool_call_alternate_marker() -> None:
    raw = '<tool_call>[{"name": "read_clipboard", "arguments": {}}]'
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    assert calls[0]["function"]["name"] == "read_clipboard"


def test_parses_unwrapped_single_object() -> None:
    raw = '<|tool_call|>{"name": "list_windows", "arguments": {}}'
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    assert calls[0]["function"]["name"] == "list_windows"


def test_handles_trailing_junk_after_closing_bracket() -> None:
    raw = (
        '<|tool_call|>[{"name": "read_clipboard", "arguments": {}}]'
        "\n\nSome trailing model chatter."
    )
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    assert calls[0]["function"]["name"] == "read_clipboard"


def test_returns_none_on_garbage() -> None:
    raw = "<|tool_call|>not json at all"
    assert _parse_granite_tool_calls(raw) is None


def test_parses_multiple_tool_calls() -> None:
    raw = (
        "<|tool_call|>["
        '{"name": "take_screenshot", "arguments": {}},'
        '{"name": "ocr_image", "arguments": {}}'
        "]"
    )
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 2
    assert [c["function"]["name"] for c in calls] == ["take_screenshot", "ocr_image"]


def test_parses_bare_json_array_no_marker() -> None:
    # Granite drops the marker after the first call — must still recognize.
    raw = '[{"name": "write_clipboard", "arguments": {"text": "eat\\nsleep\\nwork"}}]'
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    assert calls[0]["function"]["name"] == "write_clipboard"


def test_looks_like_tool_call_accepts_bare_json() -> None:
    from navi.brain.worker import _looks_like_tool_call

    assert _looks_like_tool_call('[{"name": "x", "arguments": {}}]')
    assert _looks_like_tool_call('{"name": "x", "arguments": {}}')
    assert _looks_like_tool_call("<|tool_call|>[{...}]")
    assert _looks_like_tool_call("<tool_call>[{...}]")
    # Whitespace inside braces — Granite emits this constantly
    assert _looks_like_tool_call('[{    "name": "x" }]')
    assert _looks_like_tool_call('[\n  {\n    "name": "x"\n  }\n]')
    # Function-key variant
    assert _looks_like_tool_call('[{"function": "x"}]')
    assert _looks_like_tool_call('{"function": {"name": "x"}}')
    # Negative cases
    assert not _looks_like_tool_call("Sure! Let me help you.")
    assert not _looks_like_tool_call("[1, 2, 3]")  # no name field — let it text-respond
    assert not _looks_like_tool_call("```python")


def test_parser_handles_function_string_shape() -> None:
    raw = '[{"function": "read_clipboard", "arguments": {}}]'
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    assert calls[0]["function"]["name"] == "read_clipboard"


def test_parser_handles_nested_function_shape() -> None:
    raw = '[{"function": {"name": "list_windows", "arguments": {}}}]'
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    assert calls[0]["function"]["name"] == "list_windows"


def test_parser_handles_parameters_synonym() -> None:
    raw = '[{"name": "open_app", "parameters": {"name_or_path": "notepad"}}]'
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    import json as _json
    assert _json.loads(calls[0]["function"]["arguments"]) == {"name_or_path": "notepad"}


def test_extract_bracket_tool_calls_after_narration() -> None:
    from navi.brain.worker import _extract_bracket_tool_calls

    raw = (
        'Now, I\'ll type "eat", "sleep", "work" into the Notepad window.\n\n'
        '[tool:type_text, arguments: {"text": "eat\\nsleep\\nwork"}]'
    )
    calls = _extract_bracket_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    import json as _json
    fn = calls[0]["function"]
    assert fn["name"] == "type_text"
    assert _json.loads(fn["arguments"]) == {"text": "eat\nsleep\nwork"}


def test_extract_bracket_tool_calls_returns_none_on_plain_text() -> None:
    from navi.brain.worker import _extract_bracket_tool_calls

    assert _extract_bracket_tool_calls("Just a regular response.") is None
    assert _extract_bracket_tool_calls("[unrelated brackets, no tool here]") is None


def test_extract_marker_tool_calls_after_apology_prose() -> None:
    """The exact case the user hit: model preambles, then emits the real
    `<tool_call>[{...}]` form mid-response. The early-stream sniff misses
    this because the prose came first; the late-stage extractor must catch it.
    """
    from navi.brain.worker import _extract_marker_tool_calls
    raw = (
        "I apologize for the confusion. To read and summarize the content "
        "of the PDF, please use the read_pdf tool instead. Here's how:\n"
        '<tool_call>[{"name": "read_pdf", "arguments": '
        '{"path": "C:/Users/SinghMa/Desktop/x.pdf"}}]'
    )
    calls = _extract_marker_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    fn = calls[0]["function"]
    assert fn["name"] == "read_pdf"
    assert json.loads(fn["arguments"]) == {"path": "C:/Users/SinghMa/Desktop/x.pdf"}


def test_extract_marker_tool_calls_handles_pipe_marker_mid_text() -> None:
    """Same case but with the canonical `<|tool_call|>` marker."""
    from navi.brain.worker import _extract_marker_tool_calls
    raw = (
        "Sure, let me check the clipboard for you.\n\n"
        '<|tool_call|>[{"name": "read_clipboard", "arguments": {}}]'
    )
    calls = _extract_marker_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    assert calls[0]["function"]["name"] == "read_clipboard"


def test_extract_marker_tool_calls_returns_none_when_no_marker() -> None:
    from navi.brain.worker import _extract_marker_tool_calls
    assert _extract_marker_tool_calls("Just prose, no tools.") is None
    assert _extract_marker_tool_calls("[some other bracket content]") is None


# --- Phi-style paired markers (open + close) ---------------------------


def test_parses_phi_paired_marker_single_object() -> None:
    """Phi-4-mini emits <|tool_call|>{...}<|/tool_call|> — closing marker
    must be stripped before JSON parse."""
    raw = '<|tool_call|>{"name": "read_clipboard", "arguments": {}}<|/tool_call|>'
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    assert calls[0]["function"]["name"] == "read_clipboard"


def test_parses_phi_paired_marker_array() -> None:
    raw = (
        '<|tool_call|>[{"name": "read_file", "arguments": '
        '{"path": "C:/x.txt"}}]<|/tool_call|>'
    )
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    assert calls[0]["function"]["name"] == "read_file"
    assert json.loads(calls[0]["function"]["arguments"]) == {"path": "C:/x.txt"}


def test_parses_html_style_closing_marker() -> None:
    """Some chat templates render the close as </tool_call> instead."""
    raw = '<|tool_call|>{"name": "list_windows", "arguments": {}}</tool_call>'
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    assert calls[0]["function"]["name"] == "list_windows"


def test_marker_extractor_finds_phi_paired_call_after_prose() -> None:
    """Phi might also preamble before the call; the marker scanner should
    still find it AND strip the closing marker."""
    from navi.brain.worker import _extract_marker_tool_calls
    raw = (
        "Sure, I'll check that for you.\n\n"
        '<|tool_call|>{"name": "read_clipboard", '
        '"arguments": {}}<|/tool_call|>'
    )
    calls = _extract_marker_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    assert calls[0]["function"]["name"] == "read_clipboard"


# --- Phi-4-mini OFFICIAL format: <|tool_calls|>[...] (PLURAL marker) ---


def test_parses_phi_official_plural_marker_array() -> None:
    """Phi-4-mini emits PLURAL `<|tool_calls|>[...]<|/tool_calls|>` — this
    is the official format per Microsoft's HF model card. Without plural
    markers in our table, the call landed in chat as raw text and 'nothing
    worked' for users who tried Phi.
    """
    raw = (
        '<|tool_calls|>[{"name": "read_clipboard", '
        '"arguments": {}}]<|/tool_calls|>'
    )
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    assert calls[0]["function"]["name"] == "read_clipboard"


def test_parses_phi_plural_marker_with_args() -> None:
    raw = (
        '<|tool_calls|>[{"name": "get_weather", "arguments": '
        '{"location": "Paris", "format": "celsius"}}]<|/tool_calls|>'
    )
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    fn = calls[0]["function"]
    assert fn["name"] == "get_weather"
    assert json.loads(fn["arguments"]) == {"location": "Paris", "format": "celsius"}


def test_parses_phi_plural_marker_multiple_calls() -> None:
    """Phi-4-mini supports parallel function calls — array can have N items."""
    raw = (
        '<|tool_calls|>['
        '{"name": "read_clipboard", "arguments": {}}, '
        '{"name": "list_windows", "arguments": {}}'
        ']<|/tool_calls|>'
    )
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 2
    assert calls[0]["function"]["name"] == "read_clipboard"
    assert calls[1]["function"]["name"] == "list_windows"


def test_marker_extractor_finds_phi_plural_marker_mid_prose() -> None:
    """Phi sometimes preambles too; the marker scanner must catch the
    plural marker anywhere in the response."""
    from navi.brain.worker import _extract_marker_tool_calls
    raw = (
        "I'll check the weather for you.\n"
        '<|tool_calls|>[{"name": "get_weather", '
        '"arguments": {"location": "Paris"}}]<|/tool_calls|>'
    )
    calls = _extract_marker_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    assert calls[0]["function"]["name"] == "get_weather"


def test_plural_marker_does_not_swallow_singular() -> None:
    """`<|tool_calls|>` matching must not consume a `<|tool_call|>` opening
    by mistake. The order in `_TOOL_CALL_MARKERS` puts plural first; verify
    the singular still works on its own."""
    raw = '<|tool_call|>[{"name": "read_clipboard", "arguments": {}}]'
    calls = _parse_granite_tool_calls(raw)
    assert calls is not None and len(calls) == 1
    assert calls[0]["function"]["name"] == "read_clipboard"
