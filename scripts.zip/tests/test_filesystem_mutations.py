"""Tests for the new mutating filesystem tools.

Covers create_dir, delete_file, delete_dir, move_path, copy_path,
find_files, file_info, plus the _is_protected_path safety guard.

All operations target tmp_path so the user's real filesystem is never
touched.
"""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from navi.tools import filesystem as fs
from navi.tools import all_tools, get_tool


# ----- registration --------------------------------------------------------


@pytest.mark.parametrize("name,risk", [
    ("create_dir", "medium"),
    ("delete_file", "high"),
    ("delete_dir", "high"),
    ("move_path", "high"),
    ("copy_path", "medium"),
    ("find_files", "safe"),
    ("file_info", "safe"),
])
def test_new_tools_registered_with_expected_risk(name: str, risk: str) -> None:
    names = {t.name for t in all_tools()}
    assert name in names, f"{name} is not registered"
    t = get_tool(name)
    assert t is not None
    assert t.risk == risk, (
        f"{name} risk should be {risk!r} so the permission UI gates it "
        f"correctly; got {t.risk!r}"
    )


# ----- create_dir ----------------------------------------------------------


def test_create_dir_creates_new(tmp_path: Path) -> None:
    target = tmp_path / "newdir"
    out = fs.create_dir(str(target))
    assert "Created" in out
    assert target.is_dir()


def test_create_dir_creates_parents(tmp_path: Path) -> None:
    target = tmp_path / "a" / "b" / "c"
    out = fs.create_dir(str(target))
    assert "Created" in out
    assert target.is_dir()


def test_create_dir_idempotent_with_exist_ok(tmp_path: Path) -> None:
    target = tmp_path / "dup"
    target.mkdir()
    out = fs.create_dir(str(target), exist_ok=True)
    assert "Created" in out  # treated as success


def test_create_dir_fails_when_exists_and_not_exist_ok(tmp_path: Path) -> None:
    target = tmp_path / "dup"
    target.mkdir()
    out = fs.create_dir(str(target), exist_ok=False)
    assert out.startswith("Error: already exists")


def test_create_dir_rejects_relative() -> None:
    out = fs.create_dir("relative/path")
    assert "must be absolute" in out


# ----- delete_file ---------------------------------------------------------


def test_delete_file_removes_file(tmp_path: Path) -> None:
    f = tmp_path / "x.txt"
    f.write_text("bye")
    out = fs.delete_file(str(f))
    assert "Deleted" in out
    assert not f.exists()


def test_delete_file_refuses_directory(tmp_path: Path) -> None:
    d = tmp_path / "subdir"
    d.mkdir()
    out = fs.delete_file(str(d))
    assert "use delete_dir" in out
    assert d.exists()


def test_delete_file_missing_path(tmp_path: Path) -> None:
    out = fs.delete_file(str(tmp_path / "ghost.txt"))
    assert "does not exist" in out


# ----- delete_dir ----------------------------------------------------------


def test_delete_dir_empty_succeeds(tmp_path: Path) -> None:
    d = tmp_path / "empty"
    d.mkdir()
    out = fs.delete_dir(str(d))
    assert "Deleted" in out
    assert not d.exists()


def test_delete_dir_refuses_nonempty_without_recursive(tmp_path: Path) -> None:
    d = tmp_path / "full"
    d.mkdir()
    (d / "file.txt").write_text("content")
    out = fs.delete_dir(str(d), recursive=False)
    assert "not empty" in out
    assert d.exists()  # untouched


def test_delete_dir_recursive_removes_tree(tmp_path: Path) -> None:
    d = tmp_path / "tree"
    (d / "sub").mkdir(parents=True)
    (d / "sub" / "file.txt").write_text("x")
    out = fs.delete_dir(str(d), recursive=True)
    assert "Deleted" in out
    assert not d.exists()


# ----- move_path -----------------------------------------------------------


def test_move_path_renames_file(tmp_path: Path) -> None:
    a = tmp_path / "a.txt"
    a.write_text("hi")
    b = tmp_path / "b.txt"
    out = fs.move_path(str(a), str(b))
    assert "Moved" in out
    assert not a.exists()
    assert b.read_text() == "hi"


def test_move_path_into_existing_directory(tmp_path: Path) -> None:
    f = tmp_path / "f.txt"
    f.write_text("v")
    d = tmp_path / "dest"
    d.mkdir()
    out = fs.move_path(str(f), str(d))
    assert "Moved" in out
    assert (d / "f.txt").exists()
    assert not f.exists()


def test_move_path_refuses_overwrite_by_default(tmp_path: Path) -> None:
    a = tmp_path / "a.txt"
    a.write_text("new")
    b = tmp_path / "b.txt"
    b.write_text("old")
    out = fs.move_path(str(a), str(b))
    assert "already exists" in out
    assert a.exists()
    assert b.read_text() == "old"


def test_move_path_overwrite_replaces(tmp_path: Path) -> None:
    a = tmp_path / "a.txt"
    a.write_text("new")
    b = tmp_path / "b.txt"
    b.write_text("old")
    out = fs.move_path(str(a), str(b), overwrite=True)
    assert "Moved" in out
    assert b.read_text() == "new"


# ----- copy_path -----------------------------------------------------------


def test_copy_path_copies_file(tmp_path: Path) -> None:
    a = tmp_path / "src.txt"
    a.write_text("hello")
    b = tmp_path / "dst.txt"
    out = fs.copy_path(str(a), str(b))
    assert "Copied" in out
    assert a.read_text() == "hello"
    assert b.read_text() == "hello"


def test_copy_path_copies_tree(tmp_path: Path) -> None:
    src = tmp_path / "tree"
    (src / "inner").mkdir(parents=True)
    (src / "inner" / "leaf.txt").write_text("leaf")
    dst = tmp_path / "tree_copy"
    out = fs.copy_path(str(src), str(dst))
    assert "Copied" in out
    assert (dst / "inner" / "leaf.txt").read_text() == "leaf"
    # source still intact
    assert (src / "inner" / "leaf.txt").exists()


def test_copy_path_refuses_overwrite_by_default(tmp_path: Path) -> None:
    a = tmp_path / "a.txt"
    a.write_text("new")
    b = tmp_path / "b.txt"
    b.write_text("old")
    out = fs.copy_path(str(a), str(b))
    assert "already exists" in out
    assert b.read_text() == "old"


# ----- find_files ----------------------------------------------------------


def test_find_files_glob_match(tmp_path: Path) -> None:
    (tmp_path / "a.py").write_text("")
    (tmp_path / "b.py").write_text("")
    (tmp_path / "c.txt").write_text("")
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "d.py").write_text("")
    out = fs.find_files(str(tmp_path), pattern="*.py")
    assert "a.py" in out
    assert "b.py" in out
    assert "d.py" in out
    assert "c.txt" not in out


def test_find_files_max_depth_zero_is_root_only(tmp_path: Path) -> None:
    (tmp_path / "top.txt").write_text("")
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "deep.txt").write_text("")
    out = fs.find_files(str(tmp_path), pattern="*.txt", max_depth=0)
    assert "top.txt" in out
    assert "deep.txt" not in out


def test_find_files_caps_at_max_results(tmp_path: Path) -> None:
    for i in range(20):
        (tmp_path / f"f{i}.log").write_text("")
    out = fs.find_files(str(tmp_path), pattern="*.log", max_results=5)
    assert "capped" in out
    # Count actual path lines (skip header line).
    assert out.count(".log") == 5


def test_find_files_empty_match_message(tmp_path: Path) -> None:
    out = fs.find_files(str(tmp_path), pattern="*.xyz")
    assert "No files matched" in out


# ----- file_info -----------------------------------------------------------


def test_file_info_for_file(tmp_path: Path) -> None:
    f = tmp_path / "info.txt"
    f.write_text("12345")
    out = fs.file_info(str(f))
    assert "type:      file" in out
    assert "size:      5 bytes" in out
    assert "modified:" in out


def test_file_info_for_directory(tmp_path: Path) -> None:
    d = tmp_path / "subdir"
    d.mkdir()
    out = fs.file_info(str(d))
    assert "type:      directory" in out


def test_file_info_pretty_size(tmp_path: Path) -> None:
    f = tmp_path / "big.bin"
    f.write_bytes(b"x" * 5000)
    out = fs.file_info(str(f))
    assert "KB" in out


# ----- _is_protected_path safety guard ------------------------------------


def test_protected_path_blocks_drive_root() -> None:
    # On Windows test runs, C:\ should always be protected.
    assert fs._is_protected_path(Path("C:\\")) is True


def test_protected_path_blocks_user_profile_root() -> None:
    profile = os.environ.get("USERPROFILE")
    if not profile:
        pytest.skip("USERPROFILE not set")
    assert fs._is_protected_path(Path(profile)) is True


def test_protected_path_allows_normal_subdir(tmp_path: Path) -> None:
    assert fs._is_protected_path(tmp_path / "harmless") is False


def test_delete_dir_refuses_protected_even_with_recursive(tmp_path: Path,
                                                          monkeypatch) -> None:
    """Even with recursive=True and a granted permission, the seatbelt
    must still refuse to nuke C:\\Windows."""
    sysroot = os.environ.get("SystemRoot")
    if not sysroot:
        pytest.skip("SystemRoot not set")
    out = fs.delete_dir(sysroot, recursive=True)
    assert "protected" in out
    assert Path(sysroot).exists()  # absolutely still there


def test_delete_file_refuses_protected_path(monkeypatch, tmp_path: Path) -> None:
    """Force a normal-looking file to be 'protected' to confirm the guard
    is consulted before the unlink call."""
    target = tmp_path / "decoy.txt"
    target.write_text("x")
    monkeypatch.setattr(fs, "_is_protected_path", lambda p: True)
    out = fs.delete_file(str(target))
    assert "protected" in out
    assert target.exists()
