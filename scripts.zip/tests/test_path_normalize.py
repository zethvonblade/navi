from __future__ import annotations

import os

from navi.tools._paths import normalize_windows_path


def test_unix_users_path_to_windows() -> None:
    assert (
        normalize_windows_path("/Users/SinghMa/Documents/x.txt")
        == "C:\\Users\\SinghMa\\Documents\\x.txt"
    )


def test_unix_users_lowercase() -> None:
    assert normalize_windows_path("/users/SinghMa/x") == "C:\\Users\\SinghMa\\x"


def test_unix_home_path_to_windows() -> None:
    out = normalize_windows_path("/home/singhma/notes.md")
    # Should land under C:\Users somewhere with the file name preserved
    assert out.startswith("C:\\Users\\")
    assert out.endswith("notes.md")


def test_windows_path_separators_normalized() -> None:
    assert (
        normalize_windows_path("C:/Users/SinghMa/Documents/x.txt")
        == "C:\\Users\\SinghMa\\Documents\\x.txt"
    )


def test_already_native_windows_path_unchanged() -> None:
    p = "C:\\Users\\SinghMa\\x.txt"
    assert normalize_windows_path(p) == p


def test_relative_path_unchanged() -> None:
    p = "relative/path.txt"
    assert normalize_windows_path(p) == p


def test_empty_path_unchanged() -> None:
    assert normalize_windows_path("") == ""


def test_bare_slash_documents_resolves_under_userprofile() -> None:
    if not os.environ.get("USERPROFILE"):
        return
    out = normalize_windows_path("/Documents/x.txt")
    assert out.startswith(os.environ["USERPROFILE"])
    assert out.endswith("x.txt")
