"""Tests for the declarative skin kit."""

from __future__ import annotations

import pytest
from PySide6.QtCore import QPointF, QRect, Qt
from PySide6.QtGui import QColor, QImage, QPainter

from navi.pet.skins._base import PaintContext, Skin
from navi.pet.skins.kit import (
    _resolve_color,
    _resolve_palette,
    compose,
    layer,
)
from navi.pet.state import NaviState

# A fully-specified palette used by several tests
_PAL_SPEC = {
    NaviState.IDLE: "blue",
    NaviState.LISTENING: "emerald",
    NaviState.THINKING: "violet",
    NaviState.SPEAKING: "gold",
    NaviState.ASKING: "amber",
    NaviState.ERROR: "crimson",
}


@pytest.fixture
def qapp_ready(qapp):
    """Ensure a QApplication exists for QFont/QPainter usage in tests."""
    return qapp


def _make_ctx(state: NaviState = NaviState.IDLE) -> tuple[PaintContext, QImage, QPainter]:
    """Build an offscreen PaintContext for tests."""
    img = QImage(120, 120, QImage.Format.Format_ARGB32)
    img.fill(0)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    ctx = PaintContext(
        painter=p, rect=QRect(0, 0, 120, 120),
        state=state, t=0.0, pupil_x=0.0, pupil_y=0.0, ripples=[],
    )
    return ctx, img, p


# ----- color resolution ----------------------------------------------------


def test_resolve_color_state_uses_palette() -> None:
    palette = {NaviState.IDLE: QColor("#112233")}
    assert _resolve_color("state", NaviState.IDLE, palette).name() == "#112233"


def test_resolve_color_named() -> None:
    palette = _resolve_palette(_PAL_SPEC)
    c = _resolve_color("gold", NaviState.IDLE, palette)
    assert isinstance(c, QColor)
    # gold is warm — high R, high G, low B
    assert c.red() > 200
    assert c.blue() < 130


def test_resolve_color_hex_string() -> None:
    c = _resolve_color("#ff00ff", NaviState.IDLE, {})
    assert c.red() == 255 and c.blue() == 255 and c.green() == 0


def test_resolve_color_qcolor_passthrough() -> None:
    src = QColor("#abcdef")
    out = _resolve_color(src, NaviState.IDLE, {})
    assert out.name() == src.name()


def test_resolve_color_unknown_raises() -> None:
    with pytest.raises(ValueError):
        _resolve_color("not-a-color", NaviState.IDLE, {})


def test_resolve_palette_missing_states_default_to_idle() -> None:
    pal = _resolve_palette({NaviState.IDLE: "violet"})
    assert pal[NaviState.IDLE].name() == pal[NaviState.LISTENING].name()
    assert pal[NaviState.IDLE].name() == pal[NaviState.ERROR].name()


def test_resolve_palette_empty_falls_back_to_blue() -> None:
    pal = _resolve_palette(None)
    # All six states present
    assert set(pal.keys()) == set(NaviState)


# ----- compose() -----------------------------------------------------------


def test_compose_returns_skin_subclass() -> None:
    Cls = compose(name="t", description="x", palette=_PAL_SPEC, layers=[])
    assert issubclass(Cls, Skin)
    inst = Cls()
    assert inst.name == "t"
    assert inst.description == "x"


def test_compose_paints_without_error(qapp_ready) -> None:
    Cls = compose(
        name="full_stack",
        description="every layer at default settings",
        palette=_PAL_SPEC,
        layers=[
            layer.halo(),
            layer.void_body(),
            layer.rune_ring(),
            layer.hairline_ring(radius_frac=0.70),
            layer.glyph_ring(),
            layer.hexagram(),
            layer.bright_core(),
            layer.crosshair(),
            layer.listening_ripples(),
            layer.thinking_arc(),
            layer.speaking_bars(),
            layer.status_label(),
        ],
    )
    inst = Cls()
    for state in NaviState:
        ctx, img, p = _make_ctx(state)
        try:
            inst.paint(ctx)  # must not raise
        finally:
            p.end()


def test_compose_clouds_and_embers_paint(qapp_ready) -> None:
    Cls = compose(
        name="atmos",
        palette=_PAL_SPEC,
        layers=[
            layer.halo(),
            layer.void_body(),
            layer.clouds(n=3, drift_speed=0.4),
            layer.embers(n=10),
            layer.bright_core(),
        ],
    )
    inst = Cls()
    ctx, img, p = _make_ctx()
    try:
        inst.paint(ctx)
    finally:
        p.end()


def test_compose_light_column_paints(qapp_ready) -> None:
    Cls = compose(
        name="vessel",
        palette=_PAL_SPEC,
        layers=[layer.halo(), layer.void_body(), layer.light_column()],
    )
    inst = Cls()
    for state in NaviState:
        ctx, img, p = _make_ctx(state)
        try:
            inst.paint(ctx)
        finally:
            p.end()


# ----- registration --------------------------------------------------------


def test_composed_skin_can_register_in_real_registry() -> None:
    """Sanity: a composed skin can be added to REGISTRY and retrieved."""
    from navi.pet.skins import REGISTRY, get_skin
    Cls = compose(name="zzz_test_skin", description="d", palette=_PAL_SPEC, layers=[])
    REGISTRY[Cls.name] = Cls
    try:
        inst = get_skin("zzz_test_skin")
        assert isinstance(inst, Skin)
        assert inst.name == "zzz_test_skin"
    finally:
        REGISTRY.pop("zzz_test_skin", None)
