from __future__ import annotations

from navi.tools import all_tools, get_tool, tools_schema


def test_all_tools_registered() -> None:
    names = {t.name for t in all_tools()}
    assert names == {
        # Phase 3 (read-only)
        "read_clipboard",
        "read_file",
        "list_dir",
        "take_screenshot",
        "ocr_image",
        "list_windows",
        # Phase 4 (write/exec)
        "write_clipboard",
        "write_file",
        "open_app",
        "open_url",
        "focus_window",
        "run_powershell",
        "type_text",
        # Phase 5 (memory)
        "remember",
        "recall",
        # Document + web batch
        "read_pdf",
        "read_excel",
        "read_pptx",
        "read_csv",
        "summarize_file",
        "web_search",
        # Image generation
        "generate_image",
        # Filesystem mutations (organize-my-files batch)
        "create_dir",
        "delete_file",
        "delete_dir",
        "move_path",
        "copy_path",
        "find_files",
        "file_info",
        # System info + compute
        "get_datetime",
        "check_url",
        "calc",
        # Scaffolding (project templates + ruff wrappers)
        "list_stacks",
        "scaffold_project",
        "lint_python",
        "format_python",
        # AST-safe Python code edits
        "add_python_import",
        "add_python_function",
        "add_python_class",
        # Git (local-only; no remote ops)
        "git_status",
        "git_diff",
        "git_log",
        "git_branch_list",
        "git_init",
        "git_branch_create",
        "git_checkout",
        "git_add",
        "git_commit",
        # Notifications + scheduling + run_python + replace_lines
        "notify",
        "schedule_once",
        "schedule_recurring",
        "list_scheduled",
        "cancel_scheduled",
        "run_python",
        "replace_lines",
    }


def test_risk_levels_assigned() -> None:
    by_name = {t.name: t for t in all_tools()}
    assert by_name["read_clipboard"].risk == "safe"
    assert by_name["write_clipboard"].risk == "low"
    assert by_name["write_file"].risk == "medium"
    assert by_name["run_powershell"].risk == "high"


def test_get_tool_returns_callable() -> None:
    t = get_tool("read_clipboard")
    assert t is not None
    assert callable(t.func)
    assert t.risk == "safe"


def test_tools_schema_has_openai_shape() -> None:
    schema = tools_schema()
    assert isinstance(schema, list)
    for item in schema:
        assert item["type"] == "function"
        fn = item["function"]
        assert isinstance(fn["name"], str)
        assert isinstance(fn["description"], str)
        assert fn["parameters"]["type"] == "object"


def test_read_file_rejects_relative_path() -> None:
    t = get_tool("read_file")
    assert t is not None
    out = t.func(path="relative/path.txt")
    assert out.startswith("Error")


def test_read_file_rejects_missing(tmp_path) -> None:  # type: ignore[no-untyped-def]
    t = get_tool("read_file")
    assert t is not None
    out = t.func(path=str(tmp_path / "nope.txt"))
    assert "does not exist" in out


def test_read_file_returns_contents(tmp_path) -> None:  # type: ignore[no-untyped-def]
    f = tmp_path / "hello.txt"
    f.write_text("hello world", encoding="utf-8")
    t = get_tool("read_file")
    assert t is not None
    assert t.func(path=str(f)) == "hello world"


def test_read_file_extracts_docx(tmp_path) -> None:  # type: ignore[no-untyped-def]
    from docx import Document
    f = tmp_path / "doc.docx"
    d = Document()
    d.add_paragraph("Hello from a Word document.")
    d.add_paragraph("Second line.")
    d.save(str(f))
    t = get_tool("read_file")
    assert t is not None
    out = t.func(path=str(f))
    assert "Hello from a Word document." in out
    assert "Second line." in out


def test_read_file_refuses_pdf(tmp_path) -> None:  # type: ignore[no-untyped-def]
    f = tmp_path / "doc.pdf"
    f.write_bytes(b"%PDF-1.4 fake")
    t = get_tool("read_file")
    assert t is not None
    out = t.func(path=str(f))
    assert "unsupported" in out.lower() or "cannot read" in out.lower()


def test_read_file_refuses_nul_bytes(tmp_path) -> None:  # type: ignore[no-untyped-def]
    f = tmp_path / "weird.txt"
    f.write_bytes(b"hello\x00world")
    t = get_tool("read_file")
    assert t is not None
    out = t.func(path=str(f))
    assert "binary file" in out.lower()


def test_list_dir_returns_entries(tmp_path) -> None:  # type: ignore[no-untyped-def]
    (tmp_path / "a.txt").write_text("x")
    (tmp_path / "subdir").mkdir()
    t = get_tool("list_dir")
    assert t is not None
    out = t.func(path=str(tmp_path))
    assert "a.txt" in out
    assert "subdir" in out
