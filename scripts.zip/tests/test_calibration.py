"""Tests for the adapter-based calibration module.

Covers:
* Probe shape + report counts
* Auto-fix loop with a fake LLM (different adapters fail/pass)
* Report formatting
* Backwards-compat exports (detect_profile etc. for old call sites)

The actual LLM-driven probes need a live model and are exercised by the
running app — these tests stub it out.
"""

from __future__ import annotations

from pathlib import Path

from navi.brain.adapters import ADAPTERS
from navi.brain.calibration import (
    CalibrationReport,
    PROFILES,  # backwards-compat alias for ADAPTERS
    ProbeResult,
    detect_adapter,
    detect_profile,  # backwards-compat alias
    format_report_for_chat,
    run_calibration,
)


# ----- backwards-compat exports -------------------------------------------


def test_legacy_profile_aliases_still_work() -> None:
    assert detect_profile is detect_adapter
    assert PROFILES is ADAPTERS


# ----- report shape -------------------------------------------------------


def _sample_report(passed: bool = True) -> CalibrationReport:
    return CalibrationReport(
        adapter_id="granite_3",
        adapter_description="IBM Granite 3.x",
        adapter_notes="tuned target",
        model_filename="granite-3.1-2b-instruct-Q4_K_M.gguf",
        probes=[
            ProbeResult(name="math", passed=passed, expected="'4'", actual="4"),
            ProbeResult(name="follows_format", passed=passed,
                        expected="≤2 words", actual="hello", notes="1 words"),
            ProbeResult(name="coherence", passed=passed,
                        expected="contains 'Paris'", actual="Paris"),
            ProbeResult(name="no_roleplay", passed=passed,
                        expected="contains '10', no fake dialogue", actual="10"),
            ProbeResult(name="tool_call", passed=passed,
                        expected="calls read_clipboard",
                        actual="structured tool_call → read_clipboard"),
        ],
    )


def test_report_counts() -> None:
    r = _sample_report(passed=True)
    assert r.n_total == 5
    assert r.n_passed == 5
    assert r.all_passed is True


def test_report_partial_fail() -> None:
    r = _sample_report(passed=True)
    r.probes[1].passed = False
    assert r.n_passed == 4
    assert r.all_passed is False


def test_format_report_includes_marks_and_warning() -> None:
    r = _sample_report(passed=False)
    text = format_report_for_chat(r)
    assert "🧪 calibration" in text
    assert "granite" in text.lower() or "ibm" in text.lower()
    assert "✗" in text
    assert "may misbehave" in text.lower()


def test_format_report_passing_no_warning() -> None:
    r = _sample_report(passed=True)
    text = format_report_for_chat(r)
    assert "✓" in text
    assert "may misbehave" not in text.lower()


def test_format_report_includes_autofix_note() -> None:
    r = _sample_report(passed=True)
    r.fix_adapter_id = "phi"
    r.fix_adapter_description = "Microsoft Phi-4-mini / Phi-3"
    text = format_report_for_chat(r)
    assert "🔧 auto-fix applied" in text
    assert "phi" in text


# ----- auto-fix loop with a fake LLM --------------------------------------


class _FakeLLM:
    """Mock that responds based on which adapter's system prompt is sent.

    Tool-call probe fails for adapters in ``fail_with_adapters``; passes
    for the rest by emitting a Granite-style marker text the parser catches.
    """

    def __init__(self, fail_with_adapters: set[str]):
        self.fail_with_adapters = fail_with_adapters

    def create_chat_completion(self, **kwargs):
        msgs = kwargs.get("messages", [])
        sys_prompt = next(
            (m["content"] for m in msgs if m["role"] == "system"), ""
        )
        # history_resilience probe sends multiple user turns — we care about
        # the LAST one (the actual question), not the synthetic preamble.
        user_msgs = [m["content"] for m in msgs if m["role"] == "user"]
        user = user_msgs[-1] if user_msgs else ""

        if "2+2" in user:
            return self._stream_text("4")
        if "EXACTLY one word" in user:
            return self._stream_text("hello")
        if "capital of France" in user:
            return self._stream_text("Paris")
        if user.strip() == "5+5":
            return self._stream_text("10")
        # wrong_tool probe — picks the right tool from a subset
        if "currently on my clipboard" in user:
            return self._stream_text(
                '<|tool_call|>[{"name": "read_clipboard", "arguments": {}}]'
            )
        # parallel_calls probe — emit both tool calls in one response
        if "Read my clipboard AND list" in user:
            return self._stream_text(
                '<|tool_call|>['
                '{"name": "read_clipboard", "arguments": {}}, '
                '{"name": "list_windows", "arguments": {}}'
                ']'
            )
        if "Call the" in user:
            current = next(
                (a for a in ADAPTERS if a.system_prompt in sys_prompt),
                None,
            )
            if current and current.id in self.fail_with_adapters:
                return self._stream_text("Sure, I'll help with that.")
            return self._stream_text(
                '<|tool_call|>[{"name": "read_clipboard", "arguments": {}}]'
            )
        return self._stream_text("")

    def _stream_text(self, text: str):
        chunks = []
        for ch in text:
            chunks.append({"choices": [{"delta": {"content": ch},
                                        "finish_reason": None}]})
        chunks.append({"choices": [{"delta": {}, "finish_reason": "stop"}]})
        return iter(chunks)


def _fake_tools_schema() -> list[dict]:
    return [{
        "type": "function",
        "function": {
            "name": "read_clipboard",
            "description": "read the system clipboard",
            "parameters": {"type": "object", "properties": {}},
        },
    }]


def test_autofix_picks_working_adapter() -> None:
    """Granite (default for an unknown filename matching its keyword) fails;
    auto-fix walks adapters and finds one that works."""
    llm = _FakeLLM(fail_with_adapters={"granite_3"})
    report = run_calibration(
        llm, _fake_tools_schema(),
        Path("models/granite-3.1-2b-instruct-Q4_K_M.gguf"),
        auto_fix=True,
    )
    assert report.all_passed is True
    assert report.fix_adapter_id is not None
    assert report.fix_adapter_id != "granite_3"


def test_autofix_disabled_returns_failing_report() -> None:
    llm = _FakeLLM(fail_with_adapters={"granite_3"})
    report = run_calibration(
        llm, _fake_tools_schema(),
        Path("models/granite-3.1-2b-instruct.gguf"),
        auto_fix=False,
    )
    assert report.all_passed is False
    assert report.fix_adapter_id is None


def test_autofix_no_adapter_works_returns_failing() -> None:
    """Every adapter fails the tool probe — no fix possible."""
    llm = _FakeLLM(fail_with_adapters={a.id for a in ADAPTERS})
    report = run_calibration(
        llm, _fake_tools_schema(),
        Path("models/whatever.gguf"),
        auto_fix=True,
    )
    assert report.all_passed is False
    assert report.fix_adapter_id is None


def test_autofix_skipped_when_only_math_fails() -> None:
    """Math-only failures aren't fixable via prompt swap."""

    class _MathFailLLM(_FakeLLM):
        def create_chat_completion(self, **kwargs):
            user = next((m["content"] for m in kwargs["messages"]
                         if m["role"] == "user"), "")
            if "2+2" in user:
                return self._stream_text("five")
            return super().create_chat_completion(**kwargs)

    llm = _MathFailLLM(fail_with_adapters=set())
    report = run_calibration(
        llm, _fake_tools_schema(),
        Path("models/granite-3.gguf"),
        auto_fix=True,
    )
    assert report.all_passed is False
    assert report.fix_adapter_id is None


def test_initial_adapter_id_overrides_filename_detection() -> None:
    """If a previous session persisted an adapter, run_calibration should
    use it instead of re-detecting from the filename."""
    llm = _FakeLLM(fail_with_adapters=set())
    # Filename suggests Granite but we tell calibration to use Phi
    report = run_calibration(
        llm, _fake_tools_schema(),
        Path("models/granite-3.1.gguf"),
        initial_adapter_id="phi",
        auto_fix=False,
    )
    assert report.adapter_id == "phi"


def test_rambling_response_fails_math_probe() -> None:
    class _RamblerLLM(_FakeLLM):
        def create_chat_completion(self, **kwargs):
            user = next((m["content"] for m in kwargs["messages"]
                         if m["role"] == "user"), "")
            if "2+2" in user:
                return self._stream_text(
                    "Of course! Let me help you with that. The answer is 4 "
                    "because two plus two equals four in arithmetic."
                )
            return super().create_chat_completion(**kwargs)

    llm = _RamblerLLM(fail_with_adapters=set())
    report = run_calibration(
        llm, _fake_tools_schema(),
        Path("models/whatever.gguf"),
        auto_fix=False,
    )
    math = next(p for p in report.probes if p.name == "math")
    assert math.passed is False


def test_fake_dialogue_detector_catches_all_marker_variants() -> None:
    """Different models emit role markers in different shapes. The detector
    must catch every variant we've seen — `User:`, `[User]`, `<user>`, etc.
    """
    from navi.brain.calibration import _has_fake_dialogue

    # All of these should be flagged
    assert _has_fake_dialogue("User: hello\nAssistant: hi")
    assert _has_fake_dialogue("[User] hello\n[Assistant] hi")
    assert _has_fake_dialogue("<user>hello</user><assistant>hi</assistant>")
    assert _has_fake_dialogue("USER: hello\nASSISTANT: hi")
    assert _has_fake_dialogue("Some text\nuser: hello")
    assert _has_fake_dialogue("Human: hello\nAI: hi")
    # The exact bug from TinyLlama on "5+5+5"
    assert _has_fake_dialogue("[User] Can you provide me with a guide?")

    # These should NOT trip the detector — common false-positives to guard
    assert not _has_fake_dialogue("The user_id field is required.")
    assert not _has_fake_dialogue("Just a plain answer.")
    assert not _has_fake_dialogue("10")
    assert not _has_fake_dialogue("Paris is the capital of France.")
    assert not _has_fake_dialogue("Run the assistant_setup.py script.")


def test_fake_dialogue_response_fails_roleplay_probe() -> None:
    """Real bug from Granite 2B: when asked '5+5' with a long persona that
    mentions 'preferences' and 'remember/recall tools', the model emitted a
    fabricated User:/Assistant: dialogue about email fonts. Calibration was
    blind to this until we added the no_roleplay probe."""

    class _RoleplayLLM(_FakeLLM):
        def create_chat_completion(self, **kwargs):
            user = next((m["content"] for m in kwargs["messages"]
                         if m["role"] == "user"), "")
            if user.strip() == "5+5":
                return self._stream_text(
                    "User: Can you remind me of my preference for fonts?\n"
                    "Assistant: (Recall tool) You prefer Arial."
                )
            return super().create_chat_completion(**kwargs)

    llm = _RoleplayLLM(fail_with_adapters=set())
    report = run_calibration(
        llm, _fake_tools_schema(),
        Path("models/whatever.gguf"),
        auto_fix=False,
    )
    roleplay = next(p for p in report.probes if p.name == "no_roleplay")
    assert roleplay.passed is False
    assert "fake dialogue" in roleplay.notes


def test_rambling_response_fails_coherence_probe() -> None:
    class _IncoherentLLM(_FakeLLM):
        def create_chat_completion(self, **kwargs):
            user = next((m["content"] for m in kwargs["messages"]
                         if m["role"] == "user"), "")
            if "capital of France" in user:
                return self._stream_text(
                    "Sure, let me help with that. I prefer dark mode."
                )
            return super().create_chat_completion(**kwargs)

    llm = _IncoherentLLM(fail_with_adapters=set())
    report = run_calibration(
        llm, _fake_tools_schema(),
        Path("models/whatever.gguf"),
        auto_fix=False,
    )
    coherence = next(p for p in report.probes if p.name == "coherence")
    assert coherence.passed is False
