"""Tests for summarize_file (chunker + dispatch + error paths).

The LLM-driven map-reduce passes need a live model and aren't covered here —
they're exercised by the running app. These tests pin the boring stuff
(chunk boundaries, file-type dispatch, error handling).
"""

from __future__ import annotations

from pathlib import Path

import pytest

from navi.brain import shared
from navi.tools import all_tools, get_tool
from navi.tools.summarize import (
    _MAX_RAW_CHARS,
    _extract_full,
    split_chunks,
    summarize_file,
)


# ----- chunker ------------------------------------------------------------


def test_split_chunks_short_text_single_chunk() -> None:
    assert split_chunks("hello world", target_chars=1000) == ["hello world"]


def test_split_chunks_respects_paragraph_boundaries() -> None:
    paras = "\n\n".join(f"paragraph {i} " + ("x" * 200) for i in range(20))
    chunks = split_chunks(paras, target_chars=800, overlap_chars=50)
    assert len(chunks) > 1
    # No chunk should be wildly oversize (allow a small safety margin)
    assert all(len(c) <= 1200 for c in chunks)
    # Adjacent chunks share an overlapping tail/head
    for a, b in zip(chunks, chunks[1:]):
        # at least some character overlap (the carried tail from the prior chunk)
        assert any(b[:50].startswith(a[-i:]) for i in range(1, 50)) or len(a) < 50


def test_split_chunks_oversized_paragraph_is_hard_split() -> None:
    monster = "x" * 25_000  # one giant paragraph
    chunks = split_chunks(monster, target_chars=8_000)
    assert len(chunks) >= 3
    assert sum(len(c) for c in chunks) >= len(monster)


# ----- extraction dispatch -----------------------------------------------


def test_extract_full_text_file(tmp_path: Path) -> None:
    f = tmp_path / "notes.txt"
    f.write_bytes(b"hello\n\nworld")  # avoid CRLF on Windows
    assert _extract_full(f) == "hello\n\nworld"


def test_extract_full_unknown_extension(tmp_path: Path) -> None:
    f = tmp_path / "thing.xyz"
    f.write_text("data")
    with pytest.raises(ValueError) as ei:
        _extract_full(f)
    assert "summarize_file does not know" in str(ei.value)


def test_extract_full_caps_at_max_raw(tmp_path: Path) -> None:
    f = tmp_path / "big.txt"
    f.write_text("x" * (_MAX_RAW_CHARS + 1000), encoding="utf-8")
    out = _extract_full(f)
    assert len(out) == _MAX_RAW_CHARS


# ----- tool registration --------------------------------------------------


def test_summarize_file_is_registered() -> None:
    names = {t.name for t in all_tools()}
    assert "summarize_file" in names


def test_summarize_file_schema_required_path() -> None:
    t = get_tool("summarize_file")
    assert t is not None
    assert "path" in t.parameters["properties"]
    assert "path" in t.parameters["required"]


# ----- error paths (no LLM needed) ----------------------------------------


def test_summarize_file_relative_path_rejected() -> None:
    out = summarize_file(path="relative/path.txt")
    assert "must be absolute" in out


def test_summarize_file_missing_file(tmp_path: Path) -> None:
    out = summarize_file(path=str(tmp_path / "nope.txt"))
    assert "does not exist" in out


def test_summarize_file_no_llm_returns_clean_error(tmp_path: Path) -> None:
    # Make sure no leftover llm from earlier tests
    saved = shared.get_llm()
    shared.set_llm(None)
    try:
        f = tmp_path / "small.txt"
        f.write_text("hello world", encoding="utf-8")
        out = summarize_file(path=str(f))
        assert "model not loaded" in out.lower()
    finally:
        shared.set_llm(saved)


def test_summarize_file_unsupported_extension(tmp_path: Path) -> None:
    f = tmp_path / "weird.xyz"
    f.write_text("data")
    # Stub an llm so we get past that check and into _extract_full
    saved = shared.get_llm()
    shared.set_llm(object())
    try:
        out = summarize_file(path=str(f))
        assert "does not know" in out
    finally:
        shared.set_llm(saved)
