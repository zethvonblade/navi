"""Tests for src/navi/tools/system.py — get_datetime + check_url."""

from __future__ import annotations

import urllib.error
from unittest.mock import MagicMock, patch

import pytest

from navi.tools import all_tools, get_tool
from navi.tools.system import check_url, get_datetime


# ----- registration --------------------------------------------------------


def test_get_datetime_registered_safe() -> None:
    t = get_tool("get_datetime")
    assert t is not None and t.risk == "safe"


def test_check_url_registered_low() -> None:
    t = get_tool("check_url")
    assert t is not None and t.risk == "low"


# ----- get_datetime --------------------------------------------------------


def test_get_datetime_local_returns_iso_and_epoch() -> None:
    out = get_datetime()
    assert "iso:" in out
    assert "epoch:" in out
    assert "weekday:" in out
    assert "timezone:" in out
    # ISO timestamp lines should contain a T separator.
    iso_line = next(ln for ln in out.splitlines() if ln.startswith("iso:"))
    assert "T" in iso_line


def test_get_datetime_utc_marks_timezone_utc() -> None:
    out = get_datetime(tz="utc")
    assert "timezone: UTC" in out


# ----- check_url -----------------------------------------------------------


def test_check_url_rejects_empty() -> None:
    out = check_url("")
    assert "required" in out


def test_check_url_rejects_non_http_scheme() -> None:
    out = check_url("ftp://example.com")
    assert "must start with http" in out


def test_check_url_2xx_reports_reachable() -> None:
    fake_resp = MagicMock()
    fake_resp.status = 200
    fake_resp.geturl.return_value = "https://example.com"
    fake_resp.__enter__ = lambda self: fake_resp
    fake_resp.__exit__ = lambda *_: None

    with patch("urllib.request.urlopen", return_value=fake_resp):
        out = check_url("https://example.com")
    assert "reachable: true" in out
    assert "status: 200" in out


def test_check_url_404_still_reachable() -> None:
    """HTTPError means the server responded — the URL is reachable, just
    not a 2xx. Diagnostically useful: tells the agent the server is up."""
    err = urllib.error.HTTPError(
        "https://example.com/missing", 404, "Not Found", {}, None,  # type: ignore[arg-type]
    )
    with patch("urllib.request.urlopen", side_effect=err):
        out = check_url("https://example.com/missing")
    assert "reachable: true" in out
    assert "status: 404" in out


def test_check_url_url_error_unreachable() -> None:
    """URLError = couldn't even reach the server (DNS, connection refused,
    timeout). Should report unreachable with the underlying reason."""
    err = urllib.error.URLError("Name or service not known")
    with patch("urllib.request.urlopen", side_effect=err):
        out = check_url("https://nonexistent.invalid")
    assert "reachable: false" in out
    assert "Name or service not known" in out
