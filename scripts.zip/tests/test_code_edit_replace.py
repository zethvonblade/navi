"""Tests for replace_lines.

Same critical guarantee as the other code_edit tools: comments and
formatting OUTSIDE the replaced range must be byte-identical (no
``ast.unparse`` round-trip)."""

from __future__ import annotations

from pathlib import Path

import pytest

from navi.tools import get_tool
from navi.tools.code_edit import replace_lines


# ----- registration --------------------------------------------------------


def test_registered_high_risk() -> None:
    t = get_tool("replace_lines")
    assert t is not None
    assert t.risk == "high"


# ----- happy path ---------------------------------------------------------


def test_replace_single_line(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("a = 1\nb = 2\nc = 3\n")
    out = replace_lines(str(f), 2, 2, "b = 99\n")
    assert "Replaced 1 line" in out
    assert f.read_text() == "a = 1\nb = 99\nc = 3\n"


def test_replace_range(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("a\nb\nc\nd\ne\n")
    replace_lines(str(f), 2, 4, "X\nY\n")
    assert f.read_text() == "a\nX\nY\ne\n"


def test_replace_with_empty_text_deletes_range(tmp_path: Path) -> None:
    f = tmp_path / "x.txt"
    f.write_text("keep1\ngone1\ngone2\nkeep2\n")
    replace_lines(str(f), 2, 3, "")
    assert f.read_text() == "keep1\nkeep2\n"


def test_replace_appends_newline_if_missing(tmp_path: Path) -> None:
    f = tmp_path / "x.txt"
    f.write_text("a\nb\nc\n")
    replace_lines(str(f), 2, 2, "B")  # no trailing \n
    # Splice must add the \n so c isn't merged with B.
    assert f.read_text() == "a\nB\nc\n"


# ----- format preservation (the regression-guard test) -------------------


def test_replace_preserves_surrounding_comments(tmp_path: Path) -> None:
    """The whole reason this tool uses textual splice: surrounding
    comments and formatting must be byte-identical after the splice."""
    original = (
        '"""Module docstring."""\n'
        "\n"
        "# A leading comment.\n"
        "import os  # inline\n"
        "\n"
        "VAR = 'unchanged'  # important\n"
        "\n"
        "def existing():  # weird whitespace\n"
        "    pass\n"
    )
    f = tmp_path / "x.py"
    f.write_text(original)
    # Replace just line 6 (VAR = ...).
    replace_lines(str(f), 6, 6, "VAR = 'changed'  # important\n")
    new_text = f.read_text()
    # All other lines should be byte-identical.
    expected_kept = [
        '"""Module docstring."""',
        "# A leading comment.",
        "import os  # inline",
        "def existing():  # weird whitespace",
        "    pass",
    ]
    for line in expected_kept:
        assert line in new_text, f"surrounding line lost: {line!r}"
    assert "VAR = 'changed'" in new_text
    assert "VAR = 'unchanged'" not in new_text


# ----- syntax safety for .py files ---------------------------------------


def test_py_invalid_result_leaves_file_untouched(tmp_path: Path) -> None:
    """If the splice would produce invalid Python, the tool must bail
    and leave the file alone."""
    original = "def good():\n    return 1\n"
    f = tmp_path / "x.py"
    f.write_text(original)
    out = replace_lines(str(f), 1, 2, "def broken(:\n")
    assert "not valid Python" in out
    assert f.read_text() == original  # untouched


def test_non_py_files_skip_syntax_check(tmp_path: Path) -> None:
    """Plain-text files just splice — no Python validation."""
    f = tmp_path / "x.txt"
    f.write_text("a\nb\nc\n")
    out = replace_lines(str(f), 2, 2, "this is fine, not Python at all !!\n")
    assert "Replaced" in out


# ----- validation --------------------------------------------------------


def test_rejects_relative_path() -> None:
    out = replace_lines("relative.py", 1, 1, "x = 1\n")
    assert "must be absolute" in out


def test_rejects_missing_file(tmp_path: Path) -> None:
    out = replace_lines(str(tmp_path / "ghost.py"), 1, 1, "x = 1\n")
    assert "does not exist" in out


def test_rejects_zero_start_line(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("a = 1\n")
    out = replace_lines(str(f), 0, 1, "x = 1\n")
    assert "start_line must be >= 1" in out


def test_rejects_end_before_start(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("a\nb\nc\n")
    out = replace_lines(str(f), 3, 1, "x\n")
    assert "must be >= start_line" in out


def test_rejects_end_past_eof(tmp_path: Path) -> None:
    f = tmp_path / "x.py"
    f.write_text("a\nb\n")
    out = replace_lines(str(f), 1, 99, "x\n")
    assert "past end of file" in out
