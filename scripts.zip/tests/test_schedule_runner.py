"""Tests for the ScheduleRunner — fire-loop + missed-fire handling.

We exercise ``_tick`` and ``_handle_missed_at_startup`` directly with
a fake brain instead of standing up a real BrainWorker (those tests
need llama-cpp + a model).
"""

from __future__ import annotations

from datetime import datetime, timedelta
from pathlib import Path

import pytest

from navi.schedule import store as sched_store
from navi.schedule.runner import ScheduleRunner
from navi.schedule.store import Job, JobList, new_id


@pytest.fixture
def isolated_schedule(tmp_path: Path, monkeypatch):
    f = tmp_path / "scheduled.json"
    monkeypatch.setattr(sched_store, "schedule_path", lambda: f)
    return f


class _FakeBrain:
    """Minimal stand-in for BrainWorker — captures submitted prompts."""

    def __init__(self) -> None:
        self.submitted: list[str] = []

    def submit(self, prompt: str) -> None:
        self.submitted.append(prompt)


def _runner(brain, qapp, **kw) -> ScheduleRunner:
    """Build a runner without auto-starting the QTimer (we drive _tick
    manually so tests are deterministic)."""
    notes: list[str] = []
    r = ScheduleRunner(
        brain=brain,
        chat_note_cb=notes.append,
        tick_seconds=30,
        notify_on_fire=kw.get("notify_on_fire", False),
    )
    r._notes = notes  # type: ignore[attr-defined]
    return r


def _save_jobs(*jobs: Job) -> None:
    sched_store.save(JobList(jobs=list(jobs)))


def _iso(dt: datetime) -> str:
    return dt.replace(microsecond=0).isoformat()


# ----- _tick: due jobs fire -----------------------------------------------


def test_tick_fires_due_one_shot_and_deletes(qapp, isolated_schedule) -> None:
    brain = _FakeBrain()
    past = datetime.now() - timedelta(minutes=1)
    _save_jobs(Job(id=new_id(), pattern="in 5m", recurring=False,
                   next_fire=_iso(past), prompt="ping", created=_iso(past)))
    _runner(brain, qapp)._tick()

    assert brain.submitted == ["ping"]
    # One-shot deleted after firing.
    assert sched_store.load().jobs == []


def test_tick_fires_recurring_and_advances(qapp, isolated_schedule) -> None:
    brain = _FakeBrain()
    past = datetime.now() - timedelta(seconds=1)
    _save_jobs(Job(id=new_id(), pattern="every 30 minutes", recurring=True,
                   next_fire=_iso(past), prompt="ping", created=_iso(past)))
    _runner(brain, qapp)._tick()

    assert brain.submitted == ["ping"]
    jl = sched_store.load()
    assert len(jl.jobs) == 1, "recurring job should remain after firing"
    nxt = jl.jobs[0].next_fire_dt
    assert nxt > datetime.now(), "next_fire should be advanced into the future"


def test_tick_skips_future_jobs(qapp, isolated_schedule) -> None:
    brain = _FakeBrain()
    future = datetime.now() + timedelta(hours=1)
    _save_jobs(Job(id=new_id(), pattern="in 1h", recurring=False,
                   next_fire=_iso(future), prompt="later", created=_iso(future)))
    _runner(brain, qapp)._tick()

    assert brain.submitted == []
    assert len(sched_store.load().jobs) == 1  # untouched


# ----- startup missed-fire handling --------------------------------------


def test_startup_missed_one_shot_emits_note_and_deletes(qapp,
                                                        isolated_schedule) -> None:
    """Critical safety: scheduler should NOT fire a missed-while-offline
    one-shot. The user wasn't there at the original time."""
    brain = _FakeBrain()
    past = datetime.now() - timedelta(days=1)
    _save_jobs(Job(id=new_id(), pattern="yesterday at noon", recurring=False,
                   next_fire=_iso(past), prompt="noon meeting", created=_iso(past)))
    r = _runner(brain, qapp)
    r._handle_missed_at_startup()

    assert brain.submitted == [], "missed one-shots must NOT auto-fire on startup"
    assert sched_store.load().jobs == []
    # User should be told about the missed task.
    assert any("missed scheduled task" in n for n in r._notes)  # type: ignore[attr-defined]


def test_startup_missed_recurring_advances_silently(qapp,
                                                    isolated_schedule) -> None:
    """Critical: a daily job that's been missed for a week should NOT
    fire 7 times back-to-back at startup. Just advance to next future."""
    brain = _FakeBrain()
    past = datetime.now() - timedelta(days=7)
    _save_jobs(Job(id=new_id(), pattern="every 30 minutes", recurring=True,
                   next_fire=_iso(past), prompt="ping", created=_iso(past)))
    r = _runner(brain, qapp)
    r._handle_missed_at_startup()

    assert brain.submitted == [], (
        "missed recurring fires must NOT all run at startup"
    )
    jl = sched_store.load()
    assert len(jl.jobs) == 1
    assert jl.jobs[0].next_fire_dt > datetime.now()


# ----- notify_on_fire integration -----------------------------------------


def test_notify_on_fire_emits_notification(qapp, isolated_schedule,
                                           monkeypatch) -> None:
    """When notify_on_fire=True, firing should also emit a notification."""
    from navi.brain import shared
    received: list[tuple[str, str]] = []
    shared.set_notify_callback(lambda t, m: received.append((t, m)))

    brain = _FakeBrain()
    past = datetime.now() - timedelta(seconds=1)
    _save_jobs(Job(id=new_id(), pattern="in 1s", recurring=False,
                   next_fire=_iso(past), prompt="alarm", created=_iso(past)))
    r = _runner(brain, qapp, notify_on_fire=True)
    r._tick()

    assert brain.submitted == ["alarm"]
    assert len(received) == 1
    assert "alarm" in received[0][1]
    shared._notify_cb = None  # noqa: SLF001 — cleanup
