from __future__ import annotations

from pathlib import Path

import pytest


@pytest.fixture
def isolated_navi_dirs(tmp_path: Path, monkeypatch) -> Path:  # type: ignore[no-untyped-def]
    """Redirect Navi's APPDATA-rooted paths into ``tmp_path``.

    Covers memory dir, settings.json, and soul.md so prompt-assembly tests
    don't read or write the user's real %APPDATA%/Navi directory.
    """
    from navi.brain import persona
    from navi.memory import store
    from navi.perms import engine as perms_engine
    from navi.settings import store as settings_store

    mem = tmp_path / "memory"
    mem.mkdir()
    monkeypatch.setattr(store, "memory_dir", lambda: mem)

    sp = tmp_path / "settings.json"
    monkeypatch.setattr(perms_engine, "settings_path", lambda: sp)
    monkeypatch.setattr(settings_store, "settings_path", lambda: sp)

    monkeypatch.setattr(persona, "soul_path", lambda: tmp_path / "soul.md")
    return tmp_path
