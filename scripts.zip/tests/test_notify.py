"""Tests for the notify tool + shared notify callback wiring."""

from __future__ import annotations

import pytest

from navi.brain import shared
from navi.tools import get_tool
from navi.tools.notify_tool import notify


@pytest.fixture(autouse=True)
def _reset_notify_cb():
    """Each test starts with a clean callback slot."""
    shared._notify_cb = None  # noqa: SLF001
    yield
    shared._notify_cb = None  # noqa: SLF001


# ----- registration --------------------------------------------------------


def test_registered_low_risk() -> None:
    t = get_tool("notify")
    assert t is not None
    # Notifications steal focus → permission gate, but not 'high'.
    assert t.risk == "low"


# ----- happy path ----------------------------------------------------------


def test_notify_invokes_callback() -> None:
    received: list[tuple[str, str]] = []
    shared.set_notify_callback(lambda title, msg: received.append((title, msg)))

    out = notify("Heads up", "your test passed")
    assert "Notified" in out
    assert received == [("Heads up", "your test passed")]


def test_notify_strips_whitespace_and_defaults_title() -> None:
    received: list[tuple[str, str]] = []
    shared.set_notify_callback(lambda title, msg: received.append((title, msg)))

    notify("  ", "body")
    assert received[0][0] == "Navi"  # default when title blank


def test_notify_skipped_when_no_callback(isolated_navi_dirs) -> None:
    out = notify("X", "Y")
    # No callback → friendly skip message, not silent success.
    assert "skipped" in out.lower()


# ----- validation ----------------------------------------------------------


def test_notify_rejects_empty_message() -> None:
    out = notify("Title", "")
    assert "message is required" in out


# ----- settings respect ---------------------------------------------------


def test_notify_disabled_via_settings(isolated_navi_dirs) -> None:
    """When notify.enabled=false, the tool should refuse politely
    without invoking the callback."""
    from navi.settings.store import load, save
    s = load()
    s.setdefault("notify", {})["enabled"] = False
    save(s)

    received: list = []
    shared.set_notify_callback(lambda *_: received.append(1))

    out = notify("X", "Y")
    assert "disabled" in out
    assert received == []
