from __future__ import annotations

from pathlib import Path

import pytest

from navi.brain.persona import SYSTEM_PROMPT, build_system_prompt
from navi.memory import store
from navi.perms import engine as perms_engine
from navi.settings import store as settings_store


@pytest.fixture
def tmp_memory_dir(tmp_path: Path, monkeypatch) -> Path:  # type: ignore[no-untyped-def]
    # Isolate memory dir
    mem = tmp_path / "memory"
    mem.mkdir()
    monkeypatch.setattr(store, "memory_dir", lambda: mem)
    # AND isolate settings — build_system_prompt reads persona override from
    # settings.json, which would otherwise leak from the user's real config.
    sp = tmp_path / "settings.json"
    monkeypatch.setattr(perms_engine, "settings_path", lambda: sp)
    monkeypatch.setattr(settings_store, "settings_path", lambda: sp)
    return mem


def test_no_memory_returns_base_prompt(tmp_memory_dir: Path) -> None:
    assert build_system_prompt() == SYSTEM_PROMPT


def test_memory_index_appended_to_prompt(tmp_memory_dir: Path) -> None:
    store.save_memory(
        title="Coffee", description="black no sugar", type="user", content="black."
    )
    out = build_system_prompt()
    assert SYSTEM_PROMPT in out
    assert "Saved memories" in out
    assert "Coffee" in out
    assert "black no sugar" in out
