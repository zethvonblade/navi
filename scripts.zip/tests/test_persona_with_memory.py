from __future__ import annotations

from pathlib import Path

from navi.brain.persona import _HARD_RULES, build_system_prompt, load_soul
from navi.memory import store


def test_no_memory_returns_base_prompt(isolated_navi_dirs: Path) -> None:
    out = build_system_prompt()
    # Soul + hard rules present; no memory section appended.
    assert load_soul() in out
    assert _HARD_RULES in out
    assert "Saved memories" not in out


def test_memory_index_appended_to_prompt(isolated_navi_dirs: Path) -> None:
    store.save_memory(
        title="Coffee", description="black no sugar", type="user", content="black."
    )
    out = build_system_prompt()
    assert load_soul() in out
    assert _HARD_RULES in out
    assert "Saved memories" in out
    assert "Coffee" in out
    assert "black no sugar" in out
