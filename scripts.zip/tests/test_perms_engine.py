from __future__ import annotations

from navi.perms.engine import Decision, Mode, PermissionEngine, _glob_to_regex


def make_engine(allow=None, ask=None, deny=None, mode="default") -> PermissionEngine:
    return PermissionEngine({
        "defaultMode": mode,
        "permissions": {
            "allow": allow or [],
            "ask": ask or [],
            "deny": deny or [],
        },
    })


def test_no_args_tool_allowed_by_bare_rule() -> None:
    eng = make_engine(allow=["read_clipboard"])
    assert eng.evaluate("read_clipboard", {}, "safe") is Decision.ALLOW


def test_unrelated_tool_falls_back_to_risk() -> None:
    eng = make_engine(allow=["read_clipboard"])
    # take_screenshot has no rule, but risk=safe -> allow
    assert eng.evaluate("take_screenshot", {}, "safe") is Decision.ALLOW
    # high risk falls back to ask
    assert eng.evaluate("run_powershell", {"cmd": "ls"}, "high") is Decision.ASK


def test_deny_beats_allow() -> None:
    eng = make_engine(
        allow=["read_file(C:/Users/me/**)"],
        deny=["read_file(**/.env*)"],
    )
    assert (
        eng.evaluate("read_file", {"path": "C:/Users/me/.env"}, "low") is Decision.DENY
    )
    assert (
        eng.evaluate("read_file", {"path": "C:/Users/me/notes.txt"}, "low")
        is Decision.ALLOW
    )


def test_specific_allow_exempts_from_broad_ask() -> None:
    # Order: deny -> allow -> ask. A specific allow exempts a path from a
    # broad ask catch-all.
    eng = make_engine(
        allow=["read_file(C:/projects/**)"],
        ask=["read_file"],  # bare = match-any-args
    )
    # Allowed because the specific allow rule wins over the broad ask
    assert (
        eng.evaluate("read_file", {"path": "C:/projects/x.txt"}, "low")
        is Decision.ALLOW
    )
    # Falls through to ask for a path the allow doesn't cover
    assert (
        eng.evaluate("read_file", {"path": "D:/elsewhere.txt"}, "low") is Decision.ASK
    )


def test_glob_separator_neutrality() -> None:
    eng = make_engine(allow=["read_file(C:/Users/me/**)"])
    # backslash arg matches forward-slash pattern
    assert (
        eng.evaluate("read_file", {"path": "C:\\Users\\me\\notes.txt"}, "low")
        is Decision.ALLOW
    )


def test_doublestar_crosses_separators() -> None:
    eng = make_engine(deny=["read_file(**/.ssh/**)"])
    assert (
        eng.evaluate("read_file", {"path": "C:/Users/me/.ssh/id_rsa"}, "low")
        is Decision.DENY
    )


def test_single_star_does_not_cross_separator() -> None:
    pat = _glob_to_regex("C:/Users/*/notes.txt")
    import re
    rx = re.compile(pat, re.IGNORECASE)
    assert rx.match("C:/Users/me/notes.txt")
    assert not rx.match("C:/Users/me/sub/notes.txt")


def test_plan_mode_denies_everything() -> None:
    eng = make_engine(allow=["read_clipboard"], mode="plan")
    assert eng.evaluate("read_clipboard", {}, "safe") is Decision.DENY


def test_bypass_mode_allows_everything() -> None:
    eng = make_engine(deny=["read_file(**)"], mode="bypass")
    assert (
        eng.evaluate("read_file", {"path": "C:/Windows/system32/anything"}, "high")
        is Decision.ALLOW
    )


def test_unknown_tool_with_low_risk_allowed() -> None:
    eng = make_engine()
    assert eng.evaluate("never_heard_of_it", {}, "low") is Decision.ALLOW


def test_modes_enum_values() -> None:
    assert Mode("default") is Mode.DEFAULT
    assert Mode("plan") is Mode.PLAN
    assert Mode("acceptEdits") is Mode.ACCEPT_EDITS
    assert Mode("bypass") is Mode.BYPASS
