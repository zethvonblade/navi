from __future__ import annotations

from pathlib import Path

import pytest

from navi.brain import persona
from navi.brain.persona import (
    _BUNDLED_SOUL,
    _EMBEDDED_SOUL_FALLBACK,
    _HARD_RULES,
    DEFAULT_SOUL_NAME,
    apply_soul_template,
    build_system_prompt,
    get_active_soul_name,
    list_souls,
    load_soul,
    reset_soul,
    restore_soul_from_backup,
    soul_backup_path,
    soul_path,
    template_path,
)
from navi.settings import store as settings_store

EXPECTED_TEMPLATES = ("companion", "concise", "mentor", "operator", "sentinel")


def test_bundled_soul_file_exists() -> None:
    """The default template ships with the package."""
    assert _BUNDLED_SOUL.exists(), f"missing bundled soul at {_BUNDLED_SOUL}"
    text = _BUNDLED_SOUL.read_text(encoding="utf-8")
    assert "Navi" in text
    assert len(text) > 100


def test_all_five_templates_ship() -> None:
    """All five archetypes are bundled and non-trivial."""
    names = list_souls()
    assert tuple(names) == EXPECTED_TEMPLATES
    for name in names:
        body = template_path(name).read_text(encoding="utf-8")
        assert len(body) > 100, f"{name}.md looks empty/stub"
        assert "Navi" in body


def test_default_template_is_operator() -> None:
    assert DEFAULT_SOUL_NAME == "operator"
    assert _BUNDLED_SOUL == template_path("operator")


def test_first_run_copies_bundled_soul(isolated_navi_dirs: Path) -> None:
    """If %APPDATA%/Navi/soul.md doesn't exist, load_soul() creates it."""
    target = isolated_navi_dirs / "soul.md"
    assert not target.exists()
    text = load_soul()
    assert target.exists()
    assert text in target.read_text(encoding="utf-8")
    # Second call doesn't re-copy or modify
    mtime = target.stat().st_mtime_ns
    text2 = load_soul()
    assert text2 == text
    assert target.stat().st_mtime_ns == mtime


def test_user_edits_to_soul_are_picked_up(isolated_navi_dirs: Path) -> None:
    """Soul is read fresh every call — edits take effect without restart."""
    load_soul()  # first-run copy
    target = isolated_navi_dirs / "soul.md"
    target.write_text("# Custom Navi\n\nI am a different shape today.", encoding="utf-8")
    text = load_soul()
    assert "different shape" in text


def test_build_system_prompt_composition(isolated_navi_dirs: Path) -> None:
    """build_system_prompt = preamble + soul + hard_rules (no memory)."""
    prompt = build_system_prompt()
    soul = load_soul()
    assert soul in prompt
    assert _HARD_RULES in prompt
    # Hard rules must come AFTER soul — last instruction wins, so users
    # can't override anti-failure rules by editing soul.md.
    assert prompt.index(soul) < prompt.index(_HARD_RULES)


def test_persona_override_replaces_soul_and_hard_rules(isolated_navi_dirs: Path) -> None:
    """Setting ui.personaPrompt is a full opt-out — soul + hard rules skipped."""
    settings_store.save({"ui": {"personaPrompt": "JUST THIS PLEASE"}})
    prompt = build_system_prompt()
    assert "JUST THIS PLEASE" in prompt
    assert _HARD_RULES not in prompt
    # Bundled soul content shouldn't leak in either
    bundled = _BUNDLED_SOUL.read_text(encoding="utf-8").strip()
    assert bundled not in prompt


def test_soul_falls_back_when_bundled_missing(
    isolated_navi_dirs: Path, monkeypatch
) -> None:  # type: ignore[no-untyped-def]
    """If the bundled file is gone (broken install), embedded fallback is used."""
    bogus = isolated_navi_dirs / "does_not_exist.md"
    monkeypatch.setattr(persona, "_BUNDLED_SOUL", bogus)
    text = load_soul()
    assert text == _EMBEDDED_SOUL_FALLBACK.strip()


def test_apply_soul_template_overwrites_and_backs_up(
    isolated_navi_dirs: Path,
) -> None:
    """Switching templates writes the template body and saves a backup."""
    load_soul()  # first-run copy of operator
    soul_file = isolated_navi_dirs / "soul.md"
    original = soul_file.read_text(encoding="utf-8")

    apply_soul_template("concise")

    assert "Concise" in soul_file.read_text(encoding="utf-8")
    backup = soul_backup_path()
    assert backup.exists()
    assert backup.read_text(encoding="utf-8") == original


def test_apply_soul_template_unknown_name_raises(isolated_navi_dirs: Path) -> None:
    with pytest.raises(FileNotFoundError):
        apply_soul_template("does-not-exist")


def test_apply_soul_template_when_no_existing_soul(
    isolated_navi_dirs: Path,
) -> None:
    """Switching with no soul.md present skips backup but still writes."""
    soul_file = isolated_navi_dirs / "soul.md"
    assert not soul_file.exists()
    apply_soul_template("mentor")
    assert "Mentor" in soul_file.read_text(encoding="utf-8")
    assert not soul_backup_path().exists()


def test_apply_soul_template_records_active_name(isolated_navi_dirs: Path) -> None:
    apply_soul_template("sentinel")
    assert get_active_soul_name() == "sentinel"


def test_get_active_soul_name_defaults_to_operator(isolated_navi_dirs: Path) -> None:
    """No template ever applied → fall back to DEFAULT_SOUL_NAME."""
    assert get_active_soul_name() == DEFAULT_SOUL_NAME


def test_reset_soul_discards_edits_and_reapplies(isolated_navi_dirs: Path) -> None:
    """Reset re-applies the active template; user edits land in the backup."""
    apply_soul_template("mentor")
    soul_file = isolated_navi_dirs / "soul.md"
    backup_file = isolated_navi_dirs / "soul.backup.md"
    soul_file.write_text("# my edits\n\nNot mentor anymore.", encoding="utf-8")

    name = reset_soul()

    assert name == "mentor"
    assert "Mentor" in soul_file.read_text(encoding="utf-8")
    # Edits preserved in backup so the user can /soul restore.
    assert "my edits" in backup_file.read_text(encoding="utf-8")


def test_restore_soul_swaps_with_backup(isolated_navi_dirs: Path) -> None:
    """Restore swaps soul.md ↔ soul.backup.md (toggle/redo behavior)."""
    apply_soul_template("operator")
    apply_soul_template("concise")  # backup is now operator
    soul_file = isolated_navi_dirs / "soul.md"
    backup_file = isolated_navi_dirs / "soul.backup.md"
    assert "Concise" in soul_file.read_text(encoding="utf-8")
    assert "Operator" in backup_file.read_text(encoding="utf-8")

    # First restore: get operator back, concise lands in backup.
    assert restore_soul_from_backup() is True
    assert "Operator" in soul_file.read_text(encoding="utf-8")
    assert "Concise" in backup_file.read_text(encoding="utf-8")

    # Second restore acts as redo.
    assert restore_soul_from_backup() is True
    assert "Concise" in soul_file.read_text(encoding="utf-8")
    assert "Operator" in backup_file.read_text(encoding="utf-8")


def test_restore_soul_returns_false_when_no_backup(isolated_navi_dirs: Path) -> None:
    load_soul()  # first-run, no backup yet
    backup_file = isolated_navi_dirs / "soul.backup.md"
    assert not backup_file.exists()
    assert restore_soul_from_backup() is False
