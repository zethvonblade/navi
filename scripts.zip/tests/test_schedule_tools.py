"""Tests for the schedule_tools (parser + CRUD).

Covers parse_when corner cases (the dateparser shim) and the four
LLM-callable scheduling tools. The runner is tested separately
(test_schedule_runner.py).
"""

from __future__ import annotations

import os
from datetime import datetime, timedelta
from pathlib import Path

import pytest

from navi.schedule import store as sched_store
from navi.schedule.parse import next_fire_for_pattern, parse_when
from navi.tools import get_tool
from navi.tools.schedule_tools import (
    cancel_scheduled,
    list_scheduled,
    schedule_once,
    schedule_recurring,
)


@pytest.fixture
def isolated_schedule(tmp_path: Path, monkeypatch):
    """Redirect the schedule.json path into tmp_path so tests don't
    touch the real %APPDATA% file."""
    f = tmp_path / "scheduled.json"
    monkeypatch.setattr(sched_store, "schedule_path", lambda: f)
    return f


# ----- parser shim --------------------------------------------------------


def test_parse_relative_minutes() -> None:
    base = datetime(2026, 5, 4, 12, 0, 0)
    assert parse_when("in 5 minutes", base) == base + timedelta(minutes=5)


def test_parse_shorthand_intervals() -> None:
    base = datetime(2026, 5, 4, 12, 0, 0)
    assert parse_when("15m", base) == base + timedelta(minutes=15)
    assert parse_when("2h", base) == base + timedelta(hours=2)
    assert parse_when("3d", base) == base + timedelta(days=3)
    assert parse_when("1w", base) == base + timedelta(weeks=1)


def test_parse_keyword_intervals() -> None:
    base = datetime(2026, 5, 4, 12, 0, 0)
    assert parse_when("hourly", base) == base + timedelta(hours=1)
    assert parse_when("daily", base) == base + timedelta(days=1)
    assert parse_when("weekly", base) == base + timedelta(weeks=1)


def test_parse_strips_every_prefix() -> None:
    """The 'every X' prefix confuses dateparser; the shim strips it."""
    base = datetime(2026, 5, 4, 12, 0, 0)
    assert parse_when("every 15 minutes", base) == base + timedelta(minutes=15)
    assert parse_when("every hour", base) == base + timedelta(hours=1)


def test_parse_weekday_at_time() -> None:
    """The most common recurring shape: 'every monday at 9am'."""
    base = datetime(2026, 5, 4, 12, 0, 0)  # a Monday at noon
    out = parse_when("every monday at 9am", base)
    assert out is not None
    # Next Monday 9am, not today (already past noon).
    assert out.weekday() == 0
    assert out.hour == 9
    assert out > base


def test_parse_absolute_iso() -> None:
    out = parse_when("2026-12-31T15:00")
    assert out is not None
    assert out.year == 2026 and out.month == 12 and out.day == 31


def test_parse_garbage_returns_none() -> None:
    assert parse_when("absolutely not a time at all !!!") is None
    assert parse_when("") is None
    assert parse_when("   ") is None


def test_next_fire_for_pattern_advances_after_now() -> None:
    """Recurring jobs use this on every fire to compute the next slot."""
    after = datetime(2026, 5, 4, 12, 0, 0)
    nxt = next_fire_for_pattern("every 30 minutes", after=after)
    assert nxt == after + timedelta(minutes=30)


# ----- registration --------------------------------------------------------


@pytest.mark.parametrize("name,risk", [
    ("schedule_once", "medium"),
    ("schedule_recurring", "medium"),
    ("list_scheduled", "safe"),
    ("cancel_scheduled", "medium"),
])
def test_registered_with_expected_risk(name: str, risk: str) -> None:
    t = get_tool(name)
    assert t is not None
    assert t.risk == risk


# ----- schedule_once -------------------------------------------------------


def test_schedule_once_creates_entry(isolated_schedule: Path) -> None:
    out = schedule_once("in 5 minutes", "take a break")
    assert "Scheduled (one-shot)" in out
    jl = sched_store.load()
    assert len(jl.jobs) == 1
    job = jl.jobs[0]
    assert job.recurring is False
    assert job.prompt == "take a break"
    assert job.pattern == "in 5 minutes"


def test_schedule_once_rejects_unparseable(isolated_schedule: Path) -> None:
    out = schedule_once("blarghhh", "do something")
    assert "could not parse" in out
    assert sched_store.load().jobs == []


def test_schedule_once_rejects_empty_prompt(isolated_schedule: Path) -> None:
    out = schedule_once("in 5 minutes", "")
    assert "prompt is required" in out


def test_schedule_once_rejects_past_time(isolated_schedule: Path) -> None:
    """ISO time in the past should be refused — firing immediately
    would surprise the user."""
    out = schedule_once("2020-01-01T00:00", "do something")
    assert "in the past" in out


# ----- schedule_recurring --------------------------------------------------


def test_schedule_recurring_creates_recurring_entry(isolated_schedule: Path) -> None:
    out = schedule_recurring("every 5 minutes", "ping me")
    assert "Scheduled (recurring)" in out
    jl = sched_store.load()
    assert len(jl.jobs) == 1
    assert jl.jobs[0].recurring is True
    assert jl.jobs[0].pattern == "every 5 minutes"


# ----- list_scheduled -----------------------------------------------------


def test_list_scheduled_empty(isolated_schedule: Path) -> None:
    assert "no scheduled jobs" in list_scheduled()


def test_list_scheduled_shows_jobs(isolated_schedule: Path) -> None:
    schedule_once("in 5 minutes", "first")
    schedule_recurring("hourly", "second")
    out = list_scheduled()
    assert "2 scheduled job(s)" in out
    assert "first" in out
    assert "second" in out


# ----- cancel_scheduled ---------------------------------------------------


def test_cancel_removes_entry(isolated_schedule: Path) -> None:
    schedule_once("in 5 minutes", "doomed")
    job_id = sched_store.load().jobs[0].id
    out = cancel_scheduled(job_id)
    assert "Cancelled" in out
    assert sched_store.load().jobs == []


def test_cancel_unknown_id(isolated_schedule: Path) -> None:
    out = cancel_scheduled("notarealid")
    assert "No job" in out


def test_cancel_rejects_empty(isolated_schedule: Path) -> None:
    assert "required" in cancel_scheduled("")
