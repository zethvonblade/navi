from __future__ import annotations

from navi.tools import get_tool


def test_write_file_writes_content(tmp_path) -> None:  # type: ignore[no-untyped-def]
    target = tmp_path / "sub" / "out.txt"
    t = get_tool("write_file")
    assert t is not None
    out = t.func(path=str(target), content="hello world")
    assert "Wrote" in out
    assert target.read_text(encoding="utf-8") == "hello world"


def test_write_file_rejects_relative(tmp_path) -> None:  # type: ignore[no-untyped-def]
    t = get_tool("write_file")
    assert t is not None
    out = t.func(path="relative/x.txt", content="x")
    assert "must be absolute" in out


def test_write_file_refuses_docx(tmp_path) -> None:  # type: ignore[no-untyped-def]
    t = get_tool("write_file")
    assert t is not None
    out = t.func(path=str(tmp_path / "thing.docx"), content="x")
    assert "binary" in out.lower()


def test_write_clipboard_roundtrip() -> None:
    import pytest

    write = get_tool("write_clipboard")
    read = get_tool("read_clipboard")
    assert write is not None and read is not None
    out = write.func(text="phase4-clipboard-token")
    if out.startswith("Error"):
        # Windows clipboard can be transiently locked by another process when
        # the test runs headlessly. Not a logic bug — skip rather than flake.
        pytest.skip(f"Clipboard busy: {out}")
    assert "Wrote" in out
    assert read.func() == "phase4-clipboard-token"


def test_open_url_rejects_non_http() -> None:
    t = get_tool("open_url")
    assert t is not None
    out = t.func(url="javascript:alert(1)")
    assert "Error" in out

    out = t.func(url="file:///etc/passwd")
    assert "Error" in out
