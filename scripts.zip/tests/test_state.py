from __future__ import annotations

from navi.pet.state import NaviState, StateBus


def test_state_bus_starts_idle() -> None:
    bus = StateBus()
    assert bus.state is NaviState.IDLE


def test_state_bus_emits_on_change(qtbot) -> None:  # type: ignore[no-untyped-def]
    bus = StateBus()
    with qtbot.waitSignal(bus.changed, timeout=200) as blocker:
        bus.set(NaviState.THINKING)
    assert blocker.args == [NaviState.THINKING]
    assert bus.state is NaviState.THINKING


def test_state_bus_no_emit_on_same(qtbot) -> None:  # type: ignore[no-untyped-def]
    bus = StateBus()
    received: list[NaviState] = []
    bus.changed.connect(received.append)
    bus.set(NaviState.IDLE)
    qtbot.wait(50)
    assert received == []
