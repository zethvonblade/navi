"""Tests for the stack-context injection in persona.build_system_prompt.

Two scopes:

* Default path: when ``settings.scaffold.active_stack`` is set, the
  StackSpec's style_guide appears in the system prompt.
* **Plan-agent fix #1**: even when ``settings.ui.personaPrompt`` is set
  (a custom override that bypasses the soul + hard-rules path), the
  stack guide must still be appended. Without this, every user with a
  custom persona silently loses stack awareness.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from navi.brain.persona import build_system_prompt
from navi.scaffold.stacks import STACKS
from navi.settings.store import save


@pytest.fixture
def isolated_settings(isolated_navi_dirs: Path) -> Path:
    """Reuses the conftest fixture that redirects APPDATA paths into
    tmp. Returns the tmp dir."""
    return isolated_navi_dirs


def _set_active_stack(stack_id: str | None) -> None:
    """Write a settings.json with the given active_stack and nothing
    else of consequence — settings deep-merge fills the rest."""
    from navi.settings.store import load
    s = load()
    s.setdefault("scaffold", {})["active_stack"] = stack_id
    save(s)


# ----- default path (no persona override) ---------------------------------


def test_no_stack_means_no_injection(isolated_settings: Path) -> None:
    _set_active_stack(None)
    prompt = build_system_prompt()
    assert "## Active stack" not in prompt


def test_active_stack_injects_style_guide(isolated_settings: Path) -> None:
    _set_active_stack("python-cli")
    prompt = build_system_prompt()
    assert "## Active stack" in prompt
    # Prompt must contain the actual style guide text from the spec.
    expected_marker = STACKS["python-cli"].style_guide.split(".")[0]
    assert expected_marker in prompt


def test_unknown_stack_does_not_inject(isolated_settings: Path) -> None:
    _set_active_stack("not-a-real-stack")
    prompt = build_system_prompt()
    assert "## Active stack" not in prompt


def test_switching_stacks_changes_prompt(isolated_settings: Path) -> None:
    _set_active_stack("python-cli")
    p1 = build_system_prompt()
    _set_active_stack("python-pytest-lib")
    p2 = build_system_prompt()
    # Both contain the section header but different bodies.
    assert "## Active stack" in p1 and "## Active stack" in p2
    assert STACKS["python-cli"].style_guide in p1
    assert STACKS["python-pytest-lib"].style_guide in p2
    assert STACKS["python-cli"].style_guide not in p2


# ----- the Plan-agent fix #1 test ----------------------------------------


def test_stack_injects_under_persona_override(isolated_settings: Path) -> None:
    """The bug we're guarding against: persona.py originally used the
    user_override branch in isolation, so setting personaPrompt would
    silently drop stack awareness. The fix appends stack ctx AFTER the
    override branch."""
    from navi.settings.store import load
    s = load()
    s.setdefault("ui", {})["personaPrompt"] = "I am a custom persona."
    s.setdefault("scaffold", {})["active_stack"] = "python-cli"
    save(s)

    prompt = build_system_prompt()
    # Both must be present.
    assert "I am a custom persona." in prompt
    assert "## Active stack" in prompt
    assert STACKS["python-cli"].style_guide in prompt
