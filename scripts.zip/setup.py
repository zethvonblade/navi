"""Dual-purpose script: dev-env bootstrap AND setuptools build shim.

Why this file exists in two roles
---------------------------------
The package metadata for Navi lives in ``pyproject.toml`` — there is no real
need for a ``setup.py``. But you wanted a one-shot bootstrap you can run on a
fresh clone with just ``python setup.py``. The catch: when pip / setuptools
build the project (e.g. during ``pip install -e .``), they will discover this
file and execute it as a setuptools script. If we just ran the bootstrap
unconditionally we'd recurse forever.

So this file dispatches based on how it's being called:

* **Invoked by you with no args** → run the dev-environment bootstrap.
* **Invoked by pip / setuptools with build commands as args** → call
  ``setuptools.setup()``, which reads everything from ``pyproject.toml``.

Direct usage
------------
    python setup.py            # creates .venv, installs requirements

What the bootstrap does
-----------------------
1. Locates a Python 3.12 interpreter on this machine.
2. Creates ``.venv/`` if absent (idempotent — safe to re-run).
3. Upgrades pip inside the venv.
4. Installs pinned dependencies from ``requirements.txt``
   (which declares the llama-cpp-python custom index).
5. Installs ``navi`` itself in editable mode.
6. Runs an import smoke test.

Uses stdlib only so it works on a freshly cloned repo with nothing installed.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Dispatch: setuptools build vs user bootstrap
# ---------------------------------------------------------------------------
# When pip/setuptools call this file, sys.argv has commands like
# `egg_info`, `develop`, `bdist_wheel`, `editable_wheel`, `dist_info`, or
# `--build-option`/etc. A direct user invocation (`python setup.py`) has no
# args. We treat any argv beyond the script name as a build invocation and
# delegate to setuptools — which reads pyproject.toml for everything.
if len(sys.argv) > 1:
    from setuptools import setup
    setup()
    sys.exit(0)

# ---------------------------------------------------------------------------
# Bootstrap mode
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent
VENV_DIR = PROJECT_ROOT / ".venv"
REQUIREMENTS = PROJECT_ROOT / "requirements.txt"

CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
DIM = "\033[2m"
RESET = "\033[0m"


def step(msg: str) -> None:
    print(f"{CYAN}[setup]{RESET} {msg}")


def ok(msg: str) -> None:
    print(f"{GREEN}[setup]{RESET} {msg}")


def warn(msg: str) -> None:
    print(f"{YELLOW}[setup]{RESET} {msg}")


def die(msg: str) -> None:
    print(f"{RED}[setup] error:{RESET} {msg}", file=sys.stderr)
    sys.exit(1)


def venv_python() -> Path:
    if os.name == "nt":
        return VENV_DIR / "Scripts" / "python.exe"
    return VENV_DIR / "bin" / "python"


def find_system_python() -> str:
    """Locate a Python 3.12 interpreter to seed the venv with.

    Tries (in order):
      1. The current interpreter, if it's 3.12.
      2. ``py -3.12`` (Windows launcher).
      3. ``python3.12`` on PATH.
      4. Known anaconda location on this machine.
      5. ``python`` on PATH (last resort; warned if not 3.12).
    """
    if sys.version_info[:2] == (3, 12):
        return sys.executable

    if os.name == "nt" and shutil.which("py"):
        try:
            out = subprocess.run(
                ["py", "-3.12", "-c", "import sys; print(sys.executable)"],
                capture_output=True, text=True, check=True,
            )
            return out.stdout.strip()
        except subprocess.CalledProcessError:
            pass

    found = shutil.which("python3.12")
    if found:
        return found

    candidate = Path(r"C:\ProgramData\anaconda3\python.exe")
    if candidate.exists():
        return str(candidate)

    found = shutil.which("python")
    if found:
        warn(
            f"could not locate Python 3.12 explicitly; falling back to "
            f"`{found}` — version will be checked after venv creation."
        )
        return found

    die(
        "no Python interpreter found. Install Python 3.12 from "
        "https://www.python.org/ and re-run."
    )
    raise SystemExit(1)  # for type checkers


def run(cmd: list[str]) -> None:
    print(f"{DIM}    $ {' '.join(cmd)}{RESET}")
    result = subprocess.run(cmd)
    if result.returncode != 0:
        die(f"command failed (exit {result.returncode}): {' '.join(cmd)}")


def main() -> None:
    if os.name == "nt":
        os.system("")  # enable ANSI on legacy Windows terminals

    print(f"{CYAN}=== Navi dev-environment bootstrap ==={RESET}")
    print(f"    project root: {PROJECT_ROOT}")

    if not REQUIREMENTS.exists():
        die(f"missing {REQUIREMENTS} — are you running from the project root?")

    # --- Create venv if needed --------------------------------------------
    py = venv_python()
    if py.exists():
        step(".venv already exists — reusing it.")
    else:
        seed = find_system_python()
        step(f"creating .venv using {seed}")
        run([seed, "-m", "venv", str(VENV_DIR)])
        if not py.exists():
            die(f"venv created but {py} is missing")

    # --- Verify version ---------------------------------------------------
    out = subprocess.run(
        [str(py), "-c",
         "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"],
        capture_output=True, text=True, check=True,
    )
    ver = out.stdout.strip()
    if ver != "3.12":
        warn(f".venv is on Python {ver}; project requires 3.12.x. Continuing.")
    else:
        ok(f".venv on Python {ver}")

    # --- Ensure pip exists in the venv ------------------------------------
    # `python -m venv` skips bundled pip when the seed interpreter has the
    # pip wheel marked unavailable (some conda Pythons do this). Bootstrap
    # via ensurepip if needed.
    pip_check = subprocess.run([str(py), "-m", "pip", "--version"],
                               capture_output=True, text=True)
    if pip_check.returncode != 0:
        step("pip missing in .venv — bootstrapping with ensurepip")
        run([str(py), "-m", "ensurepip", "--upgrade"])

    # --- Upgrade pip ------------------------------------------------------
    step("upgrading pip")
    run([str(py), "-m", "pip", "install", "--upgrade", "pip"])

    # --- Install pinned deps ---------------------------------------------
    step("installing pinned dependencies (requirements.txt)")
    run([str(py), "-m", "pip", "install", "-r", str(REQUIREMENTS)])

    # --- Install navi in editable mode -----------------------------------
    step("installing navi in editable mode")
    run([str(py), "-m", "pip", "install", "--no-deps", "-e", str(PROJECT_ROOT)])

    # --- Smoke test ------------------------------------------------------
    step("smoke test: import navi")
    run([str(py), "-c", "import navi; print('    navi at', navi.__file__)"])

    print()
    ok("done.")
    print(f"    run:    {py.relative_to(PROJECT_ROOT)} -m navi")
    print(f"    test:   {py.relative_to(PROJECT_ROOT)} -m pytest -q")


if __name__ == "__main__":
    main()
