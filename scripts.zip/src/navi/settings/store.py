"""Settings persistence — extends the JSON file used by the permission engine.

Schema (``%APPDATA%/Navi/settings.json``)::

    {
      "defaultMode": "default",
      "permissions": { "allow": [...], "ask": [...], "deny": [...] },
      "ui": {
        "orbSize": 240,                  # px, 160-400
        "personaPrompt": null            # null = use built-in; string = override
      },
      "model": {
        "path": null                     # null = use NAVI_MODEL_PATH env or default
      }
    }

Loading is forgiving: any missing keys/sections fall back to defaults via
deep-merge so older settings.json files keep working.
"""

from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from navi._io import atomic_write_text
from navi.perms.engine import default_settings, settings_path


def ui_defaults() -> dict[str, Any]:
    return {
        "orbSize": 240,
        "personaPrompt": None,
        "skin": "classic",
        "hotkey": "ctrl+shift+space",
        "windowPosition": None,  # [x, y] — set on close
    }


def voice_defaults() -> dict[str, Any]:
    return {
        "enabled": False,         # off by default; user opts in
        "voiceId": None,          # SAPI voice token (None = default)
        "rate": 200,              # words per minute
        "volume": 0.85,           # 0.0-1.0
        "pttHotkey": "ctrl+alt+space",
    }


def model_defaults() -> dict[str, Any]:
    return {"path": None}


def image_defaults() -> dict[str, Any]:
    return {
        "model_path": None,    # null = project-relative models/FLUX.1-schnell
        "default_steps": 4,    # FLUX schnell is distilled to 1-4 steps
        "default_size": [1024, 1024],
    }


def full_defaults() -> dict[str, Any]:
    base = default_settings()
    base["ui"] = ui_defaults()
    base["model"] = model_defaults()
    base["voice"] = voice_defaults()
    base["image"] = image_defaults()
    return base


def deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Merge ``override`` into ``base`` recursively. ``base`` is not modified.

    Special case: if a key in defaults is a dict (a settings sub-section)
    and the override is None (e.g. user wrote ``"voice": null`` in
    settings.json or a stale write erased it), keep the defaults branch
    intact. Without this guard we'd wipe an entire settings section,
    losing UI defaults like ``orbSize`` and breaking later code that
    expects the dict shape.
    """
    out = deepcopy(base)
    for k, v in override.items():
        base_val = out.get(k)
        if isinstance(base_val, dict) and v is None:
            # Override explicitly clears a sub-section: preserve defaults.
            continue
        if isinstance(base_val, dict) and isinstance(v, dict):
            out[k] = deep_merge(base_val, v)
        else:
            out[k] = v
    return out


def load() -> dict[str, Any]:
    """Load settings, merging file contents over defaults. Bootstraps if missing."""
    path = settings_path()
    if not path.exists():
        defaults = full_defaults()
        atomic_write_text(path, json.dumps(defaults, indent=2))
        return defaults
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return full_defaults()
    if not isinstance(raw, dict):
        return full_defaults()
    return deep_merge(full_defaults(), raw)


def save(settings: dict[str, Any]) -> Path:
    path = settings_path()
    atomic_write_text(path, json.dumps(settings, indent=2))
    return path
