"""Settings persistence — extends the JSON file used by the permission engine.

Schema (``%APPDATA%/Navi/settings.json``)::

    {
      "defaultMode": "default",
      "permissions": { "allow": [...], "ask": [...], "deny": [...] },
      "ui": {
        "orbSize": 240,                  # px, 160-400
        "personaPrompt": null            # null = use built-in; string = override
      },
      "model": {
        "path": null                     # null = use NAVI_MODEL_PATH env or default
      }
    }

Loading is forgiving: any missing keys/sections fall back to defaults via
deep-merge so older settings.json files keep working.
"""

from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from navi.perms.engine import default_settings, settings_path


def ui_defaults() -> dict[str, Any]:
    return {
        "orbSize": 240,
        "personaPrompt": None,
        "skin": "classic",
        "hotkey": "ctrl+shift+space",
        "windowPosition": None,  # [x, y] — set on close
    }


def voice_defaults() -> dict[str, Any]:
    return {
        "enabled": False,         # off by default; user opts in
        "voiceId": None,          # SAPI voice token (None = default)
        "rate": 200,              # words per minute
        "volume": 0.85,           # 0.0-1.0
        "pttHotkey": "ctrl+alt+space",
    }


def model_defaults() -> dict[str, Any]:
    return {"path": None}


def full_defaults() -> dict[str, Any]:
    base = default_settings()
    base["ui"] = ui_defaults()
    base["model"] = model_defaults()
    base["voice"] = voice_defaults()
    return base


def deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Merge ``override`` into ``base`` recursively. ``base`` is not modified."""
    out = deepcopy(base)
    for k, v in override.items():
        if k in out and isinstance(out[k], dict) and isinstance(v, dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load() -> dict[str, Any]:
    """Load settings, merging file contents over defaults. Bootstraps if missing."""
    path = settings_path()
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        defaults = full_defaults()
        path.write_text(json.dumps(defaults, indent=2), encoding="utf-8")
        return defaults
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return full_defaults()
    if not isinstance(raw, dict):
        return full_defaults()
    return deep_merge(full_defaults(), raw)


def save(settings: dict[str, Any]) -> Path:
    path = settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(settings, indent=2), encoding="utf-8")
    return path
