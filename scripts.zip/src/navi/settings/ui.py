from __future__ import annotations

from typing import Any

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from navi.brain.persona import SYSTEM_PROMPT
from navi.pet.skins import available_skins
from navi.settings.store import load as load_settings
from navi.settings.store import save as save_settings

_ORB_MIN = 160
_ORB_MAX = 400
_MODES = ("default", "plan", "acceptEdits", "bypass")
_MODE_DESCRIPTIONS = {
    "default": "Use allow/ask/deny rules. Most-restrictive guard for general use.",
    "plan": "Navi describes only — never executes any tool.",
    "acceptEdits": "Auto-allow file writes inside %USERPROFILE% (read-only tools still allowed).",
    "bypass": "DEV ONLY — allow every tool with no prompts. Use with care.",
}


_DARK_QSS = """
QDialog { background: #161616; color: #e8e8e8; }
QLabel { color: #e8e8e8; }
QLineEdit, QPlainTextEdit, QComboBox, QSpinBox {
    background: #1e1e1e;
    color: #e8e8e8;
    padding: 4px 8px;
    border: 1px solid #2a2a2a;
    border-radius: 4px;
    selection-background-color: #2c5fc9;
}
QLineEdit:focus, QPlainTextEdit:focus, QComboBox:focus, QSpinBox:focus {
    border-color: #3B82F6;
}
QPushButton {
    background: #2a2a2a;
    color: #e8e8e8;
    padding: 6px 14px;
    border: 1px solid #3a3a3a;
    border-radius: 4px;
}
QPushButton:hover { background: #353535; }
QPushButton:default { background: #3B82F6; border-color: #3B82F6; }
QPushButton:default:hover { background: #2c6ad5; }
"""


class SettingsDialog(QDialog):
    """Dialog for editing Navi settings (`%APPDATA%/Navi/settings.json`)."""

    saved = Signal(dict)  # full settings dict, on Save

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Navi — settings")
        self.setMinimumWidth(620)
        self.setMinimumHeight(500)
        self.setStyleSheet(_DARK_QSS)
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)

        self._settings = load_settings()
        ui = self._settings.get("ui", {})
        model = self._settings.get("model", {})

        # Permission mode
        self._mode = QComboBox()
        for m in _MODES:
            self._mode.addItem(m)
        current_mode = self._settings.get("defaultMode", "default")
        if current_mode in _MODES:
            self._mode.setCurrentIndex(_MODES.index(current_mode))
        self._mode_help = QLabel(_MODE_DESCRIPTIONS[current_mode])
        self._mode_help.setStyleSheet("QLabel { color: #888; font-size: 11px; }")
        self._mode_help.setWordWrap(True)
        self._mode.currentTextChanged.connect(
            lambda m: self._mode_help.setText(_MODE_DESCRIPTIONS.get(m, ""))
        )

        # Orb size
        self._orb_size = QSpinBox()
        self._orb_size.setRange(_ORB_MIN, _ORB_MAX)
        self._orb_size.setSingleStep(20)
        self._orb_size.setSuffix(" px")
        self._orb_size.setValue(int(ui.get("orbSize", 240)))

        # Skin selector
        self._skin = QComboBox()
        self._skins = available_skins()
        for name, desc in self._skins:
            self._skin.addItem(name)
            self._skin.setItemData(self._skin.count() - 1, desc, Qt.ItemDataRole.ToolTipRole)
        current_skin = ui.get("skin", "classic")
        names = [n for n, _ in self._skins]
        if current_skin in names:
            self._skin.setCurrentIndex(names.index(current_skin))
        self._skin_help = QLabel(
            next((d for n, d in self._skins if n == current_skin), "")
        )
        self._skin_help.setStyleSheet("QLabel { color: #888; font-size: 11px; }")
        self._skin_help.setWordWrap(True)
        self._skin.currentTextChanged.connect(
            lambda n: self._skin_help.setText(
                next((d for nn, d in self._skins if nn == n), "")
            )
        )

        # Model path
        self._model_path = QLineEdit()
        self._model_path.setPlaceholderText("(default — uses NAVI_MODEL_PATH or models/...)")
        if model.get("path"):
            self._model_path.setText(str(model["path"]))
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse_model)
        path_row = QHBoxLayout()
        path_row.addWidget(self._model_path, 1)
        path_row.addWidget(browse)
        path_help = QLabel("Restart required for model path changes.")
        path_help.setStyleSheet("QLabel { color: #888; font-size: 11px; }")

        # Persona prompt
        self._persona = QPlainTextEdit()
        font = QFont("Cascadia Mono")
        if not font.exactMatch():
            font.setFamily("Consolas")
        font.setPointSize(10)
        self._persona.setFont(font)
        if ui.get("personaPrompt"):
            self._persona.setPlainText(ui["personaPrompt"])
        else:
            self._persona.setPlaceholderText("(using built-in persona — overwrite to customize)")
        reset_persona = QPushButton("Reset to default persona")
        reset_persona.clicked.connect(lambda: self._persona.setPlainText(SYSTEM_PROMPT))

        # Form layout
        form = QFormLayout()
        form.setSpacing(10)
        form.addRow(QLabel("<b>Permission mode</b>"), self._mode)
        form.addRow("", self._mode_help)
        form.addRow(QLabel("<b>Orb size</b>"), self._orb_size)
        form.addRow(QLabel("<b>Skin</b>"), self._skin)
        form.addRow("", self._skin_help)
        form.addRow(QLabel("<b>Model path</b>"), path_row)
        form.addRow("", path_help)
        form.addRow(QLabel("<b>Persona prompt</b>"), self._persona)
        form.addRow("", reset_persona)

        # Buttons
        buttons = QDialogButtonBox(self)
        save_btn = buttons.addButton("Save", QDialogButtonBox.ButtonRole.AcceptRole)
        cancel_btn = buttons.addButton("Cancel", QDialogButtonBox.ButtonRole.RejectRole)
        save_btn.setDefault(True)
        buttons.accepted.connect(self._on_save)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 12)
        layout.setSpacing(10)
        layout.addLayout(form)
        layout.addWidget(buttons)

    # --- helpers -----------------------------------------------------------
    def _browse_model(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Choose a GGUF model file",
            self._model_path.text() or "",
            "GGUF (*.gguf)",
        )
        if path:
            self._model_path.setText(path)

    def _on_save(self) -> None:
        self._settings["defaultMode"] = self._mode.currentText()
        self._settings.setdefault("ui", {})["orbSize"] = int(self._orb_size.value())
        self._settings["ui"]["skin"] = self._skin.currentText()
        persona_text = self._persona.toPlainText().strip()
        self._settings["ui"]["personaPrompt"] = persona_text or None
        self._settings.setdefault("model", {})["path"] = self._model_path.text().strip() or None

        save_settings(self._settings)
        self.saved.emit(self._settings)
        self.accept()


def open_settings(parent: QWidget | None = None) -> dict[str, Any] | None:
    """Modal helper: open the dialog, return the saved dict or None on cancel."""
    dlg = SettingsDialog(parent)
    saved: dict[str, Any] | None = None

    def _capture(s: dict[str, Any]) -> None:
        nonlocal saved
        saved = s

    dlg.saved.connect(_capture)
    dlg.exec()
    return saved
