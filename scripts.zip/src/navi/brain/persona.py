"""System prompt for Navi.

Composition (top to bottom):
  1. **Tool-use preamble** — the directive that tells the model HOW to call
     tools. Picked from :mod:`navi.brain.calibration`'s ``PROMPT_VARIANTS``
     based on what calibration determined works for the current model.
     Default is the Granite-tuned variant (verbatim from Granite 3.1's chat
     template; the model defers to its RLHF "I'm just text" reflex without it).
  2. **Soul** — user-editable identity/voice/values, loaded from
     ``%APPDATA%/Navi/soul.md`` (copied from a bundled template at
     ``navi/assets/souls/<name>.md`` on first run; default template is
     ``operator``). Switched between templates via ``/soul use <name>``
     or directly via :func:`apply_soul_template`.
  3. **Hard rules** — anti-failure-mode behavior rules that must not be
     edited away by users (one-tool-per-turn, no fake dialogue, no JSON
     blocks). Last instruction wins, so these always trump the soul.
  4. **Memory index** — first 200 lines of MEMORY.md so saved facts surface.

Per-model variant is persisted under ``settings["model_overrides"][filename]
["system_prompt_variant"]`` whenever calibration's auto-fix loop finds a
working alternative for the loaded model. On next launch the chosen variant
is applied immediately, no re-calibration needed.

If the user has explicitly set ``settings["ui"]["personaPrompt"]``, it
REPLACES preamble + soul + hard rules — they opted out of auto-tuning
entirely (tool-calling may break; that's their call).
"""

from __future__ import annotations

import os
from pathlib import Path

# Default tool-use preamble: verbatim from Granite 3.1's chat template.
# This is what calibration's "granite" variant uses, and what we fall back
# to when no per-model override is set.
_TOOL_USE_PREAMBLE_DEFAULT = (
    "You are a helpful AI assistant with access to the following tools. "
    "When a tool is required to answer the user's query, respond with "
    "<|tool_call|> followed by a JSON list of tools used. If a tool does "
    "not exist in the provided list of tools, notify the user that you do "
    "not have the ability to fulfill the request."
)

# Anti-failure-mode behavior rules. Stays in code (NOT in soul.md) so
# users editing soul.md can't accidentally break tool-calling.
#
# IMPORTANT: keep this terse and avoid suggestive nouns ("preferences",
# "facts", "decisions") — small models latch on to them and free-associate
# into fake multi-turn dialogue when the user input is ambiguous (e.g.
# "5+5" was producing a fabricated conversation about email fonts because
# the persona mentioned "preferences" + "remember/recall tools"). Saved
# in feedback_granite_tool_calling.md.
_HARD_RULES = (
    "Be concise. Use tools instead of describing them. Do not output "
    "JSON code blocks. Do NOT generate fake multi-turn dialogue with "
    "'User:' or 'Assistant:' prefixes — answer the user's actual message "
    "directly.\n\n"
    "For multi-step tasks, call ONE tool per turn, wait for its result, "
    "then continue. After completing every step, reply briefly without "
    "proposing follow-ups.\n\n"
    "Use the remember tool only when the user explicitly says to remember "
    "something. Use the recall tool only when the user asks about a "
    "previously saved memory."
)


# --- Soul ------------------------------------------------------------------
#
# Bundled soul templates ship in ``navi/assets/souls/<name>.md``. The
# user's working copy lives at ``%APPDATA%/Navi/soul.md`` and is copied
# from a template on first run (or via ``apply_soul_template``). The
# working copy is read fresh on every ``build_system_prompt()`` call so
# edits take effect without restart.

DEFAULT_SOUL_NAME = "operator"
_SOULS_DIR = Path(__file__).resolve().parent.parent / "assets" / "souls"
_BUNDLED_SOUL = _SOULS_DIR / f"{DEFAULT_SOUL_NAME}.md"

# Embedded fallback used only if every bundled file is missing (broken
# install, zipped wheel weirdness, tests that monkeypatch paths to
# non-existent locations).
_EMBEDDED_SOUL_FALLBACK = (
    "# Navi\n\n"
    "You are Navi: a local AI companion that lives on this Windows desktop.\n"
)


def soul_path() -> Path:
    """Return the user-editable soul.md path under %APPDATA%/Navi/."""
    appdata = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming")))
    return appdata / "Navi" / "soul.md"


def soul_backup_path() -> Path:
    """Return the path where ``apply_soul_template`` saves the previous soul."""
    return soul_path().with_name("soul.backup.md")


def list_souls() -> list[str]:
    """Return the sorted names of bundled soul templates (no extension)."""
    if not _SOULS_DIR.exists():
        return []
    return sorted(p.stem for p in _SOULS_DIR.glob("*.md"))


def template_path(name: str) -> Path:
    """Return the bundled template path for ``name``. Does not validate existence."""
    return _SOULS_DIR / f"{name}.md"


def _read_bundled_soul() -> str:
    try:
        return _BUNDLED_SOUL.read_text(encoding="utf-8").strip()
    except OSError:
        return _EMBEDDED_SOUL_FALLBACK.strip()


def load_soul() -> str:
    """Return the active soul text.

    First-run: copies the default template to ``%APPDATA%/Navi/soul.md``
    so the user has a real file to edit. On subsequent runs, reads that
    file fresh every call.
    """
    path = soul_path()
    if not path.exists():
        from navi._io import atomic_write_text
        try:
            atomic_write_text(path, _read_bundled_soul() + "\n")
        except OSError:
            # Couldn't write (perms, transient lock) — degrade to bundled
            # text in-memory rather than crashing prompt assembly.
            return _read_bundled_soul()
    try:
        return path.read_text(encoding="utf-8").strip()
    except OSError:
        return _read_bundled_soul()


def get_active_soul_name() -> str:
    """Return the name of the template the user last applied, or the default."""
    from navi.settings.store import load as load_settings
    settings = load_settings()
    name = (settings.get("ui", {}) or {}).get("soulTemplate")
    if name and template_path(name).exists():
        return name
    return DEFAULT_SOUL_NAME


def _set_active_soul_name(name: str) -> None:
    from navi.settings.store import load as load_settings
    from navi.settings.store import save as save_settings
    settings = load_settings()
    settings.setdefault("ui", {})["soulTemplate"] = name
    save_settings(settings)


def apply_soul_template(name: str) -> Path:
    """Overwrite ``soul.md`` with the named template.

    Saves the existing ``soul.md`` to ``soul.backup.md`` first so user
    edits aren't lost silently. Raises ``FileNotFoundError`` if ``name``
    isn't a known template. Records ``name`` as the active template in
    settings so :func:`reset_soul` can re-apply it later.
    """
    src = template_path(name)
    if not src.exists():
        raise FileNotFoundError(f"unknown soul template: {name}")
    from navi._io import atomic_write_text
    dst = soul_path()
    if dst.exists():
        try:
            atomic_write_text(soul_backup_path(), dst.read_text(encoding="utf-8"))
        except OSError:
            # Backup is best-effort; don't block the switch on a backup failure.
            pass
    atomic_write_text(dst, src.read_text(encoding="utf-8"))
    _set_active_soul_name(name)
    return dst


def reset_soul() -> str:
    """Re-apply the active template, discarding edits to ``soul.md``.

    Returns the template name that was re-applied. Backs up the current
    edited soul to ``soul.backup.md`` first, so a reset is undoable via
    :func:`restore_soul_from_backup`.
    """
    name = get_active_soul_name()
    apply_soul_template(name)
    return name


def restore_soul_from_backup() -> bool:
    """Swap ``soul.md`` and ``soul.backup.md``.

    Acts as undo for the most recent apply/reset (and as redo if called
    twice). Returns True if the swap happened, False if there was no
    backup to restore from.
    """
    backup = soul_backup_path()
    current = soul_path()
    if not backup.exists():
        return False
    from navi._io import atomic_write_text
    backup_text = backup.read_text(encoding="utf-8")
    current_text = current.read_text(encoding="utf-8") if current.exists() else ""
    atomic_write_text(current, backup_text)
    atomic_write_text(backup, current_text)
    return True


# Backwards-compat: legacy callers (and tests) still import SYSTEM_PROMPT.
# Equivalent to "default preamble + bundled soul + hard rules" with no
# memory. Computed at import time as a stable snapshot — the live
# build_system_prompt() reads soul.md fresh and is what real chat uses.
SYSTEM_PROMPT = f"{_TOOL_USE_PREAMBLE_DEFAULT}\n\n{_read_bundled_soul()}\n\n{_HARD_RULES}"


def _adapter_preamble(adapter) -> str:
    """Return the active preamble for ``adapter``.

    ``adapter.system_prompt is None`` means: trust the GGUF's chat template
    to render the tools section, just emit Navi's generic preamble.
    """
    if adapter is None or adapter.system_prompt is None:
        return _TOOL_USE_PREAMBLE_DEFAULT
    return adapter.system_prompt


def _resolve_preamble() -> str:
    """Pick the tool-use preamble for the currently-loaded model.

    Priority:
      1. ``settings["model_overrides"][filename]["adapter_id"]`` — set by
         calibration's auto-fix when it finds a working family adapter.
      2. Legacy ``system_prompt_variant`` key (migrated to an adapter id).
      3. Universal detection (chat-template fingerprint → filename →
         metadata) via :func:`detect_adapter_universal`. This catches
         renamed quants (e.g. Bartowski) that filename matching alone
         would miss.
      4. Default preamble.
    """
    # Imported lazily so importing this module doesn't pull in the whole
    # adapter / settings stack (helps test isolation).
    from navi.brain.adapters import (
        adapter_by_id,
        default_adapter,
        detect_adapter_universal,
        migrate_legacy_variant,
    )
    from navi.settings.store import load as load_settings

    settings = load_settings()
    model_path = settings.get("model", {}).get("path")
    if model_path:
        filename = Path(model_path).name
        entry = settings.get("model_overrides", {}).get(filename, {})

        # Persisted adapter id (new system)
        adapter_id = entry.get("adapter_id")
        # Legacy migration: settings written by older calibration code
        if adapter_id is None:
            adapter_id = migrate_legacy_variant(entry.get("system_prompt_variant"))

        if adapter_id:
            adapter = adapter_by_id(adapter_id)
            if adapter is not None:
                return _adapter_preamble(adapter)

        # No persisted choice — universal detection. Metadata is None at
        # this point (we don't have the loaded LLMClient handy here);
        # falls back to filename + family keywords.
        return _adapter_preamble(detect_adapter_universal(Path(model_path)))

    # No model path set yet (fresh install). Fall back to the granite_3
    # adapter — it's what the bundled model uses and what SYSTEM_PROMPT
    # (the legacy constant) corresponds to. NOT the "default" adapter,
    # which is intentionally minimal and would change behavior at first run.
    granite = adapter_by_id("granite_3")
    return _adapter_preamble(granite or default_adapter())


def build_system_prompt() -> str:
    """Return the active system prompt.

    Refreshed at the start of every ``submit`` so any newly-saved memories,
    persona changes from the Settings dialog, or calibration auto-fix
    decisions take effect without restart.
    """
    from navi.memory.store import load_index
    from navi.settings.store import load as load_settings

    settings = load_settings()

    # If the user manually customized their persona prompt, use it as-is —
    # they opted out of auto-tuning. Otherwise compose preamble + soul +
    # hard rules.
    user_override = (settings.get("ui", {}) or {}).get("personaPrompt")
    if user_override:
        base = user_override
    else:
        base = f"{_resolve_preamble()}\n\n{load_soul()}\n\n{_HARD_RULES}"

    idx = load_index()
    if not idx:
        return base
    return (
        f"{base}\n\n"
        f"## Saved memories (use the `recall` tool for full text)\n\n{idx}"
    )
