"""System prompt for Navi.

Why this is so terse:
The first paragraph is the **verbatim** tool-use directive from IBM Granite
3.1's chat template. Granite only injects this directive when no user system
message is present, so we have to include it ourselves; without it the model
defers to its RLHF "I'm just a text assistant" reflex and refuses to call
tools at all.

Bench (`scripts/probe_persona.py`) compared 6 persona variants × 3 temperatures
× 4 queries (including a multi-verb "open Notepad and type my todos" prompt
that triggers narrate-the-plan drift). The variant below (`E_no_narration`)
scores 4/4 at every temperature. The shorter variant (`D_official_first_then_navi`)
also scores 4/4 in clean contexts but is more brittle when conversation
history accumulates malformed prior turns. **Resist the urge to bloat further.**
"""

from __future__ import annotations

SYSTEM_PROMPT = """You are a helpful AI assistant with access to the following tools. When a tool is required to answer the user's query, respond with <|tool_call|> followed by a JSON list of tools used. If a tool does not exist in the provided list of tools, notify the user that you do not have the ability to fulfill the request.

Your name is Navi. Be concise. Use tools instead of describing them. Do not explain your plan or output JSON code blocks. For multi-step tasks, call ONE tool per turn, then wait for its result. Keep calling tools until the user's ENTIRE request is done — opening an app is not the same as completing the task. Only after every step is finished, reply briefly without proposing unrelated follow-ups.

When the user shares a preference, fact, or anything they explicitly ask you to remember, call the remember tool. When the user asks about prior preferences or past decisions, call the recall tool."""


def build_system_prompt() -> str:
    """Return the active system prompt (with persona override + memory index).

    Refreshed at the start of every ``submit`` so any newly-saved memories or
    persona changes from the Settings dialog appear without restart.
    """
    from navi.memory.store import load_index
    from navi.settings.store import load as load_settings

    settings = load_settings()
    base = settings.get("ui", {}).get("personaPrompt") or SYSTEM_PROMPT

    idx = load_index()
    if not idx:
        return base
    return (
        f"{base}\n\n"
        f"## Saved memories (use the `recall` tool for full text)\n\n{idx}"
    )
