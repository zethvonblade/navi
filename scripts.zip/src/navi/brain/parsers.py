"""Tool-call parser registry.

Different model families emit tool calls in different formats. Rather than
sprinkling format-specific logic across the agent loop, this module owns
ALL the recognition. Each parser is a pure function:

    parse(raw_text: str) -> list[OpenAICallDict] | None

where ``OpenAICallDict`` is the standard OpenAI shape::

    {
        "id": "call_0",
        "type": "function",
        "function": {"name": "tool_name", "arguments": '{"k": "v"}'}
    }

(``arguments`` is always a JSON-encoded **string** — that's what
llama-cpp-python and the rest of the brain expect.)

The dispatcher :func:`parse_any_tool_call` walks parsers in priority order
and returns the first match. Order matters — parsers that recognize a
strict marker come before greedy heuristics so e.g. Phi's plural-marker
output isn't accidentally swallowed by a singular-marker parser.

Format references — see ``feedback_granite_tool_calling.md`` for traps and
the relevant model docs (Granite, Phi-4-mini, Llama 3.x, Mistral, Qwen,
Gemma 3) for canonical shapes.
"""

from __future__ import annotations

import ast
import json
import re
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

# End-of-turn / end-of-message tokens models occasionally append. These are
# not interesting once they reach our parser layer — strip them off before
# JSON / pythonic decoding.
_END_TOKENS = (
    "<|eot_id|>", "<|eom_id|>", "<|end|>", "<|im_end|>",
    "<|endoftext|>", "</s>",
)


def _strip_end_tokens(text: str) -> str:
    """Trim trailing end-of-turn markers (and following whitespace)."""
    out = text.rstrip()
    changed = True
    while changed:
        changed = False
        for tok in _END_TOKENS:
            if out.endswith(tok):
                out = out[: -len(tok)].rstrip()
                changed = True
    return out


def _to_openai_call(entry: dict[str, Any], idx: int) -> dict[str, Any] | None:
    """Normalize one of the many "tool call dict" shapes to the OpenAI shape.

    Recognized shapes::

        {"name": "X", "arguments": {...}}                        # canonical
        {"name": "X", "parameters": {...}}                       # Llama JSON
        {"function": "X", "arguments": {...}}                    # function as string
        {"function": {"name": "X", "arguments": {...}}}          # nested
        {"function": {"name": "X", "parameters": {...}}}         # nested + Llama key
    """
    if not isinstance(entry, dict):
        return None

    args: Any = entry.get("arguments")
    if args is None:
        args = entry.get("parameters")
    if args is None:
        args = {}

    name: str | None = None
    if isinstance(entry.get("name"), str):
        name = entry["name"]
    elif "function" in entry:
        fn = entry["function"]
        if isinstance(fn, str):
            name = fn
        elif isinstance(fn, dict):
            if isinstance(fn.get("name"), str):
                name = fn["name"]
            if "arguments" in fn:
                args = fn["arguments"]
            elif "parameters" in fn:
                args = fn["parameters"]

    if not name:
        return None

    if not isinstance(args, str):
        try:
            args = json.dumps(args)
        except (TypeError, ValueError):
            return None

    return {
        "id": f"call_{idx}",
        "type": "function",
        "function": {"name": name, "arguments": args},
    }


def _try_parse_json_array_or_object(text: str) -> list[dict[str, Any]] | None:
    """Decode a string into a list of OpenAI calls.

    Accepts either a JSON array of objects or a single JSON object (which
    we wrap into a one-element list).
    """
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        # Try trimming trailing junk after the matching closing bracket.
        for open_ch, close_ch in (("[", "]"), ("{", "}")):
            depth = 0
            end = -1
            started = False
            for i, c in enumerate(text):
                if c == open_ch:
                    depth += 1
                    started = True
                elif c == close_ch:
                    depth -= 1
                    if started and depth == 0:
                        end = i + 1
                        break
            if end != -1:
                try:
                    data = json.loads(text[:end])
                    break
                except json.JSONDecodeError:
                    continue
        else:
            return None

    if isinstance(data, dict):
        data = [data]
    if not isinstance(data, list):
        return None

    calls: list[dict[str, Any]] = []
    for i, entry in enumerate(data):
        normalized = _to_openai_call(entry, i)
        if normalized is None:
            return None
        calls.append(normalized)
    return calls or None


# ---------------------------------------------------------------------------
# Individual parsers
# ---------------------------------------------------------------------------


def parse_marker_plural_paired(text: str) -> list[dict[str, Any]] | None:
    """Plural-marker paired format: ``<|tool_calls|>[...]<|/tool_calls|>``.

    Plural opener + closing marker + JSON array body (even for one call).
    NOT used by stock Phi-4 — Phi-4 emits a bare JSON array. Kept as a
    fallback for any community fine-tune that emits this wrapper.
    """
    OPEN, CLOSE = "<|tool_calls|>", "<|/tool_calls|>"
    idx = text.find(OPEN)
    if idx == -1:
        return None
    body = text[idx + len(OPEN):]
    end = body.find(CLOSE)
    if end != -1:
        body = body[:end]
    body = _strip_end_tokens(body.strip())
    return _try_parse_json_array_or_object(body)


def parse_marker_singular_array(text: str) -> list[dict[str, Any]] | None:
    """Granite 3.x format: ``<|tool_call|>[{...}, ...]`` (no closing marker).

    Also catches alternate openers: ``<tool_call>``, ``[tool_call]``.
    """
    for opener in ("<|tool_call|>", "<tool_call>", "[tool_call]"):
        idx = text.find(opener)
        if idx == -1:
            continue
        body = text[idx + len(opener):].lstrip()
        # Strip optional closing marker if Granite-drift adds one
        for closer in ("<|/tool_call|>", "</tool_call>", "[/tool_call]"):
            close_idx = body.rfind(closer)
            if close_idx != -1:
                body = body[:close_idx].rstrip()
        body = _strip_end_tokens(body)
        result = _try_parse_json_array_or_object(body)
        if result:
            return result
    return None


def parse_xml_tool_call_paired(text: str) -> list[dict[str, Any]] | None:
    """Granite 4 / Qwen Hermes: ``<tool_call>{...}</tool_call>``.

    Single JSON object between paired XML-style tags. May appear multiple
    times for parallel calls.
    """
    pattern = re.compile(
        r"<tool_call>\s*(.*?)\s*</tool_call>", re.DOTALL,
    )
    matches = pattern.findall(text)
    if not matches:
        return None
    calls: list[dict[str, Any]] = []
    for i, body in enumerate(matches):
        body = _strip_end_tokens(body.strip())
        try:
            entry = json.loads(body)
        except json.JSONDecodeError:
            continue
        normalized = _to_openai_call(entry, i)
        if normalized is None:
            continue
        calls.append(normalized)
    return calls or None


def parse_mistral_token(text: str) -> list[dict[str, Any]] | None:
    """Mistral: ``[TOOL_CALLS][{...}, ...]`` — the marker is a literal
    bracket-bracketed token followed by a JSON array.
    """
    MARKER = "[TOOL_CALLS]"
    idx = text.find(MARKER)
    if idx == -1:
        return None
    body = text[idx + len(MARKER):].lstrip()
    body = _strip_end_tokens(body)
    return _try_parse_json_array_or_object(body)


def parse_pythonic_call(text: str) -> list[dict[str, Any]] | None:
    """Llama 3.3 / Llama 3.2-large: ``[func_name(arg1=val1, ...)]``.

    Uses ``ast.parse`` so we get correct handling of nested literals,
    quoted strings with commas, list/dict args, etc. for free.
    """
    text = _strip_end_tokens(text.strip())
    if not (text.startswith("[") and text.endswith("]")):
        return None
    inner = text[1:-1].strip()
    if not inner:
        return None
    # Wrap in a tuple literal so ast can parse "f(),g()" as two Call nodes.
    try:
        tree = ast.parse(f"({inner},)", mode="eval")
    except SyntaxError:
        return None
    if not isinstance(tree.body, ast.Tuple):
        return None
    calls: list[dict[str, Any]] = []
    for i, elt in enumerate(tree.body.elts):
        if not isinstance(elt, ast.Call):
            return None
        if not isinstance(elt.func, ast.Name):
            return None
        if elt.args:  # Llama emits keyword args only
            return None
        kwargs: dict[str, Any] = {}
        for kw in elt.keywords:
            if kw.arg is None:  # **kwargs splat
                return None
            try:
                kwargs[kw.arg] = ast.literal_eval(kw.value)
            except (ValueError, SyntaxError):
                return None
        calls.append({
            "id": f"call_{i}",
            "type": "function",
            "function": {
                "name": elt.func.id,
                "arguments": json.dumps(kwargs),
            },
        })
    return calls or None


_MARKDOWN_TOOL_CODE_RE = re.compile(
    r"```tool_code\s*\n(.*?)\n```", re.DOTALL,
)


def parse_markdown_tool_code(text: str) -> list[dict[str, Any]] | None:
    """Gemma 3: tool calls inside ``` ```tool_code\\n...\\n``` ```.

    Body is Python-style call syntax (per Google's recommended format), so
    parses identically to the pythonic parser — except we have to extract
    the code block first.
    """
    matches = _MARKDOWN_TOOL_CODE_RE.findall(text)
    if not matches:
        return None
    calls: list[dict[str, Any]] = []
    for body in matches:
        body = body.strip()
        # Wrap as `[body]` so the pythonic parser can handle it
        wrapped = f"[{body}]" if not body.startswith("[") else body
        sub = parse_pythonic_call(wrapped)
        if sub:
            calls.extend(sub)
    if not calls:
        return None
    # Re-id sequentially across the merged set
    return [
        {**c, "id": f"call_{i}"} for i, c in enumerate(calls)
    ]


_BRACKET_PSEUDO_RE = re.compile(
    r"\[tool[_:]?\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*"
    r"(?:arguments|parameters)\s*:\s*(\{.*?\})\s*\]",
    re.DOTALL,
)


def parse_bracket_pseudo(text: str) -> list[dict[str, Any]] | None:
    """Granite drift format: ``[tool:NAME, arguments: {...}]``.

    Granite occasionally invents this pseudo-syntax after the first
    successful tool call, mid-prose. Not JSON-valid — needs regex.
    """
    matches = _BRACKET_PSEUDO_RE.findall(text)
    if not matches:
        return None
    calls: list[dict[str, Any]] = []
    for i, (name, args_json) in enumerate(matches):
        try:
            args = json.loads(args_json)
        except json.JSONDecodeError:
            continue
        if not isinstance(args, dict):
            continue
        calls.append({
            "id": f"call_{i}",
            "type": "function",
            "function": {"name": name, "arguments": json.dumps(args)},
        })
    return calls or None


# Anchored variant for sniffing: tells text_starts_tool_call whether the
# accumulated buffer starts with a bare JSON tool-call literal.
_BARE_JSON_SNIFF_RE = re.compile(
    r'^\[?\s*\{\s*["\']\s*(?:name|function)\s*["\']\s*:'
)

# Unanchored variant for the bare_json parser: finds an embedded
# `{"name": ...` literal mid-prose so we can extract it.
_BARE_JSON_EMBEDDED_RE = re.compile(
    r'\{\s*["\']\s*(?:name|function)\s*["\']\s*:'
)


def parse_bare_json_object(text: str) -> list[dict[str, Any]] | None:
    """Llama 3.1 format: bare ``{"name": "X", "parameters"|"arguments": {...}}``
    or a JSON array of same. No marker, no fence — just a JSON literal.

    This is intentionally last in the dispatcher chain because it's broad.
    """
    candidate = _strip_end_tokens(text.strip())
    if not candidate:
        return None
    # Find the first `{` or `[` that looks like a tool-call dict
    if candidate[0] not in "{[":
        # Scan for an embedded one (model preambles before the JSON)
        match = _BARE_JSON_EMBEDDED_RE.search(candidate)
        if not match:
            # Maybe an array opener
            arr_idx = candidate.find('[{"name"')
            arr_idx2 = candidate.find("[{'name'")
            arr_idx3 = candidate.find('[{"function"')
            best = min((i for i in (arr_idx, arr_idx2, arr_idx3) if i != -1),
                       default=-1)
            if best == -1:
                return None
            candidate = candidate[best:]
        else:
            candidate = candidate[match.start():]
    return _try_parse_json_array_or_object(candidate)


# ---------------------------------------------------------------------------
# GPT-OSS harmony format
# ---------------------------------------------------------------------------
# OpenAI gpt-oss-120b / 20b emit tool calls on the "commentary" channel:
#
#   <|channel|>commentary to=functions.NAME<|constrain|>json
#   <|message|>{"arg": "value"}<|call|>
#
# The <|constrain|> piece is optional (only present for json-constrained
# args). Multiple calls = multiple blocks.

_HARMONY_RE = re.compile(
    r"<\|channel\|>commentary to=functions\.([A-Za-z_][A-Za-z0-9_]*)"
    # Any chars (incl. an optional <|constrain|>json) between function name
    # and <|message|>. Non-greedy so multiple blocks parse independently.
    r".*?<\|message\|>(.*?)<\|call\|>",
    re.DOTALL,
)


def parse_harmony(text: str) -> list[dict[str, Any]] | None:
    """OpenAI GPT-OSS harmony-channel tool calls."""
    matches = _HARMONY_RE.findall(text)
    if not matches:
        return None
    calls: list[dict[str, Any]] = []
    for i, (name, body) in enumerate(matches):
        body = body.strip()
        # Body is JSON object (or empty for no-arg tools).
        if not body:
            args_json = "{}"
        else:
            try:
                args = json.loads(body)
                if not isinstance(args, dict):
                    args = {}
                args_json = json.dumps(args)
            except json.JSONDecodeError:
                continue
        calls.append({
            "id": f"call_{i}",
            "type": "function",
            "function": {"name": name, "arguments": args_json},
        })
    return calls or None


# ---------------------------------------------------------------------------
# DeepSeek V3 / R1 / R1-Distill — full-width Unicode pipe wrappers
# ---------------------------------------------------------------------------
# DeepSeek's tokenizer uses U+FF5C ｜ (FULLWIDTH VERTICAL LINE), NOT ASCII |.
# Format:
#
#   <｜tool▁calls▁begin｜>
#   <｜tool▁call▁begin｜>function<｜tool▁sep｜>NAME
#   ```json
#   {"arg": "value"}
#   ```<｜tool▁call▁end｜>
#   <｜tool▁calls▁end｜>
#
# The "▁" is U+2581 (LOWER ONE EIGHTH BLOCK, used by SentencePiece).
# R1 always emits <think>...</think> first; strip_reasoning_blocks must
# run before this parser sees the text.

_DEEPSEEK_CALL_RE = re.compile(
    r"<｜tool▁call▁begin｜>function<｜tool▁sep｜>"
    r"([A-Za-z_][A-Za-z0-9_]*)\s*"
    r"```json\s*(\{.*?\})\s*```\s*"
    r"<｜tool▁call▁end｜>",
    re.DOTALL,
)


def parse_deepseek_v3(text: str) -> list[dict[str, Any]] | None:
    """DeepSeek V3 / R1 / R1-Distill native tool-call block."""
    matches = _DEEPSEEK_CALL_RE.findall(text)
    if not matches:
        return None
    calls: list[dict[str, Any]] = []
    for i, (name, args_json_str) in enumerate(matches):
        try:
            args = json.loads(args_json_str)
        except json.JSONDecodeError:
            continue
        if not isinstance(args, dict):
            continue
        calls.append({
            "id": f"call_{i}",
            "type": "function",
            "function": {"name": name, "arguments": json.dumps(args)},
        })
    return calls or None


# ---------------------------------------------------------------------------
# GLM-4 / GLM-4.5 / GLM-4.7 — XML key/value body inside <tool_call>
# ---------------------------------------------------------------------------
# Format:
#
#   <tool_call>tool_name
#   <arg_key>k1</arg_key>
#   <arg_value>v1</arg_value>
#   <arg_key>k2</arg_key>
#   <arg_value>v2</arg_value>
#   </tool_call>
#
# The <tool_call> tag overlaps with parse_xml_tool_call_paired's opener.
# That parser tries JSON first, fails on the XML body, returns None — and
# we fall through to here. So order matters: register THIS parser AFTER
# xml_tool_call_paired in the registry.

_GLM_TOOL_CALL_RE = re.compile(
    r"<tool_call>\s*([A-Za-z_][A-Za-z0-9_.-]*)\s*\n(.*?)</tool_call>",
    re.DOTALL,
)
_GLM_ARG_PAIR_RE = re.compile(
    r"<arg_key>(.*?)</arg_key>\s*<arg_value>(.*?)</arg_value>",
    re.DOTALL,
)


def parse_glm_xml(text: str) -> list[dict[str, Any]] | None:
    """GLM-4.x XML-body tool call inside <tool_call>...</tool_call>."""
    matches = _GLM_TOOL_CALL_RE.findall(text)
    if not matches:
        return None
    calls: list[dict[str, Any]] = []
    for i, (name, body) in enumerate(matches):
        pairs = _GLM_ARG_PAIR_RE.findall(body)
        if not pairs and body.strip():
            # Body is non-empty but not arg pairs — likely the JSON shape
            # already handled by xml_tool_call_paired. Skip.
            continue
        args = {k.strip(): v.strip() for k, v in pairs}
        calls.append({
            "id": f"call_{i}",
            "type": "function",
            "function": {"name": name.strip(), "arguments": json.dumps(args)},
        })
    return calls or None


# ---------------------------------------------------------------------------
# Qwen3-Coder — <function=NAME><parameter=KEY>VALUE</parameter></function>
# ---------------------------------------------------------------------------
# Distinct from Qwen 3 instruct's Hermes <tool_call> JSON. Args are raw
# text (not JSON-encoded), one <parameter> tag per kwarg.

_QWEN3_CODER_FN_RE = re.compile(
    r"<function=([A-Za-z_][A-Za-z0-9_]*)>(.*?)</function>",
    re.DOTALL,
)
_QWEN3_CODER_PARAM_RE = re.compile(
    r"<parameter=([A-Za-z_][A-Za-z0-9_]*)>(.*?)</parameter>",
    re.DOTALL,
)


def parse_qwen3_coder_xml(text: str) -> list[dict[str, Any]] | None:
    """Qwen3-Coder XML function/parameter format."""
    matches = _QWEN3_CODER_FN_RE.findall(text)
    if not matches:
        return None
    calls: list[dict[str, Any]] = []
    for i, (name, body) in enumerate(matches):
        params = _QWEN3_CODER_PARAM_RE.findall(body)
        args = {k: v.strip() for k, v in params}
        calls.append({
            "id": f"call_{i}",
            "type": "function",
            "function": {"name": name, "arguments": json.dumps(args)},
        })
    return calls or None


# ---------------------------------------------------------------------------
# Registry + dispatcher
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ToolCallParser:
    id: str
    description: str
    detect: Callable[[str], list[dict[str, Any]] | None]
    # Strings to look for during the early-stream sniff. If any prefix matches,
    # the brain hides the streamed output until the parser at end-of-stream
    # gets to decide whether it's a real tool call.
    sniff_markers: tuple[str, ...] = field(default_factory=tuple)


# Order matters: most specific / least ambiguous first. The bare-JSON
# fallback is intentionally last because it's broad.
PARSERS: tuple[ToolCallParser, ...] = (
    # GPT-OSS harmony — extremely specific channel header, run early.
    ToolCallParser(
        id="harmony",
        description="GPT-OSS <|channel|>commentary to=functions.NAME ... <|call|>",
        detect=parse_harmony,
        sniff_markers=("<|channel|>commentary",),
    ),
    # DeepSeek V3/R1 — full-width pipes, byte-unique.
    ToolCallParser(
        id="deepseek_v3",
        description="DeepSeek V3/R1 <｜tool▁call▁begin｜>function<｜tool▁sep｜>NAME ```json{...}``` <｜tool▁call▁end｜>",
        detect=parse_deepseek_v3,
        sniff_markers=("<｜tool▁calls▁begin｜>", "<｜tool▁call▁begin｜>"),
    ),
    ToolCallParser(
        id="marker_plural_paired",
        description="Plural <|tool_calls|>[...]<|/tool_calls|> (community fine-tunes)",
        detect=parse_marker_plural_paired,
        sniff_markers=("<|tool_calls|>",),
    ),
    ToolCallParser(
        id="marker_singular_array",
        description="Granite 3.x <|tool_call|>[{...}, ...]",
        detect=parse_marker_singular_array,
        sniff_markers=("<|tool_call|>", "<tool_call>", "[tool_call]"),
    ),
    ToolCallParser(
        id="xml_tool_call_paired",
        description="Granite 4 / Qwen Hermes <tool_call>{...}</tool_call>",
        detect=parse_xml_tool_call_paired,
        # NOTE: <tool_call> overlaps with marker_singular_array's sniff;
        # only one needs to register it. We let singular handle the sniff,
        # this parser still runs at end-of-stream as a fallback.
        sniff_markers=(),
    ),
    # GLM-4 uses the same <tool_call> opener but XML key/value body. Runs
    # AFTER xml_tool_call_paired so we try JSON first; GLM only matches
    # when the body actually contains <arg_key>/<arg_value> pairs.
    ToolCallParser(
        id="glm_xml",
        description="GLM-4.x <tool_call>NAME\\n<arg_key>k</arg_key><arg_value>v</arg_value>...</tool_call>",
        detect=parse_glm_xml,
        sniff_markers=(),
    ),
    ToolCallParser(
        id="mistral_token",
        description="Mistral [TOOL_CALLS] token",
        detect=parse_mistral_token,
        sniff_markers=("[TOOL_CALLS]",),
    ),
    ToolCallParser(
        id="markdown_tool_code",
        description="Gemma 3 ```tool_code blocks",
        detect=parse_markdown_tool_code,
        sniff_markers=("```tool_code",),
    ),
    # Qwen3-Coder XML — distinct from Qwen 3 instruct. Run before pythonic
    # so the <function= opener wins over any bracket sniff fallback.
    ToolCallParser(
        id="qwen3_coder_xml",
        description="Qwen3-Coder <function=NAME><parameter=KEY>VALUE</parameter></function>",
        detect=parse_qwen3_coder_xml,
        sniff_markers=("<function=",),
    ),
    ToolCallParser(
        id="bracket_pseudo",
        description="Granite drift [tool:NAME, arguments: {...}]",
        detect=parse_bracket_pseudo,
        sniff_markers=(),
    ),
    ToolCallParser(
        id="pythonic_call",
        description="Llama 3.3 / Llama 4 [func_name(arg=val)]",
        detect=parse_pythonic_call,
        # Bracket sniff would be too greedy — runs only at end-of-stream.
        sniff_markers=(),
    ),
    ToolCallParser(
        id="bare_json_object",
        description='Llama 3.1 / Cohere {"name": ..., "parameters"|"arguments": ...}',
        detect=parse_bare_json_object,
        sniff_markers=(),
    ),
)


def parse_any_tool_call(text: str) -> list[dict[str, Any]] | None:
    """Run every parser in priority order; return the first match."""
    for parser in PARSERS:
        try:
            result = parser.detect(text)
        except Exception:  # noqa: BLE001 — never let a bad parse kill the brain
            continue
        if result:
            return result
    return None


def text_starts_tool_call(text: str) -> bool:
    """Cheap early-stream sniff. True if text starts with any registered
    parser's sniff marker, OR with a bare-JSON tool call literal, OR with a
    ``<think>`` reasoning block (Granite 3.2+/4.0 emit these before the
    actual ``<|tool_call|>`` — treat as a 'wait for it' signal so we don't
    flush the thinking trace as user-visible text).

    Used by the brain's stream loop to decide whether to suppress streaming
    output (because it's about to be a tool call) or flush as visible text.
    """
    stripped = text.lstrip()
    if stripped.startswith("<think>") or stripped.startswith("<|think|>"):
        return True
    for parser in PARSERS:
        for marker in parser.sniff_markers:
            if stripped.startswith(marker):
                return True
    if _BARE_JSON_SNIFF_RE.match(stripped):
        return True
    return False


_THINK_BLOCK_RE = re.compile(
    r"<\|?think\|?>.*?</\|?think\|?>", re.DOTALL,
)
_RESPONSE_TAG_RE = re.compile(
    r"</?\|?response\|?>", re.IGNORECASE,
)


def strip_reasoning_blocks(text: str) -> str:
    """Remove Granite 3.2+/4.0 <think>...</think> reasoning traces and the
    surrounding <response>...</response> wrapper before tool-call parsing.

    The reasoning traces are useful diagnostics but they confuse downstream
    parsing — once they're gone the remaining content matches the same
    ``<|tool_call|>[...]`` (or XML / JSON) shape every other parser already
    knows about.
    """
    cleaned = _THINK_BLOCK_RE.sub("", text)
    cleaned = _RESPONSE_TAG_RE.sub("", cleaned)
    return cleaned.strip()
