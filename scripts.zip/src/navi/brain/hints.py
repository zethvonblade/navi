"""Pre-LLM tool-use hint detector.

Some local models (Phi-4-mini, TinyLlama, smaller Qwen variants) struggle
to connect *implicit* tool-use cues — "Read this file: C:/x.docx" — to
the right registered tool. They were trained to recognize tool calls
when the user uses the explicit tool name, not when the user describes
the action in plain English.

This module detects high-confidence cues in the user's message
(absolute file paths, URLs, well-known keyword phrases) and returns a
one-line hint that gets prepended to what the brain sees:

    ⚙ hint: looks like read_file(path='C:/x.docx') — call that tool now.

Stronger models (Granite, GPT-OSS, Llama 4) tolerate the redundant hint
fine — it only fires when the pattern is unambiguous (literal absolute
path, literal URL, specific keywords). The hint is invisible to the
chat UI by default; toggle via the /hints slash command if you want to
see what's being injected.

Suggested tools must actually exist in the registered tool set — we
filter against the live ``tools_schema()`` so a hint never names a tool
the model can't call.
"""

from __future__ import annotations

import re
from collections.abc import Iterable

# ---------------------------------------------------------------------------
# Pattern → tool mapping
# ---------------------------------------------------------------------------

# Match an absolute file path with a known content-file extension.
# Anchored on the extension so we don't over-consume trailing prose; body
# is non-greedy and allows SPACES (real Windows paths often have them —
# "OneDrive - US Army", "Program Files", "My Documents", etc.). We exclude
# only quote/redirect/wildcard chars that are unambiguous path terminators.
_FILE_PATH_RE = re.compile(
    r"""
    (                              # capture full path
        (?:
            [A-Za-z]:[\\/]         # Windows drive letter root
            |
            \\\\[^\s\"'<>|*?]+\\   # UNC root
        )
        [^\"'<>|*?\r\n]+?          # path body (non-greedy; allows spaces)
        \.(?:docx|pdf|txt|md|py|js|jsx|ts|tsx|json|yaml|yml|toml|ini|csv|tsv|xlsx|xlsm|pptx|html|htm|xml|sql|sh|ps1|bat|c|cpp|cc|h|hpp|java|kt|rs|go|rb|php|css|scss|svg|log|conf|cfg|env|gguf|safetensors|png|jpg|jpeg|bmp|tiff|tif|gif|webp|ico)
    )
    \b                             # extension is a whole word (no .docx-like suffix)
    """,
    re.IGNORECASE | re.VERBOSE,
)

# Map file extension → preferred reader tool. Extensions not in the map
# fall back to read_file.
_EXT_TO_TOOL: dict[str, str] = {
    ".pdf": "read_pdf",
    ".xlsx": "read_excel",
    ".xlsm": "read_excel",
    ".pptx": "read_pptx",
    ".csv": "read_csv",
    ".png": "ocr_image",
    ".jpg": "ocr_image",
    ".jpeg": "ocr_image",
    ".bmp": "ocr_image",
    ".tiff": "ocr_image",
    ".tif": "ocr_image",
    ".gif": "ocr_image",
    ".webp": "ocr_image",
}

_URL_RE = re.compile(r"https?://[^\s\"'<>]+", re.IGNORECASE)

# Keyword cues. Each entry: (regex, tool_name, kwargs).
# Patterns are anchored loosely — any natural reference to the concept
# fires. Keep them tight enough not to trip on incidental usage.
_KEYWORD_TOOLS: tuple[tuple[re.Pattern[str], str, dict], ...] = (
    (
        re.compile(
            r"\b(?:my|the)?\s*clipboard\b|\bwhat\s+(?:did\s+i|i)\s+(?:just\s+)?cop(?:y|ied)\b",
            re.IGNORECASE,
        ),
        "read_clipboard",
        {},
    ),
    (
        re.compile(
            r"\bscreenshot\b|\bwhat'?s?\s+on\s+(?:my\s+)?screen\b|\bcapture\s+(?:my\s+)?screen\b",
            re.IGNORECASE,
        ),
        "take_screenshot",
        {},
    ),
    (
        re.compile(
            r"\b(?:open|active|all)\s+windows?\b|\bwhat\s+windows?\s+(?:do\s+i|are)\s+(?:have\s+)?open\b|\blist\s+windows?\b",
            re.IGNORECASE,
        ),
        "list_windows",
        {},
    ),
    (
        re.compile(
            r"\bsearch\s+(?:the\s+)?web\s+for\b|\bgoogle\s+(?:for\s+)?\b|\blook\s+up\s+online\b",
            re.IGNORECASE,
        ),
        "web_search",
        {},
    ),
    (
        re.compile(
            r"\bremember\s+(?:that|this)\b|\bsave\s+(?:that|this)\s+(?:to\s+)?memory\b",
            re.IGNORECASE,
        ),
        "remember",
        {},
    ),
    (
        re.compile(
            r"\b(?:do\s+you\s+)?recall\b|\bwhat\s+do\s+you\s+remember\b",
            re.IGNORECASE,
        ),
        "recall",
        {},
    ),
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_HINT_PREFIX = "⚙ hint:"

# Strip fenced ```...``` code blocks and inline `code` spans before
# pattern matching — paths, URLs, and keywords inside code are usually
# *examples* the user is asking ABOUT, not ACTIONS to perform.
_CODE_BLOCK_RE = re.compile(r"```.*?```", re.DOTALL)
_INLINE_CODE_RE = re.compile(r"`[^`\n]*`")


def _strip_code_spans(text: str) -> str:
    """Blank out fenced + inline code so matchers don't fire on examples."""
    text = _CODE_BLOCK_RE.sub(" ", text)
    text = _INLINE_CODE_RE.sub(" ", text)
    return text


def _tool_for_path(path: str) -> str:
    """Pick the best reader tool for the file extension."""
    dot = path.rfind(".")
    if dot == -1:
        return "read_file"
    ext = path[dot:].lower()
    return _EXT_TO_TOOL.get(ext, "read_file")


def _fmt_call(tool_name: str, args: dict) -> str:
    """Render a hint as ``tool_name(k='v', k2=42)``."""
    if not args:
        return f"{tool_name}()"
    parts = []
    for k, v in args.items():
        parts.append(f"{k}={v!r}")
    return f"{tool_name}({', '.join(parts)})"


def detect_hints(user_text: str, available_tools: Iterable[str]) -> str | None:
    """Return a hint line for ``user_text``, or None if nothing matched.

    ``available_tools`` is the set of tool names the LLM can actually call
    — hints that name unregistered tools are dropped so the model is
    never told to call something that isn't there.
    """
    available = set(available_tools)
    # Mask code blocks/spans so a `C:/x.docx` inside ``` ```python ``` or
    # an inline `code` span doesn't trigger read_file hints.
    text = _strip_code_spans(user_text)
    suggestions: list[str] = []
    seen: set[str] = set()  # dedupe by formatted call

    # File paths — emit one hint per path with the right reader for the ext.
    for match in _FILE_PATH_RE.finditer(text):
        path = match.group(1)
        tool = _tool_for_path(path)
        if tool not in available:
            continue
        call = _fmt_call(tool, {"path": path})
        if call in seen:
            continue
        seen.add(call)
        suggestions.append(call)

    # URLs — open_url is low-risk for https:// links.
    if "open_url" in available:
        for match in _URL_RE.finditer(text):
            url = match.group(0).rstrip(".,;:!?)")  # trim trailing punctuation
            call = _fmt_call("open_url", {"url": url})
            if call in seen:
                continue
            seen.add(call)
            suggestions.append(call)

    # Keyword phrases.
    for pattern, tool_name, kwargs in _KEYWORD_TOOLS:
        if tool_name not in available:
            continue
        if pattern.search(text):
            call = _fmt_call(tool_name, kwargs)
            if call in seen:
                continue
            seen.add(call)
            suggestions.append(call)

    if not suggestions:
        return None
    if len(suggestions) == 1:
        return f"{_HINT_PREFIX} looks like you want {suggestions[0]} — call that tool now."
    joined = " then ".join(suggestions)
    return f"{_HINT_PREFIX} looks like you want {joined} — call those tools."
