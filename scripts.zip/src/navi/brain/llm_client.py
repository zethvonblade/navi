"""Drop-in replacement for ``llama_cpp.Llama`` that runs inference in a
subprocess (see :mod:`navi.brain.llm_subprocess`).

Why
---
``llama_cpp.Llama.create_chat_completion`` holds the Python GIL for the
duration of prompt evaluation. When the LLM lives in the same process as
the Qt GUI, the GUI thread can't run Python (its QTimer callbacks are
Python) and the orb appears frozen. Hosting the LLM in a subprocess means
inference holds the *subprocess's* GIL — the main process stays smooth.

API surface
-----------
We reproduce only what the rest of Navi calls:

* ``create_chat_completion(messages, tools=None, tool_choice=None,
  max_tokens=None, temperature=None, top_p=None, stream=True)``
  → returns an iterator of llama-cpp-shaped chunk dicts.
* ``cancel()``          — interrupt an in-flight stream.
* ``close()``           — graceful shutdown of the subprocess.

That's enough to satisfy ``brain/worker.py`` and ``tools/summarize.py``
without changes.
"""

from __future__ import annotations

import json
import queue
import subprocess
import sys
import threading
from collections.abc import Iterator
from pathlib import Path
from typing import Any


class LLMSubprocessError(RuntimeError):
    """Raised when the subprocess reports an error or dies unexpectedly."""


class LLMClient:
    def __init__(
        self,
        model_path: Path | str,
        n_ctx: int,
        n_threads: int,
        n_batch: int,
        ready_timeout_s: float = 180.0,
    ) -> None:
        # Spawn the subprocess with the same Python interpreter we're using
        # — the .venv has llama_cpp installed and `navi` editable-installed,
        # so `-m navi.brain.llm_subprocess` resolves correctly.
        self._proc = subprocess.Popen(
            [sys.executable, "-u", "-m", "navi.brain.llm_subprocess"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=sys.stderr,  # so subprocess crashes show up in our console
            text=True,
            bufsize=1,  # line-buffered
            encoding="utf-8",
        )
        self._events: queue.Queue[dict[str, Any] | None] = queue.Queue()
        self._writer_lock = threading.Lock()
        # NOTE: no stream serialization lock — the agent loop is
        # single-threaded (it waits for each tool result before continuing,
        # and tools run synchronously on the brain thread). If we ever want
        # concurrent completions we'll need a request-id scheme.
        self._reader_thread = threading.Thread(
            target=self._reader_loop, daemon=True, name="llm-stdout-reader",
        )
        self._reader_thread.start()
        self._closed = False

        # Boot the model
        self._send({
            "op": "init",
            "model_path": str(model_path),
            "n_ctx": int(n_ctx),
            "n_threads": int(n_threads),
            "n_batch": int(n_batch),
        })
        try:
            evt = self._events.get(timeout=ready_timeout_s)
        except queue.Empty as exc:
            self._kill()
            raise LLMSubprocessError(
                f"subprocess didn't report ready within {ready_timeout_s}s"
            ) from exc
        if evt is None:
            raise LLMSubprocessError("subprocess died before ready")
        if evt.get("event") == "error":
            raise LLMSubprocessError(
                f"subprocess init failed: {evt.get('message')}"
            )
        if evt.get("event") != "ready":
            raise LLMSubprocessError(f"unexpected init event: {evt}")

    # --- stdout reader -------------------------------------------------------
    def _reader_loop(self) -> None:
        assert self._proc.stdout is not None
        for line in self._proc.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                evt = json.loads(line)
            except json.JSONDecodeError:
                # Subprocess wrote non-JSON to stdout (probably a llama.cpp
                # log). Drop silently — it's noise, not data we need.
                continue
            self._events.put(evt)
        # EOF — subprocess died. Push sentinel so any waiter unblocks.
        self._events.put(None)

    # --- writer --------------------------------------------------------------
    def _send(self, req: dict[str, Any]) -> None:
        if self._closed:
            raise LLMSubprocessError("LLMClient is closed")
        if self._proc.stdin is None or self._proc.poll() is not None:
            raise LLMSubprocessError("subprocess is not running")
        line = json.dumps(req) + "\n"
        with self._writer_lock:
            self._proc.stdin.write(line)
            self._proc.stdin.flush()

    # --- public API (mimics llama_cpp.Llama) ---------------------------------
    def create_chat_completion(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        tool_choice: Any = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        stream: bool = True,
    ) -> Iterator[dict[str, Any]] | dict[str, Any]:
        """Run a chat completion in the subprocess.

        Always streams under the hood (the subprocess only supports streaming).
        If ``stream=False`` we collect the chunks and synthesize a single
        response dict mirroring llama-cpp's non-streaming shape.
        """
        self._send({
            "op": "complete",
            "messages": messages,
            "tools": tools,
            "tool_choice": tool_choice,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "top_p": top_p,
        })

        if stream:
            return self._iter_chunks()

        # Non-streaming: accumulate everything into one response dict.
        content_parts: list[str] = []
        tool_call_acc: dict[int, dict[str, Any]] = {}
        finish_reason = "stop"
        for chunk in self._iter_chunks():
            delta = chunk["choices"][0].get("delta", {})
            if delta.get("content"):
                content_parts.append(delta["content"])
            for tc in delta.get("tool_calls") or []:
                idx = tc.get("index", 0)
                acc = tool_call_acc.setdefault(idx, {
                    "id": "", "type": "function",
                    "function": {"name": "", "arguments": ""},
                })
                if tc.get("id"):
                    acc["id"] = tc["id"]
                fn = tc.get("function") or {}
                if fn.get("name"):
                    acc["function"]["name"] += fn["name"]
                if fn.get("arguments"):
                    acc["function"]["arguments"] += fn["arguments"]
            fr = chunk["choices"][0].get("finish_reason")
            if fr:
                finish_reason = fr

        message: dict[str, Any] = {
            "role": "assistant",
            "content": "".join(content_parts),
        }
        if tool_call_acc:
            message["tool_calls"] = [
                tool_call_acc[k] for k in sorted(tool_call_acc)
            ]
        return {
            "choices": [{"index": 0, "message": message,
                         "finish_reason": finish_reason}],
        }

    def _iter_chunks(self) -> Iterator[dict[str, Any]]:
        """Yield ``data`` payloads from chunk events until done/cancelled."""
        while True:
            evt = self._events.get()
            if evt is None:
                raise LLMSubprocessError(
                    "subprocess died mid-completion (check stderr)"
                )
            ev_type = evt.get("event")
            if ev_type == "chunk":
                yield evt["data"]
            elif ev_type in ("done", "cancelled"):
                return
            elif ev_type == "error":
                raise LLMSubprocessError(
                    f"subprocess error: {evt.get('message')}"
                )
            # Other events (e.g. stray "ready") — ignore.

    def cancel(self) -> None:
        """Ask the subprocess to abort an in-flight stream.

        Safe to call when nothing's in flight — the cancel flag is only read
        by the streaming loop. ``cancel`` does NOT acquire ``_stream_lock``;
        that would defeat the purpose.
        """
        try:
            # Bypass the lock — we *want* this to deliver while a complete
            # is running.
            if self._proc.stdin is None or self._proc.poll() is not None:
                return
            line = json.dumps({"op": "cancel"}) + "\n"
            with self._writer_lock:
                self._proc.stdin.write(line)
                self._proc.stdin.flush()
        except Exception:
            pass  # best effort

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        try:
            line = json.dumps({"op": "shutdown"}) + "\n"
            with self._writer_lock:
                if self._proc.stdin and self._proc.poll() is None:
                    self._proc.stdin.write(line)
                    self._proc.stdin.flush()
                    self._proc.stdin.close()
        except Exception:
            pass
        try:
            self._proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            self._kill()

    def _kill(self) -> None:
        try:
            self._proc.kill()
        except Exception:
            pass
        try:
            self._proc.wait(timeout=2)
        except Exception:
            pass

    def __del__(self) -> None:  # best-effort cleanup
        try:
            self.close()
        except Exception:
            pass
