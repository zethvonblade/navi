"""Reinstall llama-cpp-python with a CUDA-enabled prebuilt wheel.

Background
----------
``llama-cpp-python`` ships separate wheels for CPU-only and CUDA builds.
The user's setup ships the CPU wheel by default; switching the brain to
GPU requires swapping the installed wheel. Building from source is
blocked on this machine by group policy, so we lean exclusively on
abetlen's prebuilt wheel index — ``--only-binary=:all:`` keeps pip from
attempting any local compile.

The install is driven from the GUI (Settings → CPU/GPU), so it runs in a
QThread and emits Qt signals for progress / completion.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from PySide6.QtCore import QObject, QThread, Signal


# abetlen's CUDA wheel index tops out at 0.3.4 (cu125+ have nothing at all),
# while the CPU wheel index ships current versions. Auto-install will
# therefore DOWNGRADE llama-cpp-python on the GPU path — the user is warned
# before this runs. cu124 wheels work with any NVIDIA driver new enough for
# CUDA 12.4 runtime (driver >= 550).
CUDA_WHEEL_INDEX = "https://abetlen.github.io/llama-cpp-python/whl/cu124"
CPU_WHEEL_INDEX = "https://abetlen.github.io/llama-cpp-python/whl/cpu"
CUDA_WHEEL_MAX_VERSION = "0.3.4"  # for messaging only


CUDA_DOWNLOAD_URL = "https://developer.nvidia.com/cuda-downloads"


def cuda_runtime_present() -> bool:
    """True if a CUDA 12.x runtime DLL can be located on this machine.

    The CUDA wheel of llama-cpp-python links against ``cudart64_12.dll`` and
    friends. These ship with the CUDA Toolkit, NOT with the NVIDIA driver,
    so a user with only the driver installed will get a DLL-load failure
    when llama_cpp tries to import. We catch that situation up front.
    """
    candidates = ["cudart64_12.dll", "cudart64_120.dll", "cudart64_121.dll",
                  "cudart64_122.dll", "cudart64_123.dll", "cudart64_124.dll"]
    # Walk PATH first — covers `CUDA_PATH/bin` if the toolkit installer added it.
    for d in os.environ.get("PATH", "").split(os.pathsep):
        if not d:
            continue
        for name in candidates:
            try:
                if (Path(d) / name).exists():
                    return True
            except OSError:
                continue
    # Fall back to the standard install root in case PATH wasn't updated.
    root = Path("C:/Program Files/NVIDIA GPU Computing Toolkit/CUDA")
    if root.exists():
        for sub in root.iterdir():
            for name in candidates:
                if (sub / "bin" / name).exists():
                    return True
    return False


def validate_llama_cpp_loadable() -> tuple[bool, str]:
    """Run ``import llama_cpp`` in a subprocess; return (ok, error_message).

    Catches the case where the wheel installs cleanly but the underlying
    DLL fails to load (missing CUDA runtime, ABI mismatch, etc.).
    """
    try:
        result = subprocess.run(
            [sys.executable, "-c", "import llama_cpp; print('OK')"],
            capture_output=True, text=True, timeout=30,
        )
    except Exception as exc:  # noqa: BLE001
        return False, f"validation subprocess failed: {exc}"
    if result.returncode == 0 and "OK" in result.stdout:
        return True, ""
    err = (result.stderr or result.stdout or "").strip()
    # Trim long tracebacks to the most relevant line.
    last = err.splitlines()[-1] if err else "no output"
    return False, last


def gpu_offload_supported() -> bool:
    """True if the installed llama-cpp build can offload to GPU.

    Runs the check in a one-shot subprocess so the calling (GUI) process
    never imports ``llama_cpp``. That matters because pip can't uninstall a
    wheel whose DLLs are loaded into a running process on Windows — letting
    the GUI keep llama_cpp unimported keeps the install path unblocked.
    """
    try:
        result = subprocess.run(
            [sys.executable, "-c",
             "from llama_cpp import llama_supports_gpu_offload as f; "
             "print('1' if f() else '0')"],
            capture_output=True, text=True, timeout=20,
        )
        return result.stdout.strip() == "1"
    except Exception:
        return False


class WheelInstaller(QObject):
    """Runs ``pip install`` in a worker thread, streams stdout via signals."""

    line = Signal(str)        # one stdout/stderr line
    finished = Signal(bool, str)  # (ok, final message)

    def __init__(self, target: str = "cuda") -> None:
        """target: 'cuda' or 'cpu' — which wheel index to install from."""
        super().__init__()
        self._target = target
        self._proc: subprocess.Popen[str] | None = None

    def cancel(self) -> None:
        """Best-effort kill of the running pip subprocess."""
        try:
            if self._proc and self._proc.poll() is None:
                self._proc.kill()
        except Exception:
            pass

    def run(self) -> None:
        index = CUDA_WHEEL_INDEX if self._target == "cuda" else CPU_WHEEL_INDEX
        # No version pin — abetlen's CUDA index doesn't carry recent versions,
        # so we install whatever's newest there (currently 0.3.4 for cu124).
        # --index-url (not --extra-index-url) keeps pip from preferring the
        # newer CPU wheel from PyPI over the CUDA wheel.
        cmd = [
            sys.executable, "-m", "pip", "install",
            "--force-reinstall", "--upgrade", "--no-deps",
            "--only-binary=:all:",
            "--progress-bar", "off",  # \r-based bars stall our line iterator
            "--index-url", index,
            "llama-cpp-python",
        ]
        self.line.emit(f"$ {' '.join(cmd)}")
        try:
            self._proc = subprocess.Popen(
                cmd,
                stdin=subprocess.DEVNULL,  # don't inherit GUI stdin — pip prompt would hang
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                encoding="utf-8",
                errors="replace",
            )
            assert self._proc.stdout is not None
            for raw in self._proc.stdout:
                self.line.emit(raw.rstrip())
            rc = self._proc.wait()
        except Exception as exc:  # noqa: BLE001
            self.finished.emit(False, f"installer failed to launch: {exc}")
            return
        if rc == 0:
            self.finished.emit(True, "Install complete. Restart Navi to load the new build.")
        else:
            self.finished.emit(False, f"pip exited with code {rc}")


def start_install(target: str = "cuda") -> tuple[QThread, WheelInstaller]:
    """Spawn a thread running the installer. Caller wires signals + starts."""
    thread = QThread()
    worker = WheelInstaller(target)
    worker.moveToThread(thread)
    thread.started.connect(worker.run)
    worker.finished.connect(thread.quit)
    return thread, worker
