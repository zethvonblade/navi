from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from PySide6.QtCore import QObject, Signal, Slot

from navi.brain.config import BrainConfig
from navi.brain.persona import SYSTEM_PROMPT, build_system_prompt
from navi.perms import audit
from navi.perms.dispatcher import PermissionDispatcher
from navi.perms.engine import Decision, PermissionEngine
from navi.tools import get_tool, tools_schema
from navi.tools._paths import normalize_windows_path


def brain_history_path() -> Path:
    appdata = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming")))
    return appdata / "Navi" / "brain_history.json"

MAX_TOOL_ITERATIONS = 3  # safety bound on tool-call loops; tighter = fail-fast on confusion

# Granite 3.x emits tool calls as raw text prefixed with one of these markers
# rather than via OpenAI-style structured ``tool_calls`` deltas. After the
# first successful call in a session, Granite often DROPS the marker entirely
# and emits a bare ``[{"name": ..., "arguments": ...}]`` JSON array, so the
# sniffer also accepts that shape.
_TOOL_CALL_MARKERS = ("<|tool_call|>", "<tool_call>", "[tool_call]")
_SNIFF_BYTES = max(max(len(m) for m in _TOOL_CALL_MARKERS), len('[{"name":'))


@dataclass
class _Message:
    role: str
    content: str = ""  # ALWAYS a string — Granite's Jinja template does
    # ``+ message['content']`` directly and crashes on None or missing key.
    tool_calls: list[dict[str, Any]] | None = None
    tool_call_id: str | None = None
    name: str | None = None  # for ``role == "tool"``

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"role": self.role, "content": self.content}
        if self.tool_calls:
            out["tool_calls"] = self.tool_calls
        if self.tool_call_id:
            out["tool_call_id"] = self.tool_call_id
        if self.name:
            out["name"] = self.name
        return out

    def to_persist(self) -> dict[str, Any]:
        """Serialize for on-disk storage. Same shape as to_dict but explicit."""
        return self.to_dict()

    @classmethod
    def from_persist(cls, d: dict[str, Any]) -> "_Message":
        return cls(
            role=d.get("role", "user"),
            content=d.get("content", ""),
            tool_calls=d.get("tool_calls"),
            tool_call_id=d.get("tool_call_id"),
            name=d.get("name"),
        )


@dataclass
class _ToolCallAcc:
    """Accumulator for streaming tool-call deltas."""

    id: str = ""
    type: str = "function"
    name: str = ""
    arguments: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "type": self.type,
            "function": {"name": self.name, "arguments": self.arguments},
        }


class BrainWorker(QObject):
    """Owns the Llama instance and runs an agent loop with tool support.

    Lives on a QThread (use ``moveToThread``). All public slots should be
    connected with the default ``AutoConnection`` so cross-thread invocations
    queue properly.
    """

    # Lifecycle / state signals
    state_loading = Signal()
    state_ready = Signal()
    state_thinking = Signal()
    state_speaking = Signal()
    state_asking = Signal()
    state_idle = Signal()
    state_error = Signal(str)

    # Streaming signals
    response_started = Signal()
    token = Signal(str)
    response_finished = Signal()

    # Tool signals
    tool_call = Signal(str, dict, str)  # name, args, decision
    tool_progress = Signal(str)  # one-line status updates from in-flight tools

    def __init__(
        self,
        config: BrainConfig,
        perms: PermissionEngine,
        dispatcher: PermissionDispatcher,
    ) -> None:
        super().__init__()
        self._config = config
        self._perms = perms
        self._dispatcher = dispatcher
        self._llm: Any = None  # llama_cpp.Llama
        self._history: list[_Message] = self._load_or_init_history()
        self._cancel = False

    # --- lifecycle ----------------------------------------------------------
    @Slot()
    def start(self) -> None:
        self.state_loading.emit()
        try:
            if not self._config.model_path.exists():
                raise FileNotFoundError(
                    f"Model file not found: {self._config.model_path}\n"
                    "Run: python scripts/download_model.py  "
                    "(or drop a GGUF in ./models/)"
                )
            from navi.brain.llm_client import LLMClient

            # Run llama-cpp in a subprocess so its GIL hold during prompt
            # eval doesn't starve the GUI thread (the orb stops animating
            # otherwise — see feedback_llama_streaming.md).
            self._llm = LLMClient(
                model_path=self._config.model_path,
                n_ctx=self._config.n_ctx,
                n_threads=self._config.n_threads,
                n_batch=self._config.n_batch,
            )
            # Expose the loaded model + a progress channel to tools that
            # need to make their own LLM calls (e.g. summarize_file's
            # map-reduce). brain.shared is a pragmatic singleton — there's
            # exactly one BrainWorker per session.
            from navi.brain import shared
            shared.set_llm(self._llm)
            shared.set_progress_callback(lambda msg: self.tool_progress.emit(msg))
            shared.set_cancel_check(lambda: self._cancel)
            # GBNF grammar would be the ideal way to constrain tool-call
            # output, but llama-cpp-python 0.3.19 (CPU prebuilt wheel for
            # Python 3.12 Windows) segfaults in `llama_sampler_sample` as
            # soon as ANY grammar is applied — including trivial ones like
            # ``root ::= [a-z ]+`` and the OpenAI-style `response_format=
            # {"type": "json_object"}` (which uses grammar internally).
            # Until we can install a fixed wheel or build from source
            # (blocked by group policy on this machine), we rely on the
            # heuristic parser tolerance in `_parse_granite_tool_calls` +
            # `_extract_bracket_tool_calls`. The grammar generator in
            # `brain/grammar.py` is kept for the day this is fixable.
            self.state_ready.emit()
            self.state_idle.emit()
        except Exception as exc:
            self.state_error.emit(str(exc))

    # --- chat ---------------------------------------------------------------
    @Slot(str)
    def submit(self, user_text: str) -> None:
        if self._llm is None:
            self.state_error.emit("Model not loaded.")
            return
        text = user_text.strip()
        if not text:
            return

        self._cancel = False
        # Refresh system prompt so any new memories saved this session show up
        if self._history and self._history[0].role == "system":
            self._history[0] = _Message("system", build_system_prompt())
        self._history.append(_Message("user", text))
        self.state_thinking.emit()
        self.response_started.emit()

        try:
            self._run_agent_loop()
        except Exception as exc:
            self.state_error.emit(f"Generation failed: {exc}")
        finally:
            self._save_history_file()
            self.response_finished.emit()
            self.state_idle.emit()

    @Slot()
    def reset_history(self) -> None:
        self._history = [_Message("system", build_system_prompt())]
        self._save_history_file()

    # --- persistence -------------------------------------------------------
    def _load_or_init_history(self) -> list[_Message]:
        path = brain_history_path()
        if not path.exists():
            return [_Message("system", build_system_prompt())]
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, list):
                raise ValueError("brain history must be a list")
            msgs = [_Message.from_persist(m) for m in data if isinstance(m, dict)]
            # Always replace the system message with a fresh one (memory + persona may have changed)
            if msgs and msgs[0].role == "system":
                msgs[0] = _Message("system", build_system_prompt())
            elif msgs:
                msgs.insert(0, _Message("system", build_system_prompt()))
            else:
                msgs = [_Message("system", build_system_prompt())]
            return msgs
        except (OSError, json.JSONDecodeError, ValueError, TypeError):
            return [_Message("system", build_system_prompt())]

    def _save_history_file(self) -> None:
        try:
            path = brain_history_path()
            path.parent.mkdir(parents=True, exist_ok=True)
            data = [m.to_persist() for m in self._history]
            path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        except OSError:
            pass  # best-effort

    @Slot()
    def cancel(self) -> None:
        self._cancel = True
        # Also signal the LLM subprocess so it bails out of any in-flight
        # streaming completion immediately (otherwise we'd wait until the
        # next chunk yields before the streaming loop notices _cancel).
        if self._llm is not None and hasattr(self._llm, "cancel"):
            try:
                self._llm.cancel()
            except Exception:
                pass

    # --- agent loop ---------------------------------------------------------
    def _run_agent_loop(self) -> None:
        saw_text_token = False
        for _ in range(MAX_TOOL_ITERATIONS):
            if self._cancel:
                return

            text_parts, tool_calls, raw_content = self._stream_one_turn(saw_text_token)
            saw_text_token = saw_text_token or bool(text_parts)

            if not tool_calls:
                # Final assistant message — done.
                if raw_content:
                    self._history.append(_Message("assistant", raw_content))
                return

            # Execute every tool call in the batch sequentially. Granite
            # often emits intentional batches (open_app + type_text) and
            # capping to one breaks legitimate multi-step intent. The
            # docx-spiral problem is now handled at the tool level: ocr_image
            # rejects non-image extensions cleanly, so a speculative
            # ocr_image call on a .docx no longer pollutes context.
            self._history.append(
                _Message("assistant", raw_content, tool_calls=tool_calls)
            )

            for call in tool_calls:
                if self._cancel:
                    return
                self._handle_tool_call(call)

            # Loop again: model gets to see the tool results.
            self.state_thinking.emit()

    def _stream_one_turn(
        self, already_speaking: bool
    ) -> tuple[list[str], list[dict[str, Any]], str]:
        """Run one streaming completion.

        Returns ``(text_parts_emitted, tool_calls, raw_content)``:
          - ``text_parts_emitted`` — text already streamed to the user (empty
            for tool-call turns since we suppress emission).
          - ``tool_calls`` — parsed tool calls, OpenAI-shaped.
          - ``raw_content`` — the full, verbatim assistant text including any
            ``<|tool_call|>...`` marker. This goes into history so Granite
            sees its own past tool calls (its chat template does not render
            structured ``tool_calls`` fields).

        Handles two tool-call dialects:
          1. OpenAI-style structured ``tool_calls`` deltas (most chat handlers).
          2. Granite-style ``<|tool_call|>[{...}]`` raw text (parsed locally).
        """
        messages = [m.to_dict() for m in self._history]
        stream = self._llm.create_chat_completion(
            messages=messages,
            tools=tools_schema(),
            tool_choice="auto",
            temperature=self._config.temperature,
            top_p=self._config.top_p,
            max_tokens=self._config.max_tokens,
            stream=True,
        )

        text_acc: list[str] = []
        tool_accs: dict[int, _ToolCallAcc] = {}
        switched_to_speaking = already_speaking
        sniffed = False
        is_granite_tool = False

        for chunk in stream:
            if self._cancel:
                break
            delta = chunk["choices"][0].get("delta", {})

            content = delta.get("content")
            if content:
                text_acc.append(content)

                if not sniffed:
                    joined = "".join(text_acc).lstrip()
                    if len(joined) >= _SNIFF_BYTES or chunk["choices"][0].get(
                        "finish_reason"
                    ):
                        sniffed = True
                        is_granite_tool = _looks_like_tool_call(joined)
                        if not is_granite_tool:
                            # Flush the buffered prefix as visible text.
                            if not switched_to_speaking:
                                self.state_speaking.emit()
                                switched_to_speaking = True
                            self.token.emit("".join(text_acc))
                elif not is_granite_tool:
                    self.token.emit(content)

            tcs = delta.get("tool_calls") or []
            for call_delta in tcs:
                idx = call_delta.get("index", 0)
                acc = tool_accs.setdefault(idx, _ToolCallAcc())
                if call_delta.get("id"):
                    acc.id = call_delta["id"]
                fn = call_delta.get("function") or {}
                if fn.get("name"):
                    acc.name += fn["name"]
                if fn.get("arguments"):
                    acc.arguments += fn["arguments"]

        raw_content = "".join(text_acc)

        # If we accumulated Granite-style raw tool calls, parse them now.
        if is_granite_tool and not tool_accs:
            parsed = _parse_granite_tool_calls(raw_content)
            if parsed is not None:
                return [], parsed, raw_content
            # Parse failed — degrade to showing the raw text so the user
            # at least sees what the model produced.
            if not switched_to_speaking:
                self.state_speaking.emit()
            self.token.emit(raw_content)
            return text_acc, [], raw_content

        if tool_accs:
            return [], [acc.to_dict() for acc in tool_accs.values()], raw_content

        # Late-stage rescue passes for tool calls embedded mid-prose.
        # Granite often narrates ("I'll use X. Here's how: <|tool_call|>[...]")
        # — the early sniff sees only the prose and streams it as text, then
        # the actual tool call falls through. Two formats to catch:
        #   1. ``<|tool_call|>[{...}]`` (or `<tool_call>` / `[tool_call]`)
        #   2. ``[tool:NAME, arguments: {...}]`` pseudo-syntax
        marker_calls = _extract_marker_tool_calls(raw_content)
        if marker_calls:
            return text_acc, marker_calls, raw_content
        bracket_calls = _extract_bracket_tool_calls(raw_content)
        if bracket_calls:
            return text_acc, bracket_calls, raw_content

        return text_acc, [], raw_content

    def _handle_tool_call(self, call: dict[str, Any]) -> None:
        name = call["function"]["name"]
        raw_args = call["function"]["arguments"] or "{}"
        try:
            args = json.loads(raw_args)
            if not isinstance(args, dict):
                args = {}
        except json.JSONDecodeError:
            args = {}

        # Repair model-emitted Unix-style paths so they match Windows allow
        # rules AND find the real file.
        if "path" in args and isinstance(args["path"], str):
            args["path"] = normalize_windows_path(args["path"])

        tool = get_tool(name)
        if tool is None:
            result = f"Error: unknown tool '{name}'."
            self.tool_call.emit(name, args, "unknown")
            audit.append(tool=name, args=args, risk="?", decision="unknown", error=result)
            self._append_tool_result(call, name, result)
            return

        decision = self._perms.evaluate(name, args, tool.risk)

        if decision is Decision.DENY:
            self.tool_call.emit(name, args, "denied")
            denial = f"Permission denied by policy: {name}"
            audit.append(tool=name, args=args, risk=tool.risk, decision="denied")
            self._append_tool_result(call, name, denial)
            return

        if decision is Decision.ASK:
            self.state_asking.emit()
            allowed = self._dispatcher.request_permission(name, args, tool.risk)
            self.state_thinking.emit()
            if not allowed:
                self.tool_call.emit(name, args, "user-denied")
                audit.append(tool=name, args=args, risk=tool.risk, decision="user-denied")
                self._append_tool_result(
                    call, name, f"User denied permission to call {name}."
                )
                return
            self.tool_call.emit(name, args, "user-allowed")
            decision_label = "user-allowed"
        else:
            self.tool_call.emit(name, args, "allowed")
            decision_label = "allowed"

        try:
            result = tool.func(**args)
        except TypeError as exc:
            result = f"Error: bad arguments for {name}: {exc}"
        except Exception as exc:
            result = f"Error executing {name}: {exc}"

        audit.append(
            tool=name,
            args=args,
            risk=tool.risk,
            decision=decision_label,
            result=str(result),
        )
        self._append_tool_result(call, name, result)

    def _append_tool_result(self, call: dict[str, Any], name: str, result: Any) -> None:
        self._history.append(
            _Message(
                role="tool",
                content=str(result),
                tool_call_id=call.get("id", ""),
                name=name,
            )
        )


import re as _re

_BARE_JSON_TOOL_RE = _re.compile(r'^\s*\[?\s*\{\s*["\'](?:name|function)["\']\s*:')

# Granite occasionally invents pseudo-syntaxes after the first successful
# tool call, e.g. ``[tool:type_text, arguments: {"text": "..."}]``. These
# are not JSON but follow a recognisable shape.
_BRACKET_TOOL_RE = _re.compile(
    r"\[tool[_:]?\s*([A-Za-z_][A-Za-z0-9_]*)\s*,\s*"
    r"(?:arguments|parameters)\s*:\s*(\{.*?\})\s*\]",
    _re.DOTALL,
)


def _looks_like_tool_call(text: str) -> bool:
    """True if ``text`` (already lstripped) appears to start a tool call.

    Note: this is a STARTSWITH check used for early-stream sniffing.
    For mid-stream pseudo-tool-calls embedded in narration (e.g. Granite's
    ``[tool:NAME, arguments: {...}]`` after a "Now I'll type..." preamble),
    we run :func:`_extract_bracket_tool_calls` on the full response after
    streaming completes.
    """
    if any(text.startswith(m) for m in _TOOL_CALL_MARKERS):
        return True
    return bool(_BARE_JSON_TOOL_RE.match(text))


def _extract_marker_tool_calls(text: str) -> list[dict[str, Any]] | None:
    """Find ``<|tool_call|>[{...}]`` (or one of the marker variants) ANYWHERE
    in ``text``, including embedded mid-prose.

    The early-stream sniff in ``_stream_one_turn`` only catches markers at the
    start of the response. When Granite preambles ("I'll use the X tool to...
    Here's how: <|tool_call|>[{...}]") the marker appears mid-response and
    falls through. This catches that case after streaming completes.
    """
    earliest = -1
    for marker in _TOOL_CALL_MARKERS:
        idx = text.find(marker)
        if idx != -1 and (earliest == -1 or idx < earliest):
            earliest = idx
    if earliest == -1:
        return None
    return _parse_granite_tool_calls(text[earliest:])


def _extract_bracket_tool_calls(text: str) -> list[dict[str, Any]] | None:
    """Find ``[tool:NAME, arguments: {...}]`` pseudo-syntax anywhere in ``text``."""
    matches = _BRACKET_TOOL_RE.findall(text)
    if not matches:
        return None
    calls: list[dict[str, Any]] = []
    for i, (name, args_json) in enumerate(matches):
        try:
            args = json.loads(args_json)
        except json.JSONDecodeError:
            continue
        if not isinstance(args, dict):
            continue
        calls.append(
            {
                "id": f"call_{i}",
                "type": "function",
                "function": {"name": name, "arguments": json.dumps(args)},
            }
        )
    return calls or None


def _serialize_single_tool_call(call: dict[str, Any]) -> str:
    """Build the assistant ``<|tool_call|>[{...}]`` content for a single call.

    Used when we cap the model's multi-call output to just the first call,
    so the conversation history reflects what was actually executed.
    """
    fn = call.get("function", {})
    return (
        "<|tool_call|>["
        + json.dumps(
            {"name": fn.get("name", ""), "arguments": json.loads(fn.get("arguments") or "{}")}
        )
        + "]"
    )


def _parse_granite_tool_calls(raw: str) -> list[dict[str, Any]] | None:
    """Parse a Granite-style ``<|tool_call|>[{name, arguments}]`` blob.

    Returns OpenAI-shaped ``tool_calls`` list, or None on parse failure.
    """
    text = raw.lstrip()
    for marker in _TOOL_CALL_MARKERS:
        if text.startswith(marker):
            text = text[len(marker) :].strip()
            break
    # Some Granite outputs forget the wrapping `[...]` and emit a single dict.
    if text.startswith("{"):
        text = "[" + text + "]"
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        # Try trimming trailing junk after the matching `]`.
        depth = 0
        end = -1
        for i, c in enumerate(text):
            if c == "[":
                depth += 1
            elif c == "]":
                depth -= 1
                if depth == 0:
                    end = i + 1
                    break
        if end == -1:
            return None
        try:
            data = json.loads(text[:end])
        except json.JSONDecodeError:
            return None
    if not isinstance(data, list):
        return None

    calls: list[dict[str, Any]] = []
    for i, entry in enumerate(data):
        if not isinstance(entry, dict):
            return None
        normalized = _normalize_call_entry(entry)
        if normalized is None:
            return None
        name, args = normalized
        if not isinstance(args, str):
            args = json.dumps(args)
        calls.append(
            {
                "id": f"call_{i}",
                "type": "function",
                "function": {"name": name, "arguments": args},
            }
        )
    return calls


def _normalize_call_entry(entry: dict[str, Any]) -> tuple[str, Any] | None:
    """Normalize Granite's varied tool-call shapes to ``(name, args)``.

    Recognized shapes::

        {"name": "X", "arguments": {...}}                        # canonical
        {"function": "X", "arguments": {...}}                    # function as string
        {"function": {"name": "X", "arguments": {...}}}          # nested
        {"name": "X", "parameters": {...}}                       # parameters synonym
    """
    args: Any = entry.get("arguments")
    if args is None:
        args = entry.get("parameters", {})

    name: str | None = None
    if isinstance(entry.get("name"), str):
        name = entry["name"]
    elif "function" in entry:
        fn = entry["function"]
        if isinstance(fn, str):
            name = fn
        elif isinstance(fn, dict):
            if isinstance(fn.get("name"), str):
                name = fn["name"]
            if "arguments" in fn:
                args = fn["arguments"]
            elif "parameters" in fn:
                args = fn["parameters"]

    if not name:
        return None
    return name, args
