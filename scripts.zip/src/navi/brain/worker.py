from __future__ import annotations

import json
import os
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from PySide6.QtCore import QObject, Signal, Slot

from navi.brain.config import BrainConfig
from navi.brain.parsers import (
    PARSERS,
    parse_any_tool_call,
    text_starts_tool_call,
)
from navi.brain.persona import SYSTEM_PROMPT, build_system_prompt
from navi.perms import audit
from navi.perms.dispatcher import PermissionDispatcher
from navi.perms.engine import Decision, PermissionEngine
from navi.tools import get_tool, tools_schema
from navi.tools._paths import normalize_windows_path


def brain_history_path() -> Path:
    appdata = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming")))
    return appdata / "Navi" / "brain_history.json"

MAX_TOOL_ITERATIONS = 3  # safety bound on tool-call loops; tighter = fail-fast on confusion

# Drift detection: how many bad turns before we suggest /calibrate.
# Low number = noisy nags; high number = users suffer through degradation.
_DRIFT_THRESHOLD = 3

# Number of streamed bytes to buffer before deciding whether the response
# is a tool call. Computed from the longest sniff marker registered in
# `brain.parsers`, with a safety floor so bare-JSON sniffs ("[{name":)
# also have enough material.
_SNIFF_BYTES = max(
    max(
        (len(m) for p in PARSERS for m in p.sniff_markers),
        default=14,
    ),
    len('[{"name":'),
)


@dataclass
class _Message:
    role: str
    content: str = ""  # ALWAYS a string — Granite's Jinja template does
    # ``+ message['content']`` directly and crashes on None or missing key.
    tool_calls: list[dict[str, Any]] | None = None
    tool_call_id: str | None = None
    name: str | None = None  # for ``role == "tool"``

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"role": self.role, "content": self.content}
        if self.tool_calls:
            out["tool_calls"] = self.tool_calls
        if self.tool_call_id:
            out["tool_call_id"] = self.tool_call_id
        if self.name:
            out["name"] = self.name
        return out

    def to_persist(self) -> dict[str, Any]:
        """Serialize for on-disk storage. Same shape as to_dict but explicit."""
        return self.to_dict()

    @classmethod
    def from_persist(cls, d: dict[str, Any]) -> "_Message":
        return cls(
            role=d.get("role", "user"),
            content=d.get("content", ""),
            tool_calls=d.get("tool_calls"),
            tool_call_id=d.get("tool_call_id"),
            name=d.get("name"),
        )


@dataclass
class _ToolCallAcc:
    """Accumulator for streaming tool-call deltas."""

    id: str = ""
    type: str = "function"
    name: str = ""
    arguments: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "type": self.type,
            "function": {"name": self.name, "arguments": self.arguments},
        }


class BrainWorker(QObject):
    """Owns the Llama instance and runs an agent loop with tool support.

    Lives on a QThread (use ``moveToThread``). All public slots should be
    connected with the default ``AutoConnection`` so cross-thread invocations
    queue properly.
    """

    # Lifecycle / state signals
    state_loading = Signal()
    state_ready = Signal()
    state_thinking = Signal()
    state_speaking = Signal()
    state_asking = Signal()
    state_idle = Signal()
    state_error = Signal(str)

    # Streaming signals
    response_started = Signal()
    token = Signal(str)
    response_finished = Signal()

    # Tool signals
    tool_call = Signal(str, dict, str)  # name, args, decision
    tool_progress = Signal(str)  # one-line status updates from in-flight tools
    tool_result = Signal(str, str)  # name, result string (chat may render
                                     # specially, e.g. inline image preview)

    # Calibration: emitted after a model load runs the probe battery.
    # Payload is the str-rendered report; PetWindow shows it in chat.
    calibration_done = Signal(str)
    calibration_started = Signal(str)  # one-line "running calibration…" hint
    # Per-probe progress: (current_1based, total, probe_name). PetWindow
    # uses this to update the tray tooltip + chat status bar so the user
    # knows calibration is alive without staring at the chat history.
    calibration_progress = Signal(int, int, str)
    # Tool-use hint injected into a user message (file paths → read_file
    # etc.). Always fires when a hint is detected; PetWindow only forwards
    # to chat when settings.ui.showHints is true.
    hint_injected = Signal(str)

    # Drift detection: raised when the model's output looks like an
    # unparsed tool call or fake dialogue leaking into visible chat.
    # PetWindow surfaces a one-time suggestion to /calibrate.
    drift_detected = Signal(str)  # the user-visible reason

    def __init__(
        self,
        config: BrainConfig,
        perms: PermissionEngine,
        dispatcher: PermissionDispatcher,
    ) -> None:
        super().__init__()
        self._config = config
        self._perms = perms
        self._dispatcher = dispatcher
        self._llm: Any = None  # llama_cpp.Llama
        self._history: list[_Message] = self._load_or_init_history()
        # threading.Event (not a bare bool) so the cross-thread cancel signal
        # has proper happens-before semantics — bare bool reads/writes are
        # atomic in CPython but lack memory barriers between threads.
        self._cancel = threading.Event()
        # Drift counter: increments when an assistant turn ends with raw
        # tool-call markers / fake-dialogue artifacts visible in the user
        # text. After _DRIFT_THRESHOLD events we emit drift_detected.
        self._drift_count = 0
        self._drift_warned = False  # only nag once per session

    # --- lifecycle ----------------------------------------------------------
    @Slot()
    def start(self) -> None:
        self.state_loading.emit()
        try:
            if not self._config.model_path.exists():
                raise FileNotFoundError(
                    f"Model file not found: {self._config.model_path}\n"
                    "Run: python scripts/download_model.py  "
                    "(or drop a GGUF in ./models/)"
                )
            from navi.brain.llm_client import LLMClient

            # Run llama-cpp in a subprocess so its GIL hold during prompt
            # eval doesn't starve the GUI thread (the orb stops animating
            # otherwise — see feedback_llama_streaming.md).
            self._llm = LLMClient(
                model_path=self._config.model_path,
                n_ctx=self._config.n_ctx,
                n_threads=self._config.n_threads,
                n_batch=self._config.n_batch,
                n_gpu_layers=self._config.n_gpu_layers,
            )
            # Expose the loaded model + a progress channel to tools that
            # need to make their own LLM calls (e.g. summarize_file's
            # map-reduce). brain.shared is a pragmatic singleton — there's
            # exactly one BrainWorker per session.
            from navi.brain import shared
            shared.set_llm(self._llm)
            shared.set_progress_callback(lambda msg: self.tool_progress.emit(msg))
            shared.set_cancel_check(self._cancel.is_set)
            # GBNF grammar would be the ideal way to constrain tool-call
            # output, but llama-cpp-python 0.3.19 (CPU prebuilt wheel for
            # Python 3.12 Windows) segfaults in `llama_sampler_sample` as
            # soon as ANY grammar is applied — including trivial ones like
            # ``root ::= [a-z ]+`` and the OpenAI-style `response_format=
            # {"type": "json_object"}` (which uses grammar internally).
            # Until we can install a fixed wheel or build from source
            # (blocked by group policy on this machine), we rely on the
            # heuristic parser tolerance in `_parse_granite_tool_calls` +
            # `_extract_bracket_tool_calls`. The grammar generator in
            # `brain/grammar.py` is kept for the day this is fixable.
            self.state_ready.emit()
            self.state_idle.emit()
            # Run calibration probes against the freshly-loaded model so the
            # user can see immediately whether tool-calling + reasoning still
            # work. Wrapped in try/except so a broken probe never blocks
            # normal use — the user can always run /calibrate manually later.
            try:
                self._run_calibration()
            except Exception as exc:  # noqa: BLE001
                self.calibration_done.emit(
                    f"⚠ calibration crashed: {exc}\n"
                    "(model is loaded; tools may still work — try a query)"
                )
        except Exception as exc:
            self.state_error.emit(str(exc))

    # --- chat ---------------------------------------------------------------
    @Slot(str)
    def submit(self, user_text: str) -> None:
        if self._llm is None:
            self.state_error.emit("Model not loaded.")
            return
        text = user_text.strip()
        if not text:
            return

        self._cancel.clear()
        # Refresh system prompt so any new memories saved this session show up
        if self._history and self._history[0].role == "system":
            self._history[0] = _Message("system", build_system_prompt())
        # Inject tool-use hints for the brain (helps weak models like
        # Phi-4-mini connect "Read this file: X" → read_file). The
        # brain sees the hint prepended to the user text; PetWindow
        # decides whether to surface it in chat (settings.ui.showHints).
        from navi.brain.hints import detect_hints
        from navi.tools import tools_schema as _tools_schema
        available = {t["function"]["name"] for t in _tools_schema()}
        hint = detect_hints(text, available)
        if hint:
            self.hint_injected.emit(hint)
            text = f"{hint}\n\n{text}"
        self._history.append(_Message("user", text))
        self.state_thinking.emit()
        self.response_started.emit()

        try:
            self._run_agent_loop()
        except Exception as exc:
            self.state_error.emit(f"Generation failed: {exc}")
        finally:
            self._save_history_file()
            self.response_finished.emit()
            self.state_idle.emit()

    @Slot()
    def reset_history(self) -> None:
        self._history = [_Message("system", build_system_prompt())]
        self._save_history_file()

    # --- persistence -------------------------------------------------------
    def _load_or_init_history(self) -> list[_Message]:
        path = brain_history_path()
        if not path.exists():
            return [_Message("system", build_system_prompt())]
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, list):
                raise ValueError("brain history must be a list")
            msgs = [_Message.from_persist(m) for m in data if isinstance(m, dict)]
            # Always replace the system message with a fresh one (memory + persona may have changed)
            if msgs and msgs[0].role == "system":
                msgs[0] = _Message("system", build_system_prompt())
            elif msgs:
                msgs.insert(0, _Message("system", build_system_prompt()))
            else:
                msgs = [_Message("system", build_system_prompt())]
            return msgs
        except (OSError, json.JSONDecodeError, ValueError, KeyError):
            # KeyError covers _Message.from_persist missing fields; we
            # deliberately don't catch TypeError here so genuine bugs (e.g.
            # someone changed _Message's signature) surface loudly instead
            # of silently emptying the user's history.
            return [_Message("system", build_system_prompt())]

    def _save_history_file(self) -> None:
        try:
            path = brain_history_path()
            data = [m.to_persist() for m in self._history]
            from navi._io import atomic_write_text
            atomic_write_text(path, json.dumps(data, ensure_ascii=False))
        except OSError:
            pass  # best-effort

    @Slot()
    def calibrate(self) -> None:
        """Re-run calibration probes on demand. Always bypasses TTL cache."""
        try:
            self._run_calibration(force=True)
        except Exception as exc:  # noqa: BLE001
            self.calibration_done.emit(f"⚠ calibration crashed: {exc}")

    @Slot()
    def calibrate_verbose(self) -> None:
        """Re-run calibration AND show the full LLM response per probe."""
        try:
            self._run_calibration(force=True, verbose=True)
        except Exception as exc:  # noqa: BLE001
            self.calibration_done.emit(f"⚠ calibration crashed: {exc}")

    def _current_adapter(self):
        """Resolve the active ModelAdapter for the loaded model.

        Used by the agent loop for sampling overrides (temperature, top_p)
        and the per-adapter post_process hook. Reads the persisted
        adapter_id from settings, falls back to the universal detector
        (chat-template fingerprint → filename → metadata).
        """
        from navi.brain.adapters import (
            adapter_by_id,
            detect_adapter_universal,
            migrate_legacy_variant,
        )
        from navi.settings.store import load as load_settings
        try:
            settings = load_settings()
            filename = self._config.model_path.name
            entry = settings.get("model_overrides", {}).get(filename, {})
            adapter_id = entry.get("adapter_id") or migrate_legacy_variant(
                entry.get("system_prompt_variant")
            )
            if adapter_id:
                a = adapter_by_id(adapter_id)
                if a is not None:
                    return a
            return detect_adapter_universal(
                self._config.model_path, self._llm_metadata(),
            )
        except Exception:
            return None

    def _current_adapter_post_process(self):
        """Return the active adapter's output sanitizer, or identity."""
        adapter = self._current_adapter()
        if adapter is None or adapter.post_process is None:
            return lambda text: text
        return adapter.post_process

    def _check_drift(self, raw_content: str) -> None:
        """Detect when the model's final response shows degradation.

        Two signals: raw tool-call markers leaking into visible text (parser
        couldn't recover) OR fake-dialogue role-marker prefixes. After
        ``_DRIFT_THRESHOLD`` such turns in a session we emit drift_detected
        once — PetWindow surfaces a one-time chat note suggesting
        /calibrate.
        """
        if not raw_content or self._drift_warned:
            return
        from navi.brain.calibration import _has_fake_dialogue
        from navi.brain.parsers import PARSERS
        # Any sniff marker leaking into visible final text = drift
        marker_visible = any(
            m in raw_content for p in PARSERS for m in p.sniff_markers
        )
        roleplay = _has_fake_dialogue(raw_content)
        if not (marker_visible or roleplay):
            return
        self._drift_count += 1
        if self._drift_count >= _DRIFT_THRESHOLD:
            self._drift_warned = True
            reason = []
            if marker_visible:
                reason.append("unparsed tool-call markers")
            if roleplay:
                reason.append("fake-dialogue prefixes")
            self.drift_detected.emit(
                f"⚠ Navi noticed responses drifting ({', '.join(reason)} in "
                f"{self._drift_count} of the last few turns). Try `/calibrate` "
                "to re-tune the model, or switch via right-click → Model."
            )

    def _llm_metadata(self) -> dict[str, str] | None:
        """Best-effort access to the loaded model's GGUF metadata.

        ``Llama.metadata`` is a dict of GGUF key→value strings. The
        LLMClient subprocess forwards this dict on the ``ready`` event
        (including ``tokenizer.chat_template``), so adapter detection can
        rely on it for both in-process and subprocess-hosted models.
        """
        try:
            return self._llm.metadata  # type: ignore[union-attr]
        except Exception:
            return None

    # TTL only matters when the cached run FAILED tool_call — we re-try
    # eventually in case the user updated llama-cpp-python or fixed a
    # config issue. Once tool_call passes, the cache is honored
    # indefinitely until the user runs /calibrate. Most calibration
    # failures (math, no_roleplay, history_resilience) are model
    # capability signals; re-running won't change them.
    _CALIBRATION_TTL_SECONDS = 6 * 60 * 60  # 6 hours, only for failed-tool_call retries

    def _run_calibration(self, *, force: bool = False, verbose: bool = False) -> None:
        """Run probes against the loaded model.

        ``force=True`` bypasses the TTL cache (used by ``/calibrate``).
        Otherwise we skip if a recent run exists with a full pass.
        """
        if self._llm is None:
            return
        import time as _time

        from navi.brain.adapters import (
            detect_adapter_with_metadata,
            migrate_legacy_variant,
        )
        from navi.brain.calibration import (
            format_report_for_chat,
            run_calibration,
        )
        from navi.settings.store import load as load_settings
        from navi.settings.store import save as save_settings
        from navi.tools import tools_schema as _tools_schema

        # Use GGUF metadata for sharper detection when filename is ambiguous
        metadata = self._llm_metadata()
        adapter = detect_adapter_with_metadata(self._config.model_path, metadata)
        settings = load_settings()
        filename = self._config.model_path.name
        overrides_for_file = settings.get("model_overrides", {}).get(filename, {})
        persisted_adapter = overrides_for_file.get("adapter_id")
        if persisted_adapter is None:
            legacy = overrides_for_file.get("system_prompt_variant")
            persisted_adapter = migrate_legacy_variant(legacy)

        # Cache skip: if we previously calibrated this exact (filename,
        # adapter) pair and tool_call PASSED, skip — calibration's job
        # is done. Other probe failures are model capability and won't
        # change on re-run. If tool_call previously failed, fall back to
        # the TTL window so we retry every few hours in case llama-cpp
        # or the model file changed. /calibrate always bypasses.
        if not force:
            cache = overrides_for_file.get("calibration_cache") or {}
            cached_adapter = cache.get("adapter_id")
            cached_ts = cache.get("at_unix")
            # tool_call_passed is the new (post-2026-04) field. If it's
            # missing, fall back to all_passed — a pre-2026 cache that
            # passed all 9 probes implies tool_call passed too, so we
            # can honor it without forcing a re-run.
            cached_tool_ok = cache.get("tool_call_passed")
            if cached_tool_ok is None and cache.get("all_passed") is True:
                cached_tool_ok = True
            active_adapter_id = persisted_adapter or adapter.id

            adapter_matches = (
                cached_adapter and cached_adapter == active_adapter_id
            )
            if adapter_matches and cached_tool_ok is True:
                # tool_call passed previously — skip indefinitely.
                age_str = ""
                if isinstance(cached_ts, (int, float)):
                    age_min = int((_time.time() - cached_ts) / 60)
                    if age_min < 60:
                        age_str = f"{age_min} min ago"
                    elif age_min < 24 * 60:
                        age_str = f"{age_min // 60} h ago"
                    else:
                        age_str = f"{age_min // (24 * 60)} d ago"
                self.calibration_done.emit(
                    f"🧪 calibration · {adapter.description} "
                    f"(cached{', ' + age_str if age_str else ''} — "
                    "tool calling passed; use /calibrate to force re-run)"
                )
                return
            # tool_call failed previously: retry only after the TTL window
            # elapses, so we don't probe on every restart but still
            # eventually re-try in case something changed.
            if (
                adapter_matches
                and cached_tool_ok is False
                and isinstance(cached_ts, (int, float))
                and (_time.time() - cached_ts) < self._CALIBRATION_TTL_SECONDS
            ):
                age_min = int((_time.time() - cached_ts) / 60)
                self.calibration_done.emit(
                    f"🧪 calibration · {adapter.description} "
                    f"(cached {age_min} min ago — tool_call failed last "
                    "time; will retry after 6h or on /calibrate)"
                )
                return

        self.calibration_started.emit(
            f"🧪 calibrating {filename} (adapter: {adapter.description})…"
        )

        def _on_progress(current: int, total: int, label: str) -> None:
            # Cross-thread safe: Qt queues signal emissions across threads.
            self.calibration_progress.emit(current, total, label)

        report = run_calibration(
            self._llm, _tools_schema(), self._config.model_path,
            initial_adapter_id=persisted_adapter,
            auto_fix=True,
            on_progress=_on_progress,
        )

        entry = settings.setdefault("model_overrides", {}).setdefault(filename, {})
        # Persist auto-fix winner
        if report.fix_adapter_id and report.fix_adapter_id != persisted_adapter:
            entry["adapter_id"] = report.fix_adapter_id
            entry.pop("system_prompt_variant", None)
            if self._history and self._history[0].role == "system":
                from navi.brain.persona import build_system_prompt
                self._history[0] = _Message("system", build_system_prompt())
        # Persist calibration cache for the skip-on-relaunch path.
        # tool_call_passed is the load-bearing field — once it's True for
        # this (filename, adapter), we skip indefinitely. Other probe
        # results are model-capability signals; their failures don't
        # warrant re-running calibration.
        tool_call_probe = next(
            (p for p in report.probes if p.name == "tool_call"), None,
        )
        entry["calibration_cache"] = {
            "adapter_id": report.fix_adapter_id or report.adapter_id,
            "at_unix": int(_time.time()),
            "tool_call_passed": bool(tool_call_probe and tool_call_probe.passed),
            "all_passed": report.all_passed,
            "n_passed": report.n_passed,
            "n_total": report.n_total,
        }
        save_settings(settings)

        self.calibration_done.emit(format_report_for_chat(report, verbose=verbose))

    @Slot()
    def cancel(self) -> None:
        self._cancel.set()
        # Also signal the LLM subprocess so it bails out of any in-flight
        # streaming completion immediately (otherwise we'd wait until the
        # next chunk yields before the streaming loop notices _cancel).
        if self._llm is not None and hasattr(self._llm, "cancel"):
            try:
                self._llm.cancel()
            except Exception:
                pass

    # --- agent loop ---------------------------------------------------------
    def _run_agent_loop(self) -> None:
        saw_text_token = False
        for _ in range(MAX_TOOL_ITERATIONS):
            if self._cancel.is_set():
                return

            text_parts, tool_calls, raw_content = self._stream_one_turn(saw_text_token)
            saw_text_token = saw_text_token or bool(text_parts)

            if not tool_calls:
                # Final assistant message — done.
                if raw_content:
                    self._history.append(_Message("assistant", raw_content))
                # Drift check: if the FINAL response (no tool_calls extracted)
                # contains raw marker text or fake-dialogue prefixes, it
                # leaked into chat as visible garbage. Count it.
                self._check_drift(raw_content)
                return

            # Execute every tool call in the batch sequentially. Granite
            # often emits intentional batches (open_app + type_text) and
            # capping to one breaks legitimate multi-step intent. The
            # docx-spiral problem is now handled at the tool level: ocr_image
            # rejects non-image extensions cleanly, so a speculative
            # ocr_image call on a .docx no longer pollutes context.
            self._history.append(
                _Message("assistant", raw_content, tool_calls=tool_calls)
            )

            for call in tool_calls:
                if self._cancel.is_set():
                    return
                self._handle_tool_call(call)

            # Loop again: model gets to see the tool results.
            self.state_thinking.emit()

    def _stream_one_turn(
        self, already_speaking: bool
    ) -> tuple[list[str], list[dict[str, Any]], str]:
        """Run one streaming completion.

        Returns ``(text_parts_emitted, tool_calls, raw_content)``:
          - ``text_parts_emitted`` — text already streamed to the user (empty
            for tool-call turns since we suppress emission).
          - ``tool_calls`` — parsed tool calls, OpenAI-shaped.
          - ``raw_content`` — the full, verbatim assistant text including any
            ``<|tool_call|>...`` marker. This goes into history so Granite
            sees its own past tool calls (its chat template does not render
            structured ``tool_calls`` fields).

        Handles two tool-call dialects:
          1. OpenAI-style structured ``tool_calls`` deltas (most chat handlers).
          2. Granite-style ``<|tool_call|>[{...}]`` raw text (parsed locally).
        """
        messages = [m.to_dict() for m in self._history]
        # Per-adapter sampling overrides: some families do better at lower
        # temp (Phi at 0.2) — adapter declares the preference, we honor it.
        adapter = self._current_adapter()
        temperature = (
            adapter.temperature_override
            if adapter and adapter.temperature_override is not None
            else self._config.temperature
        )
        top_p = (
            adapter.top_p_override
            if adapter and adapter.top_p_override is not None
            else self._config.top_p
        )
        stream = self._llm.create_chat_completion(
            messages=messages,
            tools=tools_schema(),
            tool_choice="auto",
            temperature=temperature,
            top_p=top_p,
            max_tokens=self._config.max_tokens,
            stream=True,
        )

        text_acc: list[str] = []
        tool_accs: dict[int, _ToolCallAcc] = {}
        switched_to_speaking = already_speaking
        sniffed = False
        is_granite_tool = False

        for chunk in stream:
            if self._cancel.is_set():
                break
            choices = chunk.get("choices") or []
            if not choices:
                continue
            choice0 = choices[0]
            delta = choice0.get("delta", {})

            content = delta.get("content")
            if content:
                text_acc.append(content)

                if not sniffed:
                    joined = "".join(text_acc).lstrip()
                    if len(joined) >= _SNIFF_BYTES or choice0.get("finish_reason"):
                        sniffed = True
                        is_granite_tool = text_starts_tool_call(joined)
                        if not is_granite_tool:
                            # Flush the buffered prefix as visible text.
                            if not switched_to_speaking:
                                self.state_speaking.emit()
                                switched_to_speaking = True
                            self.token.emit("".join(text_acc))
                elif not is_granite_tool:
                    self.token.emit(content)

            tcs = delta.get("tool_calls") or []
            for call_delta in tcs:
                idx = call_delta.get("index", 0)
                acc = tool_accs.setdefault(idx, _ToolCallAcc())
                if call_delta.get("id"):
                    acc.id = call_delta["id"]
                fn = call_delta.get("function") or {}
                if fn.get("name"):
                    acc.name += fn["name"]
                if fn.get("arguments"):
                    acc.arguments += fn["arguments"]

        # End-of-stream catch: if the model emitted a SHORT response (e.g.
        # just "10") the buffered text might never have crossed _SNIFF_BYTES
        # AND the final chunk's finish_reason carries empty content — so
        # the in-loop sniff never fired. Flush here so the chat actually
        # sees the response. (Bug discovered when "5+5" → "10" silently
        # disappeared from the UI.)
        if not sniffed and text_acc:
            joined = "".join(text_acc).lstrip()
            is_granite_tool = text_starts_tool_call(joined)
            if not is_granite_tool:
                if not switched_to_speaking:
                    self.state_speaking.emit()
                    switched_to_speaking = True
                self.token.emit("".join(text_acc))
            sniffed = True

        raw_content = "".join(text_acc)
        # Apply the active adapter's output sanitizer (if any) before
        # tool-call parsing. Granite 3.2+/4.0 emit <think>...</think>
        # reasoning traces and/or a <response> wrapper that need stripping;
        # other families pass through unchanged.
        post = self._current_adapter_post_process()
        cleaned_content = post(raw_content)

        # If the early-stream sniff caught a tool-call signature, parse the
        # accumulated buffer through the registry.
        if is_granite_tool and not tool_accs:
            parsed = parse_any_tool_call(cleaned_content)
            if parsed is not None:
                return [], parsed, cleaned_content
            # Parse failed — degrade to showing the raw text so the user
            # at least sees what the model produced.
            if not switched_to_speaking:
                self.state_speaking.emit()
            self.token.emit(cleaned_content or raw_content)
            return text_acc, [], cleaned_content or raw_content

        if tool_accs:
            return [], [acc.to_dict() for acc in tool_accs.values()], raw_content

        # Late-stage rescue: model preambled before emitting a tool call
        # (the early sniff missed it). The dispatcher walks every registered
        # parser format — Granite, Phi (plural), Llama JSON, pythonic,
        # Mistral [TOOL_CALLS], Qwen <tool_call>, Gemma ```tool_code, plus
        # the legacy bracket-pseudo format Granite drifts into.
        late_calls = parse_any_tool_call(cleaned_content)
        if late_calls:
            return text_acc, late_calls, cleaned_content

        return text_acc, [], raw_content

    def _handle_tool_call(self, call: dict[str, Any]) -> None:
        name = call["function"]["name"]
        raw_args = call["function"]["arguments"] or "{}"
        try:
            args = json.loads(raw_args)
            if not isinstance(args, dict):
                args = {}
        except json.JSONDecodeError:
            args = {}

        # Repair model-emitted Unix-style paths so they match Windows allow
        # rules AND find the real file.
        if "path" in args and isinstance(args["path"], str):
            args["path"] = normalize_windows_path(args["path"])

        tool = get_tool(name)
        if tool is None:
            result = f"Error: unknown tool '{name}'."
            self.tool_call.emit(name, args, "unknown")
            audit.append(tool=name, args=args, risk="?", decision="unknown", error=result)
            self._append_tool_result(call, name, result)
            return

        decision = self._perms.evaluate(name, args, tool.risk)

        if decision is Decision.DENY:
            self.tool_call.emit(name, args, "denied")
            denial = f"Permission denied by policy: {name}"
            audit.append(tool=name, args=args, risk=tool.risk, decision="denied")
            self._append_tool_result(call, name, denial)
            return

        if decision is Decision.ASK:
            self.state_asking.emit()
            allowed = self._dispatcher.request_permission(name, args, tool.risk)
            self.state_thinking.emit()
            if not allowed:
                self.tool_call.emit(name, args, "user-denied")
                audit.append(tool=name, args=args, risk=tool.risk, decision="user-denied")
                self._append_tool_result(
                    call, name, f"User denied permission to call {name}."
                )
                return
            self.tool_call.emit(name, args, "user-allowed")
            decision_label = "user-allowed"
        else:
            self.tool_call.emit(name, args, "allowed")
            decision_label = "allowed"

        try:
            result = tool.func(**args)
        except TypeError as exc:
            result = f"Error: bad arguments for {name}: {exc}"
        except Exception as exc:
            result = f"Error executing {name}: {exc}"

        audit.append(
            tool=name,
            args=args,
            risk=tool.risk,
            decision=decision_label,
            result=str(result),
        )
        self._append_tool_result(call, name, result)
        # Surface the result so the chat can render rich previews
        # (e.g. inline image when generate_image returns a path).
        self.tool_result.emit(name, str(result))

    def _append_tool_result(self, call: dict[str, Any], name: str, result: Any) -> None:
        self._history.append(
            _Message(
                role="tool",
                content=str(result),
                tool_call_id=call.get("id", ""),
                name=name,
            )
        )


def _serialize_single_tool_call(call: dict[str, Any]) -> str:
    """Build the assistant ``<|tool_call|>[{...}]`` content for a single call.

    Used when we cap the model's multi-call output to just the first call,
    so the conversation history reflects what was actually executed.

    Note: emits Granite-shape regardless of model family. The history is
    a Navi-internal record; what matters is that our own parser can re-read
    it on the next turn — and parse_any_tool_call understands this format.
    """
    fn = call.get("function", {})
    return (
        "<|tool_call|>["
        + json.dumps(
            {"name": fn.get("name", ""), "arguments": json.loads(fn.get("arguments") or "{}")}
        )
        + "]"
    )


# ---------------------------------------------------------------------------
# Backward-compat aliases — external callers (probe scripts, older tests)
# imported these by name. The implementations now live in brain.parsers;
# these shims preserve the API.
# ---------------------------------------------------------------------------

# Old: `_TOOL_CALL_MARKERS` was a tuple of opening markers used by the
# now-deleted heuristic parser. Reconstructed for any legacy caller that
# expected the constant.
_TOOL_CALL_MARKERS = tuple(
    m for p in PARSERS for m in p.sniff_markers
    if m.startswith("<") or m.startswith("[")
)


def _looks_like_tool_call(text: str) -> bool:  # pragma: no cover — alias
    return text_starts_tool_call(text)


def _parse_granite_tool_calls(raw: str) -> list[dict[str, Any]] | None:  # pragma: no cover — alias
    return parse_any_tool_call(raw)


def _extract_marker_tool_calls(text: str) -> list[dict[str, Any]] | None:  # pragma: no cover — alias
    return parse_any_tool_call(text)


def _extract_bracket_tool_calls(text: str) -> list[dict[str, Any]] | None:  # pragma: no cover — alias
    return parse_any_tool_call(text)


