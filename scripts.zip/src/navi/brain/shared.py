"""Module-level singletons that tools running on the brain thread can read.

There's exactly one BrainWorker per Navi session, so a singleton is the
right shape — it avoids plumbing the LLM and progress signal through every
tool function (most of which never need either).

Set by ``BrainWorker.start()``; cleared on shutdown.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

_llm: Any = None
_progress_cb: Callable[[str], None] | None = None
_cancel_check: Callable[[], bool] | None = None
_notify_cb: Callable[[str, str], None] | None = None


def set_llm(llm: Any) -> None:
    global _llm
    _llm = llm


def get_llm() -> Any:
    return _llm


def set_progress_callback(cb: Callable[[str], None] | None) -> None:
    """Register a callback the brain thread can call to push status updates
    to the chat. ``cb(text)`` is invoked from the brain thread; the callback
    is responsible for thread-safe forwarding (typically via a Qt signal)."""
    global _progress_cb
    _progress_cb = cb


def emit_progress(msg: str) -> None:
    """Push a one-line progress note. No-op if no callback registered."""
    if _progress_cb is not None:
        try:
            _progress_cb(msg)
        except Exception:  # noqa: BLE001 — never let a UI hiccup break a tool
            pass


def set_cancel_check(check: Callable[[], bool] | None) -> None:
    """Register a function that returns True if the user has cancelled the
    current operation. Long-running tools (summarize_file) poll this to bail
    out cleanly mid-flight when the Stop button is pressed."""
    global _cancel_check
    _cancel_check = check


def is_cancelled() -> bool:
    if _cancel_check is None:
        return False
    try:
        return bool(_cancel_check())
    except Exception:  # noqa: BLE001
        return False


def set_notify_callback(cb: Callable[[str, str], None] | None) -> None:
    """Register a callback the brain thread can invoke to surface a
    native OS notification. ``cb(title, message)`` is responsible for
    thread-safe forwarding (PetWindow uses Qt signals)."""
    global _notify_cb
    _notify_cb = cb


def emit_notification(title: str, message: str) -> None:
    """Push an OS-level notification (toast/balloon). No-op if no
    callback registered (e.g. tests, headless mode)."""
    if _notify_cb is not None:
        try:
            _notify_cb(title, message)
        except Exception:  # noqa: BLE001 — never let a UI hiccup break a tool
            pass
