from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

DEFAULT_MODEL_FILENAME = "granite-3.1-2b-instruct-Q4_K_M.gguf"


def project_root() -> Path:
    return Path(__file__).resolve().parents[3]


def default_model_path() -> Path:
    """Resolve the model path.

    Order of precedence:
      1. Settings file ``model.path`` (set via Settings dialog).
      2. ``NAVI_MODEL_PATH`` env var (absolute file path).
      3. ``<project_root>/models/granite-3.1-2b-instruct-Q4_K_M.gguf``.
    """
    try:
        from navi.settings.store import load as _load_settings

        configured = _load_settings().get("model", {}).get("path")
        if configured:
            return Path(configured)
    except Exception:
        pass
    env = os.environ.get("NAVI_MODEL_PATH")
    if env:
        return Path(env)
    return project_root() / "models" / DEFAULT_MODEL_FILENAME


@dataclass(frozen=True)
class BrainConfig:
    model_path: Path
    # Granite 3.1 supports 131k natively. 16k is a balanced default — fits
    # most documents (a typical .pptx, a long readme, a chunk of source)
    # without paying KV-cache memory for context the user rarely uses.
    # Override per-machine via settings.json `model.n_ctx`.
    n_ctx: int = 16384
    n_threads: int = max(1, (os.cpu_count() or 4) - 2)
    n_batch: int = 512
    temperature: float = 0.4  # lower => more deterministic tool calls
    top_p: float = 0.9
    max_tokens: int = 1024  # per assistant turn — enough for real summaries

    @classmethod
    def default(cls) -> "BrainConfig":
        # Allow per-machine overrides without touching code
        n_ctx = cls.n_ctx
        max_tokens = cls.max_tokens
        try:
            from navi.settings.store import load as _load_settings
            model_settings = _load_settings().get("model", {})
            n_ctx = int(model_settings.get("n_ctx", n_ctx))
            max_tokens = int(model_settings.get("max_tokens", max_tokens))
        except Exception:
            pass
        env_ctx = os.environ.get("NAVI_N_CTX")
        if env_ctx:
            try:
                n_ctx = int(env_ctx)
            except ValueError:
                pass
        return cls(model_path=default_model_path(), n_ctx=n_ctx, max_tokens=max_tokens)
