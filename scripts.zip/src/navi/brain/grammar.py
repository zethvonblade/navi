"""GBNF grammar that constrains the model to legal tool-call output.

Forces the model to emit one of exactly two shapes:

  1. ``<|tool_call|>[{"name": "<known-tool>", "arguments": {...JSON...}}, ...]``
  2. Plain text (anything not starting with ``<``, ``[``, or ``{``).

This eliminates the family of malformed outputs that the agent loop's
heuristic parsers were chasing (``[tool:NAME, arguments: {...}]``,
``{"actions": [...]}``, bare ``[{"function": {...}}]``, etc.) — the
sampler simply cannot produce them.
"""

from __future__ import annotations

import json

from navi.tools import all_tools


def build_tool_grammar() -> str:
    """Compile a GBNF grammar from the registered tool list."""
    names = sorted(t.name for t in all_tools())
    if not names:
        raise RuntimeError("No tools registered; cannot build grammar.")
    name_alts = " | ".join(json.dumps(json.dumps(n)) for n in names)

    return r"""
root ::= tool-call | text

# ---- tool call ----------------------------------------------------------
tool-call ::= "<|tool_call|>" ws "[" ws tool-entry (ws "," ws tool-entry)* ws "]"
tool-entry ::= "{" ws "\"name\"" ws ":" ws tool-name ws "," ws "\"arguments\"" ws ":" ws object ws "}"
tool-name ::= """ + name_alts + r"""

# ---- minimal JSON -------------------------------------------------------
value     ::= object | array | string | number | "true" | "false" | "null"
object    ::= "{" ws ( string ws ":" ws value (ws "," ws string ws ":" ws value)* )? ws "}"
array     ::= "[" ws ( value (ws "," ws value)* )? ws "]"
string    ::= "\"" str-char* "\""
str-char  ::= [^"\\] | "\\" str-esc
str-esc   ::= ["\\/bfnrt] | "u" hex hex hex hex
hex       ::= [0-9a-fA-F]
number    ::= "-"? int frac? exp?
int       ::= "0" | [1-9] [0-9]*
frac      ::= "." [0-9]+
exp       ::= [eE] [+-]? [0-9]+
ws        ::= [ \t\n\r]*

# ---- free-form text (must not start with a tool-call marker) ------------
# text-rest covers tab/newline/CR + every printable byte. Avoid `[^]` —
# llama.cpp's grammar parser produces a degenerate sampler from it and
# segfaults on the first token.
text      ::= text-first text-rest*
text-first ::= [^<\[\{]
text-rest  ::= [\t\n\r -~]
"""


_cache: str | None = None


def cached_tool_grammar() -> str:
    """Build the grammar once per process and reuse."""
    global _cache
    if _cache is None:
        _cache = build_tool_grammar()
    return _cache
