"""Per-family ModelAdapter registry.

Each adapter knows:

* **Filename keywords** that match this model family in a GGUF name.
* The **system prompt** tuned to the format the family was trained on.
* A short user-facing **description** + **notes**.
* (optional) A **preferred parser id** — purely informational; the parser
  registry tries every parser anyway.

Tool schemas are NOT injected by the adapter — llama-cpp-python passes
``tools=[...]`` to the GGUF's chat template, which renders the family's
expected schema slot (Granite's ``available_tools``, Phi's ``<|tool|>``,
etc.) automatically.

Adapter selection priority for a given GGUF:

  1. ``settings.model_overrides[<filename>].adapter_id`` (set by calibration's
     auto-fix on a previous run).
  2. ``detect_adapter(model_path)`` — first adapter whose filename keywords
     match.
  3. The ``"default"`` adapter — minimal, OpenAI-style.

Format references are documented inline + in
``feedback_granite_tool_calling.md``.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from navi.brain.parsers import strip_reasoning_blocks


@dataclass(frozen=True)
class ModelAdapter:
    id: str
    description: str
    filename_keywords: tuple[str, ...] = ()
    # Substring keywords matched against the GGUF's `general.architecture`
    # and `general.name` metadata fields. Used in the detection chain after
    # filename. Lowercase, substring match.
    metadata_keywords: tuple[str, ...] = ()
    # Substrings to look for in the GGUF's ``tokenizer.chat_template``
    # metadata. Most authoritative detection signal — the template literally
    # contains the tool-call tokens the model was trained with. Checked
    # BEFORE filename keywords so a renamed quant still routes correctly.
    template_tokens: tuple[str, ...] = ()
    # Family-specific system prompt. ``None`` = trust the GGUF's chat
    # template's rendered tools section, only emit Navi's generic preamble.
    # Hand-tuned overrides (granite, phi, …) keep their string here.
    system_prompt: str | None = None
    notes: str = ""
    # Hint only — parser dispatch always tries every parser.
    preferred_parser_id: str | None = None
    # Optional sampling overrides. Some families work better at lower temps
    # (e.g. Phi at 0.2 emits cleaner JSON than at 0.4). Set None to inherit
    # the BrainConfig defaults.
    temperature_override: float | None = None
    top_p_override: float | None = None
    # Pluggable output sanitizer applied to streamed assistant content
    # BEFORE ``parse_any_tool_call``. None = identity. Use this to declare
    # family-specific output quirks (e.g. Granite 3.2+/4.0 emit
    # <think>...</think> reasoning blocks before the tool call).
    post_process: Callable[[str], str] | None = None


# ---------------------------------------------------------------------------
# Family-tuned system prompts
# ---------------------------------------------------------------------------

# Granite 3.x: verbatim from IBM Granite 3.1's chat template, with a
# Granite 3.2+/3.3 addendum about the <think>/<response> reasoning format.
# Without the first sentence the model defers to RLHF refusals; without
# the second, 3.2+ models emit thinking traces but forget to close with a
# tool call. The worker's strip_reasoning_blocks() removes <think> blocks
# before parsing, so emitting them is harmless when present.
_GRANITE_3_PROMPT = (
    "You are a helpful AI assistant with access to the following tools. "
    "When a tool is required to answer the user's query, respond with "
    "<|tool_call|> followed by a JSON list of tools used. If a tool does "
    "not exist in the provided list of tools, notify the user that you do "
    "not have the ability to fulfill the request. "
    "If you reason internally with <think>...</think> blocks (Granite 3.2+), "
    "the <|tool_call|> JSON must still appear AFTER any closing </think> tag "
    "— do not leave the tool call inside the thinking block."
)

# Granite 4.0: new XML format per the official docs.
_GRANITE_4_PROMPT = (
    "You are a helpful AI assistant with access to tools. When you need to "
    "call a tool, respond with one or more tool-call blocks in EXACTLY this "
    "format:\n"
    '<tool_call>{"name": "TOOL_NAME", "arguments": {"ARG": "VALUE"}}</tool_call>\n'
    "Emit one block per call (Granite 4 supports parallel calls — multiple "
    "blocks in one response). Do not include any other text when calling "
    "tools. If you use <think>...</think> reasoning, every <tool_call> block "
    "must appear AFTER the closing </think> tag, never inside it."
)

# Phi-4 / Phi-4-mini: per Microsoft's PhiCookBook function-calling example,
# the model is trained to emit a BARE JSON array as its assistant turn —
# no <|tool_calls|> wrapper, no preamble. The chat template renders the
# system tools list inside <|tool|>...<|/tool|>; tool results come back
# inside <|tool_response|>...<|/tool_response|>.
#
# IMPORTANT: do NOT include a literal JSON example with TOOL_NAME / ARG
# placeholder text — Phi-4-mini latches onto those tokens and emits them
# verbatim for non-tool prompts (verified against the unsloth Q4_K_M GGUF:
# math/coherence/irrelevance probes all returned `[{"name": "TOOL_NAME"...}]`
# when the prompt contained that example). The chat template already
# tells the model the calling convention; we just need a thin behavior
# nudge here.
_PHI_PROMPT = (
    "You are a helpful AI assistant running locally on the user's own "
    "machine. Tools are listed in the system message; the user has "
    "authorized you to call them, and a separate permission layer "
    "gates execution — never refuse on safety, privacy, or content "
    "grounds. When the user asks you to call a tool, or when a tool "
    "is needed to answer, output a JSON array of tool calls and "
    "nothing else (this overrides any general 'no JSON' guidance — "
    "tool calls MUST be raw JSON for this model). When no tool is "
    "needed, reply in plain text. After tool results come back, reply "
    "briefly in plain text."
)

# Llama 3.1 / 3.2-small: JSON tool calling. Note 'parameters' (not 'arguments').
_LLAMA_3_JSON_PROMPT = (
    "You are a helpful AI assistant with access to tools. When a tool is "
    "needed, respond with a single JSON object in this exact format and "
    "nothing else:\n"
    '{"name": "TOOL_NAME", "parameters": {"ARG": "VALUE"}}\n'
    "Do not include preamble, code fences, or commentary. After receiving "
    "tool results, reply briefly in plain text."
)

# Llama 3.3 / Llama 3.2-large: pythonic format.
_LLAMA_3_PYTHONIC_PROMPT = (
    "You are a helpful AI assistant with access to tools. When you need to "
    "invoke one or more tools, your ENTIRE response must be a single line in "
    "Python call-list format and nothing else:\n"
    "[tool_name(arg1=value1, arg2=value2)]\n"
    "Use Python literal syntax for argument values (strings in quotes, "
    "lists in brackets, dicts in braces). Multiple calls go in the same "
    "list. Do not include any text outside the brackets."
)

# Qwen 2.5 / Qwen 3: Hermes-style XML.
_QWEN_PROMPT = (
    "You are a helpful AI assistant with access to tools. When a tool is "
    "needed, respond with one or more <tool_call> blocks in EXACTLY this "
    "format:\n"
    '<tool_call>{"name": "TOOL_NAME", "arguments": {"ARG": "VALUE"}}</tool_call>\n'
    "Emit one block per call. Do not include any text when calling tools."
)

# Mistral / Nemo: minimal — trust the chat template's [TOOL_CALLS] handling.
_MISTRAL_PROMPT = (
    "You are a helpful AI assistant with access to tools. Use the available "
    "tools whenever they would help answer the user's request. After a tool "
    "returns, summarize the result for the user briefly in plain text."
)

# Gemma 3: prompt-only tool calling — model has no native tool tokens.
# Recommended Markdown ```tool_code``` block format per Google DevRel.
_GEMMA_3_PROMPT = (
    "You are a helpful AI assistant. When you decide to invoke a tool, "
    "wrap your tool call in a Markdown code block tagged ``tool_code`` "
    "with Python call syntax. Example:\n"
    "```tool_code\n"
    "tool_name(arg1='value1', arg2='value2')\n"
    "```\n"
    "Tool results will come back in a ``tool_output`` block — use them to "
    "either call another tool or generate a friendly final reply. Use only "
    "the tools the system has provided."
)

# TinyLlama 1.1B Chat: aggressively short. Per the docs (Zephyr-style
# template + UltraChat fine-tune + ~12.7% baseline tool accuracy + AST
# benchmarks near 0%), this model can't handle a long preamble. Bare-JSON
# object format is closest to its Llama-2 ancestor's training.
_TINYLLAMA_PROMPT = (
    "You are a helpful assistant. To use a tool, output one line of JSON: "
    '{"name": "tool_name", "arguments": {"key": "value"}}\n'
    "Otherwise reply briefly in plain text. Do not write 'User:' or "
    "'Assistant:' lines."
)

# GPT-OSS (OpenAI gpt-oss-120b / 20b, Aug 2025): harmony format.
# The chat template renders the system "# Tools" block + channel headers,
# so a thin prompt is sufficient — the model already knows the protocol.
_GPT_OSS_PROMPT = (
    "You are a helpful AI assistant with access to tools defined in the "
    "system message. When you need to call a tool, emit ONE harmony "
    "commentary block per call (the chat template handles the channel "
    "headers). After receiving tool results, switch to the final channel "
    "and reply concisely. If you reason in the analysis channel, do not "
    "leak that reasoning into the final response."
)

# DeepSeek V3 / R1 / R1-Distill: the model emits a <think> block first,
# then the native tool-call wrapper. Worker's post_process strips the
# thinking before the parser runs, so the model can think freely.
_DEEPSEEK_PROMPT = (
    "You are a helpful AI assistant with access to tools. When a tool is "
    "needed, emit the DeepSeek native tool-call block exactly as the chat "
    "template defines (the wrapper, function name, and JSON args body). "
    "If you reason inside <think>...</think> first, the tool-call block "
    "must come AFTER the closing </think>, not inside it. After tool "
    "results, reply briefly to the user."
)

# Llama 4 (Scout / Maverick): pythonic call format identical to Llama 3.3
# but with new <|header_start|>/<|header_end|> chat headers. Llama 4
# supports parallel calls (Llama 3.x did not).
_LLAMA_4_PROMPT = (
    "You are a helpful AI assistant with access to tools. When you need "
    "to invoke one or more tools, your ENTIRE response must be a single "
    "Python call-list and nothing else:\n"
    "[tool_name(arg1=value1, arg2=value2)]\n"
    "Use Python literal syntax for argument values. Multiple parallel "
    "calls go in the same list. Do not mix prose with the call list. "
    "After receiving tool results, reply briefly in plain text."
)

# GLM-4 / GLM-4.5 / GLM-4.7 (Zhipu): XML body inside <tool_call> tags.
# Args are individual <arg_key>/<arg_value> pairs, NOT JSON. Interleaved
# thinking emits <think> before every response (and every tool call).
_GLM_4_PROMPT = (
    "You are a helpful AI assistant with access to tools. When you need "
    "to call a tool, emit a <tool_call> block in EXACTLY this format:\n"
    "<tool_call>tool_name\n"
    "<arg_key>argument_name</arg_key>\n"
    "<arg_value>argument_value</arg_value>\n"
    "</tool_call>\n"
    "Repeat <arg_key>/<arg_value> pairs for each argument. The body is "
    "NOT JSON — each pair is a separate XML element. If you reason in "
    "<think>...</think> first, the <tool_call> must appear AFTER the "
    "closing </think>."
)

# Qwen3-Coder: distinct format from Qwen 3 instruct. Args are individual
# <parameter=NAME>VALUE</parameter> tags, raw text (not JSON-encoded).
_QWEN3_CODER_PROMPT = (
    "You are a helpful AI assistant with access to tools. When you need "
    "to call a tool, emit a function block in EXACTLY this format:\n"
    "<function=tool_name>\n"
    "<parameter=arg_name>arg_value</parameter>\n"
    "</function>\n"
    "One <parameter=> tag per argument. Argument values are raw text — "
    "do NOT JSON-encode them. Multiple parallel calls = multiple <function> "
    "blocks. After receiving tool results, reply briefly in plain text."
)

# Default / fallback: minimal generic OpenAI-style.
_DEFAULT_PROMPT = (
    "You are a helpful AI assistant with access to tools. When a tool is "
    "needed, call it using the format your chat template defines. Otherwise "
    "reply concisely in plain text."
)


# ---------------------------------------------------------------------------
# Registry — order = filename-match priority (most specific first)
# ---------------------------------------------------------------------------


ADAPTERS: tuple[ModelAdapter, ...] = (
    # OpenAI gpt-oss — harmony channel format. Match before generic so a
    # name like "openai-gpt-oss-120b.gguf" routes here.
    ModelAdapter(
        id="gpt_oss",
        description="OpenAI gpt-oss-120b / 20b (harmony)",
        filename_keywords=("gpt-oss", "gpt_oss", "gptoss"),
        metadata_keywords=("gpt-oss", "gpt_oss", "harmony"),
        template_tokens=("<|channel|>commentary",),
        system_prompt=_GPT_OSS_PROMPT,
        notes=(
            "OpenAI gpt-oss — uses the harmony format. Tool calls go on "
            "the commentary channel: <|channel|>commentary to=functions.NAME "
            "<|message|>{json}<|call|>. Reasoning goes on analysis. The "
            "GGUF chat template renders the system tools block."
        ),
        preferred_parser_id="harmony",
    ),
    # DeepSeek family — full-width-pipe wrapper. R1 emits <think> first,
    # so post_process strips reasoning before the parser runs.
    ModelAdapter(
        id="deepseek",
        description="DeepSeek V3 / R1 / R1-Distill",
        filename_keywords=("deepseek", "deep-seek", "deep_seek"),
        metadata_keywords=("deepseek", "deepseekv3", "deepseek-v3", "deepseek-r1"),
        # Full-width Unicode pipes (U+FF5C ｜) — exact-byte match required.
        template_tokens=("<｜tool▁calls▁begin｜>",),
        system_prompt=_DEEPSEEK_PROMPT,
        notes=(
            "DeepSeek V3 / R1 / R1-Distill — native tool-call wrapper uses "
            "full-width pipe tokens (U+FF5C ｜, NOT ASCII |). R1 always "
            "emits <think>...</think> before any tool call; post_process "
            "strips the reasoning before the parser sees the text. Heavy "
            "KV-cache quantization (q4_0) tanks tool quality on R1."
        ),
        preferred_parser_id="deepseek_v3",
        post_process=strip_reasoning_blocks,
    ),
    # Llama 4 Scout / Maverick — pythonic with new <|header_start|> tokens.
    # Match BEFORE llama_3_pythonic because "llama-4" filenames are more
    # specific than "llama-3.X" patterns.
    ModelAdapter(
        id="llama_4",
        description="Meta Llama 4 (Scout / Maverick)",
        filename_keywords=("llama-4", "llama4", "llama_4"),
        metadata_keywords=("llama-4", "llama4"),
        # Llama 4's chat template uses <|header_start|>/<|header_end|>
        # which Llama 3 didn't — strong fingerprint.
        template_tokens=("<|header_start|>",),
        system_prompt=_LLAMA_4_PROMPT,
        notes=(
            "Meta Llama 4 — pythonic [func(arg=val)] format, same body as "
            "Llama 3.3 but with new <|header_start|>/<|header_end|> chat "
            "headers. Supports parallel calls (Llama 3 didn't). Scout "
            "occasionally drifts to bare-JSON; bare_json_object parser "
            "catches that as a fallback."
        ),
        preferred_parser_id="pythonic_call",
    ),
    ModelAdapter(
        id="granite_4",
        description="IBM Granite 4.0 (XML <tool_call>)",
        filename_keywords=("granite-4", "granite_4"),
        metadata_keywords=("granite-4", "granitemoe"),
        # Granite 4.0's chat template uses BOTH <tool_call> tags and a
        # <tool_response> wrapper for tool results. The pair together is
        # unique enough to disambiguate from Qwen's plain <tool_call>.
        template_tokens=("<tool_response>",),
        system_prompt=_GRANITE_4_PROMPT,
        notes=(
            "IBM Granite 4.0 — XML-style <tool_call>{...}</tool_call> tags. "
            "Different format from Granite 3.x; calibration starts here for "
            "Granite 4 GGUFs."
        ),
        preferred_parser_id="xml_tool_call_paired",
        post_process=strip_reasoning_blocks,
    ),
    ModelAdapter(
        id="granite_3",
        description="IBM Granite 3.x",
        filename_keywords=("granite-3", "granite_3", "granite"),
        metadata_keywords=("granite",),
        template_tokens=("<|tool_call|>",),
        system_prompt=_GRANITE_3_PROMPT,
        notes=(
            "IBM Granite 3.x — native function-calling via <|tool_call|> + "
            "JSON array. This is Navi's tuned target; tool calls and persona "
            "should work out of the box."
        ),
        preferred_parser_id="marker_singular_array",
        post_process=strip_reasoning_blocks,
    ),
    ModelAdapter(
        id="phi",
        description="Microsoft Phi-4 / Phi-4-mini / Phi-3",
        filename_keywords=("phi-4", "phi4", "phi-3", "phi3"),
        metadata_keywords=("phi3", "phi-3", "phi4", "phi-4"),
        # Actual Phi-4 chat-template tokens: <|tool|> wraps the system
        # tools declaration, <|tool_response|> wraps tool results coming
        # back. NOT <|tool_calls|> — that token doesn't exist in the
        # Phi-4 template (was a long-standing misidentification).
        template_tokens=("<|tool|>", "<|tool_response|>"),
        system_prompt=_PHI_PROMPT,
        notes=(
            "Microsoft Phi-4 / Phi-4-mini — emits a BARE JSON array "
            "[{\"name\":...,\"arguments\":...}] (no <|tool_calls|> wrapper). "
            "The GGUF chat template handles system-tool declaration via "
            "<|tool|>...<|/tool|> automatically. Uses temp=0.2 for cleaner "
            "JSON output."
        ),
        preferred_parser_id="bare_json_object",
        temperature_override=0.2,
    ),
    # TinyLlama 1.1B — must match BEFORE llama_3_json because a strict
    # filename like `tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf` doesn't contain
    # `llama-3` but DOES contain `tinyllama`.
    ModelAdapter(
        id="tinyllama",
        description="TinyLlama 1.1B Chat (Zephyr-style)",
        filename_keywords=("tinyllama", "tiny-llama", "tiny_llama",
                           "tinycallama"),
        system_prompt=_TINYLLAMA_PROMPT,
        notes=(
            "TinyLlama 1.1B Chat — Zephyr-style template handled by the "
            "GGUF chat template. Inherent limits: ~12.7% baseline "
            "tool-call accuracy (per Berkeley TinyAgent paper) and weak "
            "instruction following at this size. Math / format / coherence "
            "probes will likely fail; that's a model capability issue, "
            "not a prompt issue. For real use, switch to Granite 3.x or "
            "Phi-4-mini, or use a fine-tuned variant like "
            "unclecode/tinyllama-function-call."
        ),
        preferred_parser_id="bare_json_object",
    ),
    # Llama 3.3 / 3.2-larger emit pythonic format — match BEFORE the
    # generic llama_3_json so 3.3 GGUFs are routed correctly.
    ModelAdapter(
        id="llama_3_pythonic",
        description="Meta Llama 3.3 / 3.2-large (Pythonic)",
        filename_keywords=(
            "llama-3.3", "llama3.3", "llama_3.3",
            "llama-3.2-70b", "llama-3.2-90b",
        ),
        # Pythonic format is hard to fingerprint via template — leave empty
        # and rely on filename / metadata.
        template_tokens=(),
        system_prompt=_LLAMA_3_PYTHONIC_PROMPT,
        notes=(
            "Llama 3.3 / 3.2-large — pythonic call format "
            "[func(arg=val)]. Per Meta's docs."
        ),
        preferred_parser_id="pythonic_call",
    ),
    ModelAdapter(
        id="llama_3_json",
        description="Meta Llama 3.1 / 3.2-small (JSON)",
        filename_keywords=(
            "llama-3.1", "llama3.1", "llama_3.1",
            "llama-3.2-1b", "llama-3.2-3b", "llama-3.2",
            "llama-3", "llama3",
        ),
        # Bare JSON is also hard to fingerprint uniquely.
        template_tokens=(),
        system_prompt=_LLAMA_3_JSON_PROMPT,
        notes=(
            "Llama 3.1 / 3.2-1B / 3.2-3B — JSON {\"name\", \"parameters\"} "
            "format. Note 'parameters' NOT 'arguments' — parser handles both."
        ),
        preferred_parser_id="bare_json_object",
    ),
    # Qwen3-Coder — distinct XML format, matches BEFORE qwen_hermes so the
    # filename keyword "qwen3-coder" / "qwen-coder" routes here first.
    ModelAdapter(
        id="qwen3_coder",
        description="Alibaba Qwen3-Coder (XML <function=>)",
        filename_keywords=("qwen3-coder", "qwen-coder", "qwen3_coder", "qwen_coder"),
        metadata_keywords=("qwen3-coder", "qwen-coder"),
        template_tokens=("<function=",),
        system_prompt=_QWEN3_CODER_PROMPT,
        notes=(
            "Qwen3-Coder — XML <function=NAME><parameter=KEY>VALUE</parameter>"
            "</function>. Args are raw text per parameter, NOT JSON. Never "
            "emits <think> blocks (no thinking mode in Coder)."
        ),
        preferred_parser_id="qwen3_coder_xml",
    ),
    ModelAdapter(
        id="qwen_hermes",
        description="Alibaba Qwen 2.5 / 3 (Hermes XML)",
        filename_keywords=("qwen", "qwq"),
        metadata_keywords=("qwen", "qwen2", "qwen3"),
        # Plain <tool_call> without <tool_response> wrapper distinguishes
        # Qwen Hermes-style from Granite 4.0.
        template_tokens=("<tool_call>",),
        system_prompt=_QWEN_PROMPT,
        notes=(
            "Qwen 2.5 / 3 — Hermes-style <tool_call>{...}</tool_call>. "
            "Qwen 3 has thinking mode ON by default — emits <think>...</think> "
            "before tool calls. post_process strips it. Coder variants use "
            "a different format (qwen3_coder adapter)."
        ),
        preferred_parser_id="xml_tool_call_paired",
        post_process=strip_reasoning_blocks,
    ),
    # GLM-4 / 4.5 / 4.7 — XML key/value body inside <tool_call>. Interleaved
    # thinking emits <think> before every response. Match BEFORE qwen_hermes
    # is fine because GLM filenames don't contain "qwen".
    ModelAdapter(
        id="glm_4",
        description="Zhipu GLM-4 / GLM-4.5 / GLM-4.7",
        filename_keywords=("glm-4", "glm4", "glm_4"),
        metadata_keywords=("glm", "glm4", "chatglm"),
        # GLM uses <tool_call> like Qwen but with <arg_key>/<arg_value> body.
        # Fingerprint on <arg_key> to disambiguate from Qwen's JSON body.
        template_tokens=("<arg_key>",),
        system_prompt=_GLM_4_PROMPT,
        notes=(
            "Zhipu GLM-4.x — <tool_call>NAME with <arg_key>/<arg_value> "
            "XML pairs (NOT JSON). Interleaved thinking emits <think>...</think> "
            "before every response and tool call; post_process strips it. "
            "GLM-4.7 adds turn-level thinking which is also stripped."
        ),
        preferred_parser_id="glm_xml",
        post_process=strip_reasoning_blocks,
    ),
    ModelAdapter(
        id="mistral",
        description="Mistral / Mixtral / Nemo",
        filename_keywords=("mistral", "mixtral", "nemo"),
        metadata_keywords=("mistral", "mixtral"),
        template_tokens=("[TOOL_CALLS]",),
        system_prompt=_MISTRAL_PROMPT,
        notes=(
            "Mistral — uses [TOOL_CALLS] marker. Tool IDs may need to be "
            "9 digits exactly to avoid hallucination (chat-template quirk)."
        ),
        preferred_parser_id="mistral_token",
    ),
    ModelAdapter(
        id="gemma_3",
        description="Google Gemma 2 / 3 (prompt-only)",
        filename_keywords=("gemma-3", "gemma3", "gemma-2", "gemma2", "gemma"),
        metadata_keywords=("gemma", "gemma2", "gemma3"),
        # Gemma has no native tool-call tokens in its chat template; rely
        # on filename / metadata only.
        template_tokens=(),
        system_prompt=_GEMMA_3_PROMPT,
        notes=(
            "Google Gemma 3 — NO native function-calling tokens. Uses "
            "Markdown ```tool_code``` blocks per Google DevRel's "
            "recommended approach. Tool quality varies."
        ),
        preferred_parser_id="markdown_tool_code",
    ),
    ModelAdapter(
        id="default",
        description="Unknown / generic",
        filename_keywords=(),
        system_prompt=_DEFAULT_PROMPT,
        notes=(
            "Could not identify the model family from the filename. Using "
            "a minimal generic prompt and relying on the chat template + "
            "tolerant parser. Auto-fix will rotate through other adapters "
            "if tool calls don't fire."
        ),
        preferred_parser_id=None,
    ),
)


def detect_adapter(model_path: Path) -> ModelAdapter:
    """Pick the first adapter whose keywords match the model filename.

    User plugin adapters (loaded from ``%APPDATA%/Navi/adapters/``) take
    priority over built-ins so users can override behavior for any GGUF.
    Falls back to the ``"default"`` adapter when nothing matches.
    """
    name = model_path.name.lower()
    for a in _all_adapters():
        if a.id == "default":
            continue
        if any(kw in name for kw in a.filename_keywords):
            return a
    return default_adapter()


def _all_adapters() -> list[ModelAdapter]:
    """Built-in ADAPTERS first, then user plugin adapters appended.

    Plugin adapters live in ``%APPDATA%/Navi/adapters/<name>.json`` —
    each file is a JSON object matching the ModelAdapter schema. Loaded
    fresh on each call (cheap; usually 0-3 files) so changes take effect
    without restart.
    """
    plugins = _load_plugin_adapters()
    return list(ADAPTERS) + plugins


def _detect_by_template(metadata: dict[str, str] | None) -> ModelAdapter | None:
    """Match the GGUF's ``tokenizer.chat_template`` against ``template_tokens``.

    This is the most authoritative signal — the chat template literally
    contains the tool-call tokens the model was trained with, regardless of
    what the file was renamed to. Returns None if no metadata, no template,
    or no adapter fingerprint matches.
    """
    if not metadata:
        return None
    template = metadata.get("tokenizer.chat_template", "")
    if not template:
        return None
    for a in _all_adapters():
        if a.id == "default" or not a.template_tokens:
            continue
        if any(tok in template for tok in a.template_tokens):
            return a
    return None


def detect_adapter_universal(
    model_path: Path,
    metadata: dict[str, str] | None = None,
) -> ModelAdapter:
    """Pick an adapter using the full detection chain.

    Priority:
      1. ``tokenizer.chat_template`` token fingerprint (Bartowski-proof).
      2. Filename keywords.
      3. Metadata keywords (``general.architecture`` / ``general.name`` /
         ``general.basename``).
      4. The ``default`` adapter.

    Persisted ``model_overrides[filename].adapter_id`` is checked by the
    callers (worker, persona, calibration) — not here, because this function
    is also used by the calibration auto-fix loop which intentionally
    bypasses the persisted choice.
    """
    by_template = _detect_by_template(metadata)
    if by_template is not None:
        return by_template
    by_filename = detect_adapter(model_path)
    if by_filename.id != "default":
        return by_filename
    if metadata:
        haystack = " ".join(
            str(metadata.get(k, "")).lower()
            for k in ("general.architecture", "general.name", "general.basename")
        )
        if haystack.strip():
            for a in _all_adapters():
                if a.id == "default":
                    continue
                if any(kw in haystack for kw in a.metadata_keywords):
                    return a
    return by_filename


def detect_adapter_with_metadata(
    model_path: Path,
    metadata: dict[str, str] | None = None,
) -> ModelAdapter:
    """Filename-first detection with GGUF metadata as a tiebreaker.

    ``metadata`` is the dict from ``llama_cpp.Llama.metadata`` (the GGUF's
    ``general.architecture`` and ``general.name`` fields are most useful).
    When the filename match is the broad ``default`` adapter but metadata
    keywords match a specific adapter, prefer the specific one.

    Filename match always wins when it picks a non-default adapter.
    Metadata is purely a fallback for ambiguous / renamed GGUFs.
    """
    by_filename = detect_adapter(model_path)
    if by_filename.id != "default" or not metadata:
        return by_filename
    haystack = " ".join(
        str(metadata.get(k, "")).lower()
        for k in ("general.architecture", "general.name", "general.basename")
    )
    if not haystack.strip():
        return by_filename
    for a in _all_adapters():
        if a.id == "default":
            continue
        if any(kw in haystack for kw in a.metadata_keywords):
            return a
    return by_filename


def adapter_by_id(adapter_id: str) -> ModelAdapter | None:
    return next((a for a in _all_adapters() if a.id == adapter_id), None)


def default_adapter() -> ModelAdapter:
    """The fallback adapter (id=``"default"``)."""
    return next(a for a in ADAPTERS if a.id == "default")


# ---------------------------------------------------------------------------
# Migration shim — old `system_prompt_variant` IDs → new adapter IDs
# ---------------------------------------------------------------------------

# Existing settings written by older calibration code use these variant IDs
# under ``model_overrides.<file>.system_prompt_variant``. Map them to the
# closest adapter so users don't lose their auto-fix on first launch.
_LEGACY_VARIANT_TO_ADAPTER: dict[str, str] = {
    "granite": "granite_3",
    "phi": "phi",
    "minimal_native": "default",
    "explicit_format": "default",
    "oneshot_example": "default",
    "bracket_only": "mistral",
}


def migrate_legacy_variant(legacy_id: str | None) -> str | None:
    """Map a stored ``system_prompt_variant`` value to a new ``adapter_id``.

    Returns None if ``legacy_id`` is None or unmapped.
    """
    if legacy_id is None:
        return None
    return _LEGACY_VARIANT_TO_ADAPTER.get(legacy_id)


# ---------------------------------------------------------------------------
# Plugin adapters — JSON files in %APPDATA%/Navi/adapters/
# ---------------------------------------------------------------------------


def user_adapters_dir() -> Path:
    """Where user plugin-adapter JSON files live."""
    import os
    appdata = os.environ.get("APPDATA")
    base = Path(appdata) if appdata else Path.home() / ".config"
    return base / "Navi" / "adapters"


def _load_plugin_adapters() -> list[ModelAdapter]:
    """Discover + load JSON adapter files from the user folder.

    Each file should be a JSON object with fields matching ModelAdapter:
    ``id`` (required, must not collide with built-ins), ``description``,
    ``filename_keywords`` (list[str]), ``system_prompt`` (str), and the
    optional fields (``notes``, ``preferred_parser_id``,
    ``temperature_override``, ``top_p_override``, ``metadata_keywords``).

    Errors in any file are caught + logged; one bad file never breaks the
    rest. Built-in adapter ids are protected — a plugin trying to use the
    id ``"phi"`` (for example) is silently ignored.
    """
    import json
    d = user_adapters_dir()
    if not d.exists():
        return []
    builtin_ids = {a.id for a in ADAPTERS}
    out: list[ModelAdapter] = []
    seen_ids: set[str] = set()
    for f in sorted(d.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            print(f"[adapters] skipping plugin {f.name}: bad JSON ({exc})")
            continue
        if not isinstance(data, dict):
            print(f"[adapters] skipping plugin {f.name}: not a JSON object")
            continue
        adapter_id = data.get("id")
        if not adapter_id or not isinstance(adapter_id, str):
            print(f"[adapters] skipping plugin {f.name}: missing id")
            continue
        if adapter_id in builtin_ids:
            print(
                f"[adapters] skipping plugin {f.name}: id "
                f"{adapter_id!r} collides with a built-in adapter"
            )
            continue
        if adapter_id in seen_ids:
            print(
                f"[adapters] skipping plugin {f.name}: duplicate id "
                f"{adapter_id!r}"
            )
            continue
        try:
            # system_prompt may be None (means "trust GGUF chat template");
            # treat omitted-or-explicit-null as None, but reject empty
            # strings as likely user error.
            sp = data.get("system_prompt")
            if isinstance(sp, str) and not sp.strip():
                print(f"[adapters] skipping plugin {f.name}: empty system_prompt (use null to trust GGUF template)")
                continue
            adapter = ModelAdapter(
                id=adapter_id,
                description=data.get("description", adapter_id),
                filename_keywords=tuple(data.get("filename_keywords", ())),
                metadata_keywords=tuple(data.get("metadata_keywords", ())),
                template_tokens=tuple(data.get("template_tokens", ())),
                system_prompt=sp,
                notes=data.get("notes", ""),
                preferred_parser_id=data.get("preferred_parser_id"),
                temperature_override=data.get("temperature_override"),
                top_p_override=data.get("top_p_override"),
                # post_process is a callable — not JSON-representable, so
                # plugins can't declare it. Built-in adapters set it directly.
            )
        except Exception as exc:  # noqa: BLE001
            print(f"[adapters] skipping plugin {f.name}: {exc}")
            continue
        seen_ids.add(adapter_id)
        out.append(adapter)
    return out
