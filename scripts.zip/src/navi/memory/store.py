"""Markdown-backed long-term memory.

Storage layout under ``%APPDATA%/Navi/memory/``::

    MEMORY.md           # one-line index loaded into the system prompt
    user_<slug>.md      # individual memory files with YAML frontmatter
    feedback_<slug>.md
    project_<slug>.md
    reference_<slug>.md

Mirrors the Claude Code auto-memory pattern. Keyword scoring for ``recall``
is intentionally cheap (no embeddings) — sufficient for the MVP and avoids
adding a vector index dependency before it's needed.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path

VALID_TYPES = ("user", "feedback", "project", "reference")
MAX_INDEX_LINES = 200  # Keep MEMORY.md within the system prompt budget
MAX_MEMORY_FILES = 100  # Soft cap; oldest get archived when over


def memory_dir() -> Path:
    appdata = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming")))
    return appdata / "Navi" / "memory"


def index_path() -> Path:
    return memory_dir() / "MEMORY.md"


@dataclass(frozen=True)
class MemoryFile:
    name: str
    description: str
    type: str
    body: str
    path: Path


# ---------------------------------------------------------------------------
# write
# ---------------------------------------------------------------------------


def slugify(title: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "_", title.lower()).strip("_")
    return s[:60] or "untitled"


def save_memory(*, title: str, description: str, type: str, content: str) -> Path:
    """Write a memory file + update the index. Returns the file path."""
    if type not in VALID_TYPES:
        raise ValueError(f"Invalid memory type {type!r}. Use one of {VALID_TYPES}.")

    base = memory_dir()
    base.mkdir(parents=True, exist_ok=True)
    fname = f"{type}_{slugify(title)}.md"
    path = base / fname

    body = (
        f"---\n"
        f"name: {title}\n"
        f"description: {description}\n"
        f"type: {type}\n"
        f"---\n\n"
        f"{content.strip()}\n"
    )
    path.write_text(body, encoding="utf-8")

    _refresh_index_entry(fname=fname, title=title, hook=description)
    _maybe_prune()
    return path


def delete_memory(fname: str) -> bool:
    """Delete a memory file by filename. Updates the index. Returns True on success."""
    base = memory_dir()
    path = base / fname
    if not path.exists():
        return False
    try:
        path.unlink()
    except OSError:
        return False
    # Remove from index
    idx = index_path()
    if idx.exists():
        try:
            existing = idx.read_text(encoding="utf-8")
            kept = [
                ln for ln in existing.splitlines(keepends=True) if f"]({fname})" not in ln
            ]
            idx.write_text("".join(kept), encoding="utf-8")
        except OSError:
            pass
    return True


def _maybe_prune() -> None:
    """Archive oldest memory files if total exceeds MAX_MEMORY_FILES."""
    files = list_memory_files()
    if len(files) <= MAX_MEMORY_FILES:
        return
    # Sort by mtime, oldest first
    files.sort(key=lambda p: p.stat().st_mtime)
    archive_dir = memory_dir() / "_archive"
    archive_dir.mkdir(exist_ok=True)
    for old in files[: len(files) - MAX_MEMORY_FILES]:
        try:
            old.rename(archive_dir / old.name)
        except OSError:
            pass


def _refresh_index_entry(*, fname: str, title: str, hook: str) -> None:
    """Add or replace the entry for ``fname`` in MEMORY.md."""
    idx = index_path()
    line = f"- [{title}]({fname}) — {hook}\n"

    existing = idx.read_text(encoding="utf-8") if idx.exists() else ""
    kept = [
        ln for ln in existing.splitlines(keepends=True) if f"]({fname})" not in ln
    ]
    new_text = "".join(kept).rstrip("\n")
    if new_text:
        new_text += "\n"
    new_text += line
    idx.write_text(new_text, encoding="utf-8")


# ---------------------------------------------------------------------------
# read
# ---------------------------------------------------------------------------


def load_index() -> str | None:
    """Return the MEMORY.md contents (truncated) or None if empty/missing."""
    p = index_path()
    if not p.exists():
        return None
    text = p.read_text(encoding="utf-8").strip()
    if not text:
        return None
    lines = text.splitlines()
    if len(lines) > MAX_INDEX_LINES:
        lines = lines[:MAX_INDEX_LINES]
        lines.append(f"... (truncated; {len(text.splitlines()) - MAX_INDEX_LINES} more)")
    return "\n".join(lines)


def list_memory_files() -> list[Path]:
    base = memory_dir()
    if not base.exists():
        return []
    return sorted(p for p in base.glob("*.md") if p.name != "MEMORY.md")


def parse_memory_file(path: Path) -> MemoryFile:
    """Parse a memory file with YAML-ish frontmatter."""
    raw = path.read_text(encoding="utf-8")
    name = description = type_ = ""
    body = raw
    if raw.startswith("---"):
        try:
            _, fm, rest = raw.split("---", 2)
        except ValueError:
            fm, rest = "", raw
        for line in fm.strip().splitlines():
            k, _, v = line.partition(":")
            v = v.strip()
            k = k.strip().lower()
            if k == "name":
                name = v
            elif k == "description":
                description = v
            elif k == "type":
                type_ = v
        body = rest.strip()
    return MemoryFile(
        name=name or path.stem,
        description=description,
        type=type_,
        body=body,
        path=path,
    )


# ---------------------------------------------------------------------------
# search
# ---------------------------------------------------------------------------


_WORD_RE = re.compile(r"\w+")
_STOPWORDS = frozenset(
    {
        "a", "an", "the", "is", "are", "was", "were", "be", "been", "of", "to",
        "in", "on", "at", "for", "and", "or", "but", "if", "i", "me", "my",
        "you", "your", "we", "our", "do", "does", "did", "what", "which",
        "who", "when", "where", "why", "how", "this", "that", "these", "those",
        "with", "as", "it", "its", "have", "has", "had", "can", "will", "would",
    }
)


def _tokens(text: str) -> set[str]:
    return {w for w in (m.lower() for m in _WORD_RE.findall(text)) if w not in _STOPWORDS and len(w) > 1}


def search(query: str, limit: int = 3) -> list[tuple[int, MemoryFile]]:
    """Return up to ``limit`` (score, file) pairs ranked by word-overlap."""
    qtoks = _tokens(query)
    if not qtoks:
        return []
    scored: list[tuple[int, MemoryFile]] = []
    for path in list_memory_files():
        try:
            mem = parse_memory_file(path)
        except OSError:
            continue
        haystack = f"{mem.name}\n{mem.description}\n{mem.body}"
        htoks = _tokens(haystack)
        score = len(qtoks & htoks)
        if score > 0:
            scored.append((score, mem))
    scored.sort(key=lambda x: x[0], reverse=True)
    return scored[:limit]
