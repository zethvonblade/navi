from __future__ import annotations

from PySide6.QtWidgets import QApplication

from navi.pet.skins._bootstrap import ensure_user_skins_dir
from navi.pet.skins import reload_skins
from navi.pet.window import PetWindow


def run(argv: list[str]) -> int:
    app = QApplication(argv)
    app.setApplicationName("Navi")
    app.setQuitOnLastWindowClosed(True)

    # First-run setup: create %APPDATA%/Navi/skins/ with a starter skin
    # and STUDIO.md if absent, then re-scan so user skins are picked up
    # for this session (the skins package was imported before the folder
    # was guaranteed to exist).
    ensure_user_skins_dir()
    reload_skins()

    window = PetWindow()
    window.show()
    return app.exec()
