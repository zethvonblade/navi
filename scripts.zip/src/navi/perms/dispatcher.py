from __future__ import annotations

import queue
from typing import Any

from PySide6.QtCore import Qt, QObject, Signal, Slot
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QVBoxLayout,
    QWidget,
)

_RISK_COLORS = {
    "safe": "#10B981",    # green
    "low": "#3B82F6",     # blue
    "medium": "#F59E0B",  # amber
    "high": "#EF4444",    # red
}


class PermissionDialog(QDialog):
    """Custom modal for tool-permission prompts.

    Replaces a QMessageBox so we can show:
      - a colored risk badge in the title strip
      - long arguments (PowerShell commands, file content) in a scrollable
        monospace area instead of a cramped one-liner
    """

    def __init__(
        self,
        tool_name: str,
        args: dict[str, Any],
        risk: str,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle("Navi — permission")
        self.setModal(True)
        self.setMinimumWidth(560)
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)

        risk_color = _RISK_COLORS.get(risk, "#888")
        header = QLabel(
            f'<div style="font-size:13px">Navi wants to call '
            f'<code style="background:#222;color:#eee;padding:2px 6px;border-radius:3px">{tool_name}</code> '
            f'<span style="background:{risk_color};color:white;'
            f'padding:2px 8px;border-radius:10px;font-size:11px;font-weight:600">'
            f"{risk.upper()}</span></div>"
        )
        header.setWordWrap(True)

        body = QPlainTextEdit(self)
        body.setReadOnly(True)
        font = QFont("Cascadia Mono")
        if not font.exactMatch():
            font.setFamily("Consolas")
        font.setPointSize(10)
        body.setFont(font)
        body.setPlainText(_format_args(args))
        body.setMinimumHeight(120)

        buttons = QDialogButtonBox(self)
        allow_btn = buttons.addButton("Allow", QDialogButtonBox.ButtonRole.AcceptRole)
        deny_btn = buttons.addButton("Deny", QDialogButtonBox.ButtonRole.RejectRole)
        allow_btn.setStyleSheet(
            f"QPushButton {{ background:{risk_color}; color:white; "
            f"padding:6px 14px; border:0; border-radius:4px; font-weight:600 }}"
        )
        deny_btn.setStyleSheet(
            "QPushButton { padding:6px 14px; border:1px solid #555; border-radius:4px }"
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        deny_btn.setDefault(True)
        deny_btn.setFocus()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 12)
        layout.setSpacing(10)
        layout.addWidget(header)
        layout.addWidget(body, 1)

        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_row.addWidget(buttons)
        layout.addLayout(btn_row)


def _format_args(args: dict[str, Any]) -> str:
    if not args:
        return "(no arguments)"
    lines: list[str] = []
    for k, v in args.items():
        text = str(v)
        if "\n" in text or len(text) > 60:
            lines.append(f"{k}:\n  {text.replace(chr(10), chr(10) + '  ')}")
        else:
            lines.append(f"{k}: {text}")
    return "\n".join(lines)


class PermissionDispatcher(QObject):
    """Cross-thread permission prompt.

    The brain (worker thread) calls :meth:`request_permission`. We emit a
    queued signal to ourselves; the slot runs on the GUI thread, shows the
    appropriate UI (inline chat bar for low/medium risk, modal for high or
    when no chat is wired), and posts the result back through a thread-safe
    Queue.
    """

    _ask_signal = Signal(str, dict, str, object)  # tool, args, risk, response_queue

    def __init__(self, parent_window: QWidget) -> None:
        super().__init__(parent_window)
        self._parent = parent_window
        self._chat = None  # set later via set_inline_target
        self._ask_signal.connect(self._on_ask, Qt.ConnectionType.QueuedConnection)

    def set_inline_target(self, chat_window) -> None:
        """Wire the chat window so low/medium-risk asks render inline."""
        self._chat = chat_window

    def request_permission(
        self, tool_name: str, args: dict[str, Any], risk: str = "medium"
    ) -> bool:
        q: queue.Queue[bool] = queue.Queue(maxsize=1)
        self._ask_signal.emit(tool_name, args, risk, q)
        return q.get()

    @Slot(str, dict, str, object)
    def _on_ask(
        self,
        tool_name: str,
        args: dict[str, Any],
        risk: str,
        response_queue: queue.Queue,
    ) -> None:
        # High-risk and unknown-tool calls always get the modal — no risk of
        # the user missing the prompt while focused elsewhere. Low/medium-risk
        # render inline in the chat.
        if risk in ("safe", "low", "medium") and self._chat is not None:
            self._chat.show_inline_permission(tool_name, args, risk, response_queue)
            return
        dlg = PermissionDialog(tool_name, args, risk, self._parent)
        accepted = dlg.exec() == QDialog.DialogCode.Accepted
        response_queue.put(accepted)
