"""Append-only JSONL audit log of every tool call.

Stored at ``%APPDATA%/Navi/audit.jsonl``. One JSON object per line so it
streams cleanly into ``Get-Content -Wait`` / ``tail -f`` for live monitoring.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any


_MAX_AUDIT_BYTES = 10 * 1024 * 1024  # 10 MB before rotation


def audit_path() -> Path:
    appdata = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming")))
    return appdata / "Navi" / "audit.jsonl"


def _maybe_rotate(path: Path) -> None:
    """If audit file exceeds the size cap, rotate to dated archive."""
    try:
        if not path.exists() or path.stat().st_size < _MAX_AUDIT_BYTES:
            return
        archive = path.with_name(f"audit-{time.strftime('%Y%m%d-%H%M%S')}.jsonl")
        path.rename(archive)
    except OSError:
        pass


def append(
    *,
    tool: str,
    args: dict[str, Any],
    decision: str,
    risk: str,
    result: str | None = None,
    error: str | None = None,
) -> None:
    """Append one audit event. Best-effort — never raises."""
    entry: dict[str, Any] = {
        "ts": time.time(),
        "iso": time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime()),
        "tool": tool,
        "args": _sanitize_args(args),
        "risk": risk,
        "decision": decision,
    }
    if result is not None:
        # Cap result preview to keep the log readable
        entry["result_preview"] = (result[:240] + "…") if len(result) > 240 else result
    if error is not None:
        entry["error"] = error
    try:
        path = audit_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        _maybe_rotate(path)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except OSError:
        # Swallow — audit failure must never break the agent loop.
        pass


def _sanitize_args(args: dict[str, Any]) -> dict[str, Any]:
    """Truncate huge string args (file content, PS commands) for log readability."""
    out: dict[str, Any] = {}
    for k, v in args.items():
        if isinstance(v, str) and len(v) > 500:
            out[k] = v[:500] + f"… [+{len(v) - 500} chars]"
        else:
            out[k] = v
    return out
