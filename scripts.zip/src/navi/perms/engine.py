from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any


class Decision(Enum):
    ALLOW = "allow"
    ASK = "ask"
    DENY = "deny"


class Mode(str, Enum):
    DEFAULT = "default"
    PLAN = "plan"  # Navi describes only, never executes
    ACCEPT_EDITS = "acceptEdits"  # auto-allow writes inside USERPROFILE (no-op for read-only tools)
    BYPASS = "bypass"  # dev only, allow everything


_RULE_RE = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)(?:\((.*)\))?$")


@dataclass(frozen=True)
class _Rule:
    tool_name: str
    arg_pattern: re.Pattern[str] | None  # None => match any args


def _parse_rule(rule: str) -> _Rule:
    m = _RULE_RE.match(rule.strip())
    if not m:
        raise ValueError(f"Invalid permission rule: {rule!r}")
    tool_name = m.group(1)
    arg_glob = m.group(2)
    pat = re.compile(_glob_to_regex(arg_glob), re.IGNORECASE) if arg_glob is not None else None
    return _Rule(tool_name=tool_name, arg_pattern=pat)


def _glob_to_regex(pattern: str) -> str:
    """Convert a glob with `**`, `*`, `?` to a regex.

    `**`     matches any chars including path separators
    `*`      matches any chars except path separators
    `?`      matches one char except path separator
    `/` `\\` both treated as path separators (matched against either)
    """
    out: list[str] = []
    i = 0
    while i < len(pattern):
        c = pattern[i]
        if c == "*":
            if i + 1 < len(pattern) and pattern[i + 1] == "*":
                out.append(".*")
                i += 2
            else:
                out.append(r"[^/\\]*")
                i += 1
        elif c == "?":
            out.append(r"[^/\\]")
            i += 1
        elif c in r".^$+(){}[]|":
            out.append(re.escape(c))
            i += 1
        elif c in r"/\\":
            out.append(r"[/\\]")
            i += 1
        else:
            out.append(c)
            i += 1
    return "^" + "".join(out) + "$"


def _canonical_arg(args: dict[str, Any]) -> str:
    if not args:
        return ""
    if len(args) == 1:
        return str(next(iter(args.values())))
    return ", ".join(f"{k}={v}" for k, v in sorted(args.items()))


# ---------------------------------------------------------------------------
# Settings file
# ---------------------------------------------------------------------------


def settings_path() -> Path:
    appdata = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming")))
    return appdata / "Navi" / "settings.json"


def default_settings() -> dict[str, Any]:
    home = str(Path.home()).replace("\\", "/")
    return {
        "defaultMode": "default",
        "permissions": {
            "allow": [
                # Read-only and harmless inspection
                "read_clipboard",
                "take_screenshot",
                "ocr_image",
                "list_windows",
                # Reads inside the user's home tree
                f"list_dir({home}/**)",
                f"read_file({home}/**)",
                # Low-risk writes / launches considered safe by default
                "write_clipboard",
                "open_url(https://**)",
                "open_app",
                "focus_window",
                # Memory tools — always silent (Navi-managed dir)
                "remember",
                "recall",
            ],
            "ask": [
                # Catch-all for paths outside the user's home tree
                "read_file",
                "list_dir",
                # Writes always prompt unless explicitly allowed
                "write_file",
                # Plain http opens get a prompt
                "open_url",
                # Every PowerShell call needs explicit confirmation
                "run_powershell",
            ],
            "deny": [
                # Sensitive files
                "read_file(**/.env*)",
                "read_file(**/.ssh/**)",
                "read_file(**/credentials*)",
                "read_file(**/*.pem)",
                "read_file(C:/Windows/**)",
                "read_file(C:/ProgramData/**)",
                # Dangerous writes
                "write_file(**/.env*)",
                "write_file(**/.ssh/**)",
                "write_file(C:/Windows/**)",
                "write_file(C:/ProgramData/**)",
                "write_file(**/.git/config)",
                # Famously destructive PowerShell patterns
                "run_powershell(*Remove-Item*-Recurse*)",
                "run_powershell(*Format-Volume*)",
                "run_powershell(*Clear-RecycleBin*)",
                "run_powershell(*Stop-Computer*)",
                "run_powershell(*Restart-Computer*)",
            ],
        },
    }


def load_or_init_settings() -> dict[str, Any]:
    path = settings_path()
    if not path.exists():
        from navi._io import atomic_write_text
        atomic_write_text(path, json.dumps(default_settings(), indent=2))
        return default_settings()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError("settings.json must be a JSON object")
        return data
    except (OSError, json.JSONDecodeError, ValueError):
        # Corrupt file — fall back to defaults rather than crashing the
        # whole agent. The user can repair via Settings dialog.
        return default_settings()


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------


def _is_under_user_home(path_str: str) -> bool:
    """True when ``path_str`` resolves under the current user's home dir.

    Used by Mode.ACCEPT_EDITS to scope auto-allow to the user's tree.
    Returns False on any path-resolution error so we fall through to
    the ask path rather than over-permissioning.
    """
    try:
        target = Path(path_str).resolve()
        home = Path.home().resolve()
        target.relative_to(home)
        return True
    except (ValueError, OSError):
        return False


class PermissionEngine:
    def __init__(self, settings: dict[str, Any]) -> None:
        perms = settings.get("permissions", {})
        self.allow = [_parse_rule(r) for r in perms.get("allow", [])]
        self.ask = [_parse_rule(r) for r in perms.get("ask", [])]
        self.deny = [_parse_rule(r) for r in perms.get("deny", [])]
        # A typo or stale string in settings.json (e.g. "defaut" instead
        # of "default") would crash brain startup with an uncaught
        # ValueError from Mode(). Fall back gracefully — broken settings
        # shouldn't prevent the app from launching.
        raw_mode = settings.get("defaultMode", "default")
        try:
            self.mode = Mode(raw_mode)
        except ValueError:
            self.mode = Mode.DEFAULT

    def evaluate(
        self,
        tool_name: str,
        args: dict[str, Any],
        risk: str = "low",
    ) -> Decision:
        if self.mode is Mode.PLAN:
            return Decision.DENY
        if self.mode is Mode.BYPASS:
            return Decision.ALLOW

        canonical = _canonical_arg(args)

        # Order: deny -> allow -> ask -> risk-based fallback.
        # Specific allow rules thus act as exemptions from a broader ask
        # catch-all; deny always wins.
        for rule in self.deny:
            if self._match(rule, tool_name, canonical):
                return Decision.DENY
        for rule in self.allow:
            if self._match(rule, tool_name, canonical):
                return Decision.ALLOW

        # acceptEdits: auto-allow write_file when the target is inside
        # the user's home tree. Other writes (PowerShell, system paths)
        # still fall through to ask. Documented behavior in settings UI.
        if self.mode is Mode.ACCEPT_EDITS and tool_name == "write_file":
            path = args.get("path") if isinstance(args, dict) else None
            if isinstance(path, str) and _is_under_user_home(path):
                return Decision.ALLOW

        for rule in self.ask:
            if self._match(rule, tool_name, canonical):
                return Decision.ASK

        if risk in ("safe", "low"):
            return Decision.ALLOW
        return Decision.ASK

    @staticmethod
    def _match(rule: _Rule, tool_name: str, canonical_arg: str) -> bool:
        if rule.tool_name != tool_name:
            return False
        if rule.arg_pattern is None:
            return True
        # Normalize backslashes in input so patterns written with /, \\ match either.
        return bool(rule.arg_pattern.match(canonical_arg))
