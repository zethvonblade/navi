"""New Project wizard — modal launched by ``/new``.

Three controls: stack picker, project name, destination directory. On
"Scaffold", calls the SAME ``scaffold_project`` tool function the LLM
calls — no parallel code path. Result is forwarded to chat via the
``scaffolded`` signal.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from navi.scaffold.stacks import STACKS


class NewProjectDialog(QDialog):
    """Stack picker + name + dest. Calls scaffold_project on confirm."""

    scaffolded = Signal(str)  # human-readable result, forwarded to chat

    def __init__(self, parent: QWidget | None = None,
                 settings: dict[str, Any] | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("New Project")
        self.resize(520, 240)
        self._settings = settings or {}

        # --- form layout ------------------------------------------------
        self._stack_box = QComboBox()
        for sid, spec in STACKS.items():
            self._stack_box.addItem(f"{spec.label}  —  {spec.description}", sid)
        # Default to settings.scaffold.active_stack if set, else first.
        active = (self._settings.get("scaffold") or {}).get("active_stack")
        if active:
            for i in range(self._stack_box.count()):
                if self._stack_box.itemData(i) == active:
                    self._stack_box.setCurrentIndex(i)
                    break

        self._name_edit = QLineEdit()
        self._name_edit.setPlaceholderText("My Cool Tool")

        self._desc_edit = QLineEdit()
        self._desc_edit.setPlaceholderText("(optional) one-line description")

        # Destination defaults to settings or ~/Desktop.
        default_dest = (
            (self._settings.get("scaffold") or {}).get("default_dest")
            or str(Path.home() / "Desktop")
        )
        self._dest_edit = QLineEdit(default_dest)
        browse_btn = QPushButton("Browse…")
        browse_btn.clicked.connect(self._on_browse)
        dest_row = QHBoxLayout()
        dest_row.addWidget(self._dest_edit, 1)
        dest_row.addWidget(browse_btn)

        form = QFormLayout()
        form.addRow("Stack:", self._stack_box)
        form.addRow("Project name:", self._name_edit)
        form.addRow("Description:", self._desc_edit)
        form.addRow("Destination:", dest_row)

        # --- buttons ----------------------------------------------------
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Cancel
        )
        self._scaffold_btn = QPushButton("Scaffold")
        self._scaffold_btn.setDefault(True)
        self._scaffold_btn.clicked.connect(self._on_scaffold)
        buttons.addButton(self._scaffold_btn, QDialogButtonBox.ButtonRole.AcceptRole)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(
            "Create a new project from a bundled template. The folder "
            "<dest>/<slugified-name> will be created."
        ))
        layout.addLayout(form)
        layout.addWidget(buttons)

    def _on_browse(self) -> None:
        start = self._dest_edit.text().strip() or str(Path.home())
        chosen = QFileDialog.getExistingDirectory(
            self, "Choose destination folder", start
        )
        if chosen:
            self._dest_edit.setText(chosen)

    def _on_scaffold(self) -> None:
        stack_id = self._stack_box.currentData()
        name = self._name_edit.text().strip()
        dest = self._dest_edit.text().strip()
        desc = self._desc_edit.text().strip()
        if not name:
            QMessageBox.warning(self, "Project name required",
                                "Enter a project name.")
            return
        if not dest or not os.path.isabs(dest):
            QMessageBox.warning(self, "Absolute path required",
                                f"Destination must be absolute: {dest!r}")
            return

        # Call the SAME tool function the LLM calls — no parallel impl.
        from navi.tools.scaffold import scaffold_project
        result = scaffold_project(
            stack_id=stack_id,
            project_name=name,
            dest_path=dest,
            description=desc,
        )
        self.scaffolded.emit(result)
        if result.startswith("Error"):
            QMessageBox.critical(self, "Scaffold failed", result)
            return
        self.accept()
