"""Memory viewer/editor dialog — see and prune what Navi knows about you."""

from __future__ import annotations

import os
import subprocess

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from navi.memory import store

_DARK_QSS = """
QDialog { background: #161616; color: #e8e8e8; }
QListWidget {
    background: #0e0e0e;
    color: #e8e8e8;
    border: 1px solid #2a2a2a;
    border-radius: 4px;
}
QListWidget::item:selected { background: #2c5fc9; color: white; }
QPlainTextEdit {
    background: #0e0e0e;
    color: #e8e8e8;
    border: 1px solid #2a2a2a;
    border-radius: 4px;
    padding: 8px;
    selection-background-color: #2c5fc9;
}
QPushButton {
    background: #2a2a2a;
    color: #e8e8e8;
    padding: 6px 14px;
    border: 1px solid #3a3a3a;
    border-radius: 4px;
}
QPushButton:hover { background: #353535; }
QPushButton:disabled { background: #1a1a1a; color: #555; border-color: #2a2a2a; }
QLabel { color: #888; }
"""

_TYPE_COLORS = {
    "user": "#3B82F6",
    "feedback": "#F59E0B",
    "project": "#10B981",
    "reference": "#A855F7",
}


class MemoryViewer(QDialog):
    """Browse, edit, delete saved memories."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Navi — memories")
        self.resize(820, 540)
        self.setStyleSheet(_DARK_QSS)
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)

        self._info = QLabel("")
        self._info.setStyleSheet("QLabel { color: #888; font-size: 11px; }")

        # Left: list of memories
        self._list = QListWidget(self)
        self._list.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self._list.itemSelectionChanged.connect(self._on_select)

        # Right: body editor
        self._body = QPlainTextEdit(self)
        font = QFont("Cascadia Mono")
        if not font.exactMatch():
            font.setFamily("Consolas")
        font.setPointSize(10)
        self._body.setFont(font)
        self._body.setReadOnly(True)  # toggle when Edit pressed

        splitter = QSplitter(Qt.Orientation.Horizontal, self)
        splitter.addWidget(self._list)
        splitter.addWidget(self._body)
        splitter.setSizes([250, 520])

        # Action buttons
        self._edit_btn = QPushButton("Edit")
        self._edit_btn.setEnabled(False)
        self._edit_btn.clicked.connect(self._toggle_edit)
        self._save_btn = QPushButton("Save")
        self._save_btn.setEnabled(False)
        self._save_btn.clicked.connect(self._save_current)
        self._delete_btn = QPushButton("Delete")
        self._delete_btn.setEnabled(False)
        self._delete_btn.clicked.connect(self._delete_current)
        self._open_btn = QPushButton("Open in Notepad")
        self._open_btn.setEnabled(False)
        self._open_btn.clicked.connect(self._open_external)
        self._refresh_btn = QPushButton("Refresh")
        self._refresh_btn.clicked.connect(self.reload)

        action_row = QHBoxLayout()
        action_row.addWidget(self._edit_btn)
        action_row.addWidget(self._save_btn)
        action_row.addWidget(self._delete_btn)
        action_row.addWidget(self._open_btn)
        action_row.addStretch()
        action_row.addWidget(self._refresh_btn)

        # Close
        buttons = QDialogButtonBox(self)
        close_btn = buttons.addButton("Close", QDialogButtonBox.ButtonRole.RejectRole)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 12)
        layout.setSpacing(8)
        layout.addWidget(self._info)
        layout.addWidget(splitter, 1)
        layout.addLayout(action_row)
        layout.addWidget(buttons)

        self._editing = False
        self._current_path = None
        self.reload()

    # --- public ------------------------------------------------------------
    def reload(self) -> None:
        self._list.clear()
        self._body.clear()
        self._current_path = None
        self._set_buttons_enabled(False)

        files = store.list_memory_files()
        self._info.setText(
            f"{store.memory_dir()}  ·  {len(files)} memories"
        )
        for path in files:
            try:
                mem = store.parse_memory_file(path)
            except OSError:
                continue
            color = _TYPE_COLORS.get(mem.type, "#888")
            item = QListWidgetItem(f"  {mem.name}  ·  {mem.type}")
            item.setData(Qt.ItemDataRole.UserRole, str(path))
            item.setToolTip(f"{path.name}\n\n{mem.description}")
            # Color tag via stylesheet would be nicer, but per-item color works
            item.setForeground(__import__("PySide6.QtGui", fromlist=["QColor"]).QColor(color))
            self._list.addItem(item)

    # --- helpers -----------------------------------------------------------
    def _set_buttons_enabled(self, enabled: bool) -> None:
        self._edit_btn.setEnabled(enabled)
        self._delete_btn.setEnabled(enabled)
        self._open_btn.setEnabled(enabled)
        if not enabled:
            self._save_btn.setEnabled(False)
            self._editing = False
            self._edit_btn.setText("Edit")
            self._body.setReadOnly(True)

    def _on_select(self) -> None:
        items = self._list.selectedItems()
        if not items:
            self._set_buttons_enabled(False)
            return
        path_str = items[0].data(Qt.ItemDataRole.UserRole)
        from pathlib import Path
        self._current_path = Path(path_str)
        try:
            self._body.setPlainText(self._current_path.read_text(encoding="utf-8"))
        except OSError as exc:
            self._body.setPlainText(f"<could not read: {exc}>")
        self._set_buttons_enabled(True)

    def _toggle_edit(self) -> None:
        self._editing = not self._editing
        self._body.setReadOnly(not self._editing)
        self._save_btn.setEnabled(self._editing)
        self._edit_btn.setText("Cancel" if self._editing else "Edit")
        if self._editing:
            self._body.setFocus()

    def _save_current(self) -> None:
        if not self._current_path or not self._editing:
            return
        try:
            self._current_path.write_text(self._body.toPlainText(), encoding="utf-8")
        except OSError as exc:
            QMessageBox.warning(self, "Navi", f"Failed to save: {exc}")
            return
        self._toggle_edit()
        self.reload()

    def _delete_current(self) -> None:
        if not self._current_path:
            return
        reply = QMessageBox.question(
            self,
            "Delete memory?",
            f"Permanently delete '{self._current_path.name}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return
        store.delete_memory(self._current_path.name)
        self.reload()

    def _open_external(self) -> None:
        if not self._current_path:
            return
        try:
            os.startfile(str(self._current_path))
        except OSError:
            try:
                subprocess.Popen(["notepad.exe", str(self._current_path)])
            except OSError:
                pass
