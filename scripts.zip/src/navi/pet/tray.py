"""System tray icon for Navi.

Single-click toggles the orb visibility. Right-click shows a small menu
with Show/Hide orb, Open chat, Settings, and Quit.
"""

from __future__ import annotations

from typing import Callable

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QBrush, QColor, QIcon, QPainter, QPixmap, QRadialGradient
from PySide6.QtWidgets import QMenu, QSystemTrayIcon, QWidget


def _make_orb_icon(diameter: int = 32) -> QIcon:
    """Render a small AI-orb icon as a QIcon."""
    pix = QPixmap(diameter, diameter)
    pix.fill(Qt.GlobalColor.transparent)
    p = QPainter(pix)
    try:
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        cx = cy = diameter / 2
        # Outer ring
        p.setPen(Qt.PenStyle.NoPen)
        # Soft halo
        halo = QRadialGradient(cx, cy, diameter * 0.5)
        halo.setColorAt(0.0, QColor("#3B82F6"))
        halo.setColorAt(0.55, QColor(59, 130, 246, 90))
        halo.setColorAt(1.0, QColor(59, 130, 246, 0))
        p.setBrush(QBrush(halo))
        p.drawEllipse(0, 0, diameter, diameter)
        # Core
        core_r = diameter * 0.32
        p.setBrush(QBrush(QColor("#1E40AF")))
        p.drawEllipse(int(cx - core_r), int(cy - core_r), int(core_r * 2), int(core_r * 2))
        # Catchlight
        p.setBrush(QBrush(QColor(255, 255, 255, 180)))
        chr_ = core_r * 0.28
        p.drawEllipse(
            int(cx - core_r * 0.5),
            int(cy - core_r * 0.6),
            int(chr_ * 2),
            int(chr_ * 2),
        )
    finally:
        p.end()
    return QIcon(pix)


class NaviTray(QSystemTrayIcon):
    """Tray icon bound to a PetWindow."""

    def __init__(
        self,
        pet_window: QWidget,
        toggle_orb: Callable[[], None],
        toggle_chat: Callable[[], None],
        open_settings: Callable[[], None],
        open_audit: Callable[[], None],
        quit_app: Callable[[], None],
    ) -> None:
        super().__init__(_make_orb_icon(), pet_window)
        self.setToolTip("Navi")

        menu = QMenu(pet_window)

        toggle_orb_act = QAction("Show / hide orb", menu)
        toggle_orb_act.triggered.connect(toggle_orb)
        menu.addAction(toggle_orb_act)

        chat_act = QAction("Open chat", menu)
        chat_act.triggered.connect(toggle_chat)
        menu.addAction(chat_act)

        menu.addSeparator()

        settings_act = QAction("Settings…", menu)
        settings_act.triggered.connect(open_settings)
        menu.addAction(settings_act)

        audit_act = QAction("View activity log…", menu)
        audit_act.triggered.connect(open_audit)
        menu.addAction(audit_act)

        menu.addSeparator()

        quit_act = QAction("Quit Navi", menu)
        quit_act.triggered.connect(quit_app)
        menu.addAction(quit_act)

        self.setContextMenu(menu)

        # Single left-click toggles the orb (Windows standard for tray apps).
        self.activated.connect(
            lambda reason: toggle_orb() if reason == QSystemTrayIcon.ActivationReason.Trigger else None
        )
