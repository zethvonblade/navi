from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QPoint, Qt, QThread
from PySide6.QtGui import QAction, QMouseEvent
from PySide6.QtWidgets import QFileDialog, QMenu, QVBoxLayout, QWidget

from navi.brain.config import BrainConfig
from navi.brain.worker import BrainWorker
from navi.perms.dispatcher import PermissionDispatcher
from navi.perms.engine import PermissionEngine
from navi.pet.audit_viewer import AuditViewer
from navi.pet.chat_window import ChatWindow
from navi.pet.first_run import FirstRunDialog
from navi.pet.hotkey import HotkeyManager
from navi.pet.memory_viewer import MemoryViewer
from navi.pet.orb_widget import OrbWidget
from navi.pet.skins import REGISTRY as SKIN_REGISTRY
from navi.pet.skins import available_skins, reload_skins
from navi.pet.state import NaviState, StateBus
from navi.pet.tray import NaviTray
from navi.settings.store import load as load_settings
from navi.settings.store import save as save_settings
from navi.settings.ui import SettingsDialog
from navi.voice import VoiceManager


class PetWindow(QWidget):
    """Frameless, transparent, always-on-top window that hosts the Navi orb.

    Owns the BrainWorker thread and the floating ChatWindow.
    """

    def __init__(self) -> None:
        super().__init__(
            None,
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool,
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setWindowTitle("Navi")
        self.setAcceptDrops(True)  # drop a file on the orb to ask Navi about it

        # --- Load persisted settings ---------------------------------------
        self._settings = load_settings()
        orb_size = int(self._settings.get("ui", {}).get("orbSize", 240))
        self.resize(orb_size, orb_size)

        # Restore last window position
        pos = self._settings.get("ui", {}).get("windowPosition")
        if isinstance(pos, list) and len(pos) == 2:
            try:
                self.move(int(pos[0]), int(pos[1]))
            except (TypeError, ValueError):
                pass

        self.bus = StateBus()
        skin_name = self._settings.get("ui", {}).get("skin", "classic")
        self._orb = OrbWidget(self.bus, skin_name=skin_name, parent=self)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._orb)

        self._drag_offset: QPoint | None = None

        # --- Permission engine + dispatcher --------------------------------
        self._perms = PermissionEngine(self._settings)
        self._dispatcher = PermissionDispatcher(self)

        # --- Chat window ---------------------------------------------------
        self._chat = ChatWindow()
        self._chat.set_status("loading model…")
        # Wire dispatcher to chat for inline (non-modal) permission prompts
        self._dispatcher.set_inline_target(self._chat)

        # --- Brain (initial setup) -----------------------------------------
        self._brain_thread: QThread | None = None
        self._brain: BrainWorker | None = None
        self._setup_brain()

        # --- System tray ---------------------------------------------------
        self._tray = NaviTray(
            self,
            toggle_orb=self._toggle_orb_visibility,
            toggle_chat=self._toggle_chat,
            open_settings=self._open_settings,
            open_audit=self._open_audit_viewer,
            quit_app=self.close,
        )
        self._tray.show()

        # --- Global hotkey -------------------------------------------------
        hk = self._settings.get("ui", {}).get("hotkey", "ctrl+shift+space")
        self._hotkey = HotkeyManager(hk)
        self._hotkey.triggered.connect(self._summon_chat)

        # --- Voice manager (TTS + STT + push-to-talk) ---------------------
        # NOTE: created BEFORE _setup_brain so the brain wiring inside
        # _setup_brain can hook the voice manager's auto-TTS path.
        # We move the voice block here too late — but since _setup_brain has
        # already run by this point, we rewire token/response_finished now.
        v = self._settings.get("voice", {})
        self._brain_response_buffer: list[str] = []
        self._voice = VoiceManager(
            enabled=bool(v.get("enabled", False)),
            voice_id=v.get("voiceId"),
            rate=int(v.get("rate", 200)),
            volume=float(v.get("volume", 0.85)),
            ptt_hotkey=v.get("pttHotkey", "ctrl+alt+space"),
            parent=self,
        )
        # Auto-TTS hookup for the brain that's already running (re-wires too,
        # but harmless because Qt deduplicates identical connections via the
        # default UniqueConnection pattern when it matches).
        if self._brain is not None:
            self._brain.token.connect(self._collect_assistant_token)
            self._brain.response_finished.connect(self._speak_response)
        # PTT: transcribed text → submit to brain via chat
        self._voice.transcribed.connect(self._on_transcribed)
        # Speaking state syncs the orb (cosmetic)
        self._voice.speaking_started.connect(
            lambda: self.bus.set(NaviState.SPEAKING)
        )
        self._voice.speaking_finished.connect(
            lambda: self.bus.set(NaviState.IDLE)
        )
        # Stop button cancels TTS as well as generation
        self._chat.stop_requested.connect(self._voice.cancel_speech)

        # --- Slash commands from chat -------------------------------------
        self._chat.slash_command.connect(self._handle_slash_command)

    # --- brain lifecycle ----------------------------------------------------
    def _setup_brain(self) -> None:
        """Tear down any existing brain thread, then create+wire+start a new one.

        Reads ``BrainConfig.default()`` which honors the latest settings file —
        so this is also how a model swap takes effect.
        """
        # Tear down old brain (if any)
        if self._brain is not None and self._brain_thread is not None:
            try:
                self._chat.submitted.disconnect(self._brain.submit)
            except (TypeError, RuntimeError):
                pass
            self._brain.cancel()
            # Shut down the LLM subprocess cleanly so it doesn't linger.
            if self._brain._llm is not None and hasattr(self._brain._llm, "close"):
                try:
                    self._brain._llm.close()
                except Exception:
                    pass
            self._brain_thread.quit()
            self._brain_thread.wait(3000)
            self._brain.deleteLater()
            self._brain_thread.deleteLater()

        # Create new
        self._brain_thread = QThread(self)
        self._brain = BrainWorker(BrainConfig.default(), self._perms, self._dispatcher)
        self._brain.moveToThread(self._brain_thread)

        # State -> orb bus + chat status
        self._brain.state_loading.connect(lambda: self.bus.set(NaviState.THINKING))
        self._brain.state_loading.connect(lambda: self._chat.set_status("loading model…"))
        self._brain.state_ready.connect(lambda: self._chat.set_status("ready"))
        self._brain.state_ready.connect(lambda: self._chat.enable_input(True))
        self._brain.state_thinking.connect(lambda: self.bus.set(NaviState.THINKING))
        self._brain.state_thinking.connect(lambda: self._chat.set_status("thinking…"))
        self._brain.state_speaking.connect(lambda: self.bus.set(NaviState.SPEAKING))
        self._brain.state_speaking.connect(lambda: self._chat.set_status("speaking…"))
        self._brain.state_asking.connect(lambda: self.bus.set(NaviState.ASKING))
        self._brain.state_asking.connect(lambda: self._chat.set_status("waiting for permission…"))
        self._brain.state_idle.connect(lambda: self.bus.set(NaviState.IDLE))
        self._brain.state_idle.connect(lambda: self._chat.set_status("ready"))
        self._brain.state_error.connect(self._on_brain_error)

        # Streaming
        self._brain.response_started.connect(self._chat.assistant_started)
        self._brain.token.connect(self._chat.append_token)
        self._brain.response_finished.connect(self._chat.assistant_finished)
        self._brain.tool_call.connect(self._chat.show_tool_call)
        self._brain.tool_call.connect(self._on_tool_call_for_status)
        # Long-running tools (summarize_file's map-reduce) push progress notes
        # through this channel so the chat doesn't look frozen.
        self._brain.tool_progress.connect(self._chat.set_status)

        # User input -> brain
        self._chat.submitted.connect(self._brain.submit)

        # Stop button -> brain.cancel
        try:
            self._chat.stop_requested.disconnect()
        except (TypeError, RuntimeError):
            pass
        self._chat.stop_requested.connect(self._brain.cancel)

        # Retry button -> brain.submit (re-send last user message)
        try:
            self._chat.retry_requested.disconnect()
        except (TypeError, RuntimeError):
            pass
        self._chat.retry_requested.connect(self._brain.submit)

        # Voice: TTS speaks the assistant's final response (if voice enabled).
        # Wiring lives here (re-established on model swap) so a fresh brain
        # also feeds TTS.
        if hasattr(self, "_voice"):
            self._brain.token.connect(self._collect_assistant_token)
            self._brain.response_finished.connect(self._speak_response)

        # Boot
        self._brain_thread.started.connect(self._brain.start)
        self._brain_thread.start()

    # --- dragging -----------------------------------------------------------
    def mousePressEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        if self._drag_offset is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_offset)
            event.accept()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_offset = None
            event.accept()

    def mouseDoubleClickEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._toggle_chat()
            event.accept()

    # --- drag and drop ------------------------------------------------------
    def dragEnterEvent(self, event):  # type: ignore[no-untyped-def]
        if event.mimeData().hasUrls():
            # Visual feedback: orb flashes ASKING during the drag
            self.bus.set(NaviState.ASKING)
            event.acceptProposedAction()

    def dragLeaveEvent(self, event):  # type: ignore[no-untyped-def]
        self.bus.set(NaviState.IDLE)
        super().dragLeaveEvent(event)

    def dropEvent(self, event):  # type: ignore[no-untyped-def]
        self.bus.set(NaviState.IDLE)
        urls = event.mimeData().urls()
        if not urls:
            return
        paths = [u.toLocalFile() for u in urls if u.isLocalFile()]
        paths = [p for p in paths if p]
        if not paths:
            return

        # Compose a question. Single file -> "summarize", multiple -> list.
        if len(paths) == 1:
            question = f"Read and summarize this file:\n{paths[0]}"
        else:
            joined = "\n".join(f"- {p}" for p in paths)
            question = (
                f"I'm dropping these files for you to look at — "
                f"summarize each briefly:\n{joined}"
            )

        # Show chat, append user turn, send to brain
        if not self._chat.isVisible():
            self._chat.show()
            self._chat.raise_()
        self._chat.append_user(question)
        if self._brain is not None:
            self._brain.submit(question)
        event.acceptProposedAction()

    # --- context menu -------------------------------------------------------
    def contextMenuEvent(self, event):  # type: ignore[no-untyped-def]
        menu = QMenu(self)

        chat_action = QAction(
            "Hide chat" if self._chat.isVisible() else "Open chat",
            self,
        )
        chat_action.triggered.connect(self._toggle_chat)
        menu.addAction(chat_action)

        reset_action = QAction("Reset conversation", self)
        if self._brain is not None:
            reset_action.triggered.connect(self._brain.reset_history)
        menu.addAction(reset_action)

        settings_action = QAction("Settings…", self)
        settings_action.triggered.connect(self._open_settings)
        menu.addAction(settings_action)

        audit_action = QAction("View activity log…", self)
        audit_action.triggered.connect(self._open_audit_viewer)
        menu.addAction(audit_action)

        export_action = QAction("Save chat as…", self)
        export_action.triggered.connect(self._chat.export_chat)
        menu.addAction(export_action)

        clear_action = QAction("Clear chat panel", self)
        clear_action.triggered.connect(self._chat.clear_history)
        menu.addAction(clear_action)

        memory_action = QAction("View memories…", self)
        memory_action.triggered.connect(self._open_memory_viewer)
        menu.addAction(memory_action)

        # Lock-down (plan-mode) toggle
        is_locked = self._settings.get("defaultMode") == "plan"
        lock_action = QAction(
            "Unlock (default mode)" if is_locked else "Lock down (plan mode)",
            self,
        )
        lock_action.triggered.connect(self._toggle_lockdown)
        menu.addAction(lock_action)

        # Voice toggle
        voice_label = (
            "🔇 Voice off" if self._voice.enabled else "🔊 Voice on (TTS+STT)"
        )
        voice_action = QAction(voice_label, self)
        voice_action.triggered.connect(self._toggle_voice)
        menu.addAction(voice_action)

        self._build_model_menu(menu)
        self._build_skin_menu(menu)

        menu.addSeparator()

        debug = menu.addMenu("Debug state")
        for state in NaviState:
            action = QAction(state.name.title(), self)
            action.setCheckable(True)
            action.setChecked(state is self.bus.state)
            action.triggered.connect(lambda _checked=False, s=state: self.bus.set(s))
            debug.addAction(action)

        menu.addSeparator()

        quit_action = QAction("Quit", self)
        quit_action.triggered.connect(self.close)
        menu.addAction(quit_action)

        menu.exec(event.globalPos())

    # --- model menu ---------------------------------------------------------
    def _build_model_menu(self, parent: QMenu) -> None:
        sub = parent.addMenu("Model")
        current = self._brain._config.model_path if self._brain else None

        # Header line: current model + size
        if current and current.exists():
            size_mb = current.stat().st_size / (1024 * 1024)
            header = QAction(f"{current.name}  ({size_mb:.0f} MB)", self)
        elif current:
            header = QAction(f"{current.name}  (missing)", self)
        else:
            header = QAction("(no model loaded)", self)
        header.setEnabled(False)
        sub.addAction(header)

        sub.addSeparator()

        # Available GGUFs in models/ directory
        if current is not None:
            models_dir = current.parent
            if models_dir.exists():
                ggufs = sorted(models_dir.glob("*.gguf"))
                for path in ggufs:
                    is_current = path.resolve() == current.resolve() if current else False
                    label = ("● " if is_current else "    ") + path.name
                    action = QAction(label, self)
                    action.setEnabled(not is_current)
                    action.triggered.connect(
                        lambda _checked=False, p=path: self._switch_model(p)
                    )
                    sub.addAction(action)

        sub.addSeparator()
        browse = QAction("Browse for GGUF…", self)
        browse.triggered.connect(self._browse_model_file)
        sub.addAction(browse)

    def _build_skin_menu(self, parent: QMenu) -> None:
        sub = parent.addMenu("Skin")
        current = self._orb.current_skin_name()
        for name, desc in available_skins():
            label = ("● " if name == current else "    ") + name
            action = QAction(label, self)
            action.setToolTip(desc)
            action.setEnabled(name != current)
            action.triggered.connect(lambda _checked=False, n=name: self._switch_skin(n))
            sub.addAction(action)
        sub.addSeparator()
        new_action = QAction("New skin…", self)
        new_action.triggered.connect(self._open_skin_creator)
        sub.addAction(new_action)
        reload_action = QAction("Reload skins", self)
        reload_action.triggered.connect(self._reload_skins_from_menu)
        sub.addAction(reload_action)

    def _open_skin_creator(self) -> None:
        from navi.pet.skin_creator import SkinCreatorDialog
        dlg = SkinCreatorDialog(self)
        if dlg.exec() == SkinCreatorDialog.DialogCode.Accepted:
            new_name = dlg.saved_skin_name()
            if new_name:
                self._switch_skin(new_name)
                self._chat.show_system_note(f"created skin → {new_name}")

    def _reload_skins_from_menu(self) -> None:
        count, names = reload_skins()
        current = self._orb.current_skin_name()
        self._orb.set_skin(current if current in SKIN_REGISTRY else "classic")
        self._chat.show_system_note(
            f"🔄 reloaded {count} skins: {', '.join(names)}"
        )

    def _switch_skin(self, name: str) -> None:
        self._settings.setdefault("ui", {})["skin"] = name
        save_settings(self._settings)
        self._orb.set_skin(name)

    def _browse_model_file(self) -> None:
        start_dir = ""
        if self._brain is not None:
            start_dir = str(self._brain._config.model_path.parent)
        path_str, _ = QFileDialog.getOpenFileName(
            self,
            "Choose a GGUF model file",
            start_dir,
            "GGUF (*.gguf)",
        )
        if path_str:
            self._switch_model(Path(path_str))

    def _switch_model(self, new_path: Path) -> None:
        # Persist selection so the new BrainConfig.default() picks it up
        # AND it survives a restart.
        self._settings.setdefault("model", {})["path"] = str(new_path)
        save_settings(self._settings)
        self._chat.set_status(f"switching to {new_path.name}…")
        self._chat.enable_input(False)
        self._chat.show_divider(f"switched to {new_path.name}")
        self._setup_brain()

    # --- chat helpers -------------------------------------------------------
    def _toggle_chat(self) -> None:
        if self._chat.isVisible():
            self._chat.hide()
        else:
            self._chat.show()
            self._chat.raise_()
            self._chat.activateWindow()

    def _toggle_orb_visibility(self) -> None:
        if self.isVisible():
            self.hide()
        else:
            self.show()
            self.raise_()

    def _open_audit_viewer(self) -> None:
        viewer = AuditViewer(self)
        viewer.exec()

    def _open_memory_viewer(self) -> None:
        viewer = MemoryViewer(self)
        viewer.exec()

    def _toggle_lockdown(self) -> None:
        is_locked = self._settings.get("defaultMode") == "plan"
        new_mode = "default" if is_locked else "plan"
        self._settings["defaultMode"] = new_mode
        save_settings(self._settings)
        self._perms.__init__(self._settings)
        self._chat.show_system_note(
            "🔓 unlocked — tools execute normally"
            if new_mode == "default"
            else "🔒 locked down — Navi will describe but not execute any tools"
        )

    def _handle_slash_command(self, cmd: str, arg: str) -> None:
        if cmd == "skin":
            arg = arg.strip().lower()
            if arg in ("reload", "refresh"):
                count, names = reload_skins()
                current = self._orb.current_skin_name()
                self._orb.set_skin(current if current in SKIN_REGISTRY else "classic")
                self._chat.show_system_note(
                    f"🔄 reloaded {count} skins: {', '.join(names)}"
                )
                return
            if arg in ("new", "create"):
                self._open_skin_creator()
                return
            if arg in SKIN_REGISTRY:
                self._switch_skin(arg)
                self._chat.show_system_note(f"skin → {arg}")
            else:
                names = ", ".join(sorted(SKIN_REGISTRY.keys()))
                self._chat.show_system_note(
                    f"unknown skin {arg!r}. options: {names} (or 'reload')"
                )
        elif cmd == "model":
            # Match arg as substring of available GGUF filenames
            current = self._brain._config.model_path if self._brain else None
            if current is None:
                self._chat.show_system_note("no model loaded")
                return
            match = None
            for path in sorted(current.parent.glob("*.gguf")):
                if arg.lower() in path.name.lower():
                    match = path
                    break
            if match is None:
                self._chat.show_system_note(f"no GGUF in models/ matching {arg!r}")
                return
            self._switch_model(match)
        elif cmd == "memory":
            self._open_memory_viewer()
        elif cmd == "lock":
            self._settings["defaultMode"] = "plan"
            save_settings(self._settings)
            self._perms.__init__(self._settings)
            self._chat.show_system_note("🔒 locked down (plan mode)")
        elif cmd == "unlock":
            self._settings["defaultMode"] = "default"
            save_settings(self._settings)
            self._perms.__init__(self._settings)
            self._chat.show_system_note("🔓 unlocked (default mode)")
        elif cmd == "forget":
            if arg.strip().lower() != "all":
                self._chat.show_system_note("use: /forget all  (only 'all' supported for now)")
                return
            from PySide6.QtWidgets import QMessageBox
            reply = QMessageBox.question(
                self, "Forget everything?",
                "Permanently delete every saved memory? This cannot be undone.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if reply == QMessageBox.StandardButton.Yes:
                from navi.memory import store as mem_store
                for f in mem_store.list_memory_files():
                    mem_store.delete_memory(f.name)
                idx = mem_store.index_path()
                if idx.exists():
                    try:
                        idx.unlink()
                    except OSError:
                        pass
                self._chat.show_system_note("🧠 all memories cleared")

    def _open_settings(self) -> None:
        dlg = SettingsDialog(self)
        dlg.saved.connect(self._apply_settings)
        dlg.exec()

    def _apply_settings(self, settings: dict) -> None:
        prev_model = self._settings.get("model", {}).get("path")
        prev_skin = self._settings.get("ui", {}).get("skin", "classic")
        self._settings = settings

        # Resize orb if changed
        new_size = int(settings.get("ui", {}).get("orbSize", 240))
        if new_size != self.width():
            self.resize(new_size, new_size)

        # Skin
        new_skin = settings.get("ui", {}).get("skin", "classic")
        if new_skin != prev_skin:
            self._orb.set_skin(new_skin)

        # Refresh permission engine (rules + mode)
        self._perms.__init__(settings)

        # Hot-swap brain if model path changed in the settings dialog
        new_model = settings.get("model", {}).get("path")
        if new_model and new_model != prev_model:
            self._chat.set_status("switching model…")
            self._chat.enable_input(False)
            self._setup_brain()

    # Tools that return large text and trigger a long prompt-eval phase
    # before the next tokens stream. Set a clearer status so the user knows
    # Navi is still working, not frozen.
    _HEAVY_DOC_TOOLS = frozenset({
        "read_pdf", "read_pptx", "read_excel", "read_csv", "read_file"
    })

    def _on_tool_call_for_status(self, name: str, _args: dict, decision: str) -> None:
        if decision in ("allowed", "user-allowed") and name in self._HEAVY_DOC_TOOLS:
            self._chat.set_status("📄 read — summarizing (this can take ~30s on CPU)…")

    def _on_brain_error(self, message: str) -> None:
        # First-run case: model file missing — show a friendly setup dialog
        # instead of just a red error orb.
        if "Model file not found" in message:
            self._show_first_run_dialog()
            return
        self.bus.set(NaviState.ERROR)
        self._chat.set_status("error")
        self._chat.show_error(message)
        if not self._chat.isVisible():
            self._chat.show()

    def _show_first_run_dialog(self) -> None:
        dlg = FirstRunDialog(self)
        if dlg.exec() == FirstRunDialog.DialogCode.Accepted:
            chosen = dlg.persist_choice()
            if chosen is not None:
                self._settings = load_settings()
                self._chat.set_status("loading model…")
                self._chat.enable_input(False)
                self._setup_brain()
        else:
            self.close()

    def _summon_chat(self) -> None:
        """Show + focus chat (used by global hotkey + tray click)."""
        self.show()
        self.raise_()
        if not self._chat.isVisible():
            self._chat.show()
        self._chat.raise_()
        self._chat.activateWindow()

    # --- voice helpers -----------------------------------------------------
    def _collect_assistant_token(self, token: str) -> None:
        self._brain_response_buffer.append(token)

    def _speak_response(self) -> None:
        text = "".join(self._brain_response_buffer).strip()
        self._brain_response_buffer = []
        if text and self._voice.enabled:
            self._voice.speak(text)

    def _on_transcribed(self, text: str) -> None:
        """User pressed PTT and the transcription came back."""
        if not text:
            return
        self._chat.show()
        self._chat.raise_()
        self._chat.append_user(text)
        if self._brain is not None:
            self._brain.submit(text)

    def _toggle_voice(self) -> None:
        new_enabled = not self._voice.enabled
        self._voice.set_enabled(new_enabled)
        self._settings.setdefault("voice", {})["enabled"] = new_enabled
        save_settings(self._settings)
        self._chat.show_system_note(
            "🔊 voice on — push Ctrl+Alt+Space to talk"
            if new_enabled
            else "🔇 voice off"
        )
        # Audible confirmation so the user knows TTS is working
        if new_enabled:
            self._voice.speak("Voice enabled.")

    # --- shutdown -----------------------------------------------------------
    def closeEvent(self, event):  # type: ignore[no-untyped-def]
        try:
            self._settings.setdefault("ui", {})["windowPosition"] = [
                int(self.pos().x()),
                int(self.pos().y()),
            ]
            save_settings(self._settings)
        except Exception:
            pass
        if hasattr(self, "_hotkey"):
            self._hotkey.stop()
        if hasattr(self, "_voice"):
            self._voice.shutdown()
        if self._brain is not None and self._brain_thread is not None:
            self._brain.cancel()
            # Shut down the LLM subprocess so it doesn't outlive the GUI.
            if self._brain._llm is not None and hasattr(self._brain._llm, "close"):
                try:
                    self._brain._llm.close()
                except Exception:
                    pass
            self._chat.close()
            self._brain_thread.quit()
            self._brain_thread.wait(3000)
        super().closeEvent(event)
