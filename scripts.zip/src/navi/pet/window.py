from __future__ import annotations

import os
from pathlib import Path

from PySide6.QtCore import QPoint, Qt, QThread, QTimer
from PySide6.QtGui import QAction, QMouseEvent
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QMenu,
    QMessageBox,
    QProgressDialog,
    QVBoxLayout,
    QWidget,
)

from navi.brain.config import BrainConfig
from navi.brain.wheel_installer import (
    CUDA_DOWNLOAD_URL,
    CUDA_WHEEL_MAX_VERSION,
    cuda_runtime_present,
    gpu_offload_supported,
    start_install,
    validate_llama_cpp_loadable,
)
from navi.brain.worker import BrainWorker
from navi.perms.dispatcher import PermissionDispatcher
from navi.perms.engine import PermissionEngine
from navi.pet.audit_viewer import AuditViewer
from navi.pet.chat_window import ChatWindow
from navi.pet.first_run import FirstRunDialog
from navi.pet.hotkey import HotkeyManager
from navi.pet.memory_viewer import MemoryViewer
from navi.pet.orb_widget import OrbWidget
from navi.pet.skins import REGISTRY as SKIN_REGISTRY
from navi.pet.skins import available_skins, reload_skins
from navi.pet.state import NaviState, StateBus
from navi.pet.tray import NaviTray
from navi.settings.store import load as load_settings
from navi.settings.store import save as save_settings
from navi.settings.ui import SettingsDialog
from navi.voice import VoiceManager


class PetWindow(QWidget):
    """Frameless, transparent, always-on-top window that hosts the Navi orb.

    Owns the BrainWorker thread and the floating ChatWindow.
    """

    def __init__(self) -> None:
        super().__init__(
            None,
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool,
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setWindowTitle("Navi")
        self.setAcceptDrops(True)  # drop a file on the orb to ask Navi about it

        # --- Load persisted settings ---------------------------------------
        self._settings = load_settings()
        orb_size = int(self._settings.get("ui", {}).get("orbSize", 240))
        self.resize(orb_size, orb_size)

        # Restore last window position
        pos = self._settings.get("ui", {}).get("windowPosition")
        if isinstance(pos, list) and len(pos) == 2:
            try:
                self.move(int(pos[0]), int(pos[1]))
            except (TypeError, ValueError):
                pass

        self.bus = StateBus()
        skin_name = self._settings.get("ui", {}).get("skin", "classic")
        self._orb = OrbWidget(self.bus, skin_name=skin_name, parent=self)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._orb)

        self._drag_offset: QPoint | None = None

        # --- Permission engine + dispatcher --------------------------------
        self._perms = PermissionEngine(self._settings)
        self._dispatcher = PermissionDispatcher(self)

        # --- Chat window ---------------------------------------------------
        self._chat = ChatWindow()
        self._chat.set_status("loading model…")
        # Wire dispatcher to chat for inline (non-modal) permission prompts
        self._dispatcher.set_inline_target(self._chat)

        # --- Brain (initial setup) -----------------------------------------
        self._brain_thread: QThread | None = None
        self._brain: BrainWorker | None = None
        # Track chat→brain signal connections so we can disconnect the
        # PRIOR connection on _setup_brain reload — a bare disconnect()
        # raises RuntimeWarning on the first run when nothing is wired.
        self._chat_stop_conn = None
        self._chat_retry_conn = None
        self._setup_brain()

        # --- System tray ---------------------------------------------------
        self._tray = NaviTray(
            self,
            toggle_orb=self._toggle_orb_visibility,
            toggle_chat=self._toggle_chat,
            open_settings=self._open_settings,
            open_audit=self._open_audit_viewer,
            quit_app=self._quit_app,
        )
        self._tray.show()

        # --- Global hotkey -------------------------------------------------
        hk = self._settings.get("ui", {}).get("hotkey", "ctrl+shift+space")
        self._hotkey = HotkeyManager(hk)
        self._hotkey.triggered.connect(self._summon_chat)

        # --- Voice manager (TTS + STT + push-to-talk) ---------------------
        # NOTE: created BEFORE _setup_brain so the brain wiring inside
        # _setup_brain can hook the voice manager's auto-TTS path.
        # We move the voice block here too late — but since _setup_brain has
        # already run by this point, we rewire token/response_finished now.
        v = self._settings.get("voice", {})
        self._brain_response_buffer: list[str] = []
        self._voice = VoiceManager(
            enabled=bool(v.get("enabled", False)),
            voice_id=v.get("voiceId"),
            rate=int(v.get("rate", 200)),
            volume=float(v.get("volume", 0.85)),
            ptt_hotkey=v.get("pttHotkey", "ctrl+alt+space"),
            parent=self,
        )
        # Auto-TTS hookup for the brain that's already running (re-wires too,
        # but harmless because Qt deduplicates identical connections via the
        # default UniqueConnection pattern when it matches).
        if self._brain is not None:
            self._brain.token.connect(self._collect_assistant_token)
            self._brain.response_finished.connect(self._speak_response)
        # PTT: transcribed text → submit to brain via chat
        self._voice.transcribed.connect(self._on_transcribed)
        # Surface PTT install success/failure once so the user knows
        # whether voice push-to-talk is actually armed. The signal already
        # fired during VoiceManager.__init__ (before this connect ran);
        # report_ptt_status re-emits the cached result so we catch it.
        self._voice.ptt_install_status.connect(self._chat.show_system_note)
        self._voice.report_ptt_status()
        # Speaking state syncs the orb (cosmetic)
        self._voice.speaking_started.connect(
            lambda: self.bus.set(NaviState.SPEAKING)
        )
        self._voice.speaking_finished.connect(
            lambda: self.bus.set(NaviState.IDLE)
        )
        # Stop button cancels TTS as well as generation
        self._chat.stop_requested.connect(self._voice.cancel_speech)

        # --- Slash commands from chat -------------------------------------
        self._chat.slash_command.connect(self._handle_slash_command)

    # --- brain lifecycle ----------------------------------------------------
    def _setup_brain(self) -> None:
        """Tear down any existing brain thread, then create+wire+start a new one.

        Reads ``BrainConfig.default()`` which honors the latest settings file —
        so this is also how a model swap takes effect.
        """
        # Tear down old brain (if any)
        if self._brain is not None and self._brain_thread is not None:
            try:
                self._chat.submitted.disconnect(self._brain.submit)
            except (TypeError, RuntimeError):
                pass
            self._brain.cancel()
            # Shut down the LLM subprocess cleanly so it doesn't linger.
            if self._brain._llm is not None and hasattr(self._brain._llm, "close"):
                try:
                    self._brain._llm.close()
                except Exception:
                    pass
            self._brain_thread.quit()
            self._brain_thread.wait(3000)
            self._brain.deleteLater()
            self._brain_thread.deleteLater()

        # Create new
        self._brain_thread = QThread(self)
        self._brain = BrainWorker(BrainConfig.default(), self._perms, self._dispatcher)
        self._brain.moveToThread(self._brain_thread)

        # State -> orb bus + chat status
        self._brain.state_loading.connect(lambda: self.bus.set(NaviState.THINKING))
        self._brain.state_loading.connect(lambda: self._chat.set_status("loading model…"))
        self._brain.state_ready.connect(lambda: self._chat.set_status("ready"))
        self._brain.state_ready.connect(lambda: self._chat.enable_input(True))
        self._brain.state_thinking.connect(lambda: self.bus.set(NaviState.THINKING))
        self._brain.state_thinking.connect(lambda: self._chat.set_status("thinking…"))
        self._brain.state_speaking.connect(lambda: self.bus.set(NaviState.SPEAKING))
        self._brain.state_speaking.connect(lambda: self._chat.set_status("speaking…"))
        self._brain.state_asking.connect(lambda: self.bus.set(NaviState.ASKING))
        self._brain.state_asking.connect(lambda: self._chat.set_status("waiting for permission…"))
        self._brain.state_idle.connect(lambda: self.bus.set(NaviState.IDLE))
        self._brain.state_idle.connect(lambda: self._chat.set_status("ready"))
        self._brain.state_error.connect(self._on_brain_error)

        # Streaming
        self._brain.response_started.connect(self._chat.assistant_started)
        self._brain.token.connect(self._chat.append_token)
        self._brain.response_finished.connect(self._chat.assistant_finished)
        self._brain.tool_call.connect(self._chat.show_tool_call)
        self._brain.tool_call.connect(self._on_tool_call_for_status)
        # Tool results — chat may render inline (e.g. image preview)
        self._brain.tool_result.connect(self._chat.show_tool_result)
        # Long-running tools (summarize_file's map-reduce) push progress notes
        # through this channel so the chat doesn't look frozen.
        self._brain.tool_progress.connect(self._chat.set_status)
        # Calibration: model-swap probe results land in chat as a note.
        # We also surface progress via tray tooltip + chat status bar so
        # the user knows it's alive without staring at chat history.
        self._brain.calibration_started.connect(self._on_calibration_started)
        self._brain.calibration_progress.connect(self._on_calibration_progress)
        self._brain.calibration_done.connect(self._on_calibration_done)
        # Tool-use hint detector: brain always sees hints; chat only
        # surfaces them when /hints is on (settings.ui.showHints).
        self._brain.hint_injected.connect(self._on_hint_injected)
        # Drift detection: brain warns once per session if responses degrade.
        self._brain.drift_detected.connect(self._chat.show_system_note)

        # User input -> brain
        self._chat.submitted.connect(self._brain.submit)

        # Stop button -> brain.cancel. Track the Connection token so we
        # can disconnect THIS specific connection on the next _setup_brain
        # without the bare-disconnect RuntimeWarning on first launch.
        if self._chat_stop_conn is not None:
            try:
                self._chat.stop_requested.disconnect(self._chat_stop_conn)
            except (TypeError, RuntimeError):
                pass
        self._chat_stop_conn = self._chat.stop_requested.connect(self._brain.cancel)

        # Retry button -> brain.submit (re-send last user message)
        if self._chat_retry_conn is not None:
            try:
                self._chat.retry_requested.disconnect(self._chat_retry_conn)
            except (TypeError, RuntimeError):
                pass
        self._chat_retry_conn = self._chat.retry_requested.connect(self._brain.submit)

        # Voice: TTS speaks the assistant's final response (if voice enabled).
        # Wiring lives here (re-established on model swap) so a fresh brain
        # also feeds TTS.
        if hasattr(self, "_voice"):
            self._brain.token.connect(self._collect_assistant_token)
            self._brain.response_finished.connect(self._speak_response)

        # Boot
        self._brain_thread.started.connect(self._brain.start)
        self._brain_thread.start()

    # --- dragging -----------------------------------------------------------
    def mousePressEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        if self._drag_offset is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_offset)
            event.accept()

    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_offset = None
            event.accept()

    def mouseDoubleClickEvent(self, event: QMouseEvent) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._toggle_chat()
            event.accept()

    # --- drag and drop ------------------------------------------------------
    def dragEnterEvent(self, event):  # type: ignore[no-untyped-def]
        if event.mimeData().hasUrls():
            # Visual feedback: orb flashes ASKING during the drag
            self.bus.set(NaviState.ASKING)
            event.acceptProposedAction()

    def dragLeaveEvent(self, event):  # type: ignore[no-untyped-def]
        self.bus.set(NaviState.IDLE)
        super().dragLeaveEvent(event)

    def dropEvent(self, event):  # type: ignore[no-untyped-def]
        self.bus.set(NaviState.IDLE)
        urls = event.mimeData().urls()
        if not urls:
            return
        paths = [u.toLocalFile() for u in urls if u.isLocalFile()]
        paths = [p for p in paths if p]
        if not paths:
            return

        # Compose a question. Single file -> "summarize", multiple -> list.
        if len(paths) == 1:
            question = f"Read and summarize this file:\n{paths[0]}"
        else:
            joined = "\n".join(f"- {p}" for p in paths)
            question = (
                f"I'm dropping these files for you to look at — "
                f"summarize each briefly:\n{joined}"
            )

        # Show chat, append user turn, send to brain.
        #
        # IMPORTANT: route through the chat's `submitted` signal instead of
        # calling `self._brain.submit(question)` directly. `submit` is a
        # @Slot but a direct call ignores thread affinity and runs the
        # entire agent loop (LLM subprocess pipe reads, tool dispatch,
        # multi-turn iteration) on the GUI thread — that's the freeze.
        # Going through the signal hits the queued connection set up in
        # `_setup_brain` and the work runs on the brain's QThread.
        if not self._chat.isVisible():
            self._chat.show()
            self._chat.raise_()
        self._chat.append_user(question)
        # Set THINKING immediately so the orb shows activity while the
        # queued submit is in flight (brain emits state_thinking once it
        # actually starts, but that's a few event-loop ticks away).
        self.bus.set(NaviState.THINKING)
        self._chat.submitted.emit(question)
        event.acceptProposedAction()

    # --- context menu -------------------------------------------------------
    def contextMenuEvent(self, event):  # type: ignore[no-untyped-def]
        menu = QMenu(self)

        chat_action = QAction(
            "Hide chat" if self._chat.isVisible() else "Open chat",
            self,
        )
        chat_action.triggered.connect(self._toggle_chat)
        menu.addAction(chat_action)

        reset_action = QAction("Reset conversation", self)
        if self._brain is not None:
            reset_action.triggered.connect(self._brain.reset_history)
        menu.addAction(reset_action)

        settings_action = QAction("Settings…", self)
        settings_action.triggered.connect(self._open_settings)
        menu.addAction(settings_action)

        audit_action = QAction("View activity log…", self)
        audit_action.triggered.connect(self._open_audit_viewer)
        menu.addAction(audit_action)

        export_action = QAction("Save chat as…", self)
        export_action.triggered.connect(self._chat.export_chat)
        menu.addAction(export_action)

        clear_action = QAction("Clear chat panel", self)
        clear_action.triggered.connect(self._chat.clear_history)
        menu.addAction(clear_action)

        memory_action = QAction("View memories…", self)
        memory_action.triggered.connect(self._open_memory_viewer)
        menu.addAction(memory_action)

        # Lock-down (plan-mode) toggle
        is_locked = self._settings.get("defaultMode") == "plan"
        lock_action = QAction(
            "Unlock (default mode)" if is_locked else "Lock down (plan mode)",
            self,
        )
        lock_action.triggered.connect(self._toggle_lockdown)
        menu.addAction(lock_action)

        # Voice toggle
        voice_label = (
            "🔇 Voice off" if self._voice.enabled else "🔊 Voice on (TTS+STT)"
        )
        voice_action = QAction(voice_label, self)
        voice_action.triggered.connect(self._toggle_voice)
        menu.addAction(voice_action)

        self._build_model_menu(menu)
        self._build_skin_menu(menu)
        self._build_soul_menu(menu)

        menu.addSeparator()

        debug = menu.addMenu("Debug state")
        for state in NaviState:
            action = QAction(state.name.title(), self)
            action.setCheckable(True)
            action.setChecked(state is self.bus.state)
            action.triggered.connect(lambda _checked=False, s=state: self.bus.set(s))
            debug.addAction(action)

        menu.addSeparator()

        quit_action = QAction("Quit", self)
        quit_action.triggered.connect(self.close)
        menu.addAction(quit_action)

        menu.exec(event.globalPos())

    # --- model menu ---------------------------------------------------------
    def _build_model_menu(self, parent: QMenu) -> None:
        sub = parent.addMenu("Model")
        current = self._brain._config.model_path if self._brain else None

        # Header line: current model + size
        if current and current.exists():
            size_mb = current.stat().st_size / (1024 * 1024)
            header = QAction(f"{current.name}  ({size_mb:.0f} MB)", self)
        elif current:
            header = QAction(f"{current.name}  (missing)", self)
        else:
            header = QAction("(no model loaded)", self)
        header.setEnabled(False)
        sub.addAction(header)

        sub.addSeparator()

        # Available GGUFs in models/ directory
        if current is not None:
            models_dir = current.parent
            if models_dir.exists():
                ggufs = sorted(models_dir.glob("*.gguf"))
                for path in ggufs:
                    is_current = path.resolve() == current.resolve() if current else False
                    label = ("● " if is_current else "    ") + path.name
                    action = QAction(label, self)
                    action.setEnabled(not is_current)
                    action.triggered.connect(
                        lambda _checked=False, p=path: self._switch_model(p)
                    )
                    sub.addAction(action)

        sub.addSeparator()
        browse = QAction("Browse for GGUF…", self)
        browse.triggered.connect(self._browse_model_file)
        sub.addAction(browse)

    def _build_skin_menu(self, parent: QMenu) -> None:
        sub = parent.addMenu("Skin")
        current = self._orb.current_skin_name()
        for name, desc in available_skins():
            label = ("● " if name == current else "    ") + name
            action = QAction(label, self)
            action.setToolTip(desc)
            action.setEnabled(name != current)
            action.triggered.connect(lambda _checked=False, n=name: self._switch_skin(n))
            sub.addAction(action)
        sub.addSeparator()
        new_action = QAction("New skin…", self)
        new_action.triggered.connect(self._open_skin_creator)
        sub.addAction(new_action)
        reload_action = QAction("Reload skins", self)
        reload_action.triggered.connect(self._reload_skins_from_menu)
        sub.addAction(reload_action)

    def _build_soul_menu(self, parent: QMenu) -> None:
        from navi.brain.persona import (
            list_souls,
            load_soul,
            soul_path,
            template_path,
        )
        sub = parent.addMenu("Soul")
        current_text = load_soul()
        for name in list_souls():
            try:
                bundled = template_path(name).read_text(encoding="utf-8").strip()
            except OSError:
                bundled = ""
            is_current = bundled == current_text
            label = ("● " if is_current else "    ") + name
            action = QAction(label, self)
            action.setEnabled(not is_current)
            action.triggered.connect(
                lambda _checked=False, n=name: self._switch_soul(n)
            )
            sub.addAction(action)
        sub.addSeparator()
        from navi.brain.persona import get_active_soul_name, soul_backup_path
        active = get_active_soul_name()
        reset_action = QAction(f"Reset to {active} (discard edits)", self)
        reset_action.triggered.connect(lambda: self._handle_soul_command("reset"))
        sub.addAction(reset_action)
        restore_action = QAction("Restore previous (undo last switch)", self)
        restore_action.setEnabled(soul_backup_path().exists())
        restore_action.triggered.connect(lambda: self._handle_soul_command("restore"))
        sub.addAction(restore_action)
        sub.addSeparator()
        edit_action = QAction("Edit soul.md…", self)
        edit_action.triggered.connect(lambda: self._handle_soul_command("edit"))
        sub.addAction(edit_action)
        show_action = QAction("Show current soul…", self)
        show_action.triggered.connect(lambda: self._handle_soul_command(""))
        sub.addAction(show_action)
        # Surface the path for users who want to navigate to the file directly.
        sub.addSeparator()
        path_action = QAction(f"📁 {soul_path()}", self)
        path_action.setEnabled(False)
        sub.addAction(path_action)

    def _switch_soul(self, name: str) -> None:
        from navi.brain.persona import apply_soul_template, soul_backup_path
        try:
            apply_soul_template(name)
        except FileNotFoundError:
            self._chat.show_system_note(f"unknown soul template: {name}")
            return
        self._chat.show_system_note(
            f"📜 soul → {name}  (previous saved to {soul_backup_path().name})"
        )

    def _open_skin_creator(self) -> None:
        from navi.pet.skin_creator import SkinCreatorDialog
        dlg = SkinCreatorDialog(self)
        if dlg.exec() == SkinCreatorDialog.DialogCode.Accepted:
            new_name = dlg.saved_skin_name()
            if new_name:
                self._switch_skin(new_name)
                self._chat.show_system_note(f"created skin → {new_name}")

    def _reload_skins_from_menu(self) -> None:
        count, names = reload_skins()
        current = self._orb.current_skin_name()
        self._orb.set_skin(current if current in SKIN_REGISTRY else "classic")
        self._chat.show_system_note(
            f"🔄 reloaded {count} skins: {', '.join(names)}"
        )

    def _switch_skin(self, name: str) -> None:
        self._settings.setdefault("ui", {})["skin"] = name
        save_settings(self._settings)
        self._orb.set_skin(name)

    def _browse_model_file(self) -> None:
        start_dir = ""
        if self._brain is not None:
            start_dir = str(self._brain._config.model_path.parent)
        path_str, _ = QFileDialog.getOpenFileName(
            self,
            "Choose a GGUF model file",
            start_dir,
            "GGUF (*.gguf)",
        )
        if path_str:
            self._switch_model(Path(path_str))

    def _switch_model(self, new_path: Path) -> None:
        # Persist selection so the new BrainConfig.default() picks it up
        # AND it survives a restart.
        self._settings.setdefault("model", {})["path"] = str(new_path)
        save_settings(self._settings)
        self._chat.set_status(f"switching to {new_path.name}…")
        self._chat.enable_input(False)
        self._chat.show_divider(f"switched to {new_path.name}")
        # Tear down the image subprocess too — it may hold an LLM-coupled
        # state (e.g. some pipelines load a CLIP encoder sized for the
        # text model). Lazy-respawned on next image_gen call.
        try:
            from navi.image.client import reset_image_client
            reset_image_client()
        except Exception:
            pass
        self._setup_brain()

    # --- chat helpers -------------------------------------------------------
    def _toggle_chat(self) -> None:
        if self._chat.isVisible():
            self._chat.hide()
        else:
            self._chat.show()
            self._chat.raise_()
            self._chat.activateWindow()

    def _toggle_orb_visibility(self) -> None:
        if self.isVisible():
            self.hide()
        else:
            self.show()
            self.raise_()

    def _open_audit_viewer(self) -> None:
        viewer = AuditViewer(self)
        viewer.exec()

    def _open_memory_viewer(self) -> None:
        viewer = MemoryViewer(self)
        viewer.exec()

    def _handle_soul_command(self, arg: str) -> None:
        from navi.brain.persona import (
            apply_soul_template,
            get_active_soul_name,
            list_souls,
            load_soul,
            reset_soul,
            restore_soul_from_backup,
            soul_backup_path,
            soul_path,
            template_path,
        )
        path = soul_path()
        parts = arg.strip().split(maxsplit=1)
        sub = parts[0].lower() if parts else ""
        rest = parts[1].strip() if len(parts) > 1 else ""

        if sub == "edit":
            # Touch the file (so the editor opens an existing file, not a
            # save-as dialog) by triggering load_soul()'s first-run copy.
            load_soul()
            try:
                os.startfile(str(path))  # type: ignore[attr-defined]
            except OSError as exc:
                self._chat.show_system_note(f"couldn't open {path}: {exc}")
            else:
                self._chat.show_system_note(f"📝 opened {path} in default editor")
            return

        if sub in ("reload", "refresh"):
            text = load_soul()
            self._chat.show_system_note(
                f"🔄 soul reloaded ({len(text)} chars) — next turn will use it"
            )
            return

        if sub == "list":
            names = list_souls()
            if not names:
                self._chat.show_system_note("no bundled soul templates found")
                return
            current = load_soul()
            lines = ["📜 soul templates:"]
            for n in names:
                bundled = template_path(n).read_text(encoding="utf-8").strip()
                marker = " ← current" if bundled == current else ""
                lines.append(f"  • {n}{marker}")
            lines.append("\nuse: /soul use <name>")
            self._chat.show_system_note("\n".join(lines))
            return

        if sub == "use":
            if not rest:
                self._chat.show_system_note("use: /soul use <name>  (try /soul list)")
                return
            try:
                apply_soul_template(rest)
            except FileNotFoundError:
                names = ", ".join(list_souls())
                self._chat.show_system_note(
                    f"unknown soul {rest!r}. options: {names}"
                )
                return
            self._chat.show_system_note(
                f"📜 soul → {rest}  (previous saved to {soul_backup_path().name})"
            )
            return

        if sub == "reset":
            name = reset_soul()
            self._chat.show_system_note(
                f"📜 soul reset → {name}  (your edits saved to {soul_backup_path().name})"
            )
            return

        if sub == "restore":
            if not restore_soul_from_backup():
                self._chat.show_system_note(
                    "no backup to restore from — make a switch with /soul use first"
                )
                return
            self._chat.show_system_note(
                f"📜 soul restored from {soul_backup_path().name} "
                f"(call /soul restore again to undo)"
            )
            return

        if sub:
            self._chat.show_system_note(
                "use: /soul | /soul list | /soul use <name> | /soul reset | "
                "/soul restore | /soul edit | /soul reload"
            )
            return

        text = load_soul()
        self._chat.show_system_note(f"📜 soul.md @ {path}\n\n{text}")

    def _toggle_lockdown(self) -> None:
        is_locked = self._settings.get("defaultMode") == "plan"
        new_mode = "default" if is_locked else "plan"
        self._settings["defaultMode"] = new_mode
        save_settings(self._settings)
        self._perms.__init__(self._settings)
        self._chat.show_system_note(
            "🔓 unlocked — tools execute normally"
            if new_mode == "default"
            else "🔒 locked down — Navi will describe but not execute any tools"
        )

    def _handle_slash_command(self, cmd: str, arg: str) -> None:
        if cmd == "skin":
            arg = arg.strip().lower()
            if arg in ("reload", "refresh"):
                count, names = reload_skins()
                current = self._orb.current_skin_name()
                self._orb.set_skin(current if current in SKIN_REGISTRY else "classic")
                self._chat.show_system_note(
                    f"🔄 reloaded {count} skins: {', '.join(names)}"
                )
                return
            if arg in ("new", "create"):
                self._open_skin_creator()
                return
        elif cmd == "calibrate":
            if self._brain is None:
                self._chat.show_system_note("no brain loaded")
                return
            if arg.strip().lower() in ("verbose", "v", "-v"):
                self._brain.calibrate_verbose()
            else:
                self._brain.calibrate()
            return
            if arg in SKIN_REGISTRY:
                self._switch_skin(arg)
                self._chat.show_system_note(f"skin → {arg}")
            else:
                names = ", ".join(sorted(SKIN_REGISTRY.keys()))
                self._chat.show_system_note(
                    f"unknown skin {arg!r}. options: {names} (or 'reload')"
                )
        elif cmd == "model":
            # Match arg as substring of available GGUF filenames
            current = self._brain._config.model_path if self._brain else None
            if current is None:
                self._chat.show_system_note("no model loaded")
                return
            match = None
            for path in sorted(current.parent.glob("*.gguf")):
                if arg.lower() in path.name.lower():
                    match = path
                    break
            if match is None:
                self._chat.show_system_note(f"no GGUF in models/ matching {arg!r}")
                return
            self._switch_model(match)
        elif cmd == "memory":
            self._open_memory_viewer()
        elif cmd == "soul":
            self._handle_soul_command(arg)
        elif cmd == "hints":
            ui = self._settings.setdefault("ui", {})
            current = bool(ui.get("showHints", False))
            arg_norm = arg.strip().lower()
            if arg_norm in ("on", "true", "1"):
                new_val = True
            elif arg_norm in ("off", "false", "0"):
                new_val = False
            elif arg_norm in ("", "toggle"):
                new_val = not current
            elif arg_norm in ("status", "?"):
                self._chat.show_system_note(
                    f"⚙ hints are {'ON' if current else 'OFF'} "
                    "(brain always sees them; chat only shows when ON)"
                )
                return
            else:
                self._chat.show_system_note(
                    "use: /hints on | off | toggle | status"
                )
                return
            ui["showHints"] = new_val
            save_settings(self._settings)
            self._chat.show_system_note(
                f"⚙ hints {'ON' if new_val else 'OFF'} — "
                f"chat will {'show' if new_val else 'hide'} the auto-detected "
                "tool suggestions (brain always sees them either way)"
            )
        elif cmd == "lock":
            self._settings["defaultMode"] = "plan"
            save_settings(self._settings)
            self._perms.__init__(self._settings)
            self._chat.show_system_note("🔒 locked down (plan mode)")
        elif cmd == "unlock":
            self._settings["defaultMode"] = "default"
            save_settings(self._settings)
            self._perms.__init__(self._settings)
            self._chat.show_system_note("🔓 unlocked (default mode)")
        elif cmd == "forget":
            if arg.strip().lower() != "all":
                self._chat.show_system_note("use: /forget all  (only 'all' supported for now)")
                return
            from PySide6.QtWidgets import QMessageBox
            reply = QMessageBox.question(
                self, "Forget everything?",
                "Permanently delete every saved memory? This cannot be undone.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if reply == QMessageBox.StandardButton.Yes:
                from navi.memory import store as mem_store
                for f in mem_store.list_memory_files():
                    mem_store.delete_memory(f.name)
                idx = mem_store.index_path()
                if idx.exists():
                    try:
                        idx.unlink()
                    except OSError:
                        pass
                self._chat.show_system_note("🧠 all memories cleared")

    def _open_settings(self) -> None:
        dlg = SettingsDialog(self)
        dlg.saved.connect(self._apply_settings)
        dlg.exec()

    def _apply_settings(self, settings: dict) -> None:
        prev_model = self._settings.get("model", {}).get("path")
        prev_ngl = int(self._settings.get("model", {}).get("n_gpu_layers", 0))
        prev_skin = self._settings.get("ui", {}).get("skin", "classic")
        self._settings = settings

        # Resize orb if changed
        new_size = int(settings.get("ui", {}).get("orbSize", 240))
        if new_size != self.width():
            self.resize(new_size, new_size)

        # Skin
        new_skin = settings.get("ui", {}).get("skin", "classic")
        if new_skin != prev_skin:
            self._orb.set_skin(new_skin)

        # Refresh permission engine (rules + mode)
        self._perms.__init__(settings)

        # Hot-swap brain if model path or compute device changed
        new_model = settings.get("model", {}).get("path")
        new_ngl = int(settings.get("model", {}).get("n_gpu_layers", 0))
        device_changed = new_ngl != prev_ngl
        model_changed = bool(new_model and new_model != prev_model)

        # If switching to GPU and the current llama-cpp build can't offload,
        # we need to reinstall the CUDA wheel. Tear the brain down FIRST so
        # the brain subprocess releases its grip on the llama-cpp DLLs —
        # otherwise pip's uninstall step hangs on Windows file locks.
        if device_changed and new_ngl != 0 and not gpu_offload_supported():
            installed = self._install_cuda_wheel()
            if not installed:
                # Roll back the persisted setting so the dropdown reflects
                # what's actually loaded.
                self._settings.setdefault("model", {})["n_gpu_layers"] = prev_ngl
                save_settings(self._settings)
                # Brain is down (we tore it down for the install) — bring it
                # back on the previous (CPU) setting.
                self._setup_brain()
                return

        if model_changed or device_changed:
            self._chat.set_status("switching model…")
            self._chat.enable_input(False)
            self._setup_brain()

    def _install_cuda_wheel(self) -> bool:
        """Confirm, preflight, tear down brain, install, validate, rollback if needed."""
        # Preflight: CUDA wheel needs the CUDA runtime (cudart64_*.dll) which
        # ships with the CUDA Toolkit, not the driver. Fail loudly here
        # instead of letting the user wait for a download that won't load.
        if not cuda_runtime_present():
            QMessageBox.warning(
                self,
                "CUDA toolkit not found",
                "GPU support needs the NVIDIA CUDA Toolkit (12.x) — your "
                "driver alone is not enough. The CUDA build of "
                "llama-cpp-python links against cudart64_12.dll, which only "
                "ships with the toolkit installer.\n\n"
                f"Install the toolkit from:\n{CUDA_DOWNLOAD_URL}\n\n"
                "Then come back and try again.",
            )
            return False

        confirm = QMessageBox.question(
            self,
            "Install CUDA wheel?",
            "To run on GPU, Navi needs to reinstall llama-cpp-python with "
            "a CUDA wheel (~200 MB download).\n\n"
            f"⚠ The official CUDA wheel index only goes up to "
            f"{CUDA_WHEEL_MAX_VERSION}, so this will DOWNGRADE the package "
            "from your current version. Some newer model templates (incl. "
            "Granite tool calling) may stop working. If anything goes wrong, "
            "Navi will roll back to the CPU wheel automatically.\n\nContinue?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if confirm != QMessageBox.StandardButton.Yes:
            return False

        # Stop the brain subprocess so its loaded llama-cpp DLLs aren't
        # locked when pip tries to uninstall the wheel.
        self._chat.set_status("stopping brain for GPU install…")
        self._teardown_brain()

        ok, msg = self._run_pip_install("cuda", "Downloading CUDA build of llama-cpp-python…")
        if not ok:
            QMessageBox.warning(self, "Install failed", msg or "Cancelled or unknown error.")
            return False

        # Validate the new wheel actually loads (CUDA runtime present, ABI ok, etc.)
        load_ok, load_err = validate_llama_cpp_loadable()
        if not load_ok:
            # Auto-rollback to CPU so the user isn't left with a broken brain.
            QMessageBox.warning(
                self,
                "GPU build won't load — rolling back",
                "The CUDA wheel installed but Python can't load its DLLs:\n\n"
                f"{load_err}\n\n"
                "Reinstalling the CPU wheel so Navi keeps working.",
            )
            rb_ok, rb_msg = self._run_pip_install("cpu", "Rolling back to CPU wheel…")
            if not rb_ok:
                QMessageBox.critical(
                    self,
                    "Rollback failed",
                    f"Couldn't reinstall the CPU wheel either:\n\n{rb_msg}\n\n"
                    "Run manually:\n"
                    "  pip install --force-reinstall --only-binary=:all: \\\n"
                    "    --index-url https://abetlen.github.io/llama-cpp-python/whl/cpu \\\n"
                    "    llama-cpp-python",
                )
            return False

        QMessageBox.information(
            self,
            "GPU support installed",
            "CUDA build of llama-cpp-python is installed and loads cleanly. "
            "The brain will reload on the GPU now.",
        )
        return True

    def _teardown_brain(self) -> None:
        """Stop the brain thread + LLM subprocess so DLL files become unlocked."""
        if self._brain is None or self._brain_thread is None:
            return
        try:
            self._chat.submitted.disconnect(self._brain.submit)
        except (TypeError, RuntimeError):
            pass
        self._brain.cancel()
        if self._brain._llm is not None and hasattr(self._brain._llm, "close"):
            try:
                self._brain._llm.close()
            except Exception:
                pass
        self._brain_thread.quit()
        self._brain_thread.wait(3000)
        self._brain.deleteLater()
        self._brain_thread.deleteLater()
        self._brain = None
        self._brain_thread = None

    def _run_pip_install(self, target: str, headline: str) -> tuple[bool, str]:
        """Run the wheel installer with a modal progress dialog + heartbeat."""
        progress = QProgressDialog(headline, "Cancel", 0, 0, self)
        progress.setWindowTitle("Installing")
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setMinimumDuration(0)
        progress.setAutoClose(False)
        progress.setAutoReset(False)

        thread, worker = start_install(target)
        self._install_thread = thread  # keep refs alive
        self._install_worker = worker

        last_line = {"text": "starting…"}
        elapsed = {"s": 0}

        def on_line(text: str) -> None:
            last_line["text"] = text[-180:]
            progress.setLabelText(f"[{elapsed['s']}s] {last_line['text']}")

        heartbeat = QTimer(self)
        heartbeat.setInterval(1000)

        def tick() -> None:
            elapsed["s"] += 1
            progress.setLabelText(f"[{elapsed['s']}s] {last_line['text']}")

        heartbeat.timeout.connect(tick)
        heartbeat.start()

        result: dict[str, object] = {"ok": False, "msg": ""}

        def on_finished(ok: bool, msg: str) -> None:
            result["ok"] = ok
            result["msg"] = msg
            heartbeat.stop()
            progress.cancel()

        worker.line.connect(on_line)
        worker.finished.connect(on_finished)
        # Both Cancel button (canceled) and X/ESC (rejected) must kill pip
        # — by default QProgressDialog only emits canceled on the button.
        # worker.cancel() is idempotent so wiring both is safe.
        progress.canceled.connect(worker.cancel)
        progress.rejected.connect(worker.cancel)

        thread.start()
        try:
            progress.exec()
        finally:
            # Stop the heartbeat unconditionally — exec() can return for
            # reasons other than on_finished (an exception inside the Qt
            # event loop, the dialog being destroyed, etc.) and a stray
            # QTimer firing on a destroyed dialog raises.
            heartbeat.stop()
        thread.wait(10_000)
        return bool(result["ok"]), str(result["msg"])

    # Tools that return large text and trigger a long prompt-eval phase
    # before the next tokens stream. Set a clearer status so the user knows
    # Navi is still working, not frozen.
    _HEAVY_DOC_TOOLS = frozenset({
        "read_pdf", "read_pptx", "read_excel", "read_csv", "read_file"
    })

    def _on_tool_call_for_status(self, name: str, _args: dict, decision: str) -> None:
        if decision in ("allowed", "user-allowed") and name in self._HEAVY_DOC_TOOLS:
            self._chat.set_status("📄 read — summarizing (this can take ~30s on CPU)…")

    # --- calibration progress surface --------------------------------------
    def _on_calibration_started(self, note: str) -> None:
        # Single chat line at start (chat may be hidden — that's OK, the
        # tray balloon below covers visibility).
        self._chat.show_system_note(note)
        self._chat.set_status("🧪 calibrating…")
        self._tray.setToolTip("Navi — calibrating…")
        # Tray balloon — visible without opening chat. ~5s, info-level.
        try:
            from PySide6.QtWidgets import QSystemTrayIcon
            self._tray.showMessage(
                "Navi calibrating",
                "Tuning the model for tool calling — usually 30–90s.",
                QSystemTrayIcon.MessageIcon.Information,
                5000,
            )
        except Exception:  # noqa: BLE001
            pass

    def _on_calibration_progress(self, current: int, total: int, label: str) -> None:
        # Update both surfaces — chat status (visible when chat is open)
        # and tray tooltip (visible on hover with chat closed).
        msg = f"🧪 calibrating {current}/{total}: {label}"
        self._chat.set_status(msg)
        self._tray.setToolTip(f"Navi — {msg}")

    def _on_calibration_done(self, report_text: str) -> None:
        self._chat.show_system_note(report_text)
        self._chat.set_status("ready")
        self._tray.setToolTip("Navi")

    def _on_hint_injected(self, hint: str) -> None:
        # Only surface in chat when the user has opted in via /hints on.
        if self._settings.get("ui", {}).get("showHints", False):
            self._chat.show_system_note(hint)

    def _on_brain_error(self, message: str) -> None:
        # First-run case: model file missing — show a friendly setup dialog
        # instead of just a red error orb.
        if "Model file not found" in message:
            self._show_first_run_dialog()
            return
        self.bus.set(NaviState.ERROR)
        self._chat.set_status("error")
        self._chat.show_error(message)
        if not self._chat.isVisible():
            self._chat.show()

    def _show_first_run_dialog(self) -> None:
        dlg = FirstRunDialog(self)
        if dlg.exec() == FirstRunDialog.DialogCode.Accepted:
            chosen = dlg.persist_choice()
            if chosen is not None:
                self._settings = load_settings()
                self._chat.set_status("loading model…")
                self._chat.enable_input(False)
                self._setup_brain()
        else:
            self.close()

    def _summon_chat(self) -> None:
        """Show + focus chat (used by global hotkey + tray click)."""
        self.show()
        self.raise_()
        if not self._chat.isVisible():
            self._chat.show()
        self._chat.raise_()
        self._chat.activateWindow()

    # --- voice helpers -----------------------------------------------------
    def _collect_assistant_token(self, token: str) -> None:
        self._brain_response_buffer.append(token)

    def _speak_response(self) -> None:
        text = "".join(self._brain_response_buffer).strip()
        self._brain_response_buffer = []
        if text and self._voice.enabled:
            self._voice.speak(text)

    def _on_transcribed(self, text: str) -> None:
        """User pressed PTT and the transcription came back."""
        if not text:
            return
        self._chat.show()
        self._chat.raise_()
        self._chat.append_user(text)
        # Route via the chat's signal so submit runs on the brain QThread
        # (queued connection) rather than blocking the GUI thread. Same
        # reasoning as dropEvent.
        self.bus.set(NaviState.THINKING)
        self._chat.submitted.emit(text)

    def _toggle_voice(self) -> None:
        new_enabled = not self._voice.enabled
        self._voice.set_enabled(new_enabled)
        self._settings.setdefault("voice", {})["enabled"] = new_enabled
        save_settings(self._settings)
        self._chat.show_system_note(
            "🔊 voice on — push Ctrl+Alt+Space to talk"
            if new_enabled
            else "🔇 voice off"
        )
        # Audible confirmation so the user knows TTS is working
        if new_enabled:
            self._voice.speak("Voice enabled.")

    # --- shutdown -----------------------------------------------------------
    def _quit_app(self) -> None:
        # PetWindow uses Qt.Tool, which setQuitOnLastWindowClosed ignores —
        # so closing it isn't enough to exit. Close (running cleanup) then quit.
        self._tray.hide()
        self.close()
        QApplication.quit()

    def closeEvent(self, event):  # type: ignore[no-untyped-def]
        try:
            self._settings.setdefault("ui", {})["windowPosition"] = [
                int(self.pos().x()),
                int(self.pos().y()),
            ]
            save_settings(self._settings)
        except Exception:
            pass
        if hasattr(self, "_hotkey"):
            try:
                self._hotkey.stop()
            except Exception:
                pass
        if hasattr(self, "_voice"):
            # Best-effort: a TTS engine that's hung in runAndWait can
            # raise here, but we MUST continue so the keyboard library's
            # PTT hook gets uninstalled by VoiceManager.shutdown's
            # finally chain — leaving a global hook installed after
            # Navi exits would intercept keystrokes for any other app.
            try:
                self._voice.shutdown()
            except Exception:
                pass
        # Flush chat-window HTML history (atomic write) so anything the
        # user can see in the chat panel survives the quit.
        try:
            self._chat._save_history()  # noqa: SLF001
        except Exception:
            pass
        if self._brain is not None and self._brain_thread is not None:
            self._brain.cancel()
            # Flush brain history so a mid-turn quit doesn't lose the
            # last assistant message. Atomic write — durable to a kill
            # immediately after this returns.
            try:
                self._brain._save_history_file()  # noqa: SLF001
            except Exception:
                pass
            # Shut down the LLM subprocess so it doesn't outlive the GUI.
            if self._brain._llm is not None and hasattr(self._brain._llm, "close"):
                try:
                    self._brain._llm.close()
                except Exception:
                    pass
            self._chat.close()
            self._brain_thread.quit()
            self._brain_thread.wait(3000)
        # Tear down the image subprocess too (lazy-spawned; may not exist).
        try:
            from navi.image.client import reset_image_client
            reset_image_client()
        except Exception:
            pass
        super().closeEvent(event)
