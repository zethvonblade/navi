from __future__ import annotations

import json
import time
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from navi.perms.audit import audit_path

_DARK_QSS = """
QDialog { background: #161616; color: #e8e8e8; }
QPlainTextEdit {
    background: #0e0e0e;
    color: #e8e8e8;
    border: 1px solid #2a2a2a;
    border-radius: 4px;
    padding: 8px;
    selection-background-color: #2c5fc9;
}
QPushButton {
    background: #2a2a2a;
    color: #e8e8e8;
    padding: 6px 14px;
    border: 1px solid #3a3a3a;
    border-radius: 4px;
}
QPushButton:hover { background: #353535; }
QLabel { color: #888; padding: 0 4px; }
"""

_DECISION_COLORS = {
    "allowed": "#888",
    "user-allowed": "#10B981",
    "denied": "#EF4444",
    "user-denied": "#EF4444",
    "unknown": "#F59E0B",
}


class AuditViewer(QDialog):
    """Show entries from %APPDATA%/Navi/audit.jsonl (most recent first)."""

    def __init__(self, parent: QWidget | None = None, max_entries: int = 200) -> None:
        super().__init__(parent)
        self.setWindowTitle("Navi — activity log")
        self.resize(820, 540)
        self.setStyleSheet(_DARK_QSS)
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)

        self._max_entries = max_entries

        self._info = QLabel("")
        self._info.setStyleSheet("QLabel { color: #888; font-size: 11px; }")

        self._view = QPlainTextEdit(self)
        self._view.setReadOnly(True)
        font = QFont("Cascadia Mono")
        if not font.exactMatch():
            font.setFamily("Consolas")
        font.setPointSize(9)
        self._view.setFont(font)

        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self.reload)
        open_dir = QPushButton("Open log folder")
        open_dir.clicked.connect(self._open_log_folder)
        buttons = QDialogButtonBox(self)
        close_btn = buttons.addButton("Close", QDialogButtonBox.ButtonRole.RejectRole)
        buttons.rejected.connect(self.reject)

        top = QHBoxLayout()
        top.addWidget(self._info, 1)
        top.addWidget(open_dir)
        top.addWidget(refresh)

        bottom = QHBoxLayout()
        bottom.addStretch()
        bottom.addWidget(buttons)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 12)
        layout.setSpacing(8)
        layout.addLayout(top)
        layout.addWidget(self._view, 1)
        layout.addLayout(bottom)

        self.reload()

    # --- public ------------------------------------------------------------
    def reload(self) -> None:
        path = audit_path()
        if not path.exists():
            self._view.setPlainText("(no audit log yet — call a tool first)")
            self._info.setText(f"{path}")
            return

        entries = self._read_entries(path)
        rendered = self._render_html(entries[: self._max_entries])

        self._info.setText(f"{path}  ·  showing {len(entries[: self._max_entries])} of {len(entries)} entries")

        # Use HTML so we get colored decision tags. The colors render in
        # QPlainTextEdit's HTML mode via setHtml… actually QPlainTextEdit
        # doesn't render HTML. Switch to plain-formatted text but keep the
        # output structured.
        self._view.setPlainText(self._render_plaintext(entries[: self._max_entries]))

    # --- helpers -----------------------------------------------------------
    @staticmethod
    def _read_entries(path: Path) -> list[dict]:
        out: list[dict] = []
        try:
            with path.open("r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        out.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        except OSError:
            pass
        out.reverse()  # most recent first
        return out

    @staticmethod
    def _render_plaintext(entries: list[dict]) -> str:
        if not entries:
            return "(no entries)"
        lines: list[str] = []
        for e in entries:
            iso = e.get("iso") or time.strftime(
                "%Y-%m-%dT%H:%M:%S", time.localtime(e.get("ts", 0))
            )
            tool = e.get("tool", "?")
            risk = e.get("risk", "?")
            decision = e.get("decision", "?")
            args = e.get("args", {})
            args_str = ", ".join(f"{k}={v!r}" for k, v in args.items()) if args else ""
            head = f"[{iso}]  {decision:<14}  {tool}({args_str})  risk={risk}"
            lines.append(head)
            preview = e.get("result_preview")
            if preview:
                # indent preview
                for ln in str(preview).splitlines():
                    lines.append(f"    {ln}")
            error = e.get("error")
            if error:
                lines.append(f"    ERROR: {error}")
            lines.append("")
        return "\n".join(lines).rstrip()

    @staticmethod
    def _render_html(entries: list[dict]) -> str:
        # Reserved for future: render with color via QTextEdit (not used by
        # the QPlainTextEdit currently in use).
        return ""

    def _open_log_folder(self) -> None:
        import os
        import subprocess
        path = audit_path().parent
        try:
            os.startfile(str(path))
        except OSError:
            subprocess.Popen(["explorer", str(path)])
