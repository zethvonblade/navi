"""Skin Creator — visual builder for custom orb skins.

A QDialog with three columns:

* **Left:**   skin name + 6 palette colour swatches + Save / Cancel
* **Centre:** live preview of the orb (cycles through every state)
* **Right:**  scrollable layer list — each layer has a checkbox to
              include it, plus the 2–4 most useful parameter knobs

When you Save:

1. A ``compose(...)`` Python file is generated and written to
   ``%APPDATA%/Navi/skins/<name>.py``.
2. ``reload_skins()`` re-runs the discovery scan.
3. The orb switches to the new skin.

The generated file is plain Python — open it any time to fine-tune
parameters that aren't in the UI, or refactor with imperative paint code.
"""

from __future__ import annotations

import dataclasses
import re
from collections.abc import Callable
from typing import Any

from PySide6.QtCore import QPointF, QSize, Qt, QTimer
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import (
    QCheckBox,
    QColorDialog,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFormLayout,
    QFrame,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from navi.pet.skins import REGISTRY, get_skin, reload_skins
from navi.pet.skins._base import PaintContext
from navi.pet.skins._paths import user_skins_dir
from navi.pet.skins.kit import compose, layer
from navi.pet.state import NaviState

# ---------------------------------------------------------------------------
# Layer catalogue — what to show in the right column.
# Order = display order. Each entry: (label, layer factory class, default-on,
# field whitelist for the param panel).
# ---------------------------------------------------------------------------

_NAMED_COLORS = [
    "state", "blue", "cyan", "violet", "gold", "rose",
    "emerald", "amber", "crimson", "white",
    "deep_void", "deep_indigo", "deep_violet", "deep_teal",
]

# Fields exposed in the UI per layer. Other fields stay at their dataclass
# defaults (and the user can edit the saved .py to override them).
_LAYER_CATALOG: list[tuple[str, type, bool, list[str]]] = [
    ("Halo",           layer.halo,              True,  ["scale", "intensity", "color"]),
    ("Void body",      layer.void_body,         True,  ["radius_frac", "top_color", "bottom_color", "rim", "rim_color"]),
    ("Drifting clouds", layer.clouds,           False, ["n", "drift_speed", "color", "intensity"]),
    ("Embers",         layer.embers,            False, ["n", "drift_speed", "size", "color"]),
    ("Light column",   layer.light_column,      False, ["width_frac", "color", "track_cursor", "bead"]),
    ("Rune ring",      layer.rune_ring,         True,  ["radius_frac", "rotation_speed", "n_marks", "accent_every", "color"]),
    ("Hairline ring",  layer.hairline_ring,     False, ["radius_frac", "alpha", "color"]),
    ("Glyph ring",     layer.glyph_ring,        False, ["radius_frac", "n", "rotation_speed", "color"]),
    ("Hexagram",       layer.hexagram,          False, ["radius_frac", "rotation_speed", "color", "glow"]),
    ("Bright core",    layer.bright_core,       True,  ["size_frac", "track_cursor", "color"]),
    ("Crosshair",      layer.crosshair,         False, ["length_frac", "track_cursor", "color"]),
    ("Listening ripples", layer.listening_ripples, True, ["radius_frac", "color"]),
    ("Thinking arc",   layer.thinking_arc,      True,  ["radius_frac", "speed_deg", "color"]),
    ("Speaking bars",  layer.speaking_bars,     True,  ["n", "amplitude_frac", "color"]),
    ("Status label",   layer.status_label,      False, ["color", "size_frac"]),
]

_DEFAULT_PALETTE: dict[NaviState, str] = {
    NaviState.IDLE: "#5FA8FF",
    NaviState.LISTENING: "#5FE0B0",
    NaviState.THINKING: "#A98BFF",
    NaviState.SPEAKING: "#F0C060",
    NaviState.ASKING: "#FFB870",
    NaviState.ERROR: "#E55060",
}


# ---------------------------------------------------------------------------
# Helper widgets
# ---------------------------------------------------------------------------


class _ColorSwatch(QPushButton):
    """A clickable color swatch that opens QColorDialog."""

    def __init__(self, color: str, label: str = "", parent: QWidget | None = None):
        super().__init__(parent)
        self._label = label
        self.setFixedSize(58, 28)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._color = QColor(color)
        self._refresh()
        self.clicked.connect(self._pick)

    def color(self) -> QColor:
        return QColor(self._color)

    def hex(self) -> str:
        return self._color.name()

    def set_color(self, c: QColor | str) -> None:
        self._color = QColor(c)
        self._refresh()

    def _refresh(self) -> None:
        self.setStyleSheet(
            f"background-color: {self._color.name()};"
            "border: 1px solid #333; border-radius: 4px;"
        )
        self.setText("")

    def _pick(self) -> None:
        dlg = QColorDialog(self._color, self)
        dlg.setWindowTitle(f"Pick {self._label}" if self._label else "Pick color")
        if dlg.exec() == QColorDialog.DialogCode.Accepted:
            self.set_color(dlg.selectedColor())
            self.window().findChild(_PreviewOrb).request_rebuild()  # type: ignore[union-attr]


class _ColorSpecCombo(QWidget):
    """Combo of named colors + 'custom...' that opens QColorDialog.

    Stored value is whatever you'd write in compose() — either one of the
    named strings ("state", "gold", ...) or a "#RRGGBB" hex string.
    """

    def __init__(self, value: Any, on_change: Callable[[], None], parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        self._on_change = on_change
        self._combo = QComboBox()
        self._combo.addItems([*_NAMED_COLORS, "custom…"])
        self._swatch = QPushButton()
        self._swatch.setFixedSize(20, 20)
        self._swatch.setCursor(Qt.CursorShape.PointingHandCursor)
        self._swatch.clicked.connect(self._pick_custom)
        layout.addWidget(self._combo, 1)
        layout.addWidget(self._swatch, 0)
        self._set_value(value)
        self._combo.currentTextChanged.connect(self._on_combo_changed)

    def _set_value(self, value: Any) -> None:
        if isinstance(value, QColor):
            self._value = value.name()
        else:
            self._value = str(value) if value is not None else "state"
        if self._value in _NAMED_COLORS:
            self._combo.setCurrentText(self._value)
        else:
            self._combo.setCurrentText("custom…")
        self._update_swatch()

    def value(self) -> str:
        return self._value

    def _on_combo_changed(self, text: str) -> None:
        if text == "custom…":
            self._pick_custom()
        else:
            self._value = text
            self._update_swatch()
            self._on_change()

    def _pick_custom(self) -> None:
        start = QColor(self._value if self._value.startswith("#") else "#5FA8FF")
        c = QColorDialog.getColor(start, self, "Pick color")
        if c.isValid():
            self._value = c.name()
            self._update_swatch()
            self._on_change()

    def _update_swatch(self) -> None:
        from navi.pet.skins.kit import _NAMED_COLORS as KIT_NAMED
        if self._value in KIT_NAMED:
            qc = KIT_NAMED[self._value]
        elif self._value == "state":
            qc = QColor("#888")
        elif self._value.startswith("#"):
            qc = QColor(self._value)
        else:
            qc = QColor("#888")
        self._swatch.setStyleSheet(
            f"background-color: {qc.name()};"
            "border: 1px solid #333; border-radius: 3px;"
        )


# ---------------------------------------------------------------------------
# Layer card — checkbox to enable + collapsible param panel
# ---------------------------------------------------------------------------


class _LayerCard(QGroupBox):
    """One layer's controls. Holds a layer instance and exposes a getter
    for its current state and a toggle for whether it's included."""

    def __init__(
        self,
        label: str,
        layer_cls: type,
        default_on: bool,
        fields: list[str],
        on_change: Callable[[], None],
        parent: QWidget | None = None,
    ):
        super().__init__(label, parent)
        self.setCheckable(True)
        self.setChecked(default_on)
        self.toggled.connect(lambda _on: on_change())
        self._on_change = on_change
        self._layer_cls = layer_cls
        self._fields = fields
        self._instance = layer_cls()  # holds current values
        self._editors: dict[str, QWidget] = {}

        form = QFormLayout(self)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        form.setContentsMargins(8, 6, 8, 8)
        form.setSpacing(4)

        for fname in fields:
            field = next(
                (f for f in dataclasses.fields(layer_cls) if f.name == fname),
                None,
            )
            if field is None:
                continue
            current = getattr(self._instance, fname)
            editor = self._make_editor(field, current)
            if editor is not None:
                self._editors[fname] = editor
                form.addRow(fname.replace("_", " ") + ":", editor)

    def _make_editor(self, field, value) -> QWidget | None:
        ftype = field.type
        # Color spec — string union or QColor
        if field.name in (
            "color", "top_color", "bottom_color", "rim_color", "bright_color",
        ):
            ed = _ColorSpecCombo(value, self._on_change)
            return ed
        if ftype is bool or isinstance(value, bool):
            ed = QCheckBox()
            ed.setChecked(bool(value))
            ed.toggled.connect(lambda _v: self._on_change())
            return ed
        if ftype is int or isinstance(value, int):
            ed = QSpinBox()
            ed.setRange(0, 9999)
            ed.setValue(int(value))
            ed.valueChanged.connect(lambda _v: self._on_change())
            return ed
        if ftype is float or isinstance(value, float):
            ed = QDoubleSpinBox()
            ed.setRange(-100.0, 100.0)
            ed.setSingleStep(0.05)
            ed.setDecimals(3)
            ed.setValue(float(value))
            ed.valueChanged.connect(lambda _v: self._on_change())
            return ed
        return None

    def is_enabled(self) -> bool:
        return self.isChecked()

    def values(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for fname, ed in self._editors.items():
            if isinstance(ed, _ColorSpecCombo):
                out[fname] = ed.value()
            elif isinstance(ed, QCheckBox):
                out[fname] = ed.isChecked()
            elif isinstance(ed, QSpinBox):
                out[fname] = ed.value()
            elif isinstance(ed, QDoubleSpinBox):
                out[fname] = ed.value()
        return out

    def build_layer(self):
        return self._layer_cls(**self.values())


# ---------------------------------------------------------------------------
# Live preview widget — a mini orb driven by the current edit state
# ---------------------------------------------------------------------------


class _PreviewOrb(QWidget):
    """Renders an in-progress skin via the current layer cards and palette.

    Cycles automatically through every NaviState (2 sec each) so the user
    can see how each state looks. A click pauses cycling and lets you pick
    a state from the dropdown.
    """

    def __init__(
        self,
        cards_provider: Callable[[], list[_LayerCard]],
        palette_provider: Callable[[], dict[NaviState, str]],
        parent: QWidget | None = None,
    ):
        super().__init__(parent)
        self._cards_provider = cards_provider
        self._palette_provider = palette_provider
        self.setMinimumSize(220, 220)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.setFixedSize(240, 240)

        self._t = 0.0
        self._dt = 1.0 / 60.0
        self._state = NaviState.IDLE
        self._auto_cycle = True
        self._cycle_period = 2.0  # seconds per state
        self._ripples: list[float] = []
        self._last_ripple = -1.0
        self._pupil_x = 0.0
        self._pupil_y = 0.0

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(16)

    def set_state(self, state: NaviState) -> None:
        self._state = state
        self._auto_cycle = False
        self.update()

    def resume_cycle(self) -> None:
        self._auto_cycle = True
        self.update()

    def request_rebuild(self) -> None:
        self.update()

    def _tick(self) -> None:
        self._t += self._dt
        if self._auto_cycle:
            states = list(NaviState)
            idx = int(self._t / self._cycle_period) % len(states)
            new_state = states[idx]
            if new_state is not self._state:
                self._state = new_state
                if new_state is NaviState.LISTENING:
                    self._ripples.clear()
                    self._last_ripple = self._t
        # Simulate listening ripples
        if self._state is NaviState.LISTENING:
            if self._t - self._last_ripple > 0.8:
                self._ripples.append(self._t)
                self._last_ripple = self._t
        self._ripples = [b for b in self._ripples if self._t - b < 1.2]
        self.update()

    def paintEvent(self, _evt) -> None:  # type: ignore[no-untyped-def]
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)

        # Backdrop — soft dark so colors read correctly
        p.fillRect(self.rect(), QColor("#0c0c14"))

        # Build live skin from cards + palette
        try:
            cards = self._cards_provider()
            palette_spec = self._palette_provider()
            layers = [c.build_layer() for c in cards if c.is_enabled()]
            from navi.pet.skins.kit import _resolve_palette
            palette = _resolve_palette(palette_spec)
        except Exception:
            return

        ctx = PaintContext(
            painter=p, rect=self.rect(),
            state=self._state, t=self._t,
            pupil_x=self._pupil_x, pupil_y=self._pupil_y,
            ripples=list(self._ripples),
        )
        for L in layers:
            try:
                L.draw(ctx, self._state, palette)
            except Exception:
                # one bad layer shouldn't break the preview
                continue

        # State badge in the top-left
        p.setPen(QColor("#bbb"))
        from PySide6.QtGui import QFont
        f = QFont("Consolas", 8)
        f.setBold(True)
        p.setFont(f)
        label = self._state.name + ("  ▶" if self._auto_cycle else "")
        p.drawText(self.rect().adjusted(8, 4, -8, 0),
                   int(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft),
                   label)


# ---------------------------------------------------------------------------
# Main dialog
# ---------------------------------------------------------------------------


class SkinCreatorDialog(QDialog):
    """Visual builder for custom skins."""

    def __init__(self, parent: QWidget | None = None):
        super().__init__(parent)
        self.setWindowTitle("Skin Creator")
        self.resize(900, 640)
        self._saved_name: str | None = None  # set on successful save
        self._build_ui()

    # --- public ---------------------------------------------------------
    def saved_skin_name(self) -> str | None:
        return self._saved_name

    # --- UI -------------------------------------------------------------
    def _build_ui(self) -> None:
        root = QHBoxLayout(self)
        root.setSpacing(10)

        # Left column ----------------------------------------------------
        left = QVBoxLayout()
        left.setSpacing(8)

        name_box = QGroupBox("Skin")
        name_form = QFormLayout(name_box)
        self._name_edit = QLineEdit()
        self._name_edit.setPlaceholderText("e.g. my_orb")
        name_form.addRow("Name:", self._name_edit)
        self._desc_edit = QLineEdit()
        self._desc_edit.setPlaceholderText("(optional one-liner)")
        name_form.addRow("Description:", self._desc_edit)
        left.addWidget(name_box)

        palette_box = QGroupBox("Palette (per state)")
        palette_layout = QVBoxLayout(palette_box)
        palette_layout.setSpacing(4)
        self._palette_swatches: dict[NaviState, _ColorSwatch] = {}
        for state, hex_default in _DEFAULT_PALETTE.items():
            row = QHBoxLayout()
            lbl = QLabel(state.name.title())
            lbl.setMinimumWidth(80)
            sw = _ColorSwatch(hex_default, label=state.name.lower())
            self._palette_swatches[state] = sw
            row.addWidget(lbl)
            row.addWidget(sw)
            row.addStretch(1)
            palette_layout.addLayout(row)
        left.addWidget(palette_box)

        # State preview selector
        state_box = QGroupBox("Preview state")
        state_layout = QHBoxLayout(state_box)
        self._state_combo = QComboBox()
        self._state_combo.addItem("auto cycle", None)
        for s in NaviState:
            self._state_combo.addItem(s.name.title(), s)
        self._state_combo.currentIndexChanged.connect(self._on_state_pick)
        state_layout.addWidget(self._state_combo)
        left.addWidget(state_box)

        left.addStretch(1)

        # Save / Cancel buttons
        btns = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save
            | QDialogButtonBox.StandardButton.Cancel
        )
        btns.button(QDialogButtonBox.StandardButton.Save).setText("Save && Apply")
        btns.accepted.connect(self._save)
        btns.rejected.connect(self.reject)
        left.addWidget(btns)

        # Centre column --------------------------------------------------
        centre = QVBoxLayout()
        centre.setAlignment(Qt.AlignmentFlag.AlignTop)
        self._preview = _PreviewOrb(
            cards_provider=self._enabled_cards,
            palette_provider=self._palette_spec,
            parent=self,
        )
        preview_frame = QFrame()
        preview_frame.setObjectName("previewFrame")
        preview_frame.setStyleSheet(
            "#previewFrame { border: 1px solid #333; border-radius: 8px; "
            "background: #0c0c14; }"
        )
        pf_lay = QVBoxLayout(preview_frame)
        pf_lay.setContentsMargins(2, 2, 2, 2)
        pf_lay.addWidget(self._preview)
        centre.addWidget(preview_frame, alignment=Qt.AlignmentFlag.AlignCenter)
        hint = QLabel("preview cycles every 2s — pick a state on the left to pin it")
        hint.setStyleSheet("color: #888; font-size: 10px;")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        centre.addWidget(hint)
        centre.addStretch(1)

        # Right column ---------------------------------------------------
        right_label = QLabel("Layers (drawn top-to-bottom)")
        right_label.setStyleSheet("font-weight: bold;")

        right_scroll = QScrollArea()
        right_scroll.setWidgetResizable(True)
        right_inner = QWidget()
        right_layout = QVBoxLayout(right_inner)
        right_layout.setSpacing(6)
        right_layout.setContentsMargins(4, 4, 4, 4)

        self._cards: list[_LayerCard] = []
        for label, cls, default_on, fields in _LAYER_CATALOG:
            card = _LayerCard(
                label, cls, default_on, fields,
                on_change=self._preview.request_rebuild,
                parent=right_inner,
            )
            self._cards.append(card)
            right_layout.addWidget(card)
        right_layout.addStretch(1)
        right_scroll.setWidget(right_inner)

        right_col = QVBoxLayout()
        right_col.addWidget(right_label)
        right_col.addWidget(right_scroll, 1)

        # Stitch ---------------------------------------------------------
        root.addLayout(left, 0)
        root.addLayout(centre, 0)
        root.addLayout(right_col, 1)

        # Live preview also updates whenever a swatch changes — wire here
        # so we don't have to plumb through _ColorSwatch's parent traversal.
        for sw in self._palette_swatches.values():
            sw.clicked.connect(self._preview.request_rebuild)

    # --- callbacks ------------------------------------------------------
    def _on_state_pick(self, _idx: int) -> None:
        state = self._state_combo.currentData()
        if state is None:
            self._preview.resume_cycle()
        else:
            self._preview.set_state(state)

    def _enabled_cards(self) -> list[_LayerCard]:
        return self._cards

    def _palette_spec(self) -> dict[NaviState, str]:
        return {s: sw.hex() for s, sw in self._palette_swatches.items()}

    # --- save -----------------------------------------------------------
    def _save(self) -> None:
        raw_name = self._name_edit.text().strip()
        if not raw_name:
            QMessageBox.warning(self, "Name required",
                                "Give your skin a name before saving.")
            return
        # Sanitize to a valid python identifier-ish skin name
        name = re.sub(r"[^a-z0-9_]+", "_", raw_name.lower()).strip("_")
        if not name:
            QMessageBox.warning(self, "Bad name",
                                "Use letters, digits, and underscores.")
            return
        if name in REGISTRY and name not in self._existing_user_skin_names():
            QMessageBox.warning(
                self, "Name conflicts with built-in",
                f"'{name}' is a built-in skin name. Pick another.",
            )
            return

        # Generate the .py file
        desc = self._desc_edit.text().strip() or f"Custom skin '{name}'"
        py_text = self._render_compose_py(name, desc)

        target = user_skins_dir() / f"{name}.py"
        if target.exists():
            reply = QMessageBox.question(
                self, "Overwrite?",
                f"'{name}.py' already exists. Overwrite?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if reply != QMessageBox.StandardButton.Yes:
                return
        from navi._io import atomic_write_text
        atomic_write_text(target, py_text)

        # Reload + signal back
        try:
            count, names = reload_skins()
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Reload failed", str(exc))
            return
        if name not in names:
            QMessageBox.critical(
                self, "Skin didn't load",
                f"Saved {target}\nbut it didn't appear in the registry. "
                f"Check Navi's console for the load error.",
            )
            return

        # Sanity-check the saved skin actually instantiates
        try:
            get_skin(name)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Skin failed to instantiate", str(exc))
            return

        self._saved_name = name
        self.accept()

    def _existing_user_skin_names(self) -> set[str]:
        d = user_skins_dir()
        if not d.exists():
            return set()
        return {p.stem for p in d.glob("*.py")}

    def _render_compose_py(self, name: str, description: str) -> str:
        """Generate a clean compose() .py file from the current UI state."""
        lines: list[str] = []
        lines.append(f'"""Custom skin: {name}.\n\nGenerated by Navi\'s Skin Creator. Edit freely.\n"""')
        lines.append("")
        lines.append("from navi.pet.skins.kit import compose, layer")
        lines.append("from navi.pet.state import NaviState")
        lines.append("")
        # Discover which layer factories we use
        used_factories = sorted({
            c._layer_cls.__name__
            for c in self._cards if c.is_enabled()
        })
        lines.append(f"# Layer factories used: {', '.join(used_factories)}")
        lines.append("")
        lines.append(f"_NAME = {name!r}")
        lines.append(f"_DESC = {description!r}")
        lines.append("")
        lines.append("_PALETTE = {")
        for state, sw in self._palette_swatches.items():
            lines.append(f"    NaviState.{state.name}: {sw.hex()!r},")
        lines.append("}")
        lines.append("")
        lines.append("_LAYERS = [")
        for card in self._cards:
            if not card.is_enabled():
                continue
            kwargs = card.values()
            cls_name = card._layer_cls.__name__
            kw_str = self._render_kwargs(kwargs)
            lines.append(f"    layer.{_factory_name(cls_name)}({kw_str}),")
        lines.append("]")
        lines.append("")
        lines.append("Skin = compose(name=_NAME, description=_DESC, palette=_PALETTE, layers=_LAYERS)")
        lines.append("")
        return "\n".join(lines)

    def _render_kwargs(self, kwargs: dict[str, Any]) -> str:
        parts = []
        for k, v in kwargs.items():
            parts.append(f"{k}={v!r}")
        return ", ".join(parts)


# Map dataclass class names back to their `layer.foo` factory name
_FACTORY_NAME_BY_CLASS = {
    "Halo": "halo",
    "VoidBody": "void_body",
    "Clouds": "clouds",
    "Embers": "embers",
    "LightColumn": "light_column",
    "RuneRing": "rune_ring",
    "HairlineRing": "hairline_ring",
    "GlyphRing": "glyph_ring",
    "Hexagram": "hexagram",
    "BrightCore": "bright_core",
    "Crosshair": "crosshair",
    "ListeningRipples": "listening_ripples",
    "ThinkingArc": "thinking_arc",
    "SpeakingBars": "speaking_bars",
    "StatusLabel": "status_label",
}


def _factory_name(cls_name: str) -> str:
    return _FACTORY_NAME_BY_CLASS.get(cls_name, cls_name.lower())
