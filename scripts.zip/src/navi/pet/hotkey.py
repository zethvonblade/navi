"""Global hotkey manager (Windows-only).

Uses the ``keyboard`` library (no admin required on Windows). The library's
callbacks fire on its own thread, so we re-emit a Qt signal that the GUI
thread can connect to safely.
"""

from __future__ import annotations

from PySide6.QtCore import QObject, Signal


class HotkeyManager(QObject):
    """Bridges a global hotkey to a Qt signal."""

    triggered = Signal()

    def __init__(self, hotkey: str = "ctrl+shift+space") -> None:
        super().__init__()
        self._hotkey = hotkey
        self._handle = None
        self._installed = False
        try:
            import keyboard

            # ``add_hotkey`` returns a handle we can use to remove the binding.
            # ``suppress=False`` lets the keystroke fall through to other apps.
            self._handle = keyboard.add_hotkey(hotkey, self.triggered.emit)
            self._installed = True
        except ImportError:
            pass
        except Exception:
            # Silently swallow — global hotkeys aren't critical and some
            # security software blocks low-level keyboard hooks.
            pass

    @property
    def installed(self) -> bool:
        return self._installed

    @property
    def hotkey(self) -> str:
        return self._hotkey

    def stop(self) -> None:
        if not self._installed:
            return
        try:
            import keyboard

            if self._handle is not None:
                keyboard.remove_hotkey(self._handle)
        except Exception:
            pass
        self._installed = False
