"""Friendly first-run dialog when the model file can't be found."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from navi.brain.config import default_model_path
from navi.settings.store import load as load_settings
from navi.settings.store import save as save_settings

_DARK_QSS = """
QDialog { background: #161616; color: #e8e8e8; }
QLabel { color: #e8e8e8; }
QLineEdit {
    background: #1e1e1e;
    color: #e8e8e8;
    padding: 6px 10px;
    border: 1px solid #2a2a2a;
    border-radius: 4px;
}
QPushButton {
    background: #2a2a2a;
    color: #e8e8e8;
    padding: 6px 14px;
    border: 1px solid #3a3a3a;
    border-radius: 4px;
}
QPushButton:hover { background: #353535; }
QPushButton:default { background: #3B82F6; border-color: #3B82F6; }
QPushButton:default:hover { background: #2c6ad5; }
"""


class FirstRunDialog(QDialog):
    """Shown when the LLM model file is missing.

    Lets the user point Navi at an existing GGUF anywhere on disk, with
    download instructions for the recommended models.
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Navi — set up the model")
        self.setMinimumWidth(620)
        self.setStyleSheet(_DARK_QSS)
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, True)

        expected = default_model_path()

        title = QLabel("<b>Navi can't find a language model file.</b>")
        title_font = title.font()
        title_font.setPointSizeF(title_font.pointSizeF() * 1.15)
        title.setFont(title_font)

        details = QLabel(
            f"Navi looked for:\n"
            f"<code style='background:#222;padding:2px 6px;border-radius:3px'>{expected}</code><br><br>"
            "Either drop a GGUF file at that path, or pick one from elsewhere on disk.<br><br>"
            "<b>Recommended models</b> (US-origin, commercial-clean licenses):"
            "<ul>"
            "<li><b>IBM Granite 3.1 2B Instruct</b> (Apache 2.0, ~1.5 GB) — "
            "<a href='https://huggingface.co/ibm-granite/granite-3.1-2b-instruct-GGUF' style='color:#3B82F6'>download</a></li>"
            "<li><b>Microsoft Phi-4-mini-instruct</b> (MIT, ~2.5 GB) — "
            "<a href='https://huggingface.co/bartowski/Phi-4-mini-instruct-GGUF' style='color:#3B82F6'>download</a></li>"
            "</ul>"
            "<small style='color:#888'>If huggingface.co is blocked on this network, "
            "download from a personal device and copy the .gguf to your project's "
            "<code>models/</code> folder.</small>"
        )
        details.setWordWrap(True)
        details.setOpenExternalLinks(True)

        # Path row
        self._path_edit = QLineEdit()
        self._path_edit.setPlaceholderText("Path to a .gguf file…")
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse)
        path_row = QHBoxLayout()
        path_row.addWidget(self._path_edit, 1)
        path_row.addWidget(browse)

        font = QFont("Cascadia Mono")
        if not font.exactMatch():
            font.setFamily("Consolas")
        font.setPointSize(9)
        self._path_edit.setFont(font)

        # Buttons
        buttons = QDialogButtonBox(self)
        save_btn = buttons.addButton("Save & retry", QDialogButtonBox.ButtonRole.AcceptRole)
        cancel_btn = buttons.addButton("Quit Navi", QDialogButtonBox.ButtonRole.RejectRole)
        save_btn.setDefault(True)
        save_btn.setEnabled(False)
        self._path_edit.textChanged.connect(
            lambda t: save_btn.setEnabled(bool(t.strip()))
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 18, 20, 14)
        layout.setSpacing(12)
        layout.addWidget(title)
        layout.addWidget(details)
        layout.addLayout(path_row)
        layout.addWidget(buttons)

    def _browse(self) -> None:
        path_str, _ = QFileDialog.getOpenFileName(
            self, "Choose a GGUF model file", "", "GGUF (*.gguf)"
        )
        if path_str:
            self._path_edit.setText(path_str)

    def chosen_path(self) -> str:
        return self._path_edit.text().strip()

    def persist_choice(self) -> Path | None:
        path = self.chosen_path()
        if not path:
            return None
        settings = load_settings()
        settings.setdefault("model", {})["path"] = path
        save_settings(settings)
        return Path(path)
