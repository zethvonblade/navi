from __future__ import annotations

import math

from PySide6.QtCore import QPoint, QSize, Qt, QTimer
from PySide6.QtGui import QCursor, QPainter
from PySide6.QtWidgets import QWidget

from navi.pet.skins import DEFAULT_SKIN, PaintContext, Skin, get_skin
from navi.pet.state import NaviState, StateBus


class OrbWidget(QWidget):
    """Hosts the active :class:`Skin` and feeds it shared per-frame state.

    Owns the animation timer, cursor-tracking pupil position, and ripple
    timestamps. Skins are pure renderers — they receive a :class:`PaintContext`
    via ``paint()`` and draw whatever they like.
    """

    def __init__(
        self,
        bus: StateBus,
        skin_name: str = DEFAULT_SKIN,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        # Mouse goes to the parent window so the whole area is draggable.
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)

        self.bus = bus
        self._skin: Skin = get_skin(skin_name)

        self._t = 0.0
        self._dt = 1.0 / 60.0

        self._ripples: list[float] = []
        self._last_ripple = -1.0

        # Smoothed cursor offset (relative to widget center) used by skins
        # that want a cursor-following pupil/reticle.
        self._pupil_x = 0.0
        self._pupil_y = 0.0

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(16)

    # --- size hints ---------------------------------------------------------
    def sizeHint(self) -> QSize:
        return QSize(240, 240)

    def minimumSizeHint(self) -> QSize:
        return QSize(160, 160)

    # --- public API ---------------------------------------------------------
    def set_skin(self, name: str) -> None:
        self._skin = get_skin(name)
        self.update()

    def current_skin_name(self) -> str:
        return self._skin.name

    # --- animation tick -----------------------------------------------------
    def _tick(self) -> None:
        self._t += self._dt
        if self.bus.state is NaviState.LISTENING:
            if self._t - self._last_ripple > 0.8:
                self._ripples.append(self._t)
                self._last_ripple = self._t
        self._ripples = [b for b in self._ripples if self._t - b < 1.2]

        # Update smoothed pupil offset toward cursor
        rect = self.rect()
        cx = rect.width() / 2.0
        cy = rect.height() / 2.0
        global_cursor = QCursor.pos()
        widget_origin = self.mapToGlobal(QPoint(0, 0))
        target_dx = global_cursor.x() - widget_origin.x() - cx
        target_dy = global_cursor.y() - widget_origin.y() - cy
        max_offset = min(cx, cy) * 0.18
        dist = math.hypot(target_dx, target_dy)
        if dist > max_offset and dist > 0:
            target_dx *= max_offset / dist
            target_dy *= max_offset / dist
        self._pupil_x += (target_dx - self._pupil_x) * 0.18
        self._pupil_y += (target_dy - self._pupil_y) * 0.18

        self.update()

    # --- paint --------------------------------------------------------------
    def paintEvent(self, _event) -> None:  # type: ignore[no-untyped-def]
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        ctx = PaintContext(
            painter=p,
            rect=self.rect(),
            state=self.bus.state,
            t=self._t,
            pupil_x=self._pupil_x,
            pupil_y=self._pupil_y,
            ripples=list(self._ripples),
        )
        self._skin.paint(ctx)
