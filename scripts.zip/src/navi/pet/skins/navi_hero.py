"""Navi-hero skin — anime energy-ball orb.

Design notes:
- Inspired by ``images/navi.png`` — the reference shows a spiky-haired
  hero in teal-and-red cyber armor channeling a glowing energy ball in
  one hand. We translate the ENERGY BALL itself into the orb skin.
- Molten gold/yellow core with darker amber striations.
- Crackling red plasma rim (the bright red-orange edge of the ball).
- Cool cyan-teal halo (the suit's primary color, repurposed as ambient
  glow so the ball reads against any wallpaper).
- Thin circuit-pattern lines overlay the body (echo of the suit's
  techno-trace detailing).
- Yellow-white spark embers drift upward inside the body.
- State-driven palette shifts: gold (idle), cyan (listening), amber
  (thinking), bright red (speaking), white-amber (asking), deep red
  strobe (error).
"""

from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import (
    QBrush,
    QColor,
    QConicalGradient,
    QPainterPath,
    QPen,
    QPolygonF,
    QRadialGradient,
)

from navi.pet.skins._base import PaintContext, Skin
from navi.pet.skins._colors import (
    draw_embers,
    rgba,
)
from navi.pet.state import NaviState

# --- Palette pulled from the reference art ---------------------------------
# Suit teal / cyan. The "cool" hue.
NAVI_TEAL = QColor("#2DD4D4")
NAVI_TEAL_DEEP = QColor("#0E5E5E")

# Suit red trim and the energy-ball flame edge.
NAVI_RED = QColor("#E53947")
NAVI_RED_DEEP = QColor("#7A1922")

# Energy-ball molten center: gold → amber → orange.
NAVI_GOLD = QColor("#FFE066")
NAVI_AMBER = QColor("#F5A623")
NAVI_ORANGE = QColor("#FF7A1A")

# Body interior darkness behind the molten swirl.
NAVI_DARK = QColor("#2A0E05")
NAVI_BLACK = QColor("#0A0405")


# state -> (core_bright, core_mid, rim_color)
# core_bright = inner highlight; core_mid = body fill mid-stop; rim = plasma edge
_PALETTE: dict[NaviState, tuple[QColor, QColor, QColor]] = {
    NaviState.IDLE:      (NAVI_GOLD,   NAVI_AMBER,  NAVI_ORANGE),
    NaviState.LISTENING: (QColor("#E0FFFF"), NAVI_TEAL, NAVI_TEAL_DEEP),
    NaviState.THINKING:  (NAVI_GOLD,   NAVI_AMBER,  NAVI_RED),
    NaviState.SPEAKING:  (QColor("#FFF8DC"), NAVI_ORANGE, NAVI_RED),
    NaviState.ASKING:    (QColor("#FFFFD0"), NAVI_GOLD,   NAVI_AMBER),
    NaviState.ERROR:     (QColor("#FFD0D0"), NAVI_RED,    NAVI_RED_DEEP),
}


class NaviHeroSkin(Skin):
    name = "navi-hero"
    description = (
        "Anime energy-ball orb — molten gold core, red plasma rim, teal halo, "
        "circuit-pattern accents. Inspired by images/navi.png."
    )

    def paint(self, ctx: PaintContext) -> None:
        p = ctx.painter
        rect = ctx.rect
        cx = rect.width() / 2.0
        cy = rect.height() / 2.0
        center = QPointF(cx, cy)
        max_r = min(cx, cy) - 6.0
        state = ctx.state
        bright, mid, rim = _PALETTE[state]

        # State-driven motion: speaking and error pulse fast; thinking
        # spins; listening breathes; idle slowly churns.
        breath = 1.0 + 0.030 * math.sin(ctx.t * 2 * math.pi / 3.5)
        body_r = max_r * 0.78 * breath

        intensity = 0.95
        spin = ctx.t * 0.30
        if state is NaviState.SPEAKING:
            intensity = 0.85 + 0.15 * (
                0.5 + 0.5 * math.sin(ctx.t * 2 * math.pi * 2.4)
            )
            spin = ctx.t * 0.55
        elif state is NaviState.THINKING:
            spin = ctx.t * 1.1  # noticeably faster spin
        elif state is NaviState.LISTENING:
            intensity = 0.85 + 0.15 * math.sin(ctx.t * 2 * math.pi / 1.6)
        elif state is NaviState.ASKING:
            intensity = 0.70 + 0.30 * math.sin(ctx.t * 2 * math.pi * 0.9)
        elif state is NaviState.ERROR:
            intensity = 0.50 + 0.50 * math.sin(ctx.t * 2 * math.pi * 4.0)
            spin = ctx.t * 1.8

        # ---- 1. Cool teal outer halo (the suit's color, repurposed) ------
        # Lets the warm core pop against any wallpaper without clashing.
        halo_grad = QRadialGradient(center, max_r * 1.25)
        halo_grad.setColorAt(0.0, rgba(NAVI_TEAL, int(60 * intensity)))
        halo_grad.setColorAt(0.55, rgba(NAVI_TEAL, int(20 * intensity)))
        halo_grad.setColorAt(1.0, rgba(NAVI_TEAL, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(halo_grad))
        p.drawEllipse(center, max_r * 1.25, max_r * 1.25)

        # ---- 2. Plasma flame rim — conical sweep so the rim "swirls" ----
        # This is the bright red-orange edge of the energy ball in the art.
        flame_r = body_r * 1.10
        flame_conic = QConicalGradient(center, math.degrees(-spin) % 360.0)
        flame_conic.setColorAt(0.00, rgba(rim, int(220 * intensity)))
        flame_conic.setColorAt(0.10, rgba(NAVI_GOLD, int(180 * intensity)))
        flame_conic.setColorAt(0.20, rgba(rim, int(220 * intensity)))
        flame_conic.setColorAt(0.30, rgba(NAVI_AMBER, int(180 * intensity)))
        flame_conic.setColorAt(0.50, rgba(rim, int(200 * intensity)))
        flame_conic.setColorAt(0.70, rgba(NAVI_GOLD, int(180 * intensity)))
        flame_conic.setColorAt(0.85, rgba(rim, int(220 * intensity)))
        flame_conic.setColorAt(1.00, rgba(rim, int(220 * intensity)))
        flame_pen = QPen(QBrush(flame_conic), max(2.5, max_r * 0.045))
        flame_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(flame_pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(center, flame_r, flame_r)

        # ---- 3. Molten body — dark interior + gold/amber radial fill ----
        body_grad = QRadialGradient(
            QPointF(cx - body_r * 0.25, cy - body_r * 0.30),
            body_r * 1.6,
        )
        body_grad.setColorAt(0.00, rgba(bright, 230))
        body_grad.setColorAt(0.30, rgba(mid, 230))
        body_grad.setColorAt(0.75, rgba(NAVI_DARK, 230))
        body_grad.setColorAt(1.00, rgba(NAVI_BLACK, 240))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(body_grad))
        p.drawEllipse(center, body_r, body_r)

        # ---- 4. Inner conical swirl (the spinning molten flow) ----------
        # Clip to body so the swirl doesn't leak past the rim.
        p.save()
        clip = QPainterPath()
        clip.addEllipse(center, body_r, body_r)
        p.setClipPath(clip)

        swirl = QConicalGradient(center, math.degrees(spin * 1.3) % 360.0)
        swirl.setColorAt(0.00, rgba(bright, int(160 * intensity)))
        swirl.setColorAt(0.25, rgba(mid, int(60 * intensity)))
        swirl.setColorAt(0.50, rgba(rim, int(120 * intensity)))
        swirl.setColorAt(0.75, rgba(NAVI_DARK, 0))
        swirl.setColorAt(1.00, rgba(bright, int(160 * intensity)))
        p.setBrush(QBrush(swirl))
        p.drawEllipse(center, body_r * 0.95, body_r * 0.95)

        # ---- 5. Spark embers drifting upward inside the body ------------
        # Fits the "energy crackling out of the ball" look from the art.
        draw_embers(
            p, cx, cy, body_r * 0.92, NAVI_GOLD, ctx.t,
            n=14, seed=0.0, drift_speed=0.9,
            size=1.7, alpha_max=int(220 * intensity),
        )
        # Second pass with red-orange embers, counter-seeded for variety.
        draw_embers(
            p, cx, cy, body_r * 0.92, rim, ctx.t,
            n=8, seed=2.7, drift_speed=0.7,
            size=1.4, alpha_max=int(180 * intensity),
        )
        p.restore()

        # ---- 6. Circuit-pattern accents (echo of the suit's tech trace) -
        # Thin teal lines crossing the body — eight radial spokes that
        # turn ~90° at mid-radius, mimicking the L-shaped traces on the
        # suit. Subtle, doesn't dominate.
        self._draw_circuit_traces(
            p, cx, cy, body_r, NAVI_TEAL,
            alpha=int(110 * intensity),
            phase=spin * 0.4,  # very slow rotation
        )

        # ---- 7. Listening ripples (cyan, expanding past the rim) --------
        if state is NaviState.LISTENING:
            for birth in ctx.ripples:
                progress = min((ctx.t - birth) / 1.2, 1.0)
                r = body_r + (max_r * 0.20) * progress
                alpha = int(180 * (1.0 - progress) * intensity)
                pen = QPen(rgba(NAVI_TEAL, alpha), 1.2)
                p.setPen(pen)
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawEllipse(center, r, r)

        # ---- 8. Hairline rim — crisp red edge ---------------------------
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(rgba(rim, int(200 * intensity)), 1.2))
        p.drawEllipse(center, body_r, body_r)

        # ---- 9. Bright cursor-tracking core (the "spark" the hero holds) -
        focal_x = cx + ctx.pupil_x * 0.35
        focal_y = cy + ctx.pupil_y * 0.35
        core_r = max_r * 0.12
        core_grad = QRadialGradient(
            QPointF(focal_x, focal_y), core_r * 2.6,
        )
        core_grad.setColorAt(0.00, rgba(QColor(255, 255, 255), int(240 * intensity)))
        core_grad.setColorAt(0.35, rgba(bright, int(220 * intensity)))
        core_grad.setColorAt(0.85, rgba(mid, int(80 * intensity)))
        core_grad.setColorAt(1.00, rgba(rim, 0))
        p.setBrush(QBrush(core_grad))
        p.drawEllipse(QPointF(focal_x, focal_y), core_r * 2.6, core_r * 2.6)
        # White-hot pinprick center
        p.setBrush(QBrush(rgba(QColor(255, 255, 255), int(245 * intensity))))
        p.drawEllipse(QPointF(focal_x, focal_y), core_r * 0.45, core_r * 0.45)

        # ---- 10. Speaking flame burst — short tongues from the rim ------
        if state is NaviState.SPEAKING:
            self._draw_flame_tongues(
                p, cx, cy, body_r, rim, ctx.t,
                intensity=intensity,
            )

    # --- helpers --------------------------------------------------------
    def _draw_circuit_traces(
        self,
        p,
        cx: float,
        cy: float,
        body_r: float,
        color: QColor,
        alpha: int,
        phase: float,
    ) -> None:
        """Eight L-shaped traces from rim toward center (echo of the suit)."""
        if alpha <= 4:
            return
        pen = QPen(rgba(color, alpha), 1.2)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        pen.setJoinStyle(Qt.PenJoinStyle.MiterJoin)
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        n = 8
        outer = body_r * 0.92
        elbow = body_r * 0.55
        inner = body_r * 0.30
        bend_arc = math.pi / n  # how far the trace turns at the elbow
        for i in range(n):
            base = phase + i * (2 * math.pi / n) - math.pi / 2
            # Three-segment polyline: outer point -> elbow -> inner point
            x0 = cx + math.cos(base) * outer
            y0 = cy + math.sin(base) * outer
            x1 = cx + math.cos(base) * elbow
            y1 = cy + math.sin(base) * elbow
            # Bend angle alternates direction so traces don't all curl the same way.
            bend = bend_arc if (i % 2 == 0) else -bend_arc
            x2 = cx + math.cos(base + bend) * inner
            y2 = cy + math.sin(base + bend) * inner
            p.drawLine(QPointF(x0, y0), QPointF(x1, y1))
            p.drawLine(QPointF(x1, y1), QPointF(x2, y2))
            # Small node at the inner endpoint
            p.setBrush(QBrush(rgba(color, alpha)))
            p.drawEllipse(QPointF(x2, y2), 1.4, 1.4)
            p.setBrush(Qt.BrushStyle.NoBrush)

    def _draw_flame_tongues(
        self,
        p,
        cx: float,
        cy: float,
        body_r: float,
        color: QColor,
        t: float,
        intensity: float,
    ) -> None:
        """Triangle 'flame tongues' jutting outward from the rim."""
        n = 12
        flicker_seed = t * 5.0
        for i in range(n):
            angle = i * (2 * math.pi / n) + math.sin(t * 0.9 + i) * 0.05
            flicker = 0.5 + 0.5 * math.sin(flicker_seed + i * 1.7)
            length = body_r * (0.10 + 0.14 * flicker)
            base_w = body_r * 0.05
            # Triangle tip outward, base on rim
            tip_x = cx + math.cos(angle) * (body_r + length)
            tip_y = cy + math.sin(angle) * (body_r + length)
            # Two base points perpendicular to the radial direction
            perp = angle + math.pi / 2
            bx1 = cx + math.cos(angle) * body_r + math.cos(perp) * base_w
            by1 = cy + math.sin(angle) * body_r + math.sin(perp) * base_w
            bx2 = cx + math.cos(angle) * body_r - math.cos(perp) * base_w
            by2 = cy + math.sin(angle) * body_r - math.sin(perp) * base_w
            poly = QPolygonF([
                QPointF(tip_x, tip_y),
                QPointF(bx1, by1),
                QPointF(bx2, by2),
            ])
            alpha = int(180 * intensity * flicker)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(rgba(color, alpha)))
            p.drawPolygon(poly)
