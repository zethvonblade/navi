"""Skin kit — declarative composition of skins from named layers.

Build a skin by stacking layers from bottom to top, like Photoshop or CSS::

    from navi.pet.skins.kit import compose, layer
    from navi.pet.state import NaviState

    MySkin = compose(
        name="ember_orb",
        description="dark orb with floating embers",
        palette={
            NaviState.IDLE: "blue",
            NaviState.LISTENING: "emerald",
            NaviState.THINKING: "violet",
            NaviState.SPEAKING: "gold",
            NaviState.ASKING: "amber",
            NaviState.ERROR: "crimson",
        },
        layers=[
            layer.halo(scale=1.20),
            layer.void_body(),
            layer.rune_ring(),
            layer.embers(n=14),
            layer.bright_core(),
            layer.listening_ripples(),
        ],
    )

Drop that file in ``%APPDATA%/Navi/skins/`` and the registry picks it up
automatically — no manual registration required.

Color specs
-----------
Anywhere a layer takes ``color=...``, you can pass:

* ``"state"`` — use the per-state color from your ``palette`` dict
* a named color: ``"blue"``, ``"cyan"``, ``"violet"``, ``"gold"``, ``"rose"``,
  ``"emerald"``, ``"amber"``, ``"crimson"``, ``"white"``
* a hex string ``"#RRGGBB"``
* a :class:`PySide6.QtGui.QColor` instance directly

Layer inventory
---------------
See :class:`layer` for the full list. The standard pile-up that produces
something orb-like is::

    halo  → void_body  → ring(s)  → state_effects  → bright_core
"""

from __future__ import annotations

import math
import sys
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any, ClassVar, Union

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import (
    QBrush,
    QColor,
    QConicalGradient,
    QLinearGradient,
    QPainterPath,
    QPen,
    QRadialGradient,
)

from navi.pet.skins._base import PaintContext, Skin
from navi.pet.skins._colors import (
    ARC_AMBER,
    ARC_BLUE,
    ARC_CRIMSON,
    ARC_CYAN,
    ARC_EMERALD,
    ARC_GOLD,
    ARC_ROSE,
    ARC_VIOLET,
    DEEP_INDIGO,
    DEEP_TEAL,
    DEEP_VIOLET,
    DEEP_VOID,
    draw_embers,
    draw_glyph_marks,
    draw_hexagram,
    draw_rune_ring,
    make_mono_font,
    rgba,
    soft_glow_circle,
)
from navi.pet.state import NaviState

ColorSpec = Union[str, QColor, None]

_NAMED_COLORS: dict[str, QColor] = {
    "blue": ARC_BLUE,
    "cyan": ARC_CYAN,
    "violet": ARC_VIOLET,
    "gold": ARC_GOLD,
    "rose": ARC_ROSE,
    "emerald": ARC_EMERALD,
    "amber": ARC_AMBER,
    "crimson": ARC_CRIMSON,
    "deep_void": DEEP_VOID,
    "deep_indigo": DEEP_INDIGO,
    "deep_violet": DEEP_VIOLET,
    "deep_teal": DEEP_TEAL,
    "white": QColor("#FFFFFF"),
    "black": QColor("#000000"),
}


def _resolve_color(spec: ColorSpec, state: NaviState, palette: dict[NaviState, QColor]) -> QColor:
    if spec is None or spec == "state":
        return palette[state]
    if isinstance(spec, QColor):
        return spec
    if isinstance(spec, str):
        if spec.startswith("#"):
            return QColor(spec)
        if spec in _NAMED_COLORS:
            return _NAMED_COLORS[spec]
    raise ValueError(f"unrecognized color spec: {spec!r}")


def _resolve_palette(
    palette: Mapping[NaviState, ColorSpec] | None,
) -> dict[NaviState, QColor]:
    """Normalize a palette spec into a full state→QColor map.

    Missing states fall back to the IDLE color (or ARC_BLUE if IDLE is missing).
    """
    palette = palette or {}
    base_spec = palette.get(NaviState.IDLE, "blue")
    base = _resolve_color(base_spec, NaviState.IDLE, {NaviState.IDLE: ARC_BLUE})
    out: dict[NaviState, QColor] = {}
    for s in NaviState:
        spec = palette.get(s)
        out[s] = _resolve_color(spec, s, {s: base}) if spec is not None else base
    return out


# ============================================================================
# Layers
# ============================================================================


@dataclass
class _LayerBase:
    """Base for all layers. Subclasses implement ``draw``."""

    def draw(
        self,
        ctx: PaintContext,
        state: NaviState,
        palette: dict[NaviState, QColor],
    ) -> None:
        raise NotImplementedError


# ----- Body / background ----------------------------------------------------


@dataclass
class Halo(_LayerBase):
    scale: float = 1.20
    intensity: float = 0.85
    color: ColorSpec = "state"

    def draw(self, ctx, state, palette):
        c = _resolve_color(self.color, state, palette)
        rect = ctx.rect
        cx, cy = rect.width() / 2.0, rect.height() / 2.0
        max_r = min(cx, cy) - 6.0
        center = QPointF(cx, cy)
        r = max_r * self.scale
        grad = QRadialGradient(center, r)
        grad.setColorAt(0.0, rgba(c, int(80 * self.intensity)))
        grad.setColorAt(0.55, rgba(c, int(22 * self.intensity)))
        grad.setColorAt(1.0, rgba(c, 0))
        ctx.painter.setPen(Qt.PenStyle.NoPen)
        ctx.painter.setBrush(QBrush(grad))
        ctx.painter.drawEllipse(center, r, r)


@dataclass
class VoidBody(_LayerBase):
    """Deep solid orb body with a depth gradient + thin rim."""

    radius_frac: float = 0.92
    top_color: ColorSpec = "deep_indigo"
    bottom_color: ColorSpec = "deep_void"
    rim: bool = True
    rim_color: ColorSpec = "state"
    rim_alpha: int = 140

    def draw(self, ctx, state, palette):
        rect = ctx.rect
        cx, cy = rect.width() / 2.0, rect.height() / 2.0
        max_r = min(cx, cy) - 6.0
        center = QPointF(cx, cy)
        r = max_r * self.radius_frac
        top = _resolve_color(self.top_color, state, palette)
        bot = _resolve_color(self.bottom_color, state, palette)
        grad = QRadialGradient(QPointF(cx - r * 0.30, cy - r * 0.32), r * 1.7)
        grad.setColorAt(0.00, rgba(top, 250))
        grad.setColorAt(0.50, rgba(bot, 250))
        grad.setColorAt(1.00, rgba(QColor(0, 0, 0), 250))
        p = ctx.painter
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(grad))
        p.drawEllipse(center, r, r)
        if self.rim:
            rim_c = _resolve_color(self.rim_color, state, palette)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(rgba(rim_c, self.rim_alpha), 1.0))
            p.drawEllipse(center, r, r)


@dataclass
class Clouds(_LayerBase):
    """Drifting nebula clouds clipped to a circular body."""

    n: int = 2
    radius_frac: float = 0.92
    drift_speed: float = 0.5
    color: ColorSpec = "state"
    bright_color: ColorSpec = "white"
    intensity: float = 1.0

    def draw(self, ctx, state, palette):
        rect = ctx.rect
        cx, cy = rect.width() / 2.0, rect.height() / 2.0
        center = QPointF(cx, cy)
        max_r = min(cx, cy) - 6.0
        body_r = max_r * self.radius_frac
        mid = _resolve_color(self.color, state, palette)
        bright = _resolve_color(self.bright_color, state, palette)
        p = ctx.painter
        p.save()
        clip = QPainterPath()
        clip.addEllipse(center, body_r, body_r)
        p.setClipPath(clip)
        p.setPen(Qt.PenStyle.NoPen)
        for i in range(self.n):
            phase = i * 1.7
            ox = math.sin(ctx.t * self.drift_speed * (0.30 + i * 0.15) + phase) * body_r * 0.20
            oy = math.cos(ctx.t * self.drift_speed * (0.22 + i * 0.10) + phase) * body_r * 0.16
            cc = QPointF(cx + ox, cy + oy)
            cr = body_r * (0.78 - i * 0.30)
            grad = QRadialGradient(cc, cr)
            base_a = int(140 * self.intensity * (1.0 - i * 0.25))
            grad.setColorAt(0.0, rgba(bright, int(base_a * 0.7)))
            grad.setColorAt(0.45, rgba(mid, base_a))
            grad.setColorAt(1.0, rgba(mid, 0))
            p.setBrush(QBrush(grad))
            p.drawEllipse(cc, cr, cr)
        p.restore()


@dataclass
class Embers(_LayerBase):
    """Slow-drifting ember particles inside the body."""

    n: int = 14
    radius_frac: float = 0.92
    color: ColorSpec = "state"
    drift_speed: float = 0.55
    size: float = 1.6
    alpha_max: int = 180

    def draw(self, ctx, state, palette):
        rect = ctx.rect
        cx, cy = rect.width() / 2.0, rect.height() / 2.0
        max_r = min(cx, cy) - 6.0
        c = _resolve_color(self.color, state, palette)
        draw_embers(
            ctx.painter, cx, cy, max_r * self.radius_frac, c, ctx.t,
            n=self.n, drift_speed=self.drift_speed,
            size=self.size, alpha_max=self.alpha_max,
        )


@dataclass
class LightColumn(_LayerBase):
    """Vertical luminous pillar inside the body, follows cursor on X.

    Optional bright bead rides the column on Y so vertical cursor motion
    registers too.
    """

    radius_frac: float = 0.92
    width_frac: float = 0.34
    color: ColorSpec = "state"
    track_cursor: bool = True
    bead: bool = True
    bead_size: float = 0.08

    def draw(self, ctx, state, palette):
        rect = ctx.rect
        cx, cy = rect.width() / 2.0, rect.height() / 2.0
        center = QPointF(cx, cy)
        max_r = min(cx, cy) - 6.0
        body_r = max_r * self.radius_frac
        col_w = body_r * self.width_frac
        c = _resolve_color(self.color, state, palette)
        white = QColor("#FFFFFF")

        col_x = cx + (ctx.pupil_x * 0.55 if self.track_cursor else 0.0)
        top_y = cy - body_r * 0.86
        bot_y = cy + body_r * 0.86

        p = ctx.painter
        p.save()
        clip = QPainterPath()
        clip.addEllipse(center, body_r, body_r)
        p.setClipPath(clip)

        path = QPainterPath()
        path.moveTo(col_x - col_w * 0.15, top_y)
        path.cubicTo(
            QPointF(col_x - col_w * 0.55, cy - body_r * 0.30),
            QPointF(col_x - col_w * 0.55, cy + body_r * 0.30),
            QPointF(col_x - col_w * 0.18, bot_y),
        )
        path.lineTo(col_x + col_w * 0.18, bot_y)
        path.cubicTo(
            QPointF(col_x + col_w * 0.55, cy + body_r * 0.30),
            QPointF(col_x + col_w * 0.55, cy - body_r * 0.30),
            QPointF(col_x + col_w * 0.15, top_y),
        )
        path.closeSubpath()

        col_grad = QLinearGradient(0, top_y, 0, bot_y)
        col_grad.setColorAt(0.0, rgba(c, 40))
        col_grad.setColorAt(0.45, rgba(c, 180))
        col_grad.setColorAt(0.55, rgba(white, 220))
        col_grad.setColorAt(0.65, rgba(c, 180))
        col_grad.setColorAt(1.0, rgba(c, 40))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(col_grad))
        p.drawPath(path)

        # Bright vertical centerline
        line_grad = QLinearGradient(0, top_y, 0, bot_y)
        line_grad.setColorAt(0.0, rgba(white, 0))
        line_grad.setColorAt(0.5, rgba(white, 230))
        line_grad.setColorAt(1.0, rgba(white, 0))
        line_pen = QPen(QBrush(line_grad), 1.4)
        line_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(line_pen)
        p.drawLine(QPointF(col_x, top_y), QPointF(col_x, bot_y))

        if self.bead and self.track_cursor:
            bead_y = cy + max(-body_r * 0.78, min(body_r * 0.78, ctx.pupil_y * 1.5))
            br = body_r * self.bead_size
            bead_glow = QRadialGradient(QPointF(col_x, bead_y), br * 2.6)
            bead_glow.setColorAt(0.0, rgba(white, 245))
            bead_glow.setColorAt(0.45, rgba(c, 180))
            bead_glow.setColorAt(1.0, rgba(c, 0))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QBrush(bead_glow))
            p.drawEllipse(QPointF(col_x, bead_y), br * 2.6, br * 2.6)
            p.setBrush(QBrush(rgba(white, 240)))
            p.drawEllipse(QPointF(col_x, bead_y), br * 0.55, br * 0.55)

        p.restore()


# ----- Rings ---------------------------------------------------------------


@dataclass
class RuneRing(_LayerBase):
    radius_frac: float = 0.93
    rotation_speed: float = 0.10        # radians per second
    n_marks: int = 24
    accent_every: int = 6
    color: ColorSpec = "state"
    glow: bool = True

    def draw(self, ctx, state, palette):
        rect = ctx.rect
        cx, cy = rect.width() / 2.0, rect.height() / 2.0
        center = QPointF(cx, cy)
        max_r = min(cx, cy) - 6.0
        r = max_r * self.radius_frac
        c = _resolve_color(self.color, state, palette)
        if self.glow:
            soft_glow_circle(ctx.painter, center, r, c,
                             base_alpha=140, layers=2, max_extra=2.0)
        draw_rune_ring(
            ctx.painter, center, r, c,
            n_marks=self.n_marks,
            rotation_rad=ctx.t * self.rotation_speed,
            mark_len=max_r * 0.045, mark_width=1.0,
            alpha=160, accent_every=self.accent_every,
            accent_len=max_r * 0.085, accent_alpha=220,
        )


@dataclass
class HairlineRing(_LayerBase):
    radius_frac: float = 0.70
    color: ColorSpec = "state"
    alpha: int = 130
    width: float = 0.9

    def draw(self, ctx, state, palette):
        rect = ctx.rect
        cx, cy = rect.width() / 2.0, rect.height() / 2.0
        center = QPointF(cx, cy)
        max_r = min(cx, cy) - 6.0
        c = _resolve_color(self.color, state, palette)
        ctx.painter.setBrush(Qt.BrushStyle.NoBrush)
        ctx.painter.setPen(QPen(rgba(c, self.alpha), self.width))
        ctx.painter.drawEllipse(center, max_r * self.radius_frac, max_r * self.radius_frac)


@dataclass
class GlyphRing(_LayerBase):
    radius_frac: float = 0.48
    n: int = 4
    rotation_speed: float = -0.14
    color: ColorSpec = "gold"
    size_frac: float = 0.022
    show_circle: bool = True

    def draw(self, ctx, state, palette):
        rect = ctx.rect
        cx, cy = rect.width() / 2.0, rect.height() / 2.0
        center = QPointF(cx, cy)
        max_r = min(cx, cy) - 6.0
        r = max_r * self.radius_frac
        c = _resolve_color(self.color, state, palette)
        if self.show_circle:
            ctx.painter.setBrush(Qt.BrushStyle.NoBrush)
            ctx.painter.setPen(QPen(rgba(c, 130), 0.9))
            ctx.painter.drawEllipse(center, r, r)
        draw_glyph_marks(
            ctx.painter, center, r, c,
            n=self.n,
            rotation_rad=ctx.t * self.rotation_speed,
            size=max_r * self.size_frac,
            alpha=220,
        )


@dataclass
class Hexagram(_LayerBase):
    radius_frac: float = 0.62
    rotation_speed: float = -0.16
    color: ColorSpec = "gold"
    glow: bool = True

    def draw(self, ctx, state, palette):
        rect = ctx.rect
        cx, cy = rect.width() / 2.0, rect.height() / 2.0
        center = QPointF(cx, cy)
        max_r = min(cx, cy) - 6.0
        r = max_r * self.radius_frac
        c = _resolve_color(self.color, state, palette)
        rot = ctx.t * self.rotation_speed
        if self.glow:
            draw_hexagram(ctx.painter, center, r, c, width=3.0, alpha=40, rotation_rad=rot)
        draw_hexagram(ctx.painter, center, r, c, width=1.4, alpha=200, rotation_rad=rot)


# ----- Center / tracking ---------------------------------------------------


@dataclass
class BrightCore(_LayerBase):
    """A small bright dot at the orb center, optionally cursor-tracking."""

    track_cursor: bool = True
    track_strength: float = 0.40
    size_frac: float = 0.07
    color: ColorSpec = "state"
    white_tip: bool = True

    def draw(self, ctx, state, palette):
        rect = ctx.rect
        cx, cy = rect.width() / 2.0, rect.height() / 2.0
        max_r = min(cx, cy) - 6.0
        c = _resolve_color(self.color, state, palette)
        cr = max_r * self.size_frac
        fx = cx + (ctx.pupil_x * self.track_strength if self.track_cursor else 0)
        fy = cy + (ctx.pupil_y * self.track_strength if self.track_cursor else 0)
        white = QColor("#FFFFFF")

        # bloom
        glow = QRadialGradient(QPointF(fx, fy), cr * 2.8)
        glow.setColorAt(0.0, rgba(white if self.white_tip else c, 220))
        glow.setColorAt(0.45, rgba(c, 150))
        glow.setColorAt(1.0, rgba(c, 0))
        ctx.painter.setPen(Qt.PenStyle.NoPen)
        ctx.painter.setBrush(QBrush(glow))
        ctx.painter.drawEllipse(QPointF(fx, fy), cr * 2.8, cr * 2.8)
        # bright tip
        ctx.painter.setBrush(QBrush(rgba(white if self.white_tip else c, 240)))
        ctx.painter.drawEllipse(QPointF(fx, fy), cr * 0.55, cr * 0.55)


@dataclass
class Crosshair(_LayerBase):
    track_cursor: bool = True
    track_strength: float = 0.45
    length_frac: float = 0.30
    gap_frac: float = 0.06
    color: ColorSpec = "white"
    width: float = 1.2

    def draw(self, ctx, state, palette):
        rect = ctx.rect
        cx, cy = rect.width() / 2.0, rect.height() / 2.0
        max_r = min(cx, cy) - 6.0
        c = _resolve_color(self.color, state, palette)
        rcx = cx + (ctx.pupil_x * self.track_strength if self.track_cursor else 0)
        rcy = cy + (ctx.pupil_y * self.track_strength if self.track_cursor else 0)
        L = max_r * self.length_frac
        g = max_r * self.gap_frac
        ctx.painter.setPen(QPen(rgba(c, 220), self.width))
        ctx.painter.drawLine(QPointF(rcx - L, rcy), QPointF(rcx - g, rcy))
        ctx.painter.drawLine(QPointF(rcx + g, rcy), QPointF(rcx + L, rcy))
        ctx.painter.drawLine(QPointF(rcx, rcy - L), QPointF(rcx, rcy - g))
        ctx.painter.drawLine(QPointF(rcx, rcy + g), QPointF(rcx, rcy + L))


# ----- State-conditional layers --------------------------------------------


@dataclass
class ListeningRipples(_LayerBase):
    radius_frac: float = 0.78
    color: ColorSpec = "state"
    width: float = 1.0

    def draw(self, ctx, state, palette):
        if state is not NaviState.LISTENING and not ctx.ripples:
            return
        rect = ctx.rect
        cx, cy = rect.width() / 2.0, rect.height() / 2.0
        center = QPointF(cx, cy)
        max_r = min(cx, cy) - 6.0
        c = _resolve_color(self.color, state, palette)
        base_r = max_r * self.radius_frac
        for birth in ctx.ripples:
            progress = min((ctx.t - birth) / 1.2, 1.0)
            r = base_r + (max_r * 0.20) * progress
            alpha = int(180 * (1.0 - progress))
            pen = QPen(rgba(c, alpha), self.width)
            ctx.painter.setPen(pen)
            ctx.painter.setBrush(Qt.BrushStyle.NoBrush)
            ctx.painter.drawEllipse(center, r, r)


@dataclass
class ThinkingArc(_LayerBase):
    radius_frac: float = 0.78
    speed_deg: float = 55.0
    arc_len_deg: float = 18.0
    color: ColorSpec = "state"
    width: float = 1.6

    def draw(self, ctx, state, palette):
        if state is not NaviState.THINKING:
            return
        rect = ctx.rect
        cx, cy = rect.width() / 2.0, rect.height() / 2.0
        center = QPointF(cx, cy)
        max_r = min(cx, cy) - 6.0
        c = _resolve_color(self.color, state, palette)
        rot_deg = (ctx.t * self.speed_deg) % 360.0
        grad = QConicalGradient(center, -rot_deg)
        grad.setColorAt(0.00, rgba(c, 0))
        grad.setColorAt(self.arc_len_deg / 360.0 * 0.5, rgba(c, 220))
        grad.setColorAt(self.arc_len_deg / 360.0, rgba(c, 0))
        grad.setColorAt(1.00, rgba(c, 0))
        pen = QPen(QBrush(grad), self.width)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        ctx.painter.setPen(pen)
        ctx.painter.setBrush(Qt.BrushStyle.NoBrush)
        r = max_r * self.radius_frac
        ctx.painter.drawEllipse(center, r, r)


@dataclass
class SpeakingBars(_LayerBase):
    n: int = 9
    spread_frac: float = 0.65
    base_y_frac: float = 0.55
    amplitude_frac: float = 0.10
    color: ColorSpec = "state"
    width: float = 1.6

    def draw(self, ctx, state, palette):
        if state is not NaviState.SPEAKING:
            return
        rect = ctx.rect
        cx, cy = rect.width() / 2.0, rect.height() / 2.0
        max_r = min(cx, cy) - 6.0
        c = _resolve_color(self.color, state, palette)
        spread = max_r * self.spread_frac
        base_y = cy + max_r * self.base_y_frac
        pen = QPen(rgba(c, 230), self.width)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        ctx.painter.setPen(pen)
        for i in range(self.n):
            x = cx - spread / 2 + (i / (self.n - 1)) * spread
            amp = max_r * self.amplitude_frac * (
                0.4 + 0.6 * abs(math.sin(ctx.t * 5.0 + i * 0.55))
            )
            ctx.painter.drawLine(
                QPointF(x, base_y - amp / 2),
                QPointF(x, base_y + amp / 2),
            )


@dataclass
class StatusLabel(_LayerBase):
    """Small text label at the bottom of the orb, one word per state."""

    labels: dict[NaviState, str] | None = None
    color: ColorSpec = "gold"
    size_frac: float = 0.072
    spacing_pct: float = 180.0
    y_frac: float = 0.78

    _DEFAULT_LABELS: ClassVar[dict[NaviState, str]] = {
        NaviState.IDLE: "STANDBY",
        NaviState.LISTENING: "LISTEN",
        NaviState.THINKING: "DIVINE",
        NaviState.SPEAKING: "SPEAK",
        NaviState.ASKING: "AWAIT",
        NaviState.ERROR: "WARD",
    }

    def draw(self, ctx, state, palette):
        rect = ctx.rect
        cx, cy = rect.width() / 2.0, rect.height() / 2.0
        max_r = min(cx, cy) - 6.0
        c = _resolve_color(self.color, state, palette)
        text = (self.labels or self._DEFAULT_LABELS).get(state, "")
        if not text:
            return
        font = make_mono_font(max(7.0, max_r * self.size_frac),
                              spacing_pct=self.spacing_pct, bold=True)
        ctx.painter.setFont(font)
        ctx.painter.setPen(QPen(rgba(c, 200)))
        text_y = cy + max_r * self.y_frac
        text_rect = QRectF(0, text_y, rect.width(), max_r * 0.16)
        ctx.painter.drawText(text_rect, int(Qt.AlignmentFlag.AlignCenter), text)


# ============================================================================
# Layer namespace — `layer.halo(...)`, `layer.rune_ring(...)`, etc.
# ============================================================================


class layer:
    """Factory namespace for the built-in layers.

    Each method returns a layer instance ready to drop into ``compose(layers=[...])``.
    Type-checked dataclass kwargs — your IDE will autocomplete the params.
    """
    halo = Halo
    void_body = VoidBody
    clouds = Clouds
    embers = Embers
    light_column = LightColumn
    rune_ring = RuneRing
    hairline_ring = HairlineRing
    glyph_ring = GlyphRing
    hexagram = Hexagram
    bright_core = BrightCore
    crosshair = Crosshair
    listening_ripples = ListeningRipples
    thinking_arc = ThinkingArc
    speaking_bars = SpeakingBars
    status_label = StatusLabel


# ============================================================================
# compose() — build a Skin subclass from a layer stack
# ============================================================================


def compose(
    *,
    name: str,
    description: str = "",
    palette: Mapping[NaviState, ColorSpec] | None = None,
    layers: Sequence[_LayerBase] = (),
) -> type[Skin]:
    """Synthesize a :class:`Skin` subclass from a stack of layers.

    Layers are drawn bottom-up in the order given. Each layer pulls the
    state's color from ``palette`` whenever it sees ``color="state"``.
    """
    resolved_palette = _resolve_palette(palette)
    layer_stack: tuple[_LayerBase, ...] = tuple(layers)
    skin_name = name
    skin_desc = description

    class _ComposedSkin(Skin):
        name: ClassVar[str] = skin_name
        description: ClassVar[str] = skin_desc
        _palette: ClassVar[dict[NaviState, QColor]] = resolved_palette
        _layers: ClassVar[tuple[_LayerBase, ...]] = layer_stack

        def paint(self, ctx: PaintContext) -> None:
            for L in self._layers:
                L.draw(ctx, ctx.state, self._palette)

    _ComposedSkin.__name__ = f"{name.title().replace('_', '')}Skin"
    _ComposedSkin.__qualname__ = _ComposedSkin.__name__
    # Set __module__ to the caller's module so the auto-discovery scanner
    # (which checks `obj.__module__ == mod.__name__` to filter out imports)
    # treats this class as belonging to the file it was composed in.
    # Same pattern collections.namedtuple uses.
    try:
        _ComposedSkin.__module__ = sys._getframe(1).f_globals.get(
            "__name__", _ComposedSkin.__module__,
        )
    except (AttributeError, ValueError):
        pass
    return _ComposedSkin
