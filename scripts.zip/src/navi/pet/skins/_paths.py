"""Filesystem paths for the skin system."""

from __future__ import annotations

import os
from pathlib import Path


def user_skins_dir() -> Path:
    """Where user-authored skin .py files live.

    `%APPDATA%/Navi/skins/` on Windows, `~/.config/Navi/skins/` elsewhere.
    """
    appdata = os.environ.get("APPDATA")
    base = Path(appdata) if appdata else Path.home() / ".config"
    return base / "Navi" / "skins"
