"""Tactical skin — sigil (Doctor Strange-style nested mandala).

Design notes:
- Three nested layers, each rotating slowly in alternate directions:
    1. Outer rune ring (24 marks, cardinal accents)
    2. Hexagram (two interlocking triangles) inside a hairline circle
    3. Inner glyph ring with cardinal diamond markers
- Center: a small bright crystal node, cursor-tracking.
- Pure line work — no fills, no scanlines, no glitch.
- Two-color palette: cool primary + warm gold accent. ASKING / ERROR shift
  the primary; gold stays.
- The sigil rotates at ~one revolution per minute — slow and deliberate.
"""

from __future__ import annotations

import math

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QBrush, QColor, QPen, QRadialGradient

from navi.pet.skins._base import PaintContext, Skin
from navi.pet.skins._colors import (
    ARC_AMBER,
    ARC_BLUE,
    ARC_CRIMSON,
    ARC_CYAN,
    ARC_EMERALD,
    ARC_GOLD,
    ARC_VIOLET,
    draw_glyph_marks,
    draw_hexagram,
    draw_rune_ring,
    rgba,
    soft_glow_circle,
)
from navi.pet.state import NaviState

_PRIMARY: dict[NaviState, QColor] = {
    NaviState.IDLE: ARC_BLUE,
    NaviState.LISTENING: ARC_EMERALD,
    NaviState.THINKING: ARC_VIOLET,
    NaviState.SPEAKING: ARC_CYAN,
    NaviState.ASKING: ARC_AMBER,
    NaviState.ERROR: ARC_CRIMSON,
}


class TacticalSkin(Skin):
    name = "tactical"
    description = "Sigil — nested rune ring + hexagram + glyph ring, gold accents"

    def paint(self, ctx: PaintContext) -> None:
        p = ctx.painter
        rect = ctx.rect
        cx = rect.width() / 2.0
        cy = rect.height() / 2.0
        center = QPointF(cx, cy)
        max_r = min(cx, cy) - 4.0
        state = ctx.state
        primary = _PRIMARY[state]
        accent = ARC_GOLD

        intensity = 1.0
        if state is NaviState.LISTENING:
            intensity = 0.85 + 0.15 * math.sin(ctx.t * 2 * math.pi * 1.4)
        elif state is NaviState.THINKING:
            intensity = 0.85 + 0.15 * math.sin(ctx.t * 2 * math.pi * 1.8)
        elif state is NaviState.SPEAKING:
            intensity = 0.85 + 0.15 * math.sin(ctx.t * 2 * math.pi * 2.4)
        elif state is NaviState.ASKING:
            intensity = 0.65 + 0.35 * math.sin(ctx.t * 2 * math.pi * 0.9)
        elif state is NaviState.ERROR:
            intensity = 0.55 + 0.45 * math.sin(ctx.t * 2 * math.pi * 3.5)

        # ---- 1. Soft halo (very subtle — sigil is mostly transparent) ----
        halo = QRadialGradient(center, max_r * 1.20)
        halo.setColorAt(0.0, rgba(primary, int(50 * intensity)))
        halo.setColorAt(0.55, rgba(primary, int(15 * intensity)))
        halo.setColorAt(1.0, rgba(primary, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(halo))
        p.drawEllipse(center, max_r * 1.20, max_r * 1.20)

        # ---- 2. Outer rune ring (slow rotation, primary) ------------------
        outer_r = max_r * 0.94
        soft_glow_circle(
            p, center, outer_r, primary,
            base_alpha=int(150 * intensity), layers=2, max_extra=2.0,
        )
        outer_rot = ctx.t * 0.10  # ~1 turn per 63 sec
        draw_rune_ring(
            p, center, outer_r, primary,
            n_marks=24, rotation_rad=outer_rot,
            mark_len=max_r * 0.045, mark_width=1.0,
            alpha=int(150 * intensity),
            accent_every=6, accent_len=max_r * 0.085,
            accent_alpha=int(220 * intensity),
        )
        # Inner edge of the rune band
        inner_band = max_r * 0.78
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(rgba(primary, int(110 * intensity)), 0.9))
        p.drawEllipse(center, inner_band, inner_band)

        # ---- 3. Hexagram (gold) — counter-rotates --------------------------
        hex_r = max_r * 0.62
        hex_rot = -ctx.t * 0.16
        # Two-pass for soft glow on the line work
        for w, a_mul in ((3.0, 0.18), (1.4, 1.0)):
            draw_hexagram(
                p, center, hex_r, accent,
                width=w, alpha=int(200 * intensity * a_mul),
                rotation_rad=hex_rot,
            )

        # Hairline circle inside the hexagram
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(rgba(accent, int(110 * intensity)), 0.8))
        p.drawEllipse(center, hex_r * 0.55, hex_r * 0.55)

        # ---- 4. Inner glyph ring (4 cardinal diamonds, primary) ----------
        inner_glyph_r = max_r * 0.30
        inner_glyph_rot = ctx.t * 0.20
        p.setPen(QPen(rgba(primary, int(140 * intensity)), 0.9))
        p.drawEllipse(center, inner_glyph_r, inner_glyph_r)
        draw_glyph_marks(
            p, center, inner_glyph_r, primary,
            n=4, rotation_rad=inner_glyph_rot,
            size=max_r * 0.020, alpha=int(220 * intensity),
        )

        # ---- 5. Listening ripples (between hexagram and outer ring) ------
        for birth in ctx.ripples:
            progress = min((ctx.t - birth) / 1.2, 1.0)
            r = hex_r + (max_r * 0.16) * progress
            alpha = int(180 * (1.0 - progress) * intensity)
            pen = QPen(rgba(primary, alpha), 1.0)
            p.setPen(pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(center, r, r)

        # ---- 6. Center crystal node (small bright dot, cursor-tracking) --
        rcx = cx + ctx.pupil_x * 0.30
        rcy = cy + ctx.pupil_y * 0.30
        core_r = max_r * 0.05
        bloom = QRadialGradient(QPointF(rcx, rcy), core_r * 3.5)
        bloom.setColorAt(0.0, rgba(QColor("#FFFFFF"), int(180 * intensity)))
        bloom.setColorAt(0.4, rgba(accent, int(120 * intensity)))
        bloom.setColorAt(1.0, rgba(accent, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(bloom))
        p.drawEllipse(QPointF(rcx, rcy), core_r * 3.5, core_r * 3.5)
        p.setBrush(QBrush(rgba(QColor("#FFFFFF"), int(245 * intensity))))
        p.drawEllipse(QPointF(rcx, rcy), core_r * 0.55, core_r * 0.55)
