"""Lazy first-run setup of the user skins folder.

Called from app startup, NOT on package import — keeping it lazy means
tests + tooling don't accidentally write into the user's AppData.
"""

from __future__ import annotations

from pathlib import Path

from navi.pet.skins._paths import user_skins_dir

_STARTER_FILENAME = "starter_skin.py"
_STUDIO_FILENAME = "STUDIO.md"

_STARTER_BODY = '''\
"""Example custom skin — built from the declarative kit.

Drop this file (or any .py file) in this folder and Navi will pick it up
on next launch. Run `/skin reload` from the chat to refresh without
restarting.

Open STUDIO.md in this folder for the full layer + palette reference.
"""

from navi.pet.skins.kit import compose, layer
from navi.pet.state import NaviState


# Each layer is drawn in order, bottom-up. Edit, save, then `/skin reload`
# in chat to see the change immediately.
StarterSkin = compose(
    name="starter",
    description="A simple custom orb — edit me!",

    # Per-state colors. Use named colors ("blue", "gold", "emerald", ...),
    # hex strings ("#FF6699"), or omit a state to fall back to IDLE's color.
    palette={
        NaviState.IDLE:      "blue",
        NaviState.LISTENING: "emerald",
        NaviState.THINKING:  "violet",
        NaviState.SPEAKING:  "gold",
        NaviState.ASKING:    "amber",
        NaviState.ERROR:     "crimson",
    },

    layers=[
        # 1. Soft outer glow that picks up the state color.
        layer.halo(scale=1.20, intensity=0.8),

        # 2. Deep dark body — the orb itself.
        layer.void_body(top_color="deep_indigo", bottom_color="deep_void"),

        # 3. Slowly rotating outer ring of rune-like tick marks.
        layer.rune_ring(rotation_speed=0.10, n_marks=24, accent_every=6),

        # 4. State-conditional effects — these silently no-op when the
        #    current state doesn't match.
        layer.listening_ripples(),
        layer.thinking_arc(),
        layer.speaking_bars(),

        # 5. Bright cursor-tracking center — the "eye" of the orb.
        layer.bright_core(track_cursor=True, size_frac=0.07),
    ],
)
'''


_STUDIO_BODY = """\
# Navi Skin Studio

This folder is where your **custom skins** live. Any `.py` file you drop here
that doesn't start with `_` is auto-discovered by Navi on next launch. Use
`/skin reload` from the chat to refresh without restarting.

There are two ways to write a skin:

1. **Declarative (recommended)** — stack named layers using `compose()` and
   `layer.X(...)`. No QPainter knowledge required. See `starter_skin.py` for
   a working example.
2. **Imperative** — subclass `Skin` directly and implement `paint(ctx)`.
   Look at `navi.pet.skins.classic` etc. in the source tree for examples.

---

## The declarative kit

```python
from navi.pet.skins.kit import compose, layer
from navi.pet.state import NaviState

MySkin = compose(
    name="my_skin",                        # unique, lowercase, no spaces
    description="what this skin looks like",
    palette={ NaviState.IDLE: "blue", ... },
    layers=[ layer.halo(), layer.void_body(), ... ],
)
```

Layers are drawn bottom-up in the order given. Most layers accept `color=`
which can be:

- `"state"` (the default) — use the per-state color from your `palette`
- a named color: `"blue"`, `"cyan"`, `"violet"`, `"gold"`, `"rose"`,
  `"emerald"`, `"amber"`, `"crimson"`, `"white"`, `"black"`, plus the deep
  body tones `"deep_void"`, `"deep_indigo"`, `"deep_violet"`, `"deep_teal"`
- a hex string: `"#FF6699"`
- a `QColor` instance for advanced cases

---

## Layer inventory

### Body / background

| Layer | Purpose | Key params |
|---|---|---|
| `halo` | Soft outer glow | `scale=1.20`, `intensity=0.85`, `color="state"` |
| `void_body` | Deep solid orb body with rim | `radius_frac=0.92`, `top_color`, `bottom_color`, `rim=True` |
| `clouds` | Drifting nebula clouds (clipped) | `n=2`, `drift_speed=0.5`, `color`, `bright_color` |
| `embers` | Floating ember particles (clipped) | `n=14`, `drift_speed=0.55`, `color` |
| `light_column` | Vertical light pillar, cursor-tracking | `width_frac=0.34`, `track_cursor=True`, `bead=True` |

### Rings / sigil work

| Layer | Purpose | Key params |
|---|---|---|
| `rune_ring` | Rotating ring of tick marks with cardinal accents | `radius_frac=0.93`, `rotation_speed=0.10`, `n_marks=24`, `accent_every=6` |
| `hairline_ring` | Plain thin circle | `radius_frac=0.70`, `alpha=130` |
| `glyph_ring` | Diamond glyphs at cardinal points | `radius_frac=0.48`, `n=4`, `rotation_speed=-0.14` |
| `hexagram` | Two interlocking triangles, glow option | `radius_frac=0.62`, `rotation_speed=-0.16`, `glow=True` |

### Center / tracking

| Layer | Purpose | Key params |
|---|---|---|
| `bright_core` | Bright dot with bloom, cursor-tracking | `size_frac=0.07`, `track_cursor=True`, `track_strength=0.40` |
| `crosshair` | Reticle, cursor-tracking | `length_frac=0.30`, `gap_frac=0.06` |

### State-conditional (auto-silent when state doesn't match)

| Layer | Fires on | Key params |
|---|---|---|
| `listening_ripples` | LISTENING (or any active ripples) | `radius_frac=0.78`, `color` |
| `thinking_arc` | THINKING | `speed_deg=55.0`, `arc_len_deg=18.0` |
| `speaking_bars` | SPEAKING | `n=9`, `amplitude_frac=0.10` |

### Text

| Layer | Purpose | Key params |
|---|---|---|
| `status_label` | One word per state at the bottom | `labels={...}`, `color="gold"`, `size_frac=0.072` |

---

## PaintContext (advanced — for imperative skins)

If you write `paint(self, ctx)` directly, `ctx` is a `PaintContext` with:

| Field | Type | Notes |
|---|---|---|
| `painter` | `QPainter` | Already has antialiasing on |
| `rect` | `QRect` | Widget rect — center yourself with `rect.width()/2, rect.height()/2` |
| `state` | `NaviState` | One of `IDLE / LISTENING / THINKING / SPEAKING / ASKING / ERROR` |
| `t` | `float` | Seconds since widget construction — use for animation |
| `pupil_x`, `pupil_y` | `float` | Smoothed cursor offset, widget-local |
| `ripples` | `list[float]` | Birth timestamps of LISTENING ripples to draw |

Helpers in `navi.pet.skins._colors`: `rgba`, `with_alpha`, `lighten`,
`darken`, `blend`, `make_mono_font`, plus drawing helpers `draw_rune_ring`,
`draw_glyph_marks`, `draw_hexagram`, `draw_polygon_outline`, `draw_embers`,
`soft_glow_circle`.

---

## Iterating

1. Edit your skin file in this folder.
2. In Navi's chat: `/skin reload`
3. In Navi's chat: `/skin <your-skin-name>` to switch to it.

Errors in your file print to the console but never crash Navi — your skin
is just skipped if it fails to load.
"""


def ensure_user_skins_dir() -> Path:
    """Create the user skins folder + starter content if missing.

    Idempotent. Safe to call on every launch.
    """
    d = user_skins_dir()
    d.mkdir(parents=True, exist_ok=True)
    starter = d / _STARTER_FILENAME
    if not starter.exists():
        starter.write_text(_STARTER_BODY, encoding="utf-8")
    studio = d / _STUDIO_FILENAME
    if not studio.exists():
        studio.write_text(_STUDIO_BODY, encoding="utf-8")
    return d
