"""Cortana skin — spirit vessel.

Design notes:
- A single luminous vertical light column inside a deep void orb.
- Slow ember particles drift upward through the column.
- Restrained palette: cool violet body, white-cyan column, state hue shifts
  the column tint only.
- No multiple ribbons, no scanlines — one pillar of contained light.
"""

from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import (
    QBrush,
    QColor,
    QLinearGradient,
    QPainterPath,
    QPen,
    QRadialGradient,
)

from navi.pet.skins._base import PaintContext, Skin
from navi.pet.skins._colors import (
    ARC_AMBER,
    ARC_CRIMSON,
    ARC_CYAN,
    ARC_EMERALD,
    ARC_GOLD,
    ARC_VIOLET,
    DEEP_VIOLET,
    DEEP_VOID,
    draw_embers,
    rgba,
)
from navi.pet.state import NaviState

_WHITE = QColor("#FFFFFF")

# Column tint (top of the light shaft)
_COLUMN: dict[NaviState, QColor] = {
    NaviState.IDLE: ARC_CYAN,
    NaviState.LISTENING: ARC_EMERALD,
    NaviState.THINKING: ARC_VIOLET,
    NaviState.SPEAKING: ARC_GOLD,
    NaviState.ASKING: ARC_AMBER,
    NaviState.ERROR: ARC_CRIMSON,
}


class CortanaSkin(Skin):
    name = "cortana"
    description = "Spirit vessel — single luminous column with drifting embers"

    def paint(self, ctx: PaintContext) -> None:
        p = ctx.painter
        rect = ctx.rect
        cx = rect.width() / 2.0
        cy = rect.height() / 2.0
        center = QPointF(cx, cy)
        max_r = min(cx, cy) - 6.0
        state = ctx.state
        column = _COLUMN[state]

        intensity = 1.0
        sway = 0.0
        if state is NaviState.LISTENING:
            intensity = 0.85 + 0.15 * math.sin(ctx.t * 2 * math.pi * 1.5)
            sway = math.sin(ctx.t * 1.0) * max_r * 0.04
        elif state is NaviState.THINKING:
            intensity = 0.85 + 0.15 * math.sin(ctx.t * 2 * math.pi * 2.0)
            sway = math.sin(ctx.t * 0.7) * max_r * 0.05
        elif state is NaviState.SPEAKING:
            intensity = 0.85 + 0.15 * math.sin(ctx.t * 2 * math.pi * 2.6)
            sway = math.sin(ctx.t * 1.5) * max_r * 0.06
        elif state is NaviState.ASKING:
            intensity = 0.65 + 0.35 * math.sin(ctx.t * 2 * math.pi * 0.9)
        elif state is NaviState.ERROR:
            intensity = 0.55 + 0.45 * math.sin(ctx.t * 2 * math.pi * 3.5)
            sway = math.sin(ctx.t * 5.0) * max_r * 0.03

        body_r = max_r * 0.92

        # ---- 1. Soft halo (column-tinted) ---------------------------------
        halo = QRadialGradient(center, max_r * 1.20)
        halo.setColorAt(0.0, rgba(column, int(70 * intensity)))
        halo.setColorAt(0.55, rgba(column, int(20 * intensity)))
        halo.setColorAt(1.0, rgba(column, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(halo))
        p.drawEllipse(center, max_r * 1.20, max_r * 1.20)

        # ---- 2. Deep void body --------------------------------------------
        body_grad = QRadialGradient(
            QPointF(cx - body_r * 0.30, cy - body_r * 0.30),
            body_r * 1.7,
        )
        body_grad.setColorAt(0.00, rgba(DEEP_VIOLET, 240))
        body_grad.setColorAt(0.65, rgba(DEEP_VOID, 250))
        body_grad.setColorAt(1.00, rgba(QColor(0, 0, 0), 250))
        p.setBrush(QBrush(body_grad))
        p.drawEllipse(center, body_r, body_r)

        # ---- 3. The luminous column (clipped to body) ---------------------
        # Column geometry: tall narrow shape centered horizontally, tapered
        # top and bottom. Drawn with a vertical gradient.
        p.save()
        clip = QPainterPath()
        clip.addEllipse(center, body_r, body_r)
        p.setClipPath(clip)

        col_top_y = cy - body_r * 0.86
        col_bot_y = cy + body_r * 0.86
        # Column tracks the cursor primarily on X (it's a vertical pillar),
        # plus a smaller idle sway so it never feels frozen.
        col_x = cx + ctx.pupil_x * 0.55 + sway * 0.4
        col_w = body_r * 0.34

        path = QPainterPath()
        # Build a tapered shape: narrow at top → widest at midline → narrow
        # at bottom. Use cubic curves for soft taper.
        path.moveTo(col_x - col_w * 0.15, col_top_y)
        path.cubicTo(
            QPointF(col_x - col_w * 0.55, cy - body_r * 0.30),
            QPointF(col_x - col_w * 0.55, cy + body_r * 0.30),
            QPointF(col_x - col_w * 0.18, col_bot_y),
        )
        path.lineTo(col_x + col_w * 0.18, col_bot_y)
        path.cubicTo(
            QPointF(col_x + col_w * 0.55, cy + body_r * 0.30),
            QPointF(col_x + col_w * 0.55, cy - body_r * 0.30),
            QPointF(col_x + col_w * 0.15, col_top_y),
        )
        path.closeSubpath()

        col_grad = QLinearGradient(0, col_top_y, 0, col_bot_y)
        col_grad.setColorAt(0.0, rgba(column, int(40 * intensity)))
        col_grad.setColorAt(0.45, rgba(column, int(180 * intensity)))
        col_grad.setColorAt(0.55, rgba(_WHITE, int(220 * intensity)))
        col_grad.setColorAt(0.65, rgba(column, int(180 * intensity)))
        col_grad.setColorAt(1.0, rgba(column, int(40 * intensity)))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(col_grad))
        p.drawPath(path)

        # Bright vertical centerline through the column
        line_grad = QLinearGradient(0, col_top_y, 0, col_bot_y)
        line_grad.setColorAt(0.0, rgba(_WHITE, 0))
        line_grad.setColorAt(0.5, rgba(_WHITE, int(230 * intensity)))
        line_grad.setColorAt(1.0, rgba(_WHITE, 0))
        line_pen = QPen(QBrush(line_grad), 1.4)
        line_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(line_pen)
        p.drawLine(QPointF(col_x, col_top_y), QPointF(col_x, col_bot_y))

        # Bright bead riding the column — Y tracks the cursor so vertical
        # motion is visible (the column itself is a vertical pillar so its
        # X tracking handles horizontal). Constrained to stay inside the
        # column's vertical extent.
        bead_y = cy + max(-body_r * 0.78, min(body_r * 0.78, ctx.pupil_y * 1.5))
        bead_r = body_r * 0.08
        bead_glow = QRadialGradient(QPointF(col_x, bead_y), bead_r * 2.6)
        bead_glow.setColorAt(0.0, rgba(_WHITE, int(245 * intensity)))
        bead_glow.setColorAt(0.45, rgba(column, int(180 * intensity)))
        bead_glow.setColorAt(1.0, rgba(column, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(bead_glow))
        p.drawEllipse(QPointF(col_x, bead_y), bead_r * 2.6, bead_r * 2.6)
        p.setBrush(QBrush(rgba(_WHITE, int(240 * intensity))))
        p.drawEllipse(QPointF(col_x, bead_y), bead_r * 0.55, bead_r * 0.55)

        # ---- 4. Drifting embers (clipped to body, using column tint) ------
        draw_embers(
            p, cx, cy, body_r * 0.95, column, ctx.t,
            n=10, seed=0.0,
            drift_speed=0.55 + (0.0 if state is NaviState.IDLE else 0.4),
            size=1.5, alpha_max=int(180 * intensity),
        )

        p.restore()  # release clip

        # ---- 5. Listening ripples (around the body, not inside) -----------
        for birth in ctx.ripples:
            progress = min((ctx.t - birth) / 1.2, 1.0)
            r = body_r + (max_r * 0.08) * progress
            alpha = int(180 * (1.0 - progress) * intensity)
            pen = QPen(rgba(column, alpha), 1.0)
            p.setPen(pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(center, r, r)

        # ---- 6. Hairline rim (defines the vessel) -------------------------
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(rgba(column, int(140 * intensity)), 1.0))
        p.drawEllipse(center, body_r, body_r)

        # ---- 7. Top + bottom cap accents (small triangles, gold) ---------
        # Suggests "containment" — the column is pinned at the poles.
        cap_color = ARC_GOLD if state not in (NaviState.ERROR, NaviState.ASKING) \
            else column
        cap_size = max_r * 0.04
        from PySide6.QtGui import QPolygonF
        top_cap = QPolygonF([
            QPointF(cx, cy - body_r + cap_size * 0.4),
            QPointF(cx - cap_size, cy - body_r + cap_size * 1.6),
            QPointF(cx + cap_size, cy - body_r + cap_size * 1.6),
        ])
        bot_cap = QPolygonF([
            QPointF(cx, cy + body_r - cap_size * 0.4),
            QPointF(cx - cap_size, cy + body_r - cap_size * 1.6),
            QPointF(cx + cap_size, cy + body_r - cap_size * 1.6),
        ])
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(rgba(cap_color, int(220 * intensity))))
        p.drawPolygon(top_cap)
        p.drawPolygon(bot_cap)

