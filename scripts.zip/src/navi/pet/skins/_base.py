"""Skin abstraction for the orb.

Each :class:`Skin` is a paint strategy. The host :class:`OrbWidget` owns
shared state (timer, ripples, cursor pupil position) and hands it to the
skin's ``paint()`` via a :class:`PaintContext` so skins are pure renderers.

Add a new skin in :mod:`navi.pet.skins` and register it in the package's
``__init__`` ``REGISTRY``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import ClassVar

from PySide6.QtCore import QRect
from PySide6.QtGui import QPainter

from navi.pet.state import NaviState


@dataclass
class PaintContext:
    painter: QPainter
    rect: QRect
    state: NaviState
    t: float          # seconds since widget construction
    pupil_x: float    # smoothed cursor offset, widget-local
    pupil_y: float
    ripples: list[float]  # ripple birth timestamps for LISTENING


class Skin(ABC):
    """Base class for all orb skins."""

    name: ClassVar[str] = "Skin"
    description: ClassVar[str] = ""

    @abstractmethod
    def paint(self, ctx: PaintContext) -> None: ...
