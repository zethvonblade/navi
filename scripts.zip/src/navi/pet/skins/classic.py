"""Classic skin — arcane crystal orb.

Design notes:
- Deep void body with a single soft inner glow that hints at the state.
- Slowly rotating outer rune ring (radial tick marks, cardinal accents).
- One rotating arc on THINKING; gentle ripples on LISTENING; soft pulse on
  SPEAKING / ASKING / ERROR. No glitch, no scanlines, no chromatic split.
- Lots of negative space. Reads as a quiet enchanted gem.
"""

from __future__ import annotations

import math

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QBrush, QColor, QConicalGradient, QPen, QRadialGradient

from navi.pet.skins._base import PaintContext, Skin
from navi.pet.skins._colors import (
    ARC_AMBER,
    ARC_BLUE,
    ARC_CRIMSON,
    ARC_EMERALD,
    ARC_GOLD,
    ARC_VIOLET,
    DEEP_INDIGO,
    DEEP_VOID,
    draw_rune_ring,
    rgba,
)
from navi.pet.state import NaviState

_PALETTE: dict[NaviState, QColor] = {
    NaviState.IDLE: ARC_BLUE,
    NaviState.LISTENING: ARC_EMERALD,
    NaviState.THINKING: ARC_VIOLET,
    NaviState.SPEAKING: ARC_GOLD,
    NaviState.ASKING: ARC_AMBER,
    NaviState.ERROR: ARC_CRIMSON,
}


class ClassicSkin(Skin):
    name = "classic"
    description = "Arcane crystal orb — deep void, soft inner glow, rune ring"

    def paint(self, ctx: PaintContext) -> None:
        p = ctx.painter
        rect = ctx.rect
        cx = rect.width() / 2.0
        cy = rect.height() / 2.0
        center = QPointF(cx, cy)
        max_r = min(cx, cy) - 8.0
        state = ctx.state
        accent = _PALETTE[state]

        # Per-state modulators (gentle)
        breath = 1.0 + 0.020 * math.sin(ctx.t * 2 * math.pi / 4.0)
        body_r = max_r * 0.74 * breath

        intensity = 0.85
        if state is NaviState.SPEAKING:
            intensity = 0.80 + 0.18 * (0.5 + 0.5 * math.sin(ctx.t * 2 * math.pi * 2.0))
        elif state is NaviState.ASKING:
            intensity = 0.75 + 0.25 * (0.5 + 0.5 * math.sin(ctx.t * 2 * math.pi * 0.9))
        elif state is NaviState.LISTENING:
            intensity = 0.80 + 0.15 * math.sin(ctx.t * 2 * math.pi / 1.6)
        elif state is NaviState.ERROR:
            intensity = 0.55 + 0.45 * math.sin(ctx.t * 2 * math.pi * 3.5)

        # ---- 1. Outer halo (very soft) ------------------------------------
        halo_grad = QRadialGradient(center, max_r * 1.20)
        halo_grad.setColorAt(0.0, rgba(accent, int(70 * intensity)))
        halo_grad.setColorAt(0.55, rgba(accent, int(20 * intensity)))
        halo_grad.setColorAt(1.0, rgba(accent, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(halo_grad))
        p.drawEllipse(center, max_r * 1.20, max_r * 1.20)

        # ---- 2. Slowly rotating rune ring (the signature element) ---------
        ring_r = max_r * 0.93
        rotation = ctx.t * 0.08  # very slow — about 1 turn per 78s
        draw_rune_ring(
            p, center, ring_r, accent,
            n_marks=24, rotation_rad=rotation,
            mark_len=max_r * 0.045, mark_width=1.0,
            alpha=int(150 * intensity),
            accent_every=6, accent_len=max_r * 0.085,
            accent_alpha=int(220 * intensity),
        )
        # Faint guide circle inside the rune ring
        guide_r = max_r * 0.86
        guide_pen = QPen(rgba(accent, int(45 * intensity)), 0.8)
        p.setPen(guide_pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(center, guide_r, guide_r)

        # ---- 3. Listening ripples (clean concentric pulses) ---------------
        for birth in ctx.ripples:
            progress = min((ctx.t - birth) / 1.2, 1.0)
            r = body_r + (max_r * 0.18) * progress
            alpha = int(170 * (1.0 - progress) * intensity)
            pen = QPen(rgba(accent, alpha), 1.0)
            p.setPen(pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(center, r, r)

        # ---- 4. Thinking arc (single short rotating arc on body edge) -----
        if state is NaviState.THINKING:
            rot_deg = (ctx.t * 55.0) % 360.0
            grad = QConicalGradient(center, -rot_deg)
            grad.setColorAt(0.00, rgba(accent, 0))
            grad.setColorAt(0.10, rgba(accent, int(220 * intensity)))
            grad.setColorAt(0.18, rgba(accent, 0))
            grad.setColorAt(1.00, rgba(accent, 0))
            arc_pen = QPen(QBrush(grad), 1.6)
            arc_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(arc_pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(center, body_r + 3, body_r + 3)

        # ---- 5. Crystal body — deep void with subtle depth ----------------
        body_grad = QRadialGradient(
            QPointF(cx - body_r * 0.32, cy - body_r * 0.32),
            body_r * 1.7,
        )
        body_grad.setColorAt(0.00, rgba(DEEP_INDIGO, 255))
        body_grad.setColorAt(0.40, rgba(DEEP_VOID, 255))
        body_grad.setColorAt(1.00, rgba(QColor(0, 0, 0), 255))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(body_grad))
        p.drawEllipse(center, body_r, body_r)

        # ---- 6. Inner accent glow (soft, central) -------------------------
        glow = QRadialGradient(
            QPointF(cx + ctx.pupil_x * 0.18, cy + ctx.pupil_y * 0.18),
            body_r * 0.85,
        )
        glow.setColorAt(0.0, rgba(accent, int(150 * intensity)))
        glow.setColorAt(0.50, rgba(accent, int(45 * intensity)))
        glow.setColorAt(1.0, rgba(accent, 0))
        p.setBrush(QBrush(glow))
        p.drawEllipse(center, body_r, body_r)

        # ---- 7. Hairline rim (thin precise edge) --------------------------
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(rgba(accent, int(140 * intensity)), 1.0))
        p.drawEllipse(center, body_r, body_r)

        # ---- 8. Single bright core (cursor-tracking, restrained) ----------
        focal_x = cx + ctx.pupil_x * 0.40
        focal_y = cy + ctx.pupil_y * 0.40
        core_r = max_r * 0.07
        core_grad = QRadialGradient(QPointF(focal_x, focal_y), core_r * 2.5)
        core_grad.setColorAt(0.0, rgba(QColor(255, 255, 255), int(220 * intensity)))
        core_grad.setColorAt(0.45, rgba(accent, int(150 * intensity)))
        core_grad.setColorAt(1.0, rgba(accent, 0))
        p.setBrush(QBrush(core_grad))
        p.drawEllipse(QPointF(focal_x, focal_y), core_r * 2.5, core_r * 2.5)
        p.setBrush(QBrush(rgba(QColor(255, 255, 255), int(230 * intensity))))
        p.drawEllipse(QPointF(focal_x, focal_y), core_r * 0.55, core_r * 0.55)

        # ---- 9. Speaking — gentle bottom glow line (no waveform) ----------
        if state is NaviState.SPEAKING:
            line_y = cy + body_r * 0.62
            line_w = body_r * 0.55
            pen = QPen(rgba(accent, int(220 * intensity)), 1.2)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(pen)
            p.drawLine(
                QPointF(cx - line_w / 2, line_y),
                QPointF(cx + line_w / 2, line_y),
            )

