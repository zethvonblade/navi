"""Shared color + arcane effect helpers for skins.

The skin set leans urban-fantasy / cyber-magic — restrained palette, thin
precise line work, lots of negative space, slow deliberate motion.
"""

from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QBrush, QColor, QFont, QPainter, QPen


def rgba(c: QColor, alpha: int) -> QColor:
    return QColor(c.red(), c.green(), c.blue(), max(0, min(255, alpha)))


def with_alpha(c: QColor, alpha_f: float) -> QColor:
    out = QColor(c)
    out.setAlphaF(max(0.0, min(1.0, alpha_f)))
    return out


def lighten(c: QColor, amt: float, alpha_mul: float = 1.0) -> QColor:
    h, s, v, _a = c.getHsvF()
    out = QColor.fromHsvF(
        h,
        max(0.0, s * (1.0 - amt * 0.3)),
        min(1.0, v + amt * (1.0 - v)),
    )
    out.setAlphaF(max(0.0, min(1.0, alpha_mul)))
    return out


def darken(c: QColor, amt: float, alpha_mul: float = 1.0) -> QColor:
    h, s, v, _a = c.getHsvF()
    out = QColor.fromHsvF(h, min(1.0, s + amt * 0.3), max(0.0, v * (1.0 - amt)))
    out.setAlphaF(max(0.0, min(1.0, alpha_mul * 0.9)))
    return out


def blend(a: QColor, b: QColor, t: float) -> QColor:
    t = max(0.0, min(1.0, t))
    return QColor(
        int(a.red() * (1 - t) + b.red() * t),
        int(a.green() * (1 - t) + b.green() * t),
        int(a.blue() * (1 - t) + b.blue() * t),
    )


# --- Arcane / urban-fantasy palette ----------------------------------------
# Cool body tones with one warm accent — the classic urban-fantasy contrast.
DEEP_VOID = QColor("#06000F")
DEEP_INDIGO = QColor("#0A0E2A")
DEEP_VIOLET = QColor("#160A2E")
DEEP_TEAL = QColor("#0A1A24")

ARC_BLUE = QColor("#5FA8FF")        # cool primary
ARC_CYAN = QColor("#7FE0FF")        # luminous secondary
ARC_VIOLET = QColor("#A98BFF")      # arcane purple
ARC_GOLD = QColor("#F0C060")        # warm accent (signature urban-fantasy)
ARC_ROSE = QColor("#FFA8C8")        # soft pink-rose
ARC_EMERALD = QColor("#5FE0B0")     # listening / spell-cast tone
ARC_AMBER = QColor("#FFB870")       # asking / warm warning
ARC_CRIMSON = QColor("#E55060")     # error / blood-magic


def make_mono_font(size_pt: float, spacing_pct: float = 130.0, bold: bool = True) -> QFont:
    f = QFont("Consolas")
    f.setPointSizeF(size_pt)
    f.setBold(bold)
    f.setLetterSpacing(QFont.SpacingType.PercentageSpacing, spacing_pct)
    return f


def draw_rune_ring(
    p: QPainter,
    center: QPointF,
    radius: float,
    color: QColor,
    n_marks: int = 24,
    rotation_rad: float = 0.0,
    mark_len: float = 6.0,
    mark_width: float = 1.0,
    alpha: int = 180,
    accent_every: int = 6,
    accent_len: float = 10.0,
    accent_alpha: int = 230,
) -> None:
    """Inscribe a ring of small radial tick-marks ('runes') around a circle.

    Cardinal positions (every ``accent_every`` marks) get a longer/brighter
    accent — gives the ring a "compass" or sigil feel without literal text.
    """
    cx = center.x()
    cy = center.y()
    p.setBrush(Qt.BrushStyle.NoBrush)
    for i in range(n_marks):
        angle = rotation_rad + i * (2 * math.pi / n_marks) - math.pi / 2
        is_accent = (i % accent_every) == 0
        length = accent_len if is_accent else mark_len
        width = mark_width * (1.6 if is_accent else 1.0)
        a = accent_alpha if is_accent else alpha
        pen = QPen(rgba(color, a), width)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(pen)
        r0 = radius - length
        r1 = radius
        p.drawLine(
            QPointF(cx + math.cos(angle) * r0, cy + math.sin(angle) * r0),
            QPointF(cx + math.cos(angle) * r1, cy + math.sin(angle) * r1),
        )


def draw_glyph_marks(
    p: QPainter,
    center: QPointF,
    radius: float,
    color: QColor,
    n: int = 4,
    rotation_rad: float = 0.0,
    size: float = 5.0,
    alpha: int = 220,
) -> None:
    """Place small diamond glyphs at evenly-spaced positions around a circle.

    Used as cardinal markers on sigils / mandalas.
    """
    cx = center.x()
    cy = center.y()
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QBrush(rgba(color, alpha)))
    for i in range(n):
        angle = rotation_rad + i * (2 * math.pi / n) - math.pi / 2
        x = cx + math.cos(angle) * radius
        y = cy + math.sin(angle) * radius
        # Diamond
        from PySide6.QtGui import QPolygonF
        diamond = QPolygonF([
            QPointF(x, y - size),
            QPointF(x + size, y),
            QPointF(x, y + size),
            QPointF(x - size, y),
        ])
        p.drawPolygon(diamond)


def draw_polygon_outline(
    p: QPainter,
    center: QPointF,
    radius: float,
    n_sides: int,
    color: QColor,
    width: float = 1.2,
    alpha: int = 220,
    rotation_rad: float = 0.0,
) -> None:
    """Inscribed regular polygon outline (used for hexagrams, pentagrams)."""
    from PySide6.QtGui import QPolygonF
    cx = center.x()
    cy = center.y()
    pts = []
    for i in range(n_sides):
        a = rotation_rad + i * (2 * math.pi / n_sides) - math.pi / 2
        pts.append(QPointF(cx + math.cos(a) * radius, cy + math.sin(a) * radius))
    poly = QPolygonF(pts)
    pen = QPen(rgba(color, alpha), width)
    pen.setJoinStyle(Qt.PenJoinStyle.MiterJoin)
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawPolygon(poly)


def draw_hexagram(
    p: QPainter,
    center: QPointF,
    radius: float,
    color: QColor,
    width: float = 1.0,
    alpha: int = 200,
    rotation_rad: float = 0.0,
) -> None:
    """Six-pointed star (two interlocking triangles) — sigil staple."""
    draw_polygon_outline(p, center, radius, 3, color, width, alpha, rotation_rad)
    draw_polygon_outline(
        p, center, radius, 3, color, width, alpha,
        rotation_rad + math.pi,
    )


def soft_glow_circle(
    p: QPainter,
    center: QPointF,
    radius: float,
    color: QColor,
    base_alpha: int = 180,
    layers: int = 3,
    max_extra: float = 4.0,
) -> None:
    """Subtle multi-pass bloom for a glowing ring (less aggressive than neon)."""
    p.setBrush(Qt.BrushStyle.NoBrush)
    for i in range(layers):
        frac = i / max(1, layers - 1) if layers > 1 else 0.0
        alpha = int(base_alpha * (1.0 - frac * 0.85))
        width = 0.9 + frac * max_extra
        pen = QPen(rgba(color, alpha), width)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(pen)
        p.drawEllipse(center, radius, radius)


def draw_embers(
    p: QPainter,
    cx: float,
    cy: float,
    radius: float,
    color: QColor,
    t: float,
    n: int = 14,
    seed: float = 0.0,
    drift_speed: float = 1.0,
    size: float = 1.6,
    alpha_max: int = 200,
) -> None:
    """Slow-drifting ember particles inside a disk.

    Each particle has a deterministic random seed (so the pattern is stable
    frame-to-frame) and drifts upward along a sine-perturbed path. Fades in
    and out across its lifetime so they appear / disappear naturally.
    """
    p.save()
    from PySide6.QtGui import QPainterPath
    clip = QPainterPath()
    clip.addEllipse(QPointF(cx, cy), radius, radius)
    p.setClipPath(clip)
    p.setPen(Qt.PenStyle.NoPen)
    for i in range(n):
        # Pseudo-random per-particle constants from the index + seed
        sx = ((i * 73 + 13) % 100) / 100.0       # 0..1 horizontal seed
        sd = ((i * 37 + 7) % 100) / 100.0        # 0..1 lifetime offset
        sa = ((i * 53 + 19) % 100) / 100.0       # 0..1 wobble seed
        lifetime = 5.5 + (sa * 3.0)              # 5.5–8.5 sec per particle
        local_t = (t * drift_speed + seed + sd * lifetime) % lifetime
        prog = local_t / lifetime                 # 0..1
        # Bottom→top trajectory with a sine wobble
        y = (cy + radius * 0.85) - prog * (radius * 1.7)
        x = cx + math.sin(t * 0.7 + sx * 6.28 + i) * radius * 0.35 \
            + (sx - 0.5) * radius * 1.3
        # Fade in over first 15%, fade out over last 25%
        if prog < 0.15:
            a_f = prog / 0.15
        elif prog > 0.75:
            a_f = (1.0 - prog) / 0.25
        else:
            a_f = 1.0
        a = int(alpha_max * a_f)
        if a <= 4:
            continue
        p.setBrush(QBrush(rgba(color, a)))
        # Two-layer ember: dim halo + bright core
        p.setBrush(QBrush(rgba(color, max(0, a // 4))))
        p.drawEllipse(QPointF(x, y), size * 2.0, size * 2.0)
        p.setBrush(QBrush(rgba(QColor(255, 255, 255), a)))
        p.drawEllipse(QPointF(x, y), size * 0.6, size * 0.6)
    p.restore()
