"""Plasma skin — astral cloud.

Design notes:
- Deep void body containing one large soft drifting cloud.
- Slow ember particles drift through the cloud.
- Restrained palette: state hue tints the cloud + embers, body stays dark.
- No lightning, no chromatic split — just a quiet enchanted gem.
"""

from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QBrush, QColor, QPen, QRadialGradient

from navi.pet.skins._base import PaintContext, Skin
from navi.pet.skins._colors import (
    ARC_AMBER,
    ARC_BLUE,
    ARC_CRIMSON,
    ARC_CYAN,
    ARC_EMERALD,
    ARC_GOLD,
    ARC_VIOLET,
    DEEP_TEAL,
    DEEP_VOID,
    draw_embers,
    rgba,
)
from navi.pet.state import NaviState

# State → (cloud highlight, cloud body)
_PALETTE: dict[NaviState, tuple[QColor, QColor]] = {
    NaviState.IDLE: (QColor("#E0F0FF"), ARC_BLUE),
    NaviState.LISTENING: (QColor("#E0FFE5"), ARC_EMERALD),
    NaviState.THINKING: (QColor("#F0E0FF"), ARC_VIOLET),
    NaviState.SPEAKING: (QColor("#FFE8C8"), ARC_GOLD),
    NaviState.ASKING: (QColor("#FFEAD0"), ARC_AMBER),
    NaviState.ERROR: (QColor("#FFD6D6"), ARC_CRIMSON),
}


class PlasmaSkin(Skin):
    name = "plasma"
    description = "Astral cloud — deep void with a slowly drifting nebula and embers"

    def paint(self, ctx: PaintContext) -> None:
        p = ctx.painter
        rect = ctx.rect
        cx = rect.width() / 2.0
        cy = rect.height() / 2.0
        center = QPointF(cx, cy)
        max_r = min(cx, cy) - 6.0
        state = ctx.state
        bright, mid = _PALETTE[state]

        drift = 0.35
        intensity = 1.0
        if state is NaviState.LISTENING:
            drift = 0.55
            intensity = 0.85 + 0.15 * math.sin(ctx.t * 2 * math.pi * 1.4)
        elif state is NaviState.THINKING:
            drift = 0.65
            intensity = 0.85 + 0.15 * math.sin(ctx.t * 2 * math.pi * 2.0)
        elif state is NaviState.SPEAKING:
            drift = 0.75
            intensity = 0.85 + 0.15 * math.sin(ctx.t * 2 * math.pi * 2.6)
        elif state is NaviState.ASKING:
            drift = 0.45
            intensity = 0.65 + 0.35 * math.sin(ctx.t * 2 * math.pi * 0.9)
        elif state is NaviState.ERROR:
            drift = 1.4
            intensity = 0.55 + 0.45 * math.sin(ctx.t * 2 * math.pi * 3.5)

        body_r = max_r * 0.92

        # ---- 1. Soft halo --------------------------------------------------
        halo = QRadialGradient(center, max_r * 1.22)
        halo.setColorAt(0.0, rgba(mid, int(70 * intensity)))
        halo.setColorAt(0.55, rgba(mid, int(20 * intensity)))
        halo.setColorAt(1.0, rgba(mid, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(halo))
        p.drawEllipse(center, max_r * 1.22, max_r * 1.22)

        # ---- 2. Deep void body --------------------------------------------
        body_grad = QRadialGradient(
            QPointF(cx - body_r * 0.30, cy - body_r * 0.30),
            body_r * 1.7,
        )
        body_grad.setColorAt(0.00, rgba(DEEP_TEAL, 240))
        body_grad.setColorAt(0.65, rgba(DEEP_VOID, 250))
        body_grad.setColorAt(1.00, rgba(QColor(0, 0, 0), 250))
        p.setBrush(QBrush(body_grad))
        p.drawEllipse(center, body_r, body_r)

        # ---- 3. One large drifting cloud (clipped to body) ----------------
        from PySide6.QtGui import QPainterPath
        p.save()
        clip = QPainterPath()
        clip.addEllipse(center, body_r, body_r)
        p.setClipPath(clip)

        ox = math.sin(ctx.t * drift * 0.30) * body_r * 0.18
        oy = math.cos(ctx.t * drift * 0.22 + 1.3) * body_r * 0.14
        cloud_center = QPointF(cx + ox, cy + oy)
        cloud_r = body_r * 0.78
        cloud_grad = QRadialGradient(cloud_center, cloud_r)
        cloud_grad.setColorAt(0.0, rgba(bright, int(140 * intensity)))
        cloud_grad.setColorAt(0.45, rgba(mid, int(110 * intensity)))
        cloud_grad.setColorAt(1.0, rgba(mid, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(cloud_grad))
        p.drawEllipse(cloud_center, cloud_r, cloud_r)

        # Secondary smaller cloud, counter-drifting
        ox2 = math.cos(ctx.t * drift * 0.45) * body_r * 0.22
        oy2 = math.sin(ctx.t * drift * 0.37 + 0.7) * body_r * 0.16
        cloud2_center = QPointF(cx + ox2, cy + oy2)
        cloud2_r = body_r * 0.45
        cloud2_grad = QRadialGradient(cloud2_center, cloud2_r)
        cloud2_grad.setColorAt(0.0, rgba(bright, int(100 * intensity)))
        cloud2_grad.setColorAt(0.45, rgba(mid, int(80 * intensity)))
        cloud2_grad.setColorAt(1.0, rgba(mid, 0))
        p.setBrush(QBrush(cloud2_grad))
        p.drawEllipse(cloud2_center, cloud2_r, cloud2_r)

        # ---- 4. Drifting embers (clipped to body) -------------------------
        draw_embers(
            p, cx, cy, body_r * 0.95, mid, ctx.t,
            n=12, seed=0.0, drift_speed=0.55,
            size=1.6, alpha_max=int(190 * intensity),
        )

        p.restore()  # release clip

        # ---- 5. Listening ripples (around the body) ----------------------
        for birth in ctx.ripples:
            progress = min((ctx.t - birth) / 1.2, 1.0)
            r = body_r + (max_r * 0.06) * progress
            alpha = int(180 * (1.0 - progress) * intensity)
            pen = QPen(rgba(mid, alpha), 1.0)
            p.setPen(pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(center, r, r)

        # ---- 6. Bright center crystal (cursor-tracking) ------------------
        focal_x = cx + ctx.pupil_x * 0.30
        focal_y = cy + ctx.pupil_y * 0.30
        core_r = max_r * 0.10
        core_grad = QRadialGradient(QPointF(focal_x, focal_y), core_r * 2.5)
        core_grad.setColorAt(0.0, rgba(QColor("#FFFFFF"), int(220 * intensity)))
        core_grad.setColorAt(0.40, rgba(bright, int(180 * intensity)))
        core_grad.setColorAt(1.0, rgba(mid, 0))
        p.setBrush(QBrush(core_grad))
        p.drawEllipse(QPointF(focal_x, focal_y), core_r * 2.5, core_r * 2.5)
        p.setBrush(QBrush(rgba(QColor("#FFFFFF"), int(235 * intensity))))
        p.drawEllipse(QPointF(focal_x, focal_y), core_r * 0.45, core_r * 0.45)

        # ---- 7. Hairline rim with a single gold crescent at top ----------
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(rgba(mid, int(140 * intensity)), 1.0))
        p.drawEllipse(center, body_r, body_r)
        # Gold arc at the top — like the highlight on a dark gem
        crescent_pen = QPen(rgba(ARC_CYAN, int(140 * intensity)), 1.4)
        crescent_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(crescent_pen)
        bbox = QRectF(cx - body_r, cy - body_r, body_r * 2, body_r * 2)
        p.drawArc(bbox, int(120 * 16), int(40 * 16))
