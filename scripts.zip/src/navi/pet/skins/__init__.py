"""Skin registry — auto-discovers built-in skins and user-authored skins.

How discovery works
-------------------
On import (and again on every :func:`reload_skins` call) we scan two places:

1. This package directory — every ``*.py`` file that doesn't start with
   ``_`` is imported and any subclass of :class:`Skin` it defines is added
   to :data:`REGISTRY` keyed by ``cls.name``.
2. The user folder ``%APPDATA%/Navi/skins/`` — same rules, but loaded by
   absolute path under the synthetic package ``navi_user_skins``. Errors
   in user skins are caught and printed; they never break the app.

To add a skin: write ``MySkin(Skin)`` (or use :mod:`navi.pet.skins.kit`),
drop the file in the built-in directory or the user folder. No registry
edits required.

Hot reload
----------
:func:`reload_skins` clears every cached skin module and re-runs discovery.
Wired to the ``/skin reload`` slash command in the chat panel.
"""

from __future__ import annotations

import importlib
import importlib.util
import inspect
import sys
import traceback
from pathlib import Path

from navi.pet.skins._base import PaintContext, Skin
from navi.pet.skins._paths import user_skins_dir

REGISTRY: dict[str, type[Skin]] = {}
DEFAULT_SKIN = "classic"

_USER_PKG = "navi_user_skins"


def _scan_module(mod) -> list[type[Skin]]:
    """Return every Skin subclass *defined in* this module (skip imports)."""
    out: list[type[Skin]] = []
    for _, obj in inspect.getmembers(mod, inspect.isclass):
        if not issubclass(obj, Skin) or obj is Skin:
            continue
        if obj.__module__ != mod.__name__:
            continue
        if not getattr(obj, "name", None) or obj.name == "Skin":
            continue
        out.append(obj)
    return out


def _drop_module(name: str) -> None:
    """Force-evict a module so the next import re-executes the file."""
    sys.modules.pop(name, None)


def _load_builtin_skins() -> None:
    builtin_dir = Path(__file__).parent
    for f in sorted(builtin_dir.glob("*.py")):
        if f.name.startswith("_") or f.name == "__init__.py":
            continue
        mod_name = f"navi.pet.skins.{f.stem}"
        _drop_module(mod_name)
        try:
            mod = importlib.import_module(mod_name)
        except Exception:  # noqa: BLE001 — never let one bad skin kill the app
            print(f"[skins] failed to load built-in {f.name}:")
            traceback.print_exc()
            continue
        for cls in _scan_module(mod):
            REGISTRY[cls.name] = cls


def _load_user_skins() -> None:
    user_dir = user_skins_dir()
    if not user_dir.exists():
        return
    # Pseudo-package so reload can find + evict user-skin modules cleanly.
    if _USER_PKG not in sys.modules:
        pkg = importlib.util.module_from_spec(
            importlib.util.spec_from_loader(_USER_PKG, loader=None)
        )
        pkg.__path__ = [str(user_dir)]  # type: ignore[attr-defined]
        sys.modules[_USER_PKG] = pkg
    for f in sorted(user_dir.glob("*.py")):
        if f.name.startswith("_") or f.name == "__init__.py":
            continue
        mod_name = f"{_USER_PKG}.{f.stem}"
        _drop_module(mod_name)
        try:
            spec = importlib.util.spec_from_file_location(mod_name, f)
            if spec is None or spec.loader is None:
                continue
            mod = importlib.util.module_from_spec(spec)
            sys.modules[mod_name] = mod
            spec.loader.exec_module(mod)
        except Exception:  # noqa: BLE001
            print(f"[skins] failed to load user skin {f.name}:")
            traceback.print_exc()
            continue
        for cls in _scan_module(mod):
            REGISTRY[cls.name] = cls


def _build_registry() -> None:
    REGISTRY.clear()
    _load_builtin_skins()
    _load_user_skins()


def reload_skins() -> tuple[int, list[str]]:
    """Clear and rebuild the registry.

    Returns ``(count, names)`` so the chat can display a confirmation.
    """
    _build_registry()
    return (len(REGISTRY), sorted(REGISTRY.keys()))


def get_skin(name: str) -> Skin:
    """Return an instance of the requested skin, falling back to default."""
    cls = REGISTRY.get(name) or REGISTRY[DEFAULT_SKIN]
    return cls()


def available_skins() -> list[tuple[str, str]]:
    """Return ``[(name, description), ...]`` for the UI selector."""
    items = sorted(REGISTRY.items(), key=lambda kv: (kv[0] != DEFAULT_SKIN, kv[0]))
    return [(name, cls.description) for name, cls in items]


# Initial scan on import
_build_registry()


__all__ = [
    "PaintContext",
    "Skin",
    "REGISTRY",
    "DEFAULT_SKIN",
    "get_skin",
    "available_skins",
    "reload_skins",
]
