"""JARVIS skin — arcane console.

Design notes:
- Three clean concentric rings: outer rune-marked, middle plain hairline,
  inner with cardinal diamond glyphs.
- Restrained two-color palette: cool blue primary, warm gold accent.
  ASKING and ERROR shift the primary; everything else stays cool.
- Single small status word at the bottom — no chromatic split, no glow text.
- Slow counter-rotation between rings reads as quiet machinery.
"""

from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QBrush, QColor, QPen, QRadialGradient

from navi.pet.skins._base import PaintContext, Skin
from navi.pet.skins._colors import (
    ARC_AMBER,
    ARC_BLUE,
    ARC_CRIMSON,
    ARC_CYAN,
    ARC_GOLD,
    ARC_VIOLET,
    DEEP_INDIGO,
    DEEP_VOID,
    draw_glyph_marks,
    draw_rune_ring,
    make_mono_font,
    rgba,
    soft_glow_circle,
)
from navi.pet.state import NaviState

_PRIMARY: dict[NaviState, QColor] = {
    NaviState.IDLE: ARC_BLUE,
    NaviState.LISTENING: ARC_CYAN,
    NaviState.THINKING: ARC_VIOLET,
    NaviState.SPEAKING: ARC_BLUE,
    NaviState.ASKING: ARC_AMBER,
    NaviState.ERROR: ARC_CRIMSON,
}

_STATUS_LABEL: dict[NaviState, str] = {
    NaviState.IDLE: "STANDBY",
    NaviState.LISTENING: "LISTEN",
    NaviState.THINKING: "DIVINE",
    NaviState.SPEAKING: "SPEAK",
    NaviState.ASKING: "AWAIT",
    NaviState.ERROR: "WARD",
}


class JarvisSkin(Skin):
    name = "jarvis"
    description = "Arcane console — three concentric rings, gold accents, status sigil"

    def paint(self, ctx: PaintContext) -> None:
        p = ctx.painter
        state = ctx.state
        rect = ctx.rect

        cx = rect.width() / 2.0
        cy = rect.height() / 2.0
        center = QPointF(cx, cy)
        max_r = min(cx, cy) - 6.0
        primary = _PRIMARY[state]
        accent = ARC_GOLD

        intensity = 1.0
        if state is NaviState.LISTENING:
            intensity = 0.85 + 0.15 * math.sin(ctx.t * 2 * math.pi * 1.4)
        elif state is NaviState.THINKING:
            intensity = 0.85 + 0.15 * math.sin(ctx.t * 2 * math.pi * 2.0)
        elif state is NaviState.SPEAKING:
            intensity = 0.85 + 0.15 * math.sin(ctx.t * 2 * math.pi * 2.6)
        elif state is NaviState.ASKING:
            intensity = 0.65 + 0.35 * math.sin(ctx.t * 2 * math.pi * 0.9)
        elif state is NaviState.ERROR:
            intensity = 0.55 + 0.45 * math.sin(ctx.t * 2 * math.pi * 3.5)

        # ---- 1. Soft halo (very restrained) -------------------------------
        halo = QRadialGradient(center, max_r * 1.18)
        halo.setColorAt(0.0, rgba(primary, int(60 * intensity)))
        halo.setColorAt(0.55, rgba(primary, int(15 * intensity)))
        halo.setColorAt(1.0, rgba(primary, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(halo))
        p.drawEllipse(center, max_r * 1.18, max_r * 1.18)

        # ---- 2. Faint inner backdrop (deep indigo wash) -------------------
        bd = QRadialGradient(center, max_r * 0.78)
        bd.setColorAt(0.0, rgba(DEEP_INDIGO, 80))
        bd.setColorAt(1.0, rgba(DEEP_VOID, 0))
        p.setBrush(QBrush(bd))
        p.drawEllipse(center, max_r * 0.78, max_r * 0.78)

        # ---- 3. Outer ring with rune marks (slow rotation, primary) ------
        outer_r = max_r * 0.93
        soft_glow_circle(
            p, center, outer_r, primary,
            base_alpha=int(160 * intensity), layers=2, max_extra=2.5,
        )
        rotation = ctx.t * 0.10
        draw_rune_ring(
            p, center, outer_r, primary,
            n_marks=24, rotation_rad=rotation,
            mark_len=max_r * 0.040, mark_width=1.0,
            alpha=int(150 * intensity),
            accent_every=6, accent_len=max_r * 0.075,
            accent_alpha=int(220 * intensity),
        )

        # ---- 4. Middle plain hairline ring -------------------------------
        mid_r = max_r * 0.70
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(rgba(primary, int(110 * intensity)), 0.9))
        p.drawEllipse(center, mid_r, mid_r)

        # ---- 5. Inner ring with cardinal diamond glyphs (gold) -----------
        inner_r = max_r * 0.48
        p.setPen(QPen(rgba(primary, int(140 * intensity)), 1.0))
        p.drawEllipse(center, inner_r, inner_r)
        glyph_rotation = -ctx.t * 0.14  # counter-rotate against outer ring
        draw_glyph_marks(
            p, center, inner_r, accent,
            n=4, rotation_rad=glyph_rotation,
            size=max_r * 0.022, alpha=int(220 * intensity),
        )

        # ---- 6. Listening ripples (clean) ---------------------------------
        for birth in ctx.ripples:
            progress = min((ctx.t - birth) / 1.1, 1.0)
            r = inner_r + (max_r * 0.40) * progress
            alpha = int(160 * (1.0 - progress) * intensity)
            pen = QPen(rgba(primary, alpha), 1.0)
            p.setPen(pen)
            p.drawEllipse(center, r, r)

        # ---- 7. Center crystal (small bright core, cursor-tracking) ------
        rcx = cx + ctx.pupil_x * 0.32
        rcy = cy + ctx.pupil_y * 0.32
        core_r = max_r * 0.07
        bloom = QRadialGradient(QPointF(rcx, rcy), core_r * 3.0)
        bloom.setColorAt(0.0, rgba(QColor("#FFFFFF"), int(170 * intensity)))
        bloom.setColorAt(0.4, rgba(accent, int(110 * intensity)))
        bloom.setColorAt(1.0, rgba(accent, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(bloom))
        p.drawEllipse(QPointF(rcx, rcy), core_r * 3.0, core_r * 3.0)
        p.setBrush(QBrush(rgba(QColor("#FFFFFF"), int(235 * intensity))))
        p.drawEllipse(QPointF(rcx, rcy), core_r * 0.55, core_r * 0.55)

        # ---- 8. Status word at bottom (small, plain, gold) ---------------
        font = make_mono_font(max(7.0, max_r * 0.072), spacing_pct=180.0, bold=True)
        p.setFont(font)
        p.setPen(QPen(rgba(accent, int(190 * intensity))))
        text_y = cy + max_r * 0.78
        text_rect = QRectF(0, text_y, rect.width(), max_r * 0.16)
        p.drawText(text_rect, int(Qt.AlignmentFlag.AlignCenter), _STATUS_LABEL[state])
        # tiny accent ticks beside the word
        fm = p.fontMetrics()
        text_w = fm.horizontalAdvance(_STATUS_LABEL[state])
        tick_y = text_y + max_r * 0.08
        tick_pen = QPen(rgba(accent, int(150 * intensity)), 0.9)
        p.setPen(tick_pen)
        gap = max_r * 0.025
        p.drawLine(
            QPointF(cx - text_w / 2 - gap - max_r * 0.05, tick_y),
            QPointF(cx - text_w / 2 - gap, tick_y),
        )
        p.drawLine(
            QPointF(cx + text_w / 2 + gap, tick_y),
            QPointF(cx + text_w / 2 + gap + max_r * 0.05, tick_y),
        )
