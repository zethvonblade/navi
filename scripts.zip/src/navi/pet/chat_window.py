from __future__ import annotations

import os
import re
from pathlib import Path

from PySide6.QtCore import QEvent, Qt, Signal
from PySide6.QtGui import (
    QFont,
    QKeyEvent,
    QTextCursor,
    QTextDocument,
)
from PySide6.QtWidgets import (
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QSizePolicy,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)


_HISTORY_STYLE = """
QTextEdit {
    background: #161616;
    color: #e8e8e8;
    padding: 10px;
    border: 0;
    selection-background-color: #2c5fc9;
}
"""

_INPUT_STYLE = """
QPlainTextEdit {
    background: #1e1e1e;
    color: #e8e8e8;
    padding: 8px 10px;
    border: 1px solid #2a2a2a;
    border-radius: 4px;
    selection-background-color: #2c5fc9;
}
QPlainTextEdit:focus { border-color: #3B82F6; }
QPlainTextEdit:disabled { color: #666; }
"""

_SEND_STYLE = """
QPushButton {
    background: #3B82F6;
    color: white;
    padding: 8px 14px;
    border: 0;
    border-radius: 4px;
}
QPushButton:hover { background: #2c6ad5; }
QPushButton:disabled { background: #2a2a2a; color: #666; }
"""

_STOP_STYLE = """
QPushButton {
    background: #2a2a2a;
    color: #e8e8e8;
    padding: 8px 14px;
    border: 1px solid #3a3a3a;
    border-radius: 4px;
}
QPushButton:hover { background: #EF4444; color: white; border-color: #EF4444; }
QPushButton:disabled { background: #1a1a1a; color: #555; border-color: #2a2a2a; }
"""

_RETRY_STYLE = """
QPushButton {
    background: #F59E0B;
    color: black;
    padding: 8px 14px;
    border: 0;
    border-radius: 4px;
    font-weight: 600;
}
QPushButton:hover { background: #D97706; }
"""

_QUICK_STYLE = """
QPushButton {
    background: #1e1e1e;
    color: #c8c8c8;
    padding: 4px 10px;
    border: 1px solid #2a2a2a;
    border-radius: 12px;
    font-size: 11px;
}
QPushButton:hover { background: #2a2a2a; color: #e8e8e8; border-color: #3B82F6; }
QPushButton:disabled { color: #555; }
"""

_ACTION_BAR_STYLE = """
QWidget#actionBar {
    background: #1a1a1a;
    border-top: 1px solid #2a2a2a;
    border-bottom: 1px solid #2a2a2a;
}
QLabel#actionLabel {
    color: #e8e8e8;
    padding: 8px 10px;
}
QPushButton#actionAllow {
    background: #10B981;
    color: white;
    padding: 6px 14px;
    border: 0;
    border-radius: 4px;
    font-weight: 600;
}
QPushButton#actionAllow:hover { background: #059669; }
QPushButton#actionDeny {
    background: #2a2a2a;
    color: #e8e8e8;
    padding: 6px 14px;
    border: 1px solid #3a3a3a;
    border-radius: 4px;
}
QPushButton#actionDeny:hover { background: #EF4444; color: white; border-color: #EF4444; }
"""

_STATUS_STYLE = """
QLabel {
    color: #888;
    padding: 4px 10px;
    background: #0e0e0e;
    border-top: 1px solid #2a2a2a;
}
"""


def _chat_history_path() -> Path:
    appdata = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming")))
    return appdata / "Navi" / "chat_history.html"


# Built-in slash commands (subset handled inside ChatWindow; others are
# emitted as `slash_command(name, arg)` for PetWindow to handle).
_SLASH_HELP = """\
Slash commands:
  /help                    show this list
  /clear                   clear the chat panel
  /skin <name>             switch skin, /skin reload, /skin new
  /model <name>            switch model (substring of GGUF filename)
  /memory                  open the memories viewer
  /soul                    show the soul.md path + content
  /soul list               list bundled soul templates (current marked)
  /soul use <name>         swap soul.md to a template (backs up current)
  /soul reset              re-apply the active template, discarding edits
  /soul restore            undo the last switch/reset (swap with backup)
  /soul edit               open soul.md in the default editor
  /soul reload             re-read soul.md (also auto-reloads on every turn)
  /lock                    plan-mode (no tools execute)
  /unlock                  back to default mode
  /forget all              clear long-term memory (asks for confirmation)
  /calibrate [verbose]     re-run model calibration probes (verbose = full output)
  /hints on|off|toggle     show auto-detected tool hints in chat (brain always sees them)
"""


class _InputBox(QPlainTextEdit):
    """QPlainTextEdit that sends on Enter, newline on Shift+Enter."""

    submit_requested = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setTabChangesFocus(True)
        # QPlainTextEdit is plain by definition — no setAcceptRichText needed.
        self.setMaximumHeight(110)
        self.setMinimumHeight(36)

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                # Allow newline
                super().keyPressEvent(event)
                return
            self.submit_requested.emit()
            event.accept()
            return
        super().keyPressEvent(event)


class ChatWindow(QWidget):
    """Floating chat panel for talking to Navi."""

    submitted = Signal(str)
    stop_requested = Signal()
    retry_requested = Signal(str)
    slash_command = Signal(str, str)  # (command, argument)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent, Qt.WindowType.Tool)
        self.setWindowTitle("Navi — chat")
        self.resize(560, 660)
        self.setStyleSheet("background: #161616;")

        # Quick-action toolbar (preset prompts)
        quick_row = QHBoxLayout()
        quick_row.setContentsMargins(8, 6, 8, 0)
        quick_row.setSpacing(6)
        for label, prompt in (
            ("📋 clipboard", "What's on my clipboard?"),
            ("🖥 screen", "What's on my screen right now?"),
            ("🪟 windows", "What windows do I have open?"),
            ("✨ memory", "What do you remember about me?"),
        ):
            btn = QPushButton(label, self)
            btn.setStyleSheet(_QUICK_STYLE)
            btn.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda _checked=False, p=prompt: self._submit_text(p))
            quick_row.addWidget(btn)
        quick_row.addStretch()

        # Conversation history
        self._history = QTextEdit(self)
        self._history.setReadOnly(True)
        self._history.setStyleSheet(_HISTORY_STYLE)
        font = QFont("Cascadia Mono")
        if not font.exactMatch():
            font.setFamily("Consolas")
        font.setPointSize(10)
        self._history.setFont(font)
        self._first_block = True

        # Status strip
        self._status = QLabel("starting…", self)
        self._status.setStyleSheet(_STATUS_STYLE)

        # Inline action bar (shown when permission is needed for low/medium-risk tools)
        self._action_bar = QWidget(self)
        self._action_bar.setObjectName("actionBar")
        self._action_bar.setStyleSheet(_ACTION_BAR_STYLE)
        self._action_label = QLabel("", self._action_bar)
        self._action_label.setObjectName("actionLabel")
        self._action_label.setWordWrap(True)
        self._action_allow_btn = QPushButton("Allow", self._action_bar)
        self._action_allow_btn.setObjectName("actionAllow")
        self._action_deny_btn = QPushButton("Deny", self._action_bar)
        self._action_deny_btn.setObjectName("actionDeny")
        action_layout = QHBoxLayout(self._action_bar)
        action_layout.setContentsMargins(8, 4, 8, 4)
        action_layout.setSpacing(6)
        action_layout.addWidget(self._action_label, 1)
        action_layout.addWidget(self._action_allow_btn)
        action_layout.addWidget(self._action_deny_btn)
        self._action_bar.hide()
        self._pending_response_queue = None
        # Track connection tokens so we can disconnect THIS specific
        # binding on the next show_inline_permission without the
        # bare-disconnect RuntimeWarning on first call.
        self._action_allow_conn = None
        self._action_deny_conn = None

        # Input row
        self._input = _InputBox(self)
        self._input.setStyleSheet(_INPUT_STYLE)
        self._input.setPlaceholderText("Message Navi…  (Shift+Enter for newline, /help for commands)")
        self._input.submit_requested.connect(self._send)

        self._send_btn = QPushButton("Send", self)
        self._send_btn.setStyleSheet(_SEND_STYLE)
        self._send_btn.clicked.connect(self._send)

        self._stop_btn = QPushButton("Stop", self)
        self._stop_btn.setStyleSheet(_STOP_STYLE)
        self._stop_btn.setEnabled(False)
        self._stop_btn.clicked.connect(self.stop_requested.emit)

        self._retry_btn = QPushButton("Retry", self)
        self._retry_btn.setStyleSheet(_RETRY_STYLE)
        self._retry_btn.setVisible(False)
        self._retry_btn.clicked.connect(self._on_retry_clicked)

        row = QHBoxLayout()
        row.setContentsMargins(8, 8, 8, 8)
        row.addWidget(self._input, 1)
        btn_col = QVBoxLayout()
        btn_col.setSpacing(4)
        btn_col.addWidget(self._send_btn)
        btn_col.addWidget(self._stop_btn)
        btn_col.addWidget(self._retry_btn)
        row.addLayout(btn_col)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addLayout(quick_row)
        layout.addWidget(self._history, 1)
        layout.addWidget(self._action_bar)
        layout.addWidget(self._status)
        layout.addLayout(row)

        self._streaming = False
        self._input_enabled = False
        self._stream_start_position: int | None = None
        self._stream_buffer: list[str] = []
        self._last_user_message: str | None = None
        self._set_input_enabled(False)

        self._maybe_restore_history()

    # --- public API ---------------------------------------------------------
    def set_status(self, text: str) -> None:
        self._status.setText(text)

    def enable_input(self, enabled: bool) -> None:
        self._input_enabled = enabled
        if not self._streaming:
            self._set_input_enabled(enabled)

    def append_user(self, text: str) -> None:
        self._before_block()
        self._history.insertHtml(
            '<span style="color:#9CDCFE; font-weight:600">you</span> '
        )
        self._history.insertPlainText(text)
        self._last_user_message = text
        self._retry_btn.setVisible(False)
        self._scroll_to_end()
        self._save_history()

    def assistant_started(self) -> None:
        self._streaming = True
        self._stream_buffer = []
        self._set_input_enabled(False)
        self._stop_btn.setEnabled(True)
        self._before_block()
        self._history.insertHtml(
            '<span style="color:#C586C0; font-weight:600">navi</span> '
        )
        cursor = self._history.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        self._stream_start_position = cursor.position()
        self._scroll_to_end()

    def append_token(self, token: str) -> None:
        if not self._streaming:
            return
        self._stream_buffer.append(token)
        cursor = self._history.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        self._history.setTextCursor(cursor)
        self._history.insertPlainText(token)
        self._scroll_to_end()

    def assistant_finished(self) -> None:
        self._streaming = False
        self._stop_btn.setEnabled(False)
        full = "".join(self._stream_buffer).strip()
        if full and self._stream_start_position is not None:
            cursor = self._history.textCursor()
            cursor.setPosition(self._stream_start_position)
            cursor.movePosition(
                QTextCursor.MoveOperation.End,
                QTextCursor.MoveMode.KeepAnchor,
            )
            cursor.removeSelectedText()
            cursor.insertHtml(_markdown_to_html(full))
        self._stream_buffer = []
        self._stream_start_position = None
        self._scroll_to_end()
        self._set_input_enabled(self._input_enabled)
        self._save_history()

    def show_tool_call(self, name: str, args: dict, decision: str) -> None:
        color = {
            "allowed": "#888",
            "user-allowed": "#10B981",
            "denied": "#EF4444",
            "user-denied": "#EF4444",
            "unknown": "#F59E0B",
        }.get(decision, "#888")
        suffix = {
            "denied": " — blocked by policy",
            "user-denied": " — denied by you",
            "user-allowed": " — allowed by you",
            "unknown": " — unknown tool",
        }.get(decision, "")
        args_text = ""
        if args:
            args_text = " " + ", ".join(f"{k}={v!r}" for k, v in args.items())
        self._before_block()
        self._history.insertHtml(
            f'<span style="color:{color}; font-style:italic">'
            f"⚙ {self._escape(name + args_text + suffix)}"
            f"</span>"
        )
        self._scroll_to_end()

    def show_tool_result(self, name: str, result: str) -> None:
        """Render rich tool results inline.

        Currently special-cases image generation: when a result contains
        a ``file:///…(png|jpg|jpeg|webp)`` URL, embed the image in the
        chat. Other results aren't rendered (they'd spam the chat with
        large file contents); the assistant's own narration covers them.
        """
        import re as _re
        match = _re.search(
            r"(file:///[^\s\"]+\.(?:png|jpe?g|webp|gif|bmp))",
            result, _re.IGNORECASE,
        )
        if not match:
            return
        url = match.group(1)
        self._before_block()
        # Cap displayed width so giant 1024px outputs don't blow up the
        # dock; full-res file is still on disk at the URL.
        self._history.insertHtml(
            f'<div style="margin: 4px 0;">'
            f'<img src="{url}" style="max-width: 360px; '
            f'border: 1px solid #333; border-radius: 6px;" />'
            f'</div>'
        )
        self._scroll_to_end()

    def show_error(self, message: str) -> None:
        self._before_block()
        self._history.insertHtml(
            f'<span style="color:#EF4444; font-weight:600">error</span> '
            f'<span style="color:#EF4444">{self._escape(message)}</span>'
        )
        self._scroll_to_end()
        self._retry_btn.setVisible(self._last_user_message is not None)
        self._save_history()

    def show_divider(self, label: str) -> None:
        self._before_block()
        self._history.insertHtml(
            f'<div style="text-align:center; color:#666; '
            f'border-top:1px solid #333; margin:8px 0; padding-top:6px">'
            f"── {self._escape(label)} ──</div>"
        )
        self._first_block = False
        self._scroll_to_end()
        self._save_history()

    def show_system_note(self, text: str) -> None:
        """Lightweight inline status note (used by slash commands)."""
        self._before_block()
        self._history.insertHtml(
            f'<span style="color:#3B82F6; font-style:italic">{self._escape(text)}</span>'
        )
        self._scroll_to_end()

    def show_inline_permission(
        self,
        tool_name: str,
        args: dict,
        risk: str,
        response_queue,
    ) -> None:
        """Show the in-chat action bar with Allow/Deny buttons.

        ``response_queue`` is a ``queue.Queue`` the worker thread is blocked on;
        clicking a button puts the boolean result in to unblock it.
        """
        # Make sure we're visible — user might have hidden the chat
        self.show()
        self.raise_()

        risk_color = {
            "safe": "#10B981",
            "low": "#3B82F6",
            "medium": "#F59E0B",
            "high": "#EF4444",
        }.get(risk, "#888")
        args_str = (
            ", ".join(f"{k}={v!r}" for k, v in args.items()) if args else "(no args)"
        )
        self._action_label.setText(
            f'<span style="background:{risk_color}; color:white; padding:2px 8px; '
            f'border-radius:10px; font-size:11px; font-weight:600">{risk.upper()}</span>'
            f"  Navi wants to call <code>{self._escape(tool_name)}</code>"
            f'<br><span style="color:#aaa; font-family:Consolas">{self._escape(args_str)}</span>'
        )

        # Disconnect prior bindings via tracked tokens — avoids the
        # bare-disconnect RuntimeWarning on first call.
        if self._action_allow_conn is not None:
            try:
                self._action_allow_btn.clicked.disconnect(self._action_allow_conn)
            except (TypeError, RuntimeError):
                pass
        if self._action_deny_conn is not None:
            try:
                self._action_deny_btn.clicked.disconnect(self._action_deny_conn)
            except (TypeError, RuntimeError):
                pass
        self._pending_response_queue = response_queue
        self._action_allow_conn = self._action_allow_btn.clicked.connect(
            lambda: self._answer_inline(True)
        )
        self._action_deny_conn = self._action_deny_btn.clicked.connect(
            lambda: self._answer_inline(False)
        )

        self._action_bar.show()

    def _answer_inline(self, allowed: bool) -> None:
        if self._pending_response_queue is not None:
            try:
                self._pending_response_queue.put(allowed)
            except Exception:
                pass
        self._pending_response_queue = None
        self._action_bar.hide()

    def export_chat(self) -> None:
        path_str, _ = QFileDialog.getSaveFileName(
            self, "Save chat as…", "navi-chat.md", "Markdown (*.md);;HTML (*.html)"
        )
        if not path_str:
            return
        path = Path(path_str)
        try:
            if path.suffix.lower() == ".html":
                path.write_text(self._history.toHtml(), encoding="utf-8")
            else:
                path.write_text(self._history.document().toMarkdown(), encoding="utf-8")
            self.set_status(f"saved chat to {path.name}")
        except OSError as exc:
            self.set_status(f"save failed: {exc}")

    def clear_history(self) -> None:
        self._history.clear()
        self._first_block = True
        self._last_user_message = None
        self._retry_btn.setVisible(False)
        try:
            p = _chat_history_path()
            if p.exists():
                p.unlink()
        except OSError:
            pass

    # --- internals ----------------------------------------------------------
    def _before_block(self) -> None:
        cursor = self._history.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        self._history.setTextCursor(cursor)
        if self._first_block:
            self._first_block = False
        else:
            self._history.insertPlainText("\n\n")

    def _scroll_to_end(self) -> None:
        sb = self._history.verticalScrollBar()
        sb.setValue(sb.maximum())

    def _set_input_enabled(self, enabled: bool) -> None:
        self._input.setEnabled(enabled)
        self._send_btn.setEnabled(enabled)
        if enabled:
            self._input.setFocus()

    @staticmethod
    def _escape(s: str) -> str:
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    def _send(self) -> None:
        text = self._input.toPlainText().strip()
        if not text:
            return
        self._input.clear()
        if text.startswith("/"):
            if self._handle_slash(text):
                return
        self._submit_text(text)

    def _submit_text(self, text: str) -> None:
        if not self._input_enabled and not self._streaming:
            # Quick action clicked while input was disabled (e.g. model still
            # loading). Re-enable optimistically; submit will still go through
            # the queue.
            self._set_input_enabled(False)
        self.append_user(text)
        self.submitted.emit(text)

    def _on_retry_clicked(self) -> None:
        if not self._last_user_message:
            return
        msg = self._last_user_message
        self._retry_btn.setVisible(False)
        self.append_user(msg)
        self.retry_requested.emit(msg)

    # --- slash commands ----------------------------------------------------
    def _handle_slash(self, text: str) -> bool:
        """Return True if the input was handled as a command (don't send to LLM)."""
        parts = text[1:].strip().split(maxsplit=1)
        if not parts:
            return False
        cmd = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""
        if cmd == "help":
            self.show_system_note(_SLASH_HELP)
            return True
        if cmd == "clear":
            self.clear_history()
            return True
        # Forward to PetWindow
        if cmd in ("skin", "model", "memory", "soul", "lock", "unlock",
                   "forget", "calibrate", "hints"):
            self.slash_command.emit(cmd, arg)
            return True
        self.show_system_note(f"unknown command: /{cmd}  (try /help)")
        return True

    # --- persistence -------------------------------------------------------
    def _save_history(self) -> None:
        try:
            from navi._io import atomic_write_text
            atomic_write_text(_chat_history_path(), self._history.toHtml())
        except OSError:
            pass

    def _maybe_restore_history(self) -> None:
        path = _chat_history_path()
        if not path.exists():
            return
        try:
            html = path.read_text(encoding="utf-8")
        except OSError:
            return
        if not html.strip():
            return
        self._history.setHtml(html)
        self._first_block = False
        self.show_divider("new session — model history fresh")


_BODY_RE = re.compile(r"<body[^>]*>(.*)</body>", re.DOTALL | re.IGNORECASE)


def _markdown_to_html(md_text: str) -> str:
    doc = QTextDocument()
    doc.setMarkdown(md_text)
    html = doc.toHtml()
    m = _BODY_RE.search(html)
    return m.group(1) if m else html
