from __future__ import annotations

from enum import Enum, auto

from PySide6.QtCore import QObject, Signal


class NaviState(Enum):
    """Single source of truth for the pet's outward state.

    Brain/tool code emits transitions; PetWidget reacts by switching
    Live2D motions/expressions. Pet code never imports brain code.
    """

    IDLE = auto()
    LISTENING = auto()
    THINKING = auto()
    SPEAKING = auto()
    ASKING = auto()
    ERROR = auto()


class StateBus(QObject):
    changed = Signal(NaviState)

    def __init__(self) -> None:
        super().__init__()
        self._state = NaviState.IDLE

    @property
    def state(self) -> NaviState:
        return self._state

    def set(self, new: NaviState) -> None:
        if new is self._state:
            return
        self._state = new
        self.changed.emit(new)
