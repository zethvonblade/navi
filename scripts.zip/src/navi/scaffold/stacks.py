"""Project-stack registry.

Mirrors the shape of ``navi.image.models.MODELS`` exactly — adding a new
stack is one ``StackSpec`` entry plus a template directory under
``templates/<id>/``.

``style_guide`` is the prose block injected into the system prompt when
the stack is active (see ``persona._resolve_stack_context``). Keep these
terse and avoid suggestive nouns ("preferences", "settings") — small
models latch on to those and free-associate (see
feedback_granite_tool_calling memory).

Licensing: scaffold templates and the Navi codebase ship under the same
permissive license. Don't include third-party templates that would
encumber generated projects.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


_TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"


@dataclass(frozen=True)
class StackSpec:
    """Everything the renderer + persona system need about a stack.

    ``template_dir`` is bundled inside the package so installations get
    everything; no network round-trip on first scaffold.
    """

    id: str
    label: str
    language: str
    description: str
    template_dir: Path
    style_guide: str
    lint_cmd: list[str] | None
    format_cmd: list[str] | None


_PYTHON_CLI_GUIDE = (
    "Active stack: Python CLI. Conventions: type hints on every function "
    "signature; snake_case for functions and variables; PascalCase for "
    "classes; entry point in `__main__.py` using stdlib `argparse` (no "
    "Click). After writing or editing a Python file, call `lint_python` "
    "to verify."
)

_PYTHON_PYTEST_LIB_GUIDE = (
    "Active stack: Python pytest library. Conventions: src/ layout; type "
    "hints on every public function; snake_case for functions and "
    "variables; PascalCase for classes; tests under `tests/` named "
    "`test_*.py` using bare `assert` (no unittest). After writing or "
    "editing a Python file, call `lint_python` to verify."
)


STACKS: dict[str, StackSpec] = {
    "python-cli": StackSpec(
        id="python-cli",
        label="Python CLI",
        language="python",
        description="Stdlib argparse CLI with src/ layout and a smoke test.",
        template_dir=_TEMPLATES_DIR / "python-cli",
        style_guide=_PYTHON_CLI_GUIDE,
        lint_cmd=["ruff", "check"],
        format_cmd=["ruff", "format"],
    ),
    "python-pytest-lib": StackSpec(
        id="python-pytest-lib",
        label="Python pytest library",
        language="python",
        description="Importable Python library with src/ layout and pytest scaffolding.",
        template_dir=_TEMPLATES_DIR / "python-pytest-lib",
        style_guide=_PYTHON_PYTEST_LIB_GUIDE,
        lint_cmd=["ruff", "check"],
        format_cmd=["ruff", "format"],
    ),
}

# No registry default — `/stack use <id>` requires explicit choice. Some
# users will never scaffold and shouldn't get a stack injected by surprise.
DEFAULT_STACK_ID: str | None = None


def get_spec(stack_id: str | None) -> StackSpec | None:
    """Return the spec for ``stack_id`` or None if unknown.

    Unlike ``image.models.get_spec`` this returns None on unknown id —
    the caller usually wants to surface "unknown stack: X" rather than
    silently fall back to a default that may not be what the user wanted.
    """
    if not stack_id:
        return None
    return STACKS.get(stack_id)


def list_stacks() -> list[tuple[str, StackSpec]]:
    """Stable-ordered (id, spec) pairs for help text and pickers."""
    return list(STACKS.items())
