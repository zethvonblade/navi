"""Walk a stack template directory, render each file + path component
through Jinja2, write the result to a destination directory.

We don't use cookiecutter — it pulls Click + binaryornot + arrow + a
few more transitives for prompts and post-gen hooks we don't need.
This walker is ~80 lines, stdlib + already-present jinja2.

Atomicity: each file write goes through ``navi._io.atomic_write_text``
so a crash mid-render leaves no half-written ``pyproject.toml``. The
parent directory tree is created lazily as we walk.

Path-template syntax: ``{{project_slug}}`` is allowed in directory
AND file names. ``.j2`` extension is stripped from output filenames.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from jinja2 import Environment, StrictUndefined

from navi._io import atomic_write_text
from navi.scaffold.stacks import StackSpec


_jinja_env = Environment(
    keep_trailing_newline=True,
    undefined=StrictUndefined,  # raises on {{ undefined_var }} — catches typos
    autoescape=False,            # rendering source code, NOT html
)


class ScaffoldError(RuntimeError):
    """Raised when render_stack can't or won't produce the project."""


def _render_text(text: str, vars: dict[str, Any]) -> str:
    return _jinja_env.from_string(text).render(**vars)


def _render_path_component(name: str, vars: dict[str, Any]) -> str:
    """Render a single directory or filename. Strips a trailing ``.j2``
    extension on the way out so ``foo.py.j2`` lands as ``foo.py``."""
    rendered = _render_text(name, vars)
    if rendered.endswith(".j2"):
        rendered = rendered[: -len(".j2")]
    return rendered


def _is_dir_writable(p: Path) -> bool:
    """Check whether ``p`` (a directory that exists) is writable. Walk
    upward to the first existing ancestor so the check works for paths
    we're about to create."""
    cur = p
    while not cur.exists():
        cur = cur.parent
    return os.access(cur, os.W_OK)


def render_stack(
    spec: StackSpec,
    dest: Path,
    vars: dict[str, Any],
    *,
    force: bool = False,
) -> list[Path]:
    """Materialize ``spec`` at ``dest`` with the given template ``vars``.

    Returns the list of files created (absolute paths).

    Refuses if:
    * ``dest`` exists and is non-empty (unless ``force=True``)
    * ``dest`` resolves under a protected system path
    * ``dest.parent`` is not writable
    * any required template variable is missing (StrictUndefined)
    """
    if not spec.template_dir.exists():
        raise ScaffoldError(
            f"Template directory missing: {spec.template_dir}. "
            "The stack registry references a template that wasn't bundled."
        )

    # Reuse the same protected-path guard delete_dir uses — single source
    # of truth for "do not touch this".
    from navi.tools.filesystem import _is_protected_path
    if _is_protected_path(dest):
        raise ScaffoldError(
            f"Refusing to scaffold into a protected system path: {dest}"
        )

    if dest.exists():
        if not dest.is_dir():
            raise ScaffoldError(f"Destination exists and is not a directory: {dest}")
        if any(dest.iterdir()) and not force:
            raise ScaffoldError(
                f"Destination is not empty: {dest}. "
                "Pass force=True to scaffold into it anyway."
            )
    else:
        if not _is_dir_writable(dest):
            raise ScaffoldError(
                f"Destination's parent is not writable: {dest.parent}. "
                "Pick a different location."
            )

    created: list[Path] = []
    src_root = spec.template_dir
    for src_dir, _dirnames, filenames in os.walk(src_root):
        src_dir_path = Path(src_dir)
        rel = src_dir_path.relative_to(src_root)
        # Render every component of the relative directory path so
        # ``src/{{project_slug}}/`` becomes ``src/my_app/``.
        rendered_rel = Path(*[_render_path_component(part, vars)
                              for part in rel.parts]) if rel.parts else Path()
        out_dir = dest / rendered_rel
        out_dir.mkdir(parents=True, exist_ok=True)

        for fname in filenames:
            try:
                out_name = _render_path_component(fname, vars)
                src_file = src_dir_path / fname
                content = src_file.read_text(encoding="utf-8")
                # Render content only if the file had the .j2 marker;
                # plain files (.gitignore etc.) pass through verbatim so
                # literal ``{{`` sequences aren't treated as Jinja.
                if fname.endswith(".j2"):
                    rendered = _render_text(content, vars)
                else:
                    rendered = content
            except Exception as exc:
                raise ScaffoldError(
                    f"Failed rendering {src_file}: {exc}"
                ) from exc

            out_path = out_dir / out_name
            atomic_write_text(out_path, rendered)
            created.append(out_path)

    return created
