"""Project scaffolding + stack-aware system-prompt context.

Two surfaces:

* ``stacks.py`` — registry of project templates (StackSpec).
* ``render.py`` — Jinja2-based template walker that materializes a
  StackSpec into a real project on disk.

The ``navi.tools.scaffold`` and ``navi.tools.code_edit`` tool modules
expose this to the LLM. Slash commands ``/new`` and ``/stack`` provide
the user-facing entry points.
"""
