"""Navi — a MegaMan-PET-style local AI desktop companion."""

__version__ = "0.0.1"
