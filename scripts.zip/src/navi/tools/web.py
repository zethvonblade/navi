"""Web search tool. Network-permitting.

Tries DuckDuckGo's HTML endpoint. Returns top results' titles + snippets +
URLs. If the network blocks it (common on enterprise/.mil networks), returns
a friendly "search blocked" message instead of a raw exception.
"""

from __future__ import annotations

import re
import urllib.parse

from navi.tools._registry import tool

_DDG_HTML = "https://html.duckduckgo.com/html/"
_TIMEOUT = 6.0


@tool(
    name="web_search",
    description=(
        "Search the web (DuckDuckGo) and return the top 5 result titles, "
        "snippets, and URLs. Use for current events / facts beyond the model's "
        "knowledge. Returns a 'blocked' message if the user's network firewalls "
        "search engines."
    ),
    risk="low",
    parameters={
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search query."},
        },
        "required": ["query"],
    },
)
def web_search(query: str) -> str:
    if not query.strip():
        return "Error: query must not be empty."
    try:
        import urllib.request

        url = f"{_DDG_HTML}?q={urllib.parse.quote_plus(query)}"
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Navi/0.1 Safari/537.36",
            },
        )
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            html = resp.read().decode("utf-8", errors="replace")
    except Exception as exc:
        return (
            f"Web search unavailable: {exc.__class__.__name__}. "
            "Your network may block external search engines."
        )

    results = _parse_ddg_html(html)
    if not results:
        return f"No results found for {query!r}."
    formatted: list[str] = []
    for i, r in enumerate(results[:5], 1):
        formatted.append(f"{i}. {r['title']}\n   {r['snippet']}\n   {r['url']}")
    return "\n\n".join(formatted)


# Loose HTML parsing for DDG's /html/ endpoint. Avoids adding a beautifulsoup
# dependency for this single tool.
_RESULT_RE = re.compile(
    r'<a rel="nofollow" class="result__a" href="([^"]+)"[^>]*>(.*?)</a>.*?'
    r'<a class="result__snippet"[^>]*>(.*?)</a>',
    re.DOTALL,
)
_TAG_RE = re.compile(r"<[^>]+>")
_AMP_RE = {"&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&#x27;": "'", "&#39;": "'"}


def _strip(html: str) -> str:
    out = _TAG_RE.sub("", html)
    for a, b in _AMP_RE.items():
        out = out.replace(a, b)
    return out.strip()


def _parse_ddg_html(html: str) -> list[dict[str, str]]:
    results: list[dict[str, str]] = []
    for m in _RESULT_RE.finditer(html):
        raw_url, title_html, snippet_html = m.groups()
        # DDG wraps the URL in a redirect (uddg parameter)
        url = _unwrap_ddg(raw_url)
        results.append(
            {
                "url": url,
                "title": _strip(title_html),
                "snippet": _strip(snippet_html),
            }
        )
    return results


def _unwrap_ddg(raw: str) -> str:
    if "uddg=" in raw:
        try:
            return urllib.parse.unquote(raw.split("uddg=", 1)[1].split("&", 1)[0])
        except Exception:
            return raw
    return raw
