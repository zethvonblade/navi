from __future__ import annotations

from navi.tools._registry import tool


@tool(
    name="focus_window",
    description=(
        "Bring an existing top-level window to the foreground by partial title match "
        "(case-insensitive). If multiple windows match, returns an error listing them."
    ),
    risk="low",
    category="desktop",
    parameters={
        "type": "object",
        "properties": {
            "title": {
                "type": "string",
                "description": "Substring of the window's title bar text.",
            },
        },
        "required": ["title"],
    },
)
def focus_window(title: str) -> str:
    title_lc = title.strip().lower()
    if not title_lc:
        return "Error: title must not be empty."
    try:
        from pywinauto import Desktop
    except ImportError:
        return "Error: pywinauto not installed."
    try:
        wins = Desktop(backend="win32").windows(visible_only=True)
    except Exception as exc:
        return f"Error enumerating windows: {exc}"

    matches = []
    for w in wins:
        try:
            t = (w.window_text() or "").strip()
        except Exception:
            continue
        if t and title_lc in t.lower():
            matches.append((t, w))

    if not matches:
        return f"No window matching '{title}' found."
    if len(matches) > 1:
        joined = "; ".join(t for t, _ in matches[:5])
        return f"Multiple windows match '{title}' ({len(matches)} total): {joined}. Be more specific."
    matched_title, win = matches[0]
    try:
        win.set_focus()
    except Exception as exc:
        return f"Error focusing '{matched_title}': {exc}"
    return f"Focused: {matched_title}"


@tool(
    name="list_windows",
    description="List the titles of all visible top-level desktop windows currently open.",
    risk="safe",

    category="desktop",
    parameters={"type": "object", "properties": {}, "required": []},
)
def list_windows() -> str:
    try:
        from pywinauto import Desktop
    except ImportError:
        return "Error: pywinauto not installed."

    try:
        windows = Desktop(backend="win32").windows(visible_only=True)
    except Exception as exc:
        return f"Error enumerating windows: {exc}"

    titles = []
    for w in windows:
        try:
            title = (w.window_text() or "").strip()
        except Exception:
            continue
        if title:
            titles.append(title)
    if not titles:
        return "(no visible windows)"
    return "\n".join(f"- {t}" for t in titles)
