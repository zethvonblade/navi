from __future__ import annotations

import subprocess

from navi.tools._registry import tool

POWERSHELL_TIMEOUT_SEC = 30
POWERSHELL_MAX_OUTPUT = 8000


@tool(
    name="run_powershell",
    description=(
        "Run a PowerShell command and return its stdout (and stderr if any). "
        "30-second timeout, 8 KB output cap. **High risk** — every call requires "
        "explicit user approval. Use for read-only system queries (Get-Process, "
        "Get-Service, Get-ChildItem) when no better tool exists."
    ),
    risk="high",
    parameters={
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "The PowerShell command(s) to execute.",
            },
        },
        "required": ["command"],
    },
)
def run_powershell(command: str) -> str:
    if not command.strip():
        return "Error: command must not be empty."
    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", command],
            capture_output=True,
            text=True,
            timeout=POWERSHELL_TIMEOUT_SEC,
        )
    except subprocess.TimeoutExpired:
        return f"Error: PowerShell command timed out after {POWERSHELL_TIMEOUT_SEC}s."
    except FileNotFoundError:
        return "Error: powershell.exe not found on PATH."
    except OSError as exc:
        return f"Error running PowerShell: {exc}"

    stdout = (result.stdout or "").strip()
    stderr = (result.stderr or "").strip()

    if result.returncode != 0:
        out = f"Exit {result.returncode}"
        if stderr:
            out += f"\nstderr:\n{stderr}"
        if stdout:
            out += f"\nstdout:\n{stdout}"
    else:
        out = stdout
        if stderr:
            out = f"{out}\n[stderr]\n{stderr}".strip()

    if len(out) > POWERSHELL_MAX_OUTPUT:
        out = out[:POWERSHELL_MAX_OUTPUT] + f"\n... [truncated to {POWERSHELL_MAX_OUTPUT} chars]"
    return out or "(no output)"
