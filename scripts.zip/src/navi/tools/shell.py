from __future__ import annotations

import subprocess
import sys

from navi.tools._registry import tool

POWERSHELL_TIMEOUT_SEC = 30
POWERSHELL_MAX_OUTPUT = 8000


@tool(
    name="run_powershell",
    description=(
        "Run a PowerShell command and return its stdout (and stderr if any). "
        "30-second timeout, 8 KB output cap. **High risk** — every call requires "
        "explicit user approval. Use for read-only system queries (Get-Process, "
        "Get-Service, Get-ChildItem) when no better tool exists."
    ),
    risk="high",
    category="shell",
    parameters={
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "The PowerShell command(s) to execute.",
            },
        },
        "required": ["command"],
    },
)
def run_powershell(command: str) -> str:
    if not command.strip():
        return "Error: command must not be empty."
    # CREATE_NEW_PROCESS_GROUP gives PowerShell its own group so we can
    # tree-kill it on timeout — subprocess.run's built-in timeout only kills
    # the immediate child, leaving any grandchildren PowerShell spawned alive.
    creationflags = 0
    if sys.platform == "win32":
        creationflags = subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]
    try:
        proc = subprocess.Popen(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", command],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            creationflags=creationflags,
        )
    except FileNotFoundError:
        return "Error: powershell.exe not found on PATH."
    except OSError as exc:
        return f"Error running PowerShell: {exc}"

    try:
        stdout, stderr = proc.communicate(timeout=POWERSHELL_TIMEOUT_SEC)
        rc = proc.returncode
    except subprocess.TimeoutExpired:
        # Tree-kill so any child processes PowerShell launched also die.
        if sys.platform == "win32":
            subprocess.run(
                ["taskkill", "/T", "/F", "/PID", str(proc.pid)],
                capture_output=True, check=False,
            )
        else:
            proc.kill()
        try:
            proc.communicate(timeout=2)
        except subprocess.TimeoutExpired:
            pass
        return f"Error: PowerShell command timed out after {POWERSHELL_TIMEOUT_SEC}s."

    # Mimic subprocess.CompletedProcess interface for the rest of the function.
    class _R:
        pass
    result = _R()
    result.stdout = stdout
    result.stderr = stderr
    result.returncode = rc

    stdout = (result.stdout or "").strip()
    stderr = (result.stderr or "").strip()

    if result.returncode != 0:
        out = f"Exit {result.returncode}"
        if stderr:
            out += f"\nstderr:\n{stderr}"
        if stdout:
            out += f"\nstdout:\n{stdout}"
    else:
        out = stdout
        if stderr:
            out = f"{out}\n[stderr]\n{stderr}".strip()

    if len(out) > POWERSHELL_MAX_OUTPUT:
        out = out[:POWERSHELL_MAX_OUTPUT] + f"\n... [truncated to {POWERSHELL_MAX_OUTPUT} chars]"
    return out or "(no output)"
