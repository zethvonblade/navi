from __future__ import annotations

import time

from navi.tools._registry import tool


@tool(
    name="type_text",
    description=(
        "Simulate typing text on the keyboard into the currently focused window. "
        "Newlines (\\n) are typed as Enter. Use after open_app or focus_window to "
        "enter text into a target application. **High risk** — typing into the "
        "wrong window can have destructive effects, so every call requires "
        "explicit user approval."
    ),
    risk="high",
    category="desktop",
    parameters={
        "type": "object",
        "properties": {
            "text": {
                "type": "string",
                "description": "Text to type. Use \\n for new lines.",
            },
        },
        "required": ["text"],
    },
)
def type_text(text: str) -> str:
    if not text:
        return "Error: text must not be empty."
    try:
        import pyautogui
    except ImportError:
        return "Error: pyautogui not installed."

    # Granite frequently double-escapes when emitting JSON: ``"text": "a\\nb"``
    # decodes to literal "a\nb" (backslash-n) rather than a newline. Normalize
    # common escape sequences so the user gets what they obviously meant.
    text = (
        text.replace("\\n", "\n")
        .replace("\\t", "\t")
        .replace("\\r", "\r")
    )

    # Brief pause so the user sees the orange ASKING -> THINKING transition
    # before typing starts. Helps catch a wrong-focus situation visually.
    time.sleep(0.3)

    lines = text.split("\n")
    try:
        for i, line in enumerate(lines):
            if line:
                pyautogui.write(line, interval=0.01)
            if i < len(lines) - 1:
                pyautogui.press("enter")
    except Exception as exc:
        return f"Error typing text: {exc}"
    return f"Typed {len(text)} characters across {len(lines)} line(s)."
