from __future__ import annotations

import pyperclip

from navi.tools._registry import tool


@tool(
    name="read_clipboard",
    description="Read the current Windows clipboard text contents. Returns the text or '(empty)'.",
    risk="safe",
    parameters={"type": "object", "properties": {}, "required": []},
)
def read_clipboard() -> str:
    try:
        text = pyperclip.paste() or ""
    except pyperclip.PyperclipException as exc:
        return f"Error reading clipboard: {exc}"
    return text if text else "(empty)"


@tool(
    name="write_clipboard",
    description="Set the Windows clipboard text contents (overwrites whatever is currently there).",
    risk="low",
    parameters={
        "type": "object",
        "properties": {
            "text": {"type": "string", "description": "Text to place on the clipboard."},
        },
        "required": ["text"],
    },
)
def write_clipboard(text: str) -> str:
    try:
        pyperclip.copy(text)
    except pyperclip.PyperclipException as exc:
        return f"Error writing clipboard: {exc}"
    return f"Wrote {len(text)} chars to clipboard."
