from __future__ import annotations

from navi.memory.store import VALID_TYPES, save_memory, search
from navi.tools._registry import tool


@tool(
    name="remember",
    description=(
        "Save a durable fact to long-term memory so it can be recalled in "
        "future conversations. Call this when the user asks you to remember "
        "something, shares a preference, or mentions a fact about themselves "
        "or their work that would be useful next session."
    ),
    risk="low",

    category="core",
    parameters={
        "type": "object",
        "properties": {
            "title": {
                "type": "string",
                "description": "Short title for the memory (3-7 words).",
            },
            "content": {
                "type": "string",
                "description": "The fact to remember (1-3 sentences).",
            },
            "type": {
                "type": "string",
                "description": "Memory category.",
                "enum": list(VALID_TYPES),
            },
            "description": {
                "type": "string",
                "description": "Optional one-line hook shown in the index. Defaults to a truncation of content.",
            },
        },
        "required": ["title", "content", "type"],
    },
)
def remember(title: str, content: str, type: str, description: str | None = None) -> str:
    desc = description or content.strip().split("\n")[0][:120]
    try:
        path = save_memory(title=title, description=desc, type=type, content=content)
    except ValueError as exc:
        return f"Error: {exc}"
    except OSError as exc:
        return f"Error writing memory: {exc}"
    return f"Saved memory '{title}' to {path.name}."


@tool(
    name="recall",
    description=(
        "Search long-term memory for facts relevant to a query. Returns the "
        "top matching memory snippets. Use this whenever the user asks about "
        "their preferences, prior decisions, or anything you might have "
        "saved with the remember tool in a past session."
    ),
    risk="safe",

    category="core",
    parameters={
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Words to search for in the saved memories.",
            },
        },
        "required": ["query"],
    },
)
def recall(query: str) -> str:
    hits = search(query, limit=3)
    if not hits:
        return f"No memories matched {query!r}."
    parts: list[str] = []
    for score, mem in hits:
        parts.append(
            f"### {mem.name}  ({mem.type}, score {score})\n"
            f"{mem.description}\n\n{mem.body}"
        )
    return "\n\n---\n\n".join(parts)
