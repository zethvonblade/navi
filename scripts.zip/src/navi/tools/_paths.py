"""Best-effort path repair for model-emitted strings.

Small local LLMs (Granite 3.x in particular) frequently emit Unix-style paths
on Windows because their training data is Linux-heavy. Without normalization,
``/Users/SinghMa/Documents/foo`` is rejected as non-absolute, the tool errors
out, and the agent loop spirals trying variations of the same wrong path.

We normalize once in the agent dispatcher *before* the permission check, so:
  - normalized paths match `read_file(C:/Users/SinghMa/**)` allow rules
  - the actual filesystem call succeeds against the real path
"""

from __future__ import annotations

import os


def normalize_windows_path(raw: str) -> str:
    """Map common Unix-style root paths to their Windows equivalents.

    Examples (on Windows with USERPROFILE=C:\\Users\\SinghMa)::

        normalize_windows_path('/Users/SinghMa/Documents/x.txt')
        # -> 'C:\\Users\\SinghMa\\Documents\\x.txt'

        normalize_windows_path('/home/singhma/notes.md')
        # -> 'C:\\Users\\SinghMa\\notes.md'

        normalize_windows_path('C:/Users/SinghMa/Documents/x.txt')
        # -> 'C:\\Users\\SinghMa\\Documents\\x.txt'  (slashes normalized)

        normalize_windows_path('relative/path.txt')
        # -> 'relative/path.txt'  (unchanged; tool will reject as non-absolute)
    """
    if not raw:
        return raw

    # Already a valid Windows-style absolute path? Just normalize separators.
    if len(raw) >= 2 and raw[1] == ":" and raw[0].isalpha():
        return raw.replace("/", "\\")

    # /Users/<name>/... -> C:\Users\<name>\...
    if raw.startswith(("/Users/", "/users/")):
        return "C:\\Users\\" + raw[len("/Users/") :].replace("/", "\\")

    # /home/<name>/... -> C:\Users\<name>\...  (best guess; case-folded)
    if raw.startswith("/home/"):
        rest = raw[len("/home/") :]
        # Honor the actual logged-in username's casing if it's the same person.
        userprofile = os.environ.get("USERPROFILE", "")
        if userprofile:
            user_dir = os.path.basename(userprofile)
            head, sep, tail = rest.partition("/")
            if head.lower() == user_dir.lower():
                rest = user_dir + sep + tail
        return "C:\\Users\\" + rest.replace("/", "\\")

    # Bare /Documents, /Desktop, etc -> %USERPROFILE%\Documents\...
    if raw.startswith("/") and not raw.startswith("//"):
        userprofile = os.environ.get("USERPROFILE")
        if userprofile:
            return os.path.join(userprofile, raw.lstrip("/").replace("/", "\\"))

    return raw
