"""LLM-callable wrappers around the scaffolding renderer + ruff.

* ``list_stacks``      — what's available (safe, read-only).
* ``scaffold_project`` — render a stack to disk (high-risk: writes
                         executable code into a user-chosen path).
* ``lint_python``      — run ``ruff check`` (safe, read-only).
* ``format_python``    — run ``ruff format`` (medium: rewrites files).

``ruff`` is the project's pinned dev dependency (already on the .venv
PATH); we shell out the same way ``run_powershell`` does.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

from navi.tools._registry import tool


_PROJECT_NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9 _-]{0,63}$")


def _slugify(name: str) -> str:
    """Project slug: lowercased, non-alphanumerics → underscore.

    ``my-cool app`` → ``my_cool_app``. PEP 8 module name; usable as a
    Python identifier (the templates import it as one).
    """
    s = name.strip().lower()
    s = re.sub(r"[^a-z0-9]+", "_", s)
    s = s.strip("_")
    return s or "project"


@tool(
    name="list_stacks",
    description=(
        "List the available project stacks (templates) Navi can scaffold. "
        "Call this first when the user wants to start a new project so "
        "you can show them options before calling scaffold_project."
    ),
    risk="safe",
    category="code",
    parameters={"type": "object", "properties": {}, "required": []},
)
def list_stacks() -> str:
    from navi.scaffold.stacks import list_stacks as _list
    pairs = _list()
    if not pairs:
        return "(no stacks registered)"
    lines = ["Available stacks:"]
    for sid, spec in pairs:
        lines.append(f"  {sid:25} — {spec.label} ({spec.language})")
        lines.append(f"  {'':25}   {spec.description}")
    return "\n".join(lines)


@tool(
    name="scaffold_project",
    description=(
        "Create a new project from a stack template. Writes an entire "
        "project tree (pyproject.toml, src/, tests/, README, .gitignore) "
        "into dest_path/<project_name_slugged>. Call list_stacks first "
        "if you don't already know stack_id. Refuses to write into "
        "non-empty directories or protected system paths."
    ),
    risk="high",
    category="code",
    parameters={
        "type": "object",
        "properties": {
            "stack_id": {
                "type": "string",
                "description": "Stack id from list_stacks (e.g. 'python-cli').",
            },
            "project_name": {
                "type": "string",
                "description": "Human-readable project name (e.g. 'My Cool Tool'). "
                               "Slugified to a valid Python identifier for the "
                               "package name (my_cool_tool).",
            },
            "dest_path": {
                "type": "string",
                "description": "Absolute parent directory. The project will "
                               "be created at <dest_path>/<slug>.",
            },
            "description": {
                "type": "string",
                "description": "Optional one-line project description used in "
                               "pyproject.toml and the README.",
            },
        },
        "required": ["stack_id", "project_name", "dest_path"],
    },
)
def scaffold_project(
    stack_id: str,
    project_name: str,
    dest_path: str,
    description: str = "",
) -> str:
    if not project_name or not _PROJECT_NAME_RE.match(project_name):
        return (
            f"Error: project_name must start with a letter and contain only "
            f"letters, digits, spaces, underscores, or hyphens (≤64 chars). "
            f"Got: {project_name!r}"
        )

    from navi.scaffold.render import ScaffoldError, render_stack
    from navi.scaffold.stacks import get_spec

    spec = get_spec(stack_id)
    if spec is None:
        from navi.scaffold.stacks import list_stacks as _list
        known = ", ".join(sid for sid, _ in _list())
        return f"Error: unknown stack_id {stack_id!r}. Known: {known}"

    parent = Path(dest_path)
    if not parent.is_absolute():
        return f"Error: dest_path must be absolute: {dest_path}"

    slug = _slugify(project_name)
    dest = parent / slug

    vars: dict[str, object] = {
        "project_name": project_name.strip(),
        "project_slug": slug,
        "description": description.strip(),
        "author": os.environ.get("USERNAME") or "Unknown",
        "year": __import__("datetime").datetime.now().year,
        # Derived from the running interpreter — most likely to match
        # what the user will run the scaffold with.
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}",
    }

    try:
        created = render_stack(spec, dest, vars)
    except ScaffoldError as exc:
        return f"Error: {exc}"
    except Exception as exc:  # noqa: BLE001
        return f"Error: scaffold failed: {exc}"

    summary = [
        f"Scaffolded {spec.label} at {dest}",
        f"Files created: {len(created)}",
    ]
    # Show first ~15 paths so the user (and the LLM, summarizing) sees
    # the shape of the project without 100s of bytes of file paths.
    rel_paths = sorted(str(p.relative_to(dest)) for p in created)
    summary.append("")
    for p in rel_paths[:15]:
        summary.append(f"  {p}")
    if len(rel_paths) > 15:
        summary.append(f"  ... +{len(rel_paths) - 15} more")

    # Best-effort git auto-init so the user can immediately git_branch_create
    # without needing a separate git_init call. Failures here don't fail the
    # scaffold — the files are on disk regardless.
    try:
        from navi.settings.store import load as load_settings
        scaffold_cfg = load_settings().get("scaffold") or {}
    except Exception:  # noqa: BLE001
        scaffold_cfg = {}
    if scaffold_cfg.get("git_init_on_scaffold", True):
        git_summary = _git_init_and_commit(dest, stack_id)
        if git_summary:
            summary.append("")
            summary.append(git_summary)

    summary.append("")
    summary.append(
        f"Next: cd {dest} && pip install -e . && pytest"
    )
    return "\n".join(summary)


def _git_init_and_commit(dest: Path, stack_id: str) -> str:
    """Init the scaffold as a git repo and make the initial commit.

    Returns a one-line summary, or an empty string if git wasn't
    available (in which case we silently skip — git init is a UX
    nicety, not a requirement of scaffolding).
    """
    from navi.tools.git_ops import _run_git
    init = _run_git(str(dest), ["init"], require_repo=False)
    # Friendly-install message means git isn't on PATH; skip silently.
    if init.startswith("Error: `git` not found"):
        return ""
    if init.startswith("Error") or init.startswith("Exit"):
        return f"⚠ git auto-init skipped: {init.splitlines()[0]}"
    add = _run_git(str(dest), ["add", "."])
    if add.startswith("Error") or add.startswith("Exit"):
        return f"⚠ git auto-init: init OK but `git add .` failed: {add.splitlines()[0]}"
    commit = _run_git(str(dest), ["commit", "-m", f"Initial scaffold ({stack_id})"])
    if commit.startswith("Error") or commit.startswith("Exit"):
        return f"⚠ git auto-init: staged but commit failed (likely missing user.name/email): {commit.splitlines()[0]}"
    return f"git: initialized + initial commit on {dest}"


# ---------------------------------------------------------------------------
# ruff wrappers
# ---------------------------------------------------------------------------


def _resolve_ruff() -> str | None:
    """Find ruff: the .venv binary first, then PATH."""
    venv_bin = (
        Path(sys.executable).parent / ("ruff.exe" if os.name == "nt" else "ruff")
    )
    if venv_bin.exists():
        return str(venv_bin)
    return shutil.which("ruff")


def _run_ruff(args: list[str], path: str, *, capture: bool = True) -> str:
    ruff = _resolve_ruff()
    if ruff is None:
        return (
            "Error: `ruff` not found on PATH. Install with: "
            ".venv/Scripts/python.exe -m pip install ruff"
        )
    p = Path(path)
    if not p.is_absolute():
        return f"Error: path must be absolute: {path}"
    if not p.exists():
        return f"Error: path does not exist: {path}"
    try:
        result = subprocess.run(
            [ruff, *args, str(p)],
            capture_output=capture,
            text=True,
            timeout=30,
        )
    except subprocess.TimeoutExpired:
        return "Error: ruff timed out after 30s"
    out = (result.stdout or "") + (result.stderr or "")
    out = out.strip() or "(no output)"
    if len(out) > 8000:
        out = out[:8000] + "\n... [truncated]"
    return f"exit: {result.returncode}\n{out}"


@tool(
    name="lint_python",
    description=(
        "Run `ruff check` on a Python file or directory. Reports style "
        "and lint issues without modifying anything. Call this after "
        "writing a Python file to verify it compiles and follows "
        "conventions."
    ),
    risk="safe",

    category="code",
    parameters={
        "type": "object",
        "properties": {
            "path": {"type": "string",
                     "description": "Absolute path to a .py file or a directory."},
        },
        "required": ["path"],
    },
)
def lint_python(path: str) -> str:
    return _run_ruff(["check"], path)


@tool(
    name="format_python",
    description=(
        "Run `ruff format` on a Python file or directory. Modifies files "
        "in place to apply standard formatting (line length, quotes, "
        "trailing commas). Use after lint_python flags style issues you "
        "want fixed automatically."
    ),
    risk="medium",
    category="code",
    parameters={
        "type": "object",
        "properties": {
            "path": {"type": "string",
                     "description": "Absolute path to a .py file or a directory."},
        },
        "required": ["path"],
    },
)
def format_python(path: str) -> str:
    return _run_ruff(["format"], path)
