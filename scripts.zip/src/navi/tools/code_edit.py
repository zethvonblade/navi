"""AST-validated, format-preserving code edits for Python files.

Why no ``ast.unparse``
----------------------
``ast.parse(src) → ast.unparse(tree)`` is destructive on real source
files: comments are dropped, string quotes are normalized, blank lines
are collapsed, long lines reflow. Calling that on a user's hand-written
file would diff-bomb every untouched line on the first invocation.

Strategy here:
1. Parse the LLM-provided snippet with ``ast`` to **validate** that it
   has the expected shape (single import / single def / single class).
2. Parse the **target file** with ``ast`` to find safe insertion line
   numbers and to detect duplicates (idempotency).
3. Do a **textual splice** — slice the file's source, insert the
   snippet, join. Comments and formatting in untouched regions stay
   byte-identical.
4. Re-parse the result to confirm overall syntactic validity. If the
   re-parse fails the tool bails and leaves the file untouched.

All three tools are ``risk="high"`` — they write executable code into
arbitrary files the user owns. Permission dialog shows the path so the
user can spot a stray write target.
"""

from __future__ import annotations

import ast
from pathlib import Path

from navi._io import atomic_write_text
from navi.tools._registry import tool


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _read_file_lines(path: Path) -> tuple[list[str], str]:
    """Read the file. Returns (lines_keepends, raw_source).

    Lines are kept WITH their line terminators so splice + join roundtrips
    losslessly.
    """
    raw = path.read_text(encoding="utf-8")
    lines = raw.splitlines(keepends=True)
    return lines, raw


def _validate_python_source(text: str, label: str) -> ast.Module | str:
    """Return a Module on success, or an error string."""
    try:
        return ast.parse(text)
    except SyntaxError as exc:
        return (
            f"Error: {label} is not valid Python: "
            f"{exc.msg} at line {exc.lineno}"
        )


def _module_docstring_end_line(module: ast.Module) -> int:
    """If the module starts with a docstring, return its 1-based end
    line; else 0."""
    if not module.body:
        return 0
    first = module.body[0]
    if (
        isinstance(first, ast.Expr)
        and isinstance(first.value, ast.Constant)
        and isinstance(first.value.value, str)
    ):
        return first.end_lineno or 0
    return 0


def _last_import_end_line(module: ast.Module) -> int:
    """Return the 1-based end line of the LAST top-level import, or 0
    if the module has no imports."""
    last = 0
    for node in module.body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            last = max(last, node.end_lineno or 0)
    return last


def _toplevel_names(module: ast.Module) -> set[str]:
    """Collect names of top-level def/async def/class for duplicate checks."""
    names: set[str] = set()
    for node in module.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
    return names


def _import_already_present(module: ast.Module, mod: str, names: list[str]) -> bool:
    """Idempotency check: is this exact import already in the file?

    ``names == []`` means ``import <mod>``; non-empty means
    ``from <mod> import <names>`` — every requested name must be covered.
    """
    if not names:
        for node in module.body:
            if isinstance(node, ast.Import):
                if any(alias.name == mod for alias in node.names):
                    return True
        return False
    # from-import: each requested name must already be imported FROM mod.
    have: set[str] = set()
    for node in module.body:
        if isinstance(node, ast.ImportFrom) and node.module == mod and node.level == 0:
            have.update(alias.name for alias in node.names)
    return all(n in have for n in names)


def _splice(lines: list[str], at_line: int, snippet: str) -> str:
    """Insert ``snippet`` (already terminated with \\n) at line index
    ``at_line`` (0-based: 0 = before line 1; len(lines) = end of file)."""
    head = "".join(lines[:at_line])
    tail = "".join(lines[at_line:])
    # Ensure exactly one blank line BEFORE snippet when there's content
    # above. Don't add a blank when inserting at the very top.
    if head and not head.endswith("\n\n"):
        if not head.endswith("\n"):
            head += "\n"
    return head + snippet + tail


def _ensure_trailing_blank(snippet: str) -> str:
    """Snippets should end with exactly one blank line so the next
    block in the file has breathing room."""
    snippet = snippet.rstrip("\n") + "\n"
    return snippet


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


@tool(
    name="add_python_import",
    description=(
        "Add an import to a Python file. If `names` is empty, inserts "
        "`import <module>`; otherwise `from <module> import <names>` "
        "(comma-separated). Idempotent — does nothing if the same import "
        "is already present. Preserves all existing comments and "
        "formatting."
    ),
    risk="high",
    category="code",
    parameters={
        "type": "object",
        "properties": {
            "file_path": {"type": "string",
                          "description": "Absolute path to the .py file."},
            "module": {"type": "string",
                       "description": "Module name (e.g. 'os', 'pathlib')."},
            "names": {"type": "string",
                      "description": "Comma-separated names for `from X import ...` "
                                     "(e.g. 'Path, PurePath'). Leave empty for "
                                     "plain `import X`."},
        },
        "required": ["file_path", "module"],
    },
)
def add_python_import(file_path: str, module: str, names: str = "") -> str:
    p = Path(file_path)
    if not p.is_absolute():
        return f"Error: file_path must be absolute: {file_path}"
    if not p.exists():
        return f"Error: file does not exist: {file_path}"
    if p.suffix != ".py":
        return f"Error: not a Python file: {file_path}"
    if not module or not module.strip():
        return "Error: module is required"

    name_list = [n.strip() for n in names.split(",") if n.strip()] if names else []

    lines, raw = _read_file_lines(p)
    parsed = _validate_python_source(raw, f"existing file {p.name}")
    if isinstance(parsed, str):
        return parsed

    if _import_already_present(parsed, module.strip(), name_list):
        return f"OK (no-op): import already present in {p}"

    # Build the import statement.
    if name_list:
        snippet = f"from {module.strip()} import {', '.join(name_list)}\n"
    else:
        snippet = f"import {module.strip()}\n"

    # Insertion line: after the last existing import; else after the
    # module docstring; else at the very top.
    last_import = _last_import_end_line(parsed)
    if last_import:
        at_line = last_import  # insert AFTER end_lineno (1-based) → index = end_lineno
    else:
        ds_end = _module_docstring_end_line(parsed)
        at_line = ds_end if ds_end else 0

    new_text = _splice(lines, at_line, snippet)

    # Defense in depth: re-parse to confirm we didn't somehow break the file.
    revalidate = _validate_python_source(new_text, "post-splice file")
    if isinstance(revalidate, str):
        return f"{revalidate}\n(file untouched)"

    atomic_write_text(p, new_text)
    return f"Added '{snippet.strip()}' to {p}"


def _add_toplevel_block(
    file_path: str,
    source: str,
    expected: type[ast.AST],
    label: str,
) -> str:
    """Shared implementation for add_python_function / add_python_class.

    Validates source has exactly one top-level node of ``expected`` type,
    checks for name collision with existing top-level def/class, then
    appends to the file with appropriate spacing.
    """
    p = Path(file_path)
    if not p.is_absolute():
        return f"Error: file_path must be absolute: {file_path}"
    if not p.exists():
        return f"Error: file does not exist: {file_path}"
    if p.suffix != ".py":
        return f"Error: not a Python file: {file_path}"
    if not source or not source.strip():
        return f"Error: source is required (a complete {label} definition)"

    snippet_module = _validate_python_source(source, f"{label} source")
    if isinstance(snippet_module, str):
        return snippet_module
    body = snippet_module.body
    # AsyncFunctionDef is acceptable wherever FunctionDef is acceptable.
    allowed: tuple[type[ast.AST], ...]
    if expected is ast.FunctionDef:
        allowed = (ast.FunctionDef, ast.AsyncFunctionDef)
    else:
        allowed = (expected,)
    if len(body) != 1 or not isinstance(body[0], allowed):
        return (
            f"Error: source must contain exactly one top-level {label} "
            f"definition; got {len(body)} statement(s) of types "
            f"{[type(n).__name__ for n in body]}"
        )
    new_name = body[0].name  # type: ignore[attr-defined]

    lines, raw = _read_file_lines(p)
    parsed = _validate_python_source(raw, f"existing file {p.name}")
    if isinstance(parsed, str):
        return parsed
    existing = _toplevel_names(parsed)
    if new_name in existing:
        return (
            f"Error: top-level {label} {new_name!r} already exists in {p}. "
            "Edit the existing one or pick a different name."
        )

    # Append to end with one blank line of separation.
    snippet = _ensure_trailing_blank(source)
    if raw and not raw.endswith("\n"):
        prefix = "\n\n"
    elif raw and not raw.endswith("\n\n"):
        prefix = "\n"
    elif raw:
        prefix = ""
    else:
        prefix = ""
    new_text = raw + prefix + snippet

    revalidate = _validate_python_source(new_text, "post-splice file")
    if isinstance(revalidate, str):
        return f"{revalidate}\n(file untouched)"

    atomic_write_text(p, new_text)
    return f"Added {label} {new_name!r} to {p}"


@tool(
    name="add_python_function",
    description=(
        "Append a function definition to a Python file. The `source` "
        "argument must be a complete `def name(...):` (or `async def`) "
        "block — the tool parses it to validate Python syntax and that "
        "it contains exactly one top-level function. Refuses to add a "
        "function whose name already exists at top level. Preserves "
        "all existing comments and formatting in the target file."
    ),
    risk="high",
    category="code",
    parameters={
        "type": "object",
        "properties": {
            "file_path": {"type": "string",
                          "description": "Absolute path to the .py file."},
            "source": {"type": "string",
                       "description": "Complete function source: `def foo(...):` "
                                      "with full body. Indent the body by 4 spaces "
                                      "(no leading indent on the def line)."},
        },
        "required": ["file_path", "source"],
    },
)
def add_python_function(file_path: str, source: str) -> str:
    return _add_toplevel_block(file_path, source, ast.FunctionDef, "function")


@tool(
    name="add_python_class",
    description=(
        "Append a class definition to a Python file. The `source` "
        "argument must be a complete `class Name(...):` block — the "
        "tool parses it to validate Python syntax and that it contains "
        "exactly one top-level class. Refuses to add a class whose name "
        "already exists at top level. Preserves all existing comments "
        "and formatting in the target file."
    ),
    risk="high",
    category="code",
    parameters={
        "type": "object",
        "properties": {
            "file_path": {"type": "string",
                          "description": "Absolute path to the .py file."},
            "source": {"type": "string",
                       "description": "Complete class source: `class Foo:` with "
                                      "full body. No leading indent on the class line."},
        },
        "required": ["file_path", "source"],
    },
)
def add_python_class(file_path: str, source: str) -> str:
    return _add_toplevel_block(file_path, source, ast.ClassDef, "class")


@tool(
    name="replace_lines",
    description=(
        "Replace a range of lines in a file. Lines are 1-based, end "
        "inclusive (so start=10, end=12 replaces three lines). For .py "
        "files the result is re-parsed; if the splice produces invalid "
        "Python the file is left untouched and an error is returned. "
        "Use add_python_function/class for additions; this tool is for "
        "in-place rewrites of an existing block."
    ),
    risk="high",
    category="code",
    parameters={
        "type": "object",
        "properties": {
            "file_path": {"type": "string",
                          "description": "Absolute path to the file."},
            "start_line": {"type": "integer",
                           "description": "First line to replace (1-based)."},
            "end_line": {"type": "integer",
                         "description": "Last line to replace (1-based, inclusive). "
                                        "Equal to start_line replaces a single line."},
            "new_text": {"type": "string",
                         "description": "Replacement text. May contain multiple "
                                        "lines (use \\n). May be empty (deletes "
                                        "the range)."},
        },
        "required": ["file_path", "start_line", "end_line", "new_text"],
    },
)
def replace_lines(file_path: str, start_line: int, end_line: int, new_text: str) -> str:
    p = Path(file_path)
    if not p.is_absolute():
        return f"Error: file_path must be absolute: {file_path}"
    if not p.exists():
        return f"Error: file does not exist: {file_path}"
    if not p.is_file():
        return f"Error: not a regular file: {file_path}"
    try:
        start = int(start_line)
        end = int(end_line)
    except (TypeError, ValueError):
        return "Error: start_line and end_line must be integers"
    if start < 1:
        return f"Error: start_line must be >= 1; got {start}"
    if end < start:
        return f"Error: end_line ({end}) must be >= start_line ({start})"

    lines, raw = _read_file_lines(p)
    if end > len(lines):
        return (
            f"Error: end_line {end} is past end of file "
            f"({len(lines)} lines). Use file_info to check the line count."
        )

    # Normalize new_text to end with a newline so the splice doesn't merge
    # with the line after.
    if new_text and not new_text.endswith("\n"):
        new_text += "\n"

    head = "".join(lines[: start - 1])
    tail = "".join(lines[end:])
    spliced = head + new_text + tail

    # For Python files, re-parse to confirm we didn't break syntax.
    if p.suffix == ".py":
        revalidate = _validate_python_source(spliced, "post-splice file")
        if isinstance(revalidate, str):
            return f"{revalidate}\n(file untouched)"

    atomic_write_text(p, spliced)
    n_replaced = end - start + 1
    n_new = new_text.count("\n") if new_text else 0
    return (
        f"Replaced {n_replaced} line(s) [{start}-{end}] with "
        f"{n_new} new line(s) in {p}"
    )
