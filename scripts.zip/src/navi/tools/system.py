"""System info tools: current time + URL reachability.

Both are stdlib-only — no new dependencies. ``check_url`` uses HEAD
(not GET) so the entire response body never lands in memory.
"""

from __future__ import annotations

import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

from navi.tools._registry import tool


@tool(
    name="get_datetime",
    description=(
        "Return the current date and time. Use this whenever the user "
        "asks 'what time is it', 'what's today's date', or anything that "
        "depends on knowing 'now' — the LLM has no clock of its own."
    ),
    risk="safe",

    category="core",
    parameters={
        "type": "object",
        "properties": {
            "tz": {
                "type": "string",
                "description": "Timezone: 'local' (default, machine "
                               "timezone) or 'utc'.",
            },
        },
        "required": [],
    },
)
def get_datetime(tz: str = "local") -> str:
    if tz.lower() == "utc":
        now = datetime.now(timezone.utc)
        tz_name = "UTC"
    else:
        # Naive local time + name from astimezone() trick.
        now_local = datetime.now().astimezone()
        now = now_local
        tz_name = now_local.tzname() or "local"
    iso = now.isoformat(timespec="seconds")
    epoch = int(time.time())
    weekday = now.strftime("%A")
    return (
        f"iso:      {iso}\n"
        f"weekday:  {weekday}\n"
        f"epoch:    {epoch}\n"
        f"timezone: {tz_name}"
    )


@tool(
    name="check_url",
    description=(
        "Check whether a URL is reachable. Issues an HTTP HEAD request "
        "and returns the status code plus a reachable bool. Use this "
        "for connectivity diagnostics — it does NOT download the page "
        "(use web_search for content)."
    ),
    risk="low",
    category="core",
    parameters={
        "type": "object",
        "properties": {
            "url": {
                "type": "string",
                "description": "Full URL including scheme (https://example.com).",
            },
            "timeout_s": {
                "type": "integer",
                "description": "Request timeout in seconds. Default 5.",
            },
        },
        "required": ["url"],
    },
)
def check_url(url: str, timeout_s: int = 5) -> str:
    if not url or not url.strip():
        return "Error: url is required."
    url = url.strip()
    if not (url.startswith("http://") or url.startswith("https://")):
        return f"Error: url must start with http:// or https://: {url}"
    req = urllib.request.Request(url, method="HEAD",
                                 headers={"User-Agent": "Navi/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as resp:
            status = resp.status
            return f"reachable: true\nstatus: {status}\nurl: {resp.geturl()}"
    except urllib.error.HTTPError as exc:
        # Server responded — URL exists, just not 2xx. Still counts as
        # reachable (server is up).
        return f"reachable: true\nstatus: {exc.code}\nurl: {url}"
    except urllib.error.URLError as exc:
        return f"reachable: false\nerror: {exc.reason}\nurl: {url}"
    except (OSError, ValueError) as exc:
        return f"reachable: false\nerror: {exc}\nurl: {url}"
