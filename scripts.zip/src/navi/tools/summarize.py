"""Map-reduce summarization for files too big to fit in one model context.

The direct ``read_pdf`` / ``read_pptx`` / ``read_excel`` tools cap at
``MAX_FILE_BYTES`` (~50 KB) so the result fits inside the model's 16 K
context window. For larger documents that's just truncation — the model
can only summarize what it sees.

This tool runs the document through map-reduce::

    1. Extract full text (uncapped, up to a 600 KB safety ceiling).
    2. Split at paragraph boundaries into ~8 KB chunks with small overlap.
    3. Summarize each chunk independently — N short LLM calls.
    4. Combine the chunk summaries into one final summary — 1 LLM call.

Slower than ``read_*`` (one LLM pass per chunk) but handles arbitrary size.
The same loaded llama-cpp model is reused — see ``brain.shared``.
"""

from __future__ import annotations

import re
from pathlib import Path

from navi.brain import shared
from navi.tools._registry import tool

# Safety ceiling on raw extracted text. Beyond this we'd be doing many
# minutes of CPU summarization — better to bail with a clear message.
_MAX_RAW_CHARS = 600_000

# Per-chunk target size (chars). At ~4 chars/token this is ~3k tokens —
# fits comfortably in n_ctx (16k) along with the prompt + output budget.
# Bigger chunks = fewer LLM calls = less wall time at the cost of slightly
# rougher per-chunk summaries; this trade-off favors UX on a 2B CPU model.
_CHUNK_CHARS = 12_000

# Overlap between adjacent chunks so a paragraph straddling a boundary
# still gets covered. Kept small to avoid duplicate work.
_CHUNK_OVERLAP = 150

# Per-chunk summary length budget. Tighter than before — most chunks don't
# need 400 tokens of bullet points to capture the key facts.
_CHUNK_SUMMARY_TOKENS = 250

# Final combined summary budget.
_FINAL_SUMMARY_TOKENS = 800


# ---------------------------------------------------------------------------
# Text extraction (uncapped — separate from the read_* tools' MAX_FILE_BYTES)
# ---------------------------------------------------------------------------


def _extract_pdf(p: Path) -> str:
    from pypdf import PdfReader
    reader = PdfReader(str(p))
    if reader.is_encrypted:
        raise RuntimeError(f"'{p.name}' is encrypted (password-protected)")
    parts: list[str] = []
    total = 0
    for i, page in enumerate(reader.pages):
        try:
            text = (page.extract_text() or "").strip()
        except Exception:  # noqa: BLE001
            continue
        if not text:
            continue
        parts.append(f"--- page {i + 1} ---\n{text}")
        total += len(text)
        if total >= _MAX_RAW_CHARS:
            parts.append(f"... [stopped at ~{_MAX_RAW_CHARS} chars]")
            break
    return "\n\n".join(parts)


def _extract_pptx(p: Path) -> str:
    # Same OLE2 / IRM checks as read_pptx — fail fast on encrypted files.
    with open(p, "rb") as fh:
        head = fh.read(8)
    if head.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"):
        raise RuntimeError(
            f"'{p.name}' is in OLE2 format (legacy .ppt or IRM/encrypted .pptx). "
            "Cannot extract; see read_pptx for diagnosis."
        )
    if not head.startswith(b"PK"):
        raise RuntimeError(f"'{p.name}' is not a valid .pptx file")
    from pptx import Presentation  # type: ignore[import-not-found]
    pres = Presentation(str(p))
    parts: list[str] = []
    total = 0
    for i, slide in enumerate(pres.slides):
        title = ""
        try:
            if slide.shapes.title and slide.shapes.title.has_text_frame:
                title = (slide.shapes.title.text_frame.text or "").strip()
        except Exception:  # noqa: BLE001
            pass
        body: list[str] = []
        for shape in slide.shapes:
            try:
                if not shape.has_text_frame:
                    continue
                for para in shape.text_frame.paragraphs:
                    text = "".join(run.text for run in para.runs).strip()
                    if text and text != title:
                        body.append("- " + text)
            except Exception:  # noqa: BLE001
                continue
        notes = ""
        try:
            if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
                notes = (slide.notes_slide.notes_text_frame.text or "").strip()
        except Exception:  # noqa: BLE001
            pass
        header = f"--- slide {i + 1}"
        if title:
            header += f": {title}"
        header += " ---"
        section = [header, *body]
        if notes:
            section.append(f"[notes] {notes}")
        chunk = "\n".join(section)
        parts.append(chunk)
        total += len(chunk)
        if total >= _MAX_RAW_CHARS:
            parts.append(f"... [stopped at ~{_MAX_RAW_CHARS} chars]")
            break
    return "\n\n".join(parts)


def _extract_xlsx(p: Path) -> str:
    from openpyxl import load_workbook
    wb = load_workbook(str(p), data_only=True, read_only=True)
    out: list[str] = []
    total = 0
    for ws in wb.worksheets:
        out.append(f"### Sheet: {ws.title}")
        for row in ws.iter_rows(values_only=True):
            line = " | ".join("" if v is None else str(v) for v in row)
            out.append(line)
            total += len(line)
            if total >= _MAX_RAW_CHARS:
                out.append(f"... [stopped at ~{_MAX_RAW_CHARS} chars]")
                wb.close()
                return "\n".join(out)
        out.append("")
    wb.close()
    return "\n".join(out).rstrip()


def _extract_docx(p: Path) -> str:
    from docx import Document  # type: ignore[import-not-found]
    doc = Document(str(p))
    out: list[str] = []
    total = 0
    for para in doc.paragraphs:
        text = para.text.strip()
        if not text:
            continue
        out.append(text)
        total += len(text)
        if total >= _MAX_RAW_CHARS:
            out.append(f"... [stopped at ~{_MAX_RAW_CHARS} chars]")
            break
    return "\n\n".join(out)


def _extract_text(p: Path) -> str:
    data = p.read_bytes()[:_MAX_RAW_CHARS]
    if b"\x00" in data[:8192]:
        raise RuntimeError(f"'{p.name}' looks binary (NUL bytes)")
    return data.decode("utf-8", errors="replace")


def _extract_full(p: Path) -> str:
    """Dispatch by extension. Raises on unsupported / unreadable files."""
    suffix = p.suffix.lower()
    if suffix == ".pdf":
        return _extract_pdf(p)
    if suffix == ".pptx":
        return _extract_pptx(p)
    if suffix in {".xlsx", ".xlsm"}:
        return _extract_xlsx(p)
    if suffix == ".docx":
        return _extract_docx(p)
    if suffix in {".txt", ".md", ".csv", ".log", ".json", ".xml", ".yaml", ".yml",
                  ".py", ".js", ".ts", ".rs", ".go", ".java", ".c", ".cpp", ".h"}:
        return _extract_text(p)
    raise ValueError(
        f"summarize_file does not know how to read '{suffix}'. "
        "Supported: .pdf .pptx .docx .xlsx .txt .md .csv .log .json .xml "
        "and common source-code extensions."
    )


# ---------------------------------------------------------------------------
# Chunking
# ---------------------------------------------------------------------------


def split_chunks(
    text: str,
    target_chars: int = _CHUNK_CHARS,
    overlap_chars: int = _CHUNK_OVERLAP,
) -> list[str]:
    """Split text into chunks at paragraph boundaries.

    Adjacent chunks share a small tail/head overlap so a sentence broken
    across a chunk boundary still gets full context once.
    """
    if len(text) <= target_chars:
        return [text]

    paragraphs = re.split(r"\n\s*\n", text)
    chunks: list[str] = []
    cur: list[str] = []
    cur_size = 0

    for para in paragraphs:
        psize = len(para) + 2  # +2 for the joiner
        # If a single paragraph is itself bigger than target, hard-split it.
        if psize > target_chars:
            if cur:
                chunks.append("\n\n".join(cur))
                cur = []
                cur_size = 0
            for i in range(0, len(para), target_chars):
                chunks.append(para[i : i + target_chars])
            continue
        if cur_size + psize > target_chars and cur:
            chunks.append("\n\n".join(cur))
            # Carry a short tail of the previous chunk into the next one
            tail = "\n\n".join(cur)[-overlap_chars:]
            cur = [tail] if tail else []
            cur_size = len(tail)
        cur.append(para)
        cur_size += psize
    if cur:
        chunks.append("\n\n".join(cur))
    return chunks


# ---------------------------------------------------------------------------
# Map-reduce passes
# ---------------------------------------------------------------------------


def _stream_completion(
    llm,  # type: ignore[no-untyped-def]
    messages: list[dict[str, str]],
    max_tokens: int,
) -> str:
    """Run a chat completion in STREAMING mode and accumulate the text.

    We don't surface tokens to the chat (the agent's outer loop will compose
    a final response) — but streaming is essential for the GUI: each yielded
    token releases Python's GIL, letting the orb's QTimer keep firing.
    `stream=False` makes one blocking C call that holds the GIL for the
    whole inference, which manifests as the orb freezing.
    """
    out_parts: list[str] = []
    stream = llm.create_chat_completion(
        messages=messages,
        max_tokens=max_tokens,
        temperature=0.3,
        stream=True,
    )
    for chunk in stream:
        if shared.is_cancelled():
            break
        choices = chunk.get("choices") or []
        if not choices:
            continue
        delta = choices[0].get("delta", {})
        content = delta.get("content")
        if content:
            out_parts.append(content)
    return "".join(out_parts).strip()


def _summarize_one_chunk(
    llm,  # type: ignore[no-untyped-def]
    chunk: str,
    focus: str,
    i: int,
    n: int,
) -> str:
    user_prompt = (
        f"This is chunk {i + 1} of {n} from a document. Extract the KEY POINTS "
        "as 4-8 short bullet points. Preserve names, dates, numbers, and decisions. "
        "Be factual — no opinions, no padding."
    )
    if focus:
        user_prompt += f" Focus on: {focus}."
    user_prompt += "\n\n--- chunk start ---\n" + chunk + "\n--- chunk end ---"
    return _stream_completion(
        llm,
        [
            {"role": "system",
             "content": "You are a careful, factual summarizer. Reply with bullet points only."},
            {"role": "user", "content": user_prompt},
        ],
        max_tokens=_CHUNK_SUMMARY_TOKENS,
    )


def _combine_summaries(
    llm,  # type: ignore[no-untyped-def]
    summaries: list[str],
    focus: str,
) -> str:
    joined = "\n\n".join(f"### chunk {i + 1}\n{s}" for i, s in enumerate(summaries))
    prompt = (
        f"Below are partial summaries of {len(summaries)} chunks of a document. "
        "Combine them into ONE coherent summary as 8-15 bullet points. "
        "Deduplicate repeats; preserve names, dates, numbers, and concrete decisions. "
        "Group related points. End with a one-line takeaway labelled 'Bottom line:'."
    )
    if focus:
        prompt += f" Emphasize: {focus}."
    prompt += "\n\n" + joined
    return _stream_completion(
        llm,
        [
            {"role": "system",
             "content": "You are a careful, factual summarizer."},
            {"role": "user", "content": prompt},
        ],
        max_tokens=_FINAL_SUMMARY_TOKENS,
    )


# ---------------------------------------------------------------------------
# Tool entrypoint
# ---------------------------------------------------------------------------


@tool(
    name="summarize_file",
    description=(
        "Read a file IN FULL and return a summary, even if the file is too "
        "large to fit in one model context. Internally splits the document "
        "into chunks, summarizes each, and combines. Use this when read_pdf, "
        "read_pptx, read_excel, etc. would truncate (any file with more than "
        "~40 KB of extracted text). Slower than read_* — typically 30–120 s "
        "depending on size — but handles arbitrary length. "
        "Supports .pdf .pptx .docx .xlsx .txt .md .csv .log and common code "
        "files. Path must be absolute."
    ),
    risk="low",
    parameters={
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Absolute file path."},
            "focus": {
                "type": "string",
                "description": (
                    "Optional topic to emphasize (e.g. 'security policies', "
                    "'action items', 'numbers and dates'). Empty for a general summary."
                ),
            },
        },
        "required": ["path"],
    },
)
def summarize_file(path: str, focus: str = "") -> str:
    p = Path(path)
    if not p.is_absolute():
        return f"Error: path must be absolute: {path}"
    if not p.exists() or not p.is_file():
        return f"Error: file does not exist: {path}"

    llm = shared.get_llm()
    if llm is None:
        return "Error: model not loaded — cannot summarize."

    try:
        text = _extract_full(p)
    except ValueError as exc:
        return f"Error: {exc}"
    except Exception as exc:  # noqa: BLE001
        return f"Error extracting text from {p.name}: {exc}"

    if not text.strip():
        return f"'{p.name}' has no extractable text."

    chunks = split_chunks(text)
    shared.emit_progress(
        f"📄 read {len(text):,} chars from {p.name} → "
        f"{len(chunks)} chunk{'s' if len(chunks) != 1 else ''}"
    )

    if len(chunks) == 1:
        # Fits in one pass — skip the map-reduce overhead.
        return _summarize_one_chunk(llm, chunks[0], focus, 0, 1)

    chunk_summaries: list[str] = []
    for i, chunk in enumerate(chunks):
        if shared.is_cancelled():
            return f"[summarization cancelled after {i}/{len(chunks)} chunks]"
        shared.emit_progress(f"📄 summarizing chunk {i + 1}/{len(chunks)}…")
        chunk_summaries.append(_summarize_one_chunk(llm, chunk, focus, i, len(chunks)))

    if shared.is_cancelled():
        return f"[summarization cancelled before combine; have {len(chunk_summaries)} chunk summaries]"

    # Short docs (2 chunks): skip the combine LLM pass — one more inference
    # for a barely-improved result isn't worth the wall-time on CPU.
    if len(chunks) == 2:
        return (
            f"### chunk 1\n{chunk_summaries[0]}\n\n"
            f"### chunk 2\n{chunk_summaries[1]}"
        )

    shared.emit_progress(f"📄 combining {len(chunks)} chunk summaries…")
    return _combine_summaries(llm, chunk_summaries, focus)
