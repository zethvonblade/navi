from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path

import mss

from navi.tools._registry import tool

_LAST_SHOT: Path | None = None


@tool(
    name="take_screenshot",
    description=(
        "Capture the primary monitor and save the screenshot to a temp file. "
        "Returns the file path. Use ocr_image afterward to read text from it."
    ),
    risk="safe",

    category="core",
    parameters={"type": "object", "properties": {}, "required": []},
)
def take_screenshot() -> str:
    global _LAST_SHOT
    out = Path(tempfile.gettempdir()) / "navi_screenshot.png"
    with mss.mss() as sct:
        sct.shot(mon=1, output=str(out))
    _LAST_SHOT = out
    return str(out)


_IMAGE_EXTS = frozenset({".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".tif", ".gif", ".webp"})


@tool(
    name="ocr_image",
    description=(
        "Run on-device OCR (Windows.Media.Ocr) on an IMAGE FILE only "
        "(.png, .jpg, .bmp, etc.). Use this AFTER take_screenshot to read "
        "text from the screen. **Do not use on Word/PDF/Excel documents** — "
        "for those, use read_file (which natively extracts .docx text). "
        "If no path is given, uses the most recent screenshot."
    ),
    risk="safe",
    category="desktop",
    parameters={
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Optional absolute path to an image file. Uses last screenshot if omitted.",
            },
        },
        "required": [],
    },
)
def ocr_image(path: str | None = None) -> str:
    target = Path(path) if path else _LAST_SHOT
    if target is None:
        return "Error: no image path provided and no recent screenshot."
    if not target.exists():
        return f"Error: file does not exist: {target}"
    suffix = target.suffix.lower()
    if suffix not in _IMAGE_EXTS:
        return (
            f"Error: ocr_image only works on image files ({', '.join(sorted(_IMAGE_EXTS))}). "
            f"Got '{suffix}'. For Word/PDF/text documents, use read_file instead."
        )
    try:
        return _winrt_ocr(target.resolve())
    except Exception as exc:
        return f"OCR failed: {exc}"


def _winrt_ocr(image_path: Path) -> str:
    from winsdk.windows.graphics.imaging import BitmapDecoder
    from winsdk.windows.media.ocr import OcrEngine
    from winsdk.windows.storage import FileAccessMode, StorageFile

    async def go() -> str:
        path_str = str(image_path).replace("/", "\\")
        sfile = await StorageFile.get_file_from_path_async(path_str)
        stream = await sfile.open_async(FileAccessMode.READ)
        decoder = await BitmapDecoder.create_async(stream)
        bitmap = await decoder.get_software_bitmap_async()
        engine = OcrEngine.try_create_from_user_profile_languages()
        if engine is None:
            return "(no OCR language pack installed)"
        result = await engine.recognize_async(bitmap)
        text = result.text or ""
        return text if text.strip() else "(no text recognized)"

    return asyncio.run(go())
