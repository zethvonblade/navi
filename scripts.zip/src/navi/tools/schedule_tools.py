"""LLM-callable wrappers around the schedule store + parser.

Two scheduling tools (split intentionally so the LLM doesn't have to
*guess* one-shot vs recurring) plus list/cancel for management. The
firing of jobs is handled by ``navi.schedule.runner.ScheduleRunner``,
not by these tools — they only manipulate the persistent store.
"""

from __future__ import annotations

from datetime import datetime

from navi.schedule import store as sched_store
from navi.schedule.parse import parse_when
from navi.schedule.store import Job, new_id
from navi.tools._registry import tool


def _iso(dt: datetime) -> str:
    """Match the storage ISO format (no microseconds, no tz)."""
    return dt.replace(microsecond=0).isoformat()


@tool(
    name="schedule_once",
    description=(
        "Schedule a one-shot reminder/task to fire at a specific time. "
        "When it fires, `prompt` is delivered to Navi as if the user had "
        "typed it (and an OS notification pops if enabled). The entry "
        "deletes itself after firing. Use natural language for `when`: "
        "'in 2 minutes', 'tomorrow at 5pm', 'next friday at 9am', or an "
        "ISO timestamp like '2026-12-31T15:00'."
    ),
    risk="medium",
    category="automation",
    parameters={
        "type": "object",
        "properties": {
            "when": {"type": "string",
                     "description": "Natural-language time (relative or absolute)."},
            "prompt": {"type": "string",
                       "description": "What to ask Navi when the time arrives "
                                      "(e.g. 'remind me to take a break')."},
        },
        "required": ["when", "prompt"],
    },
)
def schedule_once(when: str, prompt: str) -> str:
    if not prompt or not prompt.strip():
        return "Error: prompt is required"
    fire = parse_when(when)
    if fire is None:
        return (
            f"Error: could not parse `when` = {when!r}. Try: "
            "'in 2 minutes', 'tomorrow at 5pm', 'next friday at 9am'."
        )
    if fire <= datetime.now():
        return f"Error: parsed time {fire.isoformat()} is in the past"
    job = Job(
        id=new_id(),
        pattern=when.strip(),
        recurring=False,
        next_fire=_iso(fire),
        prompt=prompt.strip(),
        created=_iso(datetime.now()),
    )
    sched_store.add(job)
    return (
        f"Scheduled (one-shot): id={job.id}, fires at {fire.isoformat()}\n"
        f"  prompt: {prompt.strip()}"
    )


@tool(
    name="schedule_recurring",
    description=(
        "Schedule a recurring reminder/task. After each fire, the next "
        "fire time is recomputed by re-parsing `pattern` relative to "
        "now — so 'every Tuesday at 3pm' naturally jumps to the next "
        "Tuesday after each fire. Patterns: 'every 15 minutes', "
        "'hourly', 'daily', 'every Tuesday at 3pm', 'every monday at "
        "9am', '5m', '2h'."
    ),
    risk="medium",

    category="automation",
    parameters={
        "type": "object",
        "properties": {
            "pattern": {"type": "string",
                        "description": "Recurrence pattern in natural language."},
            "prompt": {"type": "string",
                       "description": "What to ask Navi each time it fires."},
        },
        "required": ["pattern", "prompt"],
    },
)
def schedule_recurring(pattern: str, prompt: str) -> str:
    if not prompt or not prompt.strip():
        return "Error: prompt is required"
    fire = parse_when(pattern)
    if fire is None:
        return (
            f"Error: could not parse `pattern` = {pattern!r}. Try: "
            "'every 15 minutes', 'hourly', 'every monday at 9am'."
        )
    if fire <= datetime.now():
        return f"Error: parsed time {fire.isoformat()} is in the past"
    job = Job(
        id=new_id(),
        pattern=pattern.strip(),
        recurring=True,
        next_fire=_iso(fire),
        prompt=prompt.strip(),
        created=_iso(datetime.now()),
    )
    sched_store.add(job)
    return (
        f"Scheduled (recurring): id={job.id}, next fire {fire.isoformat()}\n"
        f"  pattern: {pattern.strip()}\n"
        f"  prompt:  {prompt.strip()}"
    )


@tool(
    name="list_scheduled",
    description=(
        "List all scheduled jobs (one-shots + recurring) with their ids, "
        "next-fire times, and prompts. Use the id to cancel via "
        "cancel_scheduled."
    ),
    risk="safe",
    category="automation",
    parameters={"type": "object", "properties": {}, "required": []},
)
def list_scheduled() -> str:
    jl = sched_store.load()
    if not jl.jobs:
        return "(no scheduled jobs)"
    # Sort by next fire ascending so the user sees imminent first.
    jobs = sorted(jl.jobs, key=lambda j: j.next_fire)
    lines = [f"{len(jobs)} scheduled job(s):"]
    for j in jobs:
        kind = "recurring" if j.recurring else "one-shot"
        prompt = j.prompt if len(j.prompt) <= 60 else j.prompt[:57] + "..."
        lines.append(
            f"  {j.id}  [{kind:9}]  {j.next_fire}  pattern={j.pattern!r}"
        )
        lines.append(f"           prompt: {prompt}")
    return "\n".join(lines)


@tool(
    name="cancel_scheduled",
    description=(
        "Cancel a scheduled job by id. Get the id from list_scheduled. "
        "Returns whether the job was found + removed."
    ),
    risk="medium",

    category="automation",
    parameters={
        "type": "object",
        "properties": {
            "job_id": {"type": "string",
                       "description": "Job id from list_scheduled (e.g. 'abc123')."},
        },
        "required": ["job_id"],
    },
)
def cancel_scheduled(job_id: str) -> str:
    if not job_id or not job_id.strip():
        return "Error: job_id is required"
    if sched_store.remove(job_id.strip()):
        return f"Cancelled job {job_id.strip()}"
    return f"No job with id {job_id.strip()!r} (already fired or wrong id?)"
