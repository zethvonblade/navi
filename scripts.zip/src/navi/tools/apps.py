from __future__ import annotations

import os
import shutil
import subprocess
import webbrowser

from navi.tools._registry import tool

# Common Windows app shortcuts the user is likely to ask for by short name.
_KNOWN_APPS: dict[str, str] = {
    "notepad": "notepad.exe",
    "calc": "calc.exe",
    "calculator": "calc.exe",
    "explorer": "explorer.exe",
    "file explorer": "explorer.exe",
    "cmd": "cmd.exe",
    "command prompt": "cmd.exe",
    "powershell": "powershell.exe",
    "edge": "msedge.exe",
    "chrome": "chrome.exe",
    "firefox": "firefox.exe",
    "word": "winword.exe",
    "excel": "excel.exe",
    "outlook": "outlook.exe",
    "teams": "teams.exe",
    "vscode": "code.exe",
    "code": "code.exe",
    "paint": "mspaint.exe",
}


@tool(
    name="open_app",
    description=(
        "Launch a Windows application. Accepts a short name "
        "('notepad', 'chrome', 'word'), an executable name ('mspaint.exe'), "
        "or an absolute path."
    ),
    risk="low",
    category="desktop",
    parameters={
        "type": "object",
        "properties": {
            "name_or_path": {
                "type": "string",
                "description": "App short name, .exe filename, or absolute path.",
            },
        },
        "required": ["name_or_path"],
    },
)
def open_app(name_or_path: str) -> str:
    target = _resolve_app(name_or_path)
    if target is None:
        return f"Could not find an app matching '{name_or_path}'."
    try:
        if os.path.isabs(target) and os.path.exists(target):
            os.startfile(target)
        else:
            subprocess.Popen([target], shell=False)
    except OSError as exc:
        return f"Error launching {target}: {exc}"
    return f"Launched: {target}"


def _resolve_app(name: str) -> str | None:
    name = name.strip()
    if not name:
        return None
    # Absolute path
    if os.path.isabs(name) and os.path.exists(name):
        return name
    # Known app short name
    short = _KNOWN_APPS.get(name.lower())
    if short:
        return short
    # PATH lookup
    found = shutil.which(name) or shutil.which(name + ".exe")
    if found:
        return found
    # Last resort — let Windows figure it out
    return name


@tool(
    name="open_url",
    description="Open a URL in the user's default web browser. Only http:// and https:// URLs are accepted.",
    risk="low",

    category="desktop",
    parameters={
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "Full URL beginning with http:// or https://."},
        },
        "required": ["url"],
    },
)
def open_url(url: str) -> str:
    if not url.startswith(("http://", "https://")):
        return f"Error: URL must start with http:// or https:// — got: {url}"
    try:
        webbrowser.open(url, new=2)
    except Exception as exc:
        return f"Error opening URL: {exc}"
    return f"Opened: {url}"
