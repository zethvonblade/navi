"""Safe arithmetic evaluator.

LLMs are notoriously bad at multi-digit arithmetic — a 2B Granite model
will confidently report ``2,847 * 39 = 110,933`` (real answer 111,033)
because it predicts digits one at a time without carrying. This tool
gives the agent a way to do exact math.

We do NOT use ``eval()``. Instead we ``ast.parse`` the expression in
``mode="eval"`` and walk the tree with a strict whitelist:

* Allowed nodes: ``Expression``, ``BinOp``, ``UnaryOp``, ``Constant``
  (int/float only), ``Call`` to whitelisted math names, ``Name`` for
  whitelisted constants.
* Allowed operators: + - * / // % **, unary + and -.
* Allowed names: a small set of math functions/constants (sqrt, log,
  log2, sin, cos, tan, abs, round, min, max, pi, e).
* Anything else (Attribute, Subscript, Starred, comprehensions, lambdas,
  imports, name lookups outside the whitelist) raises and the tool
  returns a clear error.

This pattern is well-trodden — see e.g. RealPython's "How to Build a
Safe Calculator". The whitelist approach is the only way to be sure;
``eval`` with restricted globals has been escaped many times in the past
(``(0).__class__`` chains, format-string tricks, etc.).
"""

from __future__ import annotations

import ast
import math
import operator
from typing import Any

from navi.tools._registry import tool


_BIN_OPS: dict[type, Any] = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
_UNARY_OPS: dict[type, Any] = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}

_NAMES: dict[str, Any] = {
    "pi": math.pi,
    "e": math.e,
    "tau": math.tau,
    "inf": math.inf,
}

_FUNCS: dict[str, Any] = {
    "sqrt": math.sqrt,
    "log": math.log,         # natural log; accepts (x, base)
    "log2": math.log2,
    "log10": math.log10,
    "exp": math.exp,
    "sin": math.sin,
    "cos": math.cos,
    "tan": math.tan,
    "asin": math.asin,
    "acos": math.acos,
    "atan": math.atan,
    "abs": abs,
    "round": round,
    "min": min,
    "max": max,
    "floor": math.floor,
    "ceil": math.ceil,
}


class _UnsafeExpression(ValueError):
    """Raised when the AST contains anything outside the whitelist."""


def _safe_eval(node: ast.AST) -> Any:
    if isinstance(node, ast.Expression):
        return _safe_eval(node.body)
    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
            return node.value
        raise _UnsafeExpression(
            f"only int/float literals allowed, got {type(node.value).__name__}"
        )
    if isinstance(node, ast.BinOp):
        op_fn = _BIN_OPS.get(type(node.op))
        if op_fn is None:
            raise _UnsafeExpression(f"operator not allowed: {type(node.op).__name__}")
        return op_fn(_safe_eval(node.left), _safe_eval(node.right))
    if isinstance(node, ast.UnaryOp):
        op_fn = _UNARY_OPS.get(type(node.op))
        if op_fn is None:
            raise _UnsafeExpression(f"unary operator not allowed: {type(node.op).__name__}")
        return op_fn(_safe_eval(node.operand))
    if isinstance(node, ast.Name):
        if node.id in _NAMES:
            return _NAMES[node.id]
        raise _UnsafeExpression(f"name not allowed: {node.id!r}")
    if isinstance(node, ast.Call):
        # Only direct calls to whitelisted bare names.
        if not isinstance(node.func, ast.Name) or node.func.id not in _FUNCS:
            name = getattr(node.func, "id", type(node.func).__name__)
            raise _UnsafeExpression(f"function not allowed: {name!r}")
        if node.keywords:
            raise _UnsafeExpression("keyword arguments not allowed")
        args = [_safe_eval(a) for a in node.args]
        return _FUNCS[node.func.id](*args)
    raise _UnsafeExpression(f"node type not allowed: {type(node).__name__}")


@tool(
    name="calc",
    description=(
        "Evaluate an arithmetic expression exactly. Use this for ANY "
        "math beyond single-digit addition — LLMs reliably mis-compute "
        "multi-digit arithmetic. Supports + - * / // % ** and the math "
        "functions sqrt, log, log2, log10, exp, sin, cos, tan, asin, "
        "acos, atan, abs, round, min, max, floor, ceil; constants pi, "
        "e, tau."
    ),
    risk="safe",
    category="core",
    parameters={
        "type": "object",
        "properties": {
            "expression": {
                "type": "string",
                "description": "Arithmetic expression, e.g. '2.5 * 40 + 10' "
                               "or 'sqrt(2)' or 'log(100, 10)'.",
            },
        },
        "required": ["expression"],
    },
)
def calc(expression: str) -> str:
    if not expression or not expression.strip():
        return "Error: expression is required."
    expr = expression.strip()
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as exc:
        return f"Error: could not parse expression: {exc.msg}"
    try:
        result = _safe_eval(tree)
    except _UnsafeExpression as exc:
        return f"Error: {exc}"
    except ZeroDivisionError:
        return "Error: division by zero"
    except (ValueError, OverflowError) as exc:
        return f"Error: math error: {exc}"

    # Pretty-print: ints with thousands separators; floats with up to 10
    # decimal places trimmed of trailing zeros. Keeps the model's reading
    # of "111,033" unambiguous while not lying about precision.
    if isinstance(result, int):
        return f"{result:,}"
    if isinstance(result, float):
        if result.is_integer():
            return f"{int(result):,}"
        return f"{result:,.10f}".rstrip("0").rstrip(".")
    return str(result)
