"""Native OS notification tool.

Backed by the existing ``QSystemTrayIcon.showMessage`` on the
``NaviTray`` instance — Windows native balloon/Action Center toast
with no extra dep. Wiring in ``pet/window.py`` registers the tray's
``showMessage`` as the ``shared.set_notify_callback``.

Risk is ``low`` (not ``safe``): notifications steal focus / interrupt
the user, so they pass through the permission dialog the first time
per session. Subsequent calls ride the per-session allow.
"""

from __future__ import annotations

from navi.brain import shared
from navi.tools._registry import tool


@tool(
    name="notify",
    description=(
        "Show a native OS notification (Windows balloon/toast). Use this "
        "to grab the user's attention when the chat window may not be "
        "visible — task done, scheduled reminder fired, error worth "
        "knowing about. Title is the headline; message is the body."
    ),
    risk="low",
    category="core",
    parameters={
        "type": "object",
        "properties": {
            "title": {"type": "string",
                      "description": "Headline (≤64 chars works best)."},
            "message": {"type": "string",
                        "description": "Body text (≤200 chars works best)."},
        },
        "required": ["title", "message"],
    },
)
def notify(title: str, message: str) -> str:
    title = (title or "").strip() or "Navi"
    message = (message or "").strip()
    if not message:
        return "Error: message is required"

    try:
        from navi.settings.store import load as load_settings
        if not (load_settings().get("notify") or {}).get("enabled", True):
            return "Notifications are disabled in settings (notify.enabled=false)."
    except Exception:  # noqa: BLE001
        pass  # if settings load fails, default-on behavior

    # No-op if no callback registered (tests, headless). Surface this so
    # the LLM doesn't think it succeeded silently.
    if shared._notify_cb is None:  # noqa: SLF001
        return (
            "Notification skipped: tray not available (running headless "
            "or pre-init). Title was: " + title
        )

    shared.emit_notification(title, message)
    return f"Notified: {title}"
