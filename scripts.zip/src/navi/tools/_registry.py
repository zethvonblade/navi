from __future__ import annotations

import inspect
from dataclasses import dataclass
from typing import Any, Callable, Literal

Risk = Literal["safe", "low", "medium", "high"]

# Categories let users opt INTO heavier tool sets via /tools enable <category>.
# The schema sent to the LLM is filtered by enabled categories — keeping
# Granite 2B's prompt-eval time bounded (every tool in the schema is more
# tokens to chew through on every turn). 'core' is the always-on floor.
KNOWN_CATEGORIES = frozenset({
    "core", "files", "documents", "desktop", "shell",
    "code", "git", "image", "automation",
})


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    parameters: dict[str, Any]  # JSON schema
    risk: Risk
    func: Callable[..., Any]
    category: str = "core"


_REGISTRY: dict[str, Tool] = {}


def tool(
    name: str,
    description: str,
    risk: Risk = "low",
    parameters: dict[str, Any] | None = None,
    category: str = "core",
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Register a callable as a tool.

    If ``parameters`` is omitted, a minimal JSON schema is built from the
    function signature (string-typed unless annotated otherwise).

    ``category`` controls when the tool is exposed to the LLM. Default
    ``"core"`` means always available; other values (``"files"``,
    ``"code"``, ``"git"``, …) are off by default and need
    ``/tools enable <category>``.
    """

    if category not in KNOWN_CATEGORIES:
        # Catch typos at import — better than silently leaking a tool
        # nobody can ever enable.
        raise ValueError(
            f"unknown tool category {category!r} for tool {name!r}; "
            f"valid categories: {sorted(KNOWN_CATEGORIES)}"
        )

    def deco(func: Callable[..., Any]) -> Callable[..., Any]:
        params = parameters or _infer_params(func)
        if name in _REGISTRY:
            # Silent overwrite would mean a typo or copy-paste duplicate
            # silently shadows the original — print a warning so it's
            # noticed during development, but don't raise (raising would
            # break the import chain at app startup).
            existing = _REGISTRY[name]
            existing_mod = getattr(existing.func, "__module__", "?")
            new_mod = getattr(func, "__module__", "?")
            print(
                f"[tools] WARNING: tool {name!r} already registered by "
                f"{existing_mod}; overwriting with definition from {new_mod}"
            )
        _REGISTRY[name] = Tool(name, description, params, risk, func, category)
        return func

    return deco


def get_tool(name: str) -> Tool | None:
    return _REGISTRY.get(name)


def all_tools() -> list[Tool]:
    return list(_REGISTRY.values())


def tools_schema(
    enabled_categories: set[str] | None = None,
) -> list[dict[str, Any]]:
    """Return the OpenAI-style tool list for ``llama_cpp.create_chat_completion``.

    When ``enabled_categories`` is None, returns every registered tool
    (legacy behavior — used by tests and by ``/tools all``).

    When given, returns only tools whose ``category`` is in the set —
    plus 'core' as an unconditional floor. Disabling 'core' would break
    recall/datetime/calc and confuse the LLM; the floor keeps the agent
    coherent regardless of user choice.
    """
    if enabled_categories is None:
        active = None
    else:
        active = set(enabled_categories) | {"core"}
    return [
        {
            "type": "function",
            "function": {
                "name": t.name,
                "description": t.description,
                "parameters": t.parameters,
            },
        }
        for t in _REGISTRY.values()
        if active is None or t.category in active
    ]


def categories_in_use() -> list[str]:
    """Sorted unique categories across all registered tools. Used by
    /tools to render the on/off list."""
    return sorted({t.category for t in _REGISTRY.values()})


def _infer_params(func: Callable[..., Any]) -> dict[str, Any]:
    sig = inspect.signature(func)
    props: dict[str, Any] = {}
    required: list[str] = []
    for pname, p in sig.parameters.items():
        if pname == "self":
            continue
        json_type = "string"
        ann = p.annotation
        if ann is int:
            json_type = "integer"
        elif ann is float:
            json_type = "number"
        elif ann is bool:
            json_type = "boolean"
        props[pname] = {"type": json_type}
        if p.default is inspect.Parameter.empty:
            required.append(pname)
    return {"type": "object", "properties": props, "required": required}
