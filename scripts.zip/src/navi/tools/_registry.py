from __future__ import annotations

import inspect
from dataclasses import dataclass
from typing import Any, Callable, Literal

Risk = Literal["safe", "low", "medium", "high"]


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    parameters: dict[str, Any]  # JSON schema
    risk: Risk
    func: Callable[..., Any]


_REGISTRY: dict[str, Tool] = {}


def tool(
    name: str,
    description: str,
    risk: Risk = "low",
    parameters: dict[str, Any] | None = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Register a callable as a tool.

    If ``parameters`` is omitted, a minimal JSON schema is built from the
    function signature (string-typed unless annotated otherwise).
    """

    def deco(func: Callable[..., Any]) -> Callable[..., Any]:
        params = parameters or _infer_params(func)
        _REGISTRY[name] = Tool(name, description, params, risk, func)
        return func

    return deco


def get_tool(name: str) -> Tool | None:
    return _REGISTRY.get(name)


def all_tools() -> list[Tool]:
    return list(_REGISTRY.values())


def tools_schema() -> list[dict[str, Any]]:
    """Return the OpenAI-style tool list for ``llama_cpp.create_chat_completion``."""
    return [
        {
            "type": "function",
            "function": {
                "name": t.name,
                "description": t.description,
                "parameters": t.parameters,
            },
        }
        for t in _REGISTRY.values()
    ]


def _infer_params(func: Callable[..., Any]) -> dict[str, Any]:
    sig = inspect.signature(func)
    props: dict[str, Any] = {}
    required: list[str] = []
    for pname, p in sig.parameters.items():
        if pname == "self":
            continue
        json_type = "string"
        ann = p.annotation
        if ann is int:
            json_type = "integer"
        elif ann is float:
            json_type = "number"
        elif ann is bool:
            json_type = "boolean"
        props[pname] = {"type": json_type}
        if p.default is inspect.Parameter.empty:
            required.append(pname)
    return {"type": "object", "properties": props, "required": required}
