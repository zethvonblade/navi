"""Local git operations.

Nine tools so the LLM can wrap edits in the standard developer safety
net: branch off, commit checkpoints, diff/log to verify, switch
branches to compare. Read-only ops are ``risk="safe"`` (no permission
prompt); working-tree mutations are ``risk="medium"``.

Scope is deliberately local-only. No ``push``, ``pull``, ``fetch``,
``clone``, ``remote`` — remote ops drag in HTTPS credentials, SSH
keys, GPG signing, and 2FA. Use ``run_powershell git push ...`` if you
need that escape hatch; the credential dialog Git for Windows uses
handles itself.

All tools take an absolute ``repo_path``. Non-init tools verify the
path is an existing git working tree (``.git/`` directory present).
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from navi.tools._registry import tool


GIT_TIMEOUT_SEC = 30
GIT_MAX_OUTPUT = 8000
_GIT_INSTALL_HELP = (
    "Error: `git` not found on PATH. Install Git for Windows from "
    "https://git-scm.com/download/win and re-launch Navi so the new PATH "
    "is picked up."
)


def _run_git(repo_path: str, args: list[str], *, require_repo: bool = True) -> str:
    """Run ``git -C <repo_path> <args>`` and return its formatted output.

    Mirrors the subprocess pattern in ``tools/shell.py:run_powershell``
    (Windows tree-kill on timeout, output cap, friendly install error).
    """
    p = Path(repo_path)
    if not p.is_absolute():
        return f"Error: repo_path must be absolute: {repo_path}"
    if not p.exists():
        return f"Error: repo_path does not exist: {repo_path}"
    if not p.is_dir():
        return f"Error: repo_path is not a directory: {repo_path}"
    if require_repo and not (p / ".git").exists():
        return (
            f"Error: not a git repository: {repo_path}. "
            "Call git_init first."
        )

    cmd = ["git", "-C", str(p), *args]
    creationflags = 0
    if sys.platform == "win32":
        creationflags = subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]

    try:
        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            creationflags=creationflags,
        )
    except FileNotFoundError:
        return _GIT_INSTALL_HELP
    except OSError as exc:
        return f"Error running git: {exc}"

    try:
        stdout, stderr = proc.communicate(timeout=GIT_TIMEOUT_SEC)
        rc = proc.returncode
    except subprocess.TimeoutExpired:
        if sys.platform == "win32":
            subprocess.run(
                ["taskkill", "/T", "/F", "/PID", str(proc.pid)],
                capture_output=True, check=False,
            )
        else:
            proc.kill()
        try:
            proc.communicate(timeout=2)
        except subprocess.TimeoutExpired:
            pass
        return f"Error: git command timed out after {GIT_TIMEOUT_SEC}s."

    stdout = (stdout or "").strip()
    stderr = (stderr or "").strip()

    if rc != 0:
        out = f"Exit {rc}"
        if stderr:
            out += f"\nstderr:\n{stderr}"
        if stdout:
            out += f"\nstdout:\n{stdout}"
    else:
        out = stdout
        if stderr:
            out = f"{out}\n[stderr]\n{stderr}".strip()

    if len(out) > GIT_MAX_OUTPUT:
        out = out[:GIT_MAX_OUTPUT] + f"\n... [truncated to {GIT_MAX_OUTPUT} chars]"
    return out or "(no output)"


def _is_dirty(repo_path: str) -> bool | None:
    """Return True/False, or None if git failed (caller treats None as
    'unknown — refuse the dangerous op')."""
    raw = _run_git(repo_path, ["status", "--porcelain"])
    if raw.startswith("Error") or raw.startswith("Exit"):
        return None
    return bool(raw.strip()) and raw.strip() != "(no output)"


# ---------------------------------------------------------------------------
# Read-only tools (risk=safe)
# ---------------------------------------------------------------------------


@tool(
    name="git_status",
    description=(
        "Show the working-tree status of a git repo: current branch, "
        "ahead/behind upstream, and any modified or untracked files. "
        "Uses --porcelain=v1 --branch — terse, machine-readable, much "
        "more compact than full `git status`."
    ),
    risk="safe",

    category="git",
    parameters={
        "type": "object",
        "properties": {
            "repo_path": {"type": "string",
                          "description": "Absolute path to the git repository."},
        },
        "required": ["repo_path"],
    },
)
def git_status(repo_path: str) -> str:
    return _run_git(repo_path, ["status", "--porcelain=v1", "--branch"])


@tool(
    name="git_diff",
    description=(
        "Show changes in a git repo. By default, shows unstaged changes; "
        "pass staged=true to see what's about to be committed. Optional "
        "path filter limits diff to one file or directory."
    ),
    risk="safe",

    category="git",
    parameters={
        "type": "object",
        "properties": {
            "repo_path": {"type": "string",
                          "description": "Absolute path to the git repository."},
            "path": {"type": "string",
                     "description": "Optional file or directory path (relative "
                                    "to repo root) to limit the diff to."},
            "staged": {"type": "boolean",
                       "description": "If true, show staged changes (--staged) "
                                      "instead of unstaged. Default false."},
        },
        "required": ["repo_path"],
    },
)
def git_diff(repo_path: str, path: str = "", staged: bool = False) -> str:
    args = ["diff"]
    if staged:
        args.append("--staged")
    if path.strip():
        args.append("--")
        args.append(path.strip())
    return _run_git(repo_path, args)


@tool(
    name="git_log",
    description=(
        "Show recent commits as one-liners (hash + message). Default is "
        "the most recent 10."
    ),
    risk="safe",
    category="git",
    parameters={
        "type": "object",
        "properties": {
            "repo_path": {"type": "string",
                          "description": "Absolute path to the git repository."},
            "max_count": {"type": "integer",
                          "description": "Number of commits to show. Default 10."},
        },
        "required": ["repo_path"],
    },
)
def git_log(repo_path: str, max_count: int = 10) -> str:
    if max_count < 1:
        return "Error: max_count must be >= 1"
    return _run_git(repo_path, ["log", "--oneline", "-n", str(max_count)])


@tool(
    name="git_branch_list",
    description="List all local branches. The current branch is marked with '*'.",
    risk="safe",

    category="git",
    parameters={
        "type": "object",
        "properties": {
            "repo_path": {"type": "string",
                          "description": "Absolute path to the git repository."},
        },
        "required": ["repo_path"],
    },
)
def git_branch_list(repo_path: str) -> str:
    return _run_git(repo_path, ["branch", "--list"])


# ---------------------------------------------------------------------------
# Working-tree mutations (risk=medium)
# ---------------------------------------------------------------------------


@tool(
    name="git_init",
    description=(
        "Initialize a new git repository in an existing directory. Refuses "
        "if `.git/` already exists or if the path is a protected system "
        "location."
    ),
    risk="medium",

    category="git",
    parameters={
        "type": "object",
        "properties": {
            "repo_path": {"type": "string",
                          "description": "Absolute path to the directory to initialize."},
        },
        "required": ["repo_path"],
    },
)
def git_init(repo_path: str) -> str:
    p = Path(repo_path)
    if not p.is_absolute():
        return f"Error: repo_path must be absolute: {repo_path}"
    if not p.exists():
        return f"Error: repo_path does not exist: {repo_path}"
    if not p.is_dir():
        return f"Error: repo_path is not a directory: {repo_path}"
    if (p / ".git").exists():
        return f"Error: already a git repository: {repo_path}"
    # Defense-in-depth: don't let an LLM 'git init C:\Windows'.
    from navi.tools.filesystem import _is_protected_path
    if _is_protected_path(p):
        return f"Error: refusing to git-init a protected system path: {repo_path}"
    return _run_git(repo_path, ["init"], require_repo=False)


@tool(
    name="git_branch_create",
    description=(
        "Create a new branch. By default, also checks it out (switches "
        "the working tree to it). Refuses if the branch name already "
        "exists locally."
    ),
    risk="medium",
    category="git",
    parameters={
        "type": "object",
        "properties": {
            "repo_path": {"type": "string",
                          "description": "Absolute path to the git repository."},
            "name": {"type": "string",
                     "description": "Branch name (e.g. 'feat/foo' or 'fix-bug-123')."},
            "checkout": {"type": "boolean",
                         "description": "If true, also switch to the new branch. "
                                        "Default true."},
        },
        "required": ["repo_path", "name"],
    },
)
def git_branch_create(repo_path: str, name: str, checkout: bool = True) -> str:
    if not name or not name.strip():
        return "Error: branch name is required"
    name = name.strip()
    # Pre-check for existing branch — git's own error is fine but a
    # named-tool error is friendlier.
    existing = _run_git(repo_path, ["branch", "--list", name])
    if existing and existing != "(no output)" and not existing.startswith("Error"):
        return f"Error: branch already exists: {name}"
    args = ["checkout", "-b", name] if checkout else ["branch", name]
    return _run_git(repo_path, args)


@tool(
    name="git_checkout",
    description=(
        "Switch to an existing branch. By default refuses if the working "
        "tree has uncommitted changes (would silently abandon them). "
        "Pass force=true to discard the uncommitted changes and switch "
        "anyway — this is destructive."
    ),
    risk="medium",
    category="git",
    parameters={
        "type": "object",
        "properties": {
            "repo_path": {"type": "string",
                          "description": "Absolute path to the git repository."},
            "branch": {"type": "string",
                       "description": "Branch name to switch to."},
            "force": {"type": "boolean",
                      "description": "If true, discard uncommitted changes "
                                     "before switching. Default false."},
        },
        "required": ["repo_path", "branch"],
    },
)
def git_checkout(repo_path: str, branch: str, force: bool = False) -> str:
    if not branch or not branch.strip():
        return "Error: branch is required"
    branch = branch.strip()
    if not force:
        dirty = _is_dirty(repo_path)
        if dirty is None:
            return f"Error: could not check working-tree status of {repo_path}"
        if dirty:
            return (
                "Error: working tree has uncommitted changes. Commit them "
                "first, or pass force=true to discard them and switch."
            )
    args = ["checkout"]
    if force:
        args.append("--force")
    args.append(branch)
    return _run_git(repo_path, args)


@tool(
    name="git_add",
    description=(
        "Stage files for the next commit. `paths` is a list of paths "
        "(relative to the repo root). Pass `['.']` to stage every change "
        "— this is explicit; the tool does NOT default to 'everything'."
    ),
    risk="medium",
    category="git",
    parameters={
        "type": "object",
        "properties": {
            "repo_path": {"type": "string",
                          "description": "Absolute path to the git repository."},
            "paths": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Paths to stage, relative to repo root. "
                               "Use ['.'] to stage everything.",
            },
        },
        "required": ["repo_path", "paths"],
    },
)
def git_add(repo_path: str, paths: list[str]) -> str:
    if not paths:
        return "Error: paths is required (use ['.'] to stage everything)"
    cleaned = [p for p in paths if p and p.strip()]
    if not cleaned:
        return "Error: paths must contain at least one non-empty entry"
    out = _run_git(repo_path, ["add", "--", *cleaned])
    # `git add` prints nothing on success — surface a useful confirmation.
    if out == "(no output)":
        return f"Staged: {', '.join(cleaned)}"
    return out


@tool(
    name="git_commit",
    description=(
        "Commit the staged changes with the given message. Refuses if "
        "nothing is staged (call git_add first). Surfaces git's "
        "'user.email not set' error when the local git config is missing "
        "an author."
    ),
    risk="medium",
    category="git",
    parameters={
        "type": "object",
        "properties": {
            "repo_path": {"type": "string",
                          "description": "Absolute path to the git repository."},
            "message": {"type": "string",
                        "description": "Commit message. One short imperative "
                                       "line is conventional."},
        },
        "required": ["repo_path", "message"],
    },
)
def git_commit(repo_path: str, message: str) -> str:
    if not message or not message.strip():
        return "Error: message is required"
    # Pre-check that something is staged. `git diff --cached --quiet` exits
    # 1 when there's a staged diff, 0 when there isn't.
    raw = _run_git(repo_path, ["diff", "--cached", "--name-only"])
    if raw.startswith("Error"):
        return raw
    if raw == "(no output)" or not raw.strip():
        return (
            "Error: nothing staged to commit. Call git_add first with the "
            "files you want included."
        )
    return _run_git(repo_path, ["commit", "-m", message.strip()])
