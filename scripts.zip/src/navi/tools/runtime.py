"""Run a Python snippet in a chosen working directory.

Closes the write→test→fix loop opened by the scaffolding + AST + git
tools: the LLM can now ``add_python_function`` something, then
``run_python`` it to verify the behavior, then ``replace_lines`` to fix
what doesn't work.

Risk is ``high`` — same gate as ``run_powershell``: every call
surfaces the full code in the permission dialog so the user can spot
``os.system('rm -rf /')`` before allowing.

Interpreter resolution (in order of preference):

1. ``<cwd>/.venv/Scripts/python.exe`` — project's venv (most likely
   what the user is iterating on).
2. ``<cwd>/venv/Scripts/python.exe`` — alternate venv convention.
3. ``sys.executable`` — Navi's own interpreter.

The last fallback means ``run_python`` always works, but `import` of
project-local packages will fail unless the project happens to be on
``sys.path`` or installed in Navi's venv.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from navi.tools._registry import tool


PYTHON_TIMEOUT_DEFAULT_SEC = 30
PYTHON_TIMEOUT_MAX_SEC = 300
PYTHON_MAX_OUTPUT = 8000


def _resolve_interpreter(cwd: Path) -> str:
    """Pick the right python.exe for ``cwd``. See module docstring for order."""
    if os.name == "nt":
        candidates = [
            cwd / ".venv" / "Scripts" / "python.exe",
            cwd / "venv" / "Scripts" / "python.exe",
        ]
    else:
        candidates = [
            cwd / ".venv" / "bin" / "python",
            cwd / "venv" / "bin" / "python",
        ]
    for c in candidates:
        if c.exists():
            return str(c)
    return sys.executable


@tool(
    name="run_python",
    description=(
        "Run a Python snippet in the chosen working directory. Returns "
        "stdout (and stderr if any). Picks `<cwd>/.venv/Scripts/python.exe` "
        "if it exists so project-local imports work; otherwise falls back "
        "to Navi's own interpreter. **High risk** — every call requires "
        "explicit user approval; the full code is shown in the dialog. "
        "30s default timeout, 8 KB output cap."
    ),
    risk="high",
    category="code",
    parameters={
        "type": "object",
        "properties": {
            "code": {"type": "string",
                     "description": "Python source to run (passed via "
                                    "`python -c`). Use `\\n` for newlines."},
            "cwd": {"type": "string",
                    "description": "Absolute working directory. Determines "
                                   "venv lookup and import resolution."},
            "timeout_s": {"type": "integer",
                          "description": "Timeout in seconds. Default 30, "
                                         "max 300."},
        },
        "required": ["code", "cwd"],
    },
)
def run_python(code: str, cwd: str, timeout_s: int = PYTHON_TIMEOUT_DEFAULT_SEC) -> str:
    if not code or not code.strip():
        return "Error: code must not be empty."
    cwd_path = Path(cwd)
    if not cwd_path.is_absolute():
        return f"Error: cwd must be absolute: {cwd}"
    if not cwd_path.exists():
        return f"Error: cwd does not exist: {cwd}"
    if not cwd_path.is_dir():
        return f"Error: cwd is not a directory: {cwd}"

    # Defense-in-depth: don't let an LLM `run_python(cwd=C:\\Windows)`.
    from navi.tools.filesystem import _is_protected_path
    if _is_protected_path(cwd_path):
        return f"Error: refusing to run python in a protected system path: {cwd}"

    timeout = max(1, min(int(timeout_s or PYTHON_TIMEOUT_DEFAULT_SEC),
                         PYTHON_TIMEOUT_MAX_SEC))
    interp = _resolve_interpreter(cwd_path)

    creationflags = 0
    if sys.platform == "win32":
        creationflags = subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]

    try:
        proc = subprocess.Popen(
            [interp, "-c", code],
            cwd=str(cwd_path),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            creationflags=creationflags,
        )
    except FileNotFoundError:
        return (
            f"Error: python interpreter not found at {interp}. "
            "Verify your venv or system Python install."
        )
    except OSError as exc:
        return f"Error launching python: {exc}"

    try:
        stdout, stderr = proc.communicate(timeout=timeout)
        rc = proc.returncode
    except subprocess.TimeoutExpired:
        if sys.platform == "win32":
            subprocess.run(
                ["taskkill", "/T", "/F", "/PID", str(proc.pid)],
                capture_output=True, check=False,
            )
        else:
            proc.kill()
        try:
            proc.communicate(timeout=2)
        except subprocess.TimeoutExpired:
            pass
        return f"Error: python command timed out after {timeout}s."

    stdout = (stdout or "").strip()
    stderr = (stderr or "").strip()

    interp_note = f"[interpreter: {interp}]"
    if rc != 0:
        out = f"Exit {rc}\n{interp_note}"
        if stderr:
            out += f"\nstderr:\n{stderr}"
        if stdout:
            out += f"\nstdout:\n{stdout}"
    else:
        out = stdout
        if stderr:
            out = f"{out}\n[stderr]\n{stderr}".strip()
        out = f"{out}\n{interp_note}".strip()

    if len(out) > PYTHON_MAX_OUTPUT:
        out = out[:PYTHON_MAX_OUTPUT] + f"\n... [truncated to {PYTHON_MAX_OUTPUT} chars]"
    return out or f"(no output)\n{interp_note}"
