from __future__ import annotations

from pathlib import Path

from navi.tools._registry import tool

# Truncate tool results so the document fits the model's context window.
# Budget: n_ctx (16384) - system_prompt + memory (~3k) - history (~2k)
#         - response_budget (1k) - tool_schema (~1k) ≈ 9k tokens for the
# tool result. At ~4 chars/token that's ~36k chars; we cap at 50k to leave
# a small safety margin and rely on the LLM to summarize what it gets.
MAX_FILE_BYTES = 50_000

# Binary extensions we cannot read at all. Returns a directive to *tell* the
# user the file type is unsupported (not "ask the user to do X" — that
# phrasing makes small models try to call user-interaction tools).
_BINARY_EXTS = frozenset({
    ".doc", ".xls", ".ppt",
    ".zip", ".7z", ".tar", ".gz", ".rar",
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".webp", ".ico",
    ".mp3", ".mp4", ".mov", ".wav", ".flac", ".m4a", ".avi", ".mkv",
    ".exe", ".dll", ".bin", ".so", ".dylib", ".o", ".a", ".lib",
    ".gguf", ".safetensors", ".pt", ".pth", ".onnx",
    ".db", ".sqlite", ".iso",
})

# These have a dedicated tool — read_file refuses them and points there.
_DEDICATED_TOOL_EXTS: dict[str, str] = {
    ".pdf": "read_pdf",
    ".xlsx": "read_excel",
    ".xlsm": "read_excel",
    ".pptx": "read_pptx",
    ".csv": "read_csv",
}


@tool(
    name="read_file",
    description=(
        "Read a file from disk and return its text contents (truncated to ~50 KB; "
        "for larger files call summarize_file instead). Supports plain text "
        "(.txt, .md, .py, etc.) and Word documents (.docx). For other formats "
        "use the dedicated tool: read_pdf, read_excel, read_pptx, or read_csv. "
        "Images, archives, and legacy binary formats are not supported. "
        "Path must be absolute."
    ),
    risk="low",
    parameters={
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Absolute file path."},
        },
        "required": ["path"],
    },
)
def read_file(path: str) -> str:
    p = Path(path)
    if not p.is_absolute():
        return f"Error: path must be absolute: {path}"
    if not p.exists():
        return f"Error: file does not exist: {path}"
    if not p.is_file():
        return f"Error: not a regular file: {path}"
    suffix = p.suffix.lower()
    if suffix == ".docx":
        return _read_docx(p)
    if suffix in _DEDICATED_TOOL_EXTS:
        tool_name = _DEDICATED_TOOL_EXTS[suffix]
        return (
            f"Cannot read '{p.name}' with read_file: use the {tool_name} tool "
            f"instead (it's the dedicated tool for {suffix} files)."
        )
    if suffix in _BINARY_EXTS:
        return (
            f"Cannot read '{p.name}': unsupported binary file type ({suffix}). "
            f"Tell the user to export this file to .txt or .md if they want it read."
        )
    try:
        data = p.read_bytes()[:MAX_FILE_BYTES]
    except OSError as exc:
        return f"Error reading {path}: {exc}"
    if b"\x00" in data[:8192]:
        return (
            f"Cannot read '{p.name}': appears to be a binary file (contains NUL bytes). "
            f"Tell the user this file type is not supported."
        )
    text = data.decode("utf-8", errors="replace")
    if len(data) == MAX_FILE_BYTES:
        text += (
            f"\n... [truncated at {MAX_FILE_BYTES} bytes — for full coverage "
            f"call summarize_file(path={path!r}) instead]"
        )
    return text


@tool(
    name="read_pdf",
    description=(
        "Extract text from a PDF file. Path must be absolute. Returns the "
        "concatenated text of every page (truncated to ~50 KB; for larger "
        "PDFs call summarize_file instead). Best for born-digital PDFs; "
        "scanned/image-only PDFs return little or no text."
    ),
    risk="low",
    parameters={
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Absolute path to a .pdf file."},
            "max_pages": {
                "type": "integer",
                "description": "Optional cap on pages to read (default 50).",
            },
        },
        "required": ["path"],
    },
)
def read_pdf(path: str, max_pages: int = 50) -> str:
    p = Path(path)
    if not p.is_absolute():
        return f"Error: path must be absolute: {path}"
    if not p.exists() or not p.is_file():
        return f"Error: file does not exist: {path}"
    if p.suffix.lower() != ".pdf":
        return f"Error: not a PDF: {p.name}"
    try:
        from pypdf import PdfReader
    except ImportError:
        return "Error: pypdf is not installed. `pip install pypdf`."
    try:
        reader = PdfReader(str(p))
    except Exception as exc:
        return f"Error opening {p.name}: {exc}"
    if reader.is_encrypted:
        return f"Error: '{p.name}' is encrypted (password-protected)."
    pages = reader.pages
    out: list[str] = []
    n = min(len(pages), max(1, int(max_pages)))
    total_chars = 0
    for i in range(n):
        try:
            text = pages[i].extract_text() or ""
        except Exception as exc:
            text = f"[page {i + 1} extraction failed: {exc}]"
        text = text.strip()
        if text:
            out.append(f"--- page {i + 1} ---\n{text}")
            total_chars += len(text)
            if total_chars >= MAX_FILE_BYTES:
                out.append(
                    f"... [truncated at ~{MAX_FILE_BYTES} chars — for full "
                    f"coverage call summarize_file(path) instead]"
                )
                break
    if not out:
        return (
            f"'{p.name}' returned no text. It may be a scanned/image PDF — "
            "try ocr_image on each page after rendering."
        )
    return "\n\n".join(out)


@tool(
    name="read_excel",
    description=(
        "Read an Excel (.xlsx) workbook. Returns the first ~50 rows of each "
        "sheet as a CSV-like text grid. Path must be absolute."
    ),
    risk="low",
    parameters={
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Absolute path to a .xlsx file."},
            "max_rows": {
                "type": "integer",
                "description": "Optional cap on rows per sheet (default 50).",
            },
        },
        "required": ["path"],
    },
)
def read_excel(path: str, max_rows: int = 50) -> str:
    p = Path(path)
    if not p.is_absolute():
        return f"Error: path must be absolute: {path}"
    if not p.exists() or not p.is_file():
        return f"Error: file does not exist: {path}"
    if p.suffix.lower() not in {".xlsx", ".xlsm"}:
        return f"Error: read_excel only supports .xlsx/.xlsm — got '{p.suffix}'."
    try:
        from openpyxl import load_workbook
    except ImportError:
        return "Error: openpyxl is not installed."
    try:
        wb = load_workbook(str(p), data_only=True, read_only=True)
    except Exception as exc:
        return f"Error opening {p.name}: {exc}"
    out: list[str] = []
    try:
        for ws in wb.worksheets:
            out.append(f"### Sheet: {ws.title}")
            rows_emitted = 0
            for row in ws.iter_rows(values_only=True):
                cells = ["" if v is None else str(v) for v in row]
                out.append(" | ".join(cells))
                rows_emitted += 1
                if rows_emitted >= max(1, int(max_rows)):
                    out.append(f"... [truncated to {max_rows} rows]")
                    break
            out.append("")
    finally:
        wb.close()
    return "\n".join(out).rstrip()


@tool(
    name="read_pptx",
    description=(
        "Extract text from a PowerPoint (.pptx) file. Path must be absolute. "
        "Returns each slide's title + body text as a numbered section "
        "(truncated to ~50 KB total; for larger decks call summarize_file). "
        "Speaker notes are included if present."
    ),
    risk="low",
    parameters={
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Absolute path to a .pptx file."},
            "max_slides": {
                "type": "integer",
                "description": "Optional cap on slides to read (default 100).",
            },
        },
        "required": ["path"],
    },
)
def read_pptx(path: str, max_slides: int = 100) -> str:
    p = Path(path)
    if not p.is_absolute():
        return f"Error: path must be absolute: {path}"
    if not p.exists() or not p.is_file():
        return f"Error: file does not exist: {path}"
    if p.suffix.lower() != ".pptx":
        return f"Error: read_pptx only supports .pptx — got '{p.suffix}'."
    # Detect non-OOXML containers. Modern .pptx is a ZIP and starts with PK
    # (50 4B). The OLE2 compound-file magic D0 CF 11 E0 A1 B1 1A E1 means
    # one of: legacy .ppt, IRM/DRM-encrypted .pptx, or password-protected
    # .pptx. Each needs a different message.
    try:
        with open(p, "rb") as fh:
            head = fh.read(8)
    except OSError as exc:
        return f"Error opening {p.name}: {exc}"
    if head.startswith(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"):
        # Distinguish IRM-encrypted (DoD/enterprise common) from legacy .ppt
        # by inspecting the OLE2 stream directory.
        stream_paths: list[str] = []
        try:
            import olefile  # type: ignore[import-not-found]
            ole = olefile.OleFileIO(str(p))
            try:
                stream_paths = ["/".join(s) for s in ole.listdir()]
            finally:
                ole.close()
        except Exception:
            stream_paths = []
        is_irm = any("DRMEncrypt" in s or s == "EncryptedPackage" for s in stream_paths)
        is_password_encrypted = "EncryptedPackage" in stream_paths and not is_irm
        if is_irm:
            return (
                f"'{p.name}' is encrypted with Microsoft Information Rights "
                "Management (IRM/AD RMS) — common on DoD and enterprise "
                "documents. Only PowerPoint running as the authenticated "
                "user can decrypt it; external tools cannot. Tell the user: "
                "open the file in PowerPoint, copy the slide text into a "
                "plain .txt or .docx file, and ask Navi to read THAT."
            )
        if is_password_encrypted:
            return (
                f"'{p.name}' is password-protected (encrypted .pptx). "
                "Tell the user to open it in PowerPoint, remove the password "
                "(File → Info → Protect Presentation → Encrypt with Password "
                "→ clear the password), save, and try again."
            )
        return (
            f"'{p.name}' has a .pptx extension but is actually a legacy "
            ".ppt file (OLE2 binary format, not OOXML). Tell the user to "
            "open it in PowerPoint, then File → Save As → choose "
            "'PowerPoint Presentation (*.pptx)' from the format dropdown."
        )
    if not head.startswith(b"PK"):
        return (
            f"'{p.name}' is not a valid .pptx file (no ZIP signature). "
            "Tell the user the file may be corrupted or in an unexpected format."
        )
    try:
        from pptx import Presentation  # type: ignore[import-not-found]
    except ImportError:
        return "Error: python-pptx is not installed."
    try:
        pres = Presentation(str(p))
    except Exception as exc:  # noqa: BLE001
        return f"Error opening {p.name}: {exc}"
    out: list[str] = []
    total_chars = 0
    n = min(len(pres.slides), max(1, int(max_slides)))
    for i, slide in enumerate(pres.slides):
        if i >= n:
            break
        # Title (best-effort)
        title = ""
        try:
            if slide.shapes.title and slide.shapes.title.has_text_frame:
                title = (slide.shapes.title.text_frame.text or "").strip()
        except Exception:  # noqa: BLE001
            pass
        # Collect text from every shape that has a text frame
        body_chunks: list[str] = []
        for shape in slide.shapes:
            try:
                if not shape.has_text_frame:
                    continue
                for para in shape.text_frame.paragraphs:
                    text = "".join(run.text for run in para.runs).strip()
                    if not text:
                        continue
                    if text == title:
                        continue
                    body_chunks.append("- " + text)
            except Exception:  # noqa: BLE001
                continue
        # Speaker notes
        notes = ""
        try:
            if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
                notes = (slide.notes_slide.notes_text_frame.text or "").strip()
        except Exception:  # noqa: BLE001
            pass
        # Assemble
        header = f"--- slide {i + 1}"
        if title:
            header += f": {title}"
        header += " ---"
        section = [header]
        section.extend(body_chunks)
        if notes:
            section.append(f"[notes] {notes}")
        chunk = "\n".join(section)
        out.append(chunk)
        total_chars += len(chunk)
        if total_chars >= MAX_FILE_BYTES:
            out.append(
                f"... [truncated at ~{MAX_FILE_BYTES} chars — for full "
                f"coverage call summarize_file(path) instead]"
            )
            break
    if not out:
        return f"'{p.name}' has no extractable text (may be image-only slides)."
    return "\n\n".join(out)


@tool(
    name="read_csv",
    description=(
        "Read a CSV file and return its contents as a formatted table. "
        "Path must be absolute. Caps to ~500 rows."
    ),
    risk="low",
    parameters={
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Absolute path to a .csv file."},
            "max_rows": {
                "type": "integer",
                "description": "Optional cap on rows (default 500).",
            },
        },
        "required": ["path"],
    },
)
def read_csv(path: str, max_rows: int = 500) -> str:
    import csv

    p = Path(path)
    if not p.is_absolute():
        return f"Error: path must be absolute: {path}"
    if not p.exists() or not p.is_file():
        return f"Error: file does not exist: {path}"
    try:
        with p.open("r", encoding="utf-8", errors="replace", newline="") as f:
            reader = csv.reader(f)
            rows: list[list[str]] = []
            for i, row in enumerate(reader):
                if i >= max(1, int(max_rows)):
                    rows.append([f"... [truncated to {max_rows} rows]"])
                    break
                rows.append(row)
    except OSError as exc:
        return f"Error reading {p.name}: {exc}"
    if not rows:
        return f"'{p.name}' is empty."
    # Pretty pipe-separated output
    return "\n".join(" | ".join(c for c in row) for row in rows)


def _read_docx(p: Path) -> str:
    """Extract plain text from a Word .docx file."""
    try:
        from docx import Document  # python-docx
    except ImportError:
        return (
            f"Cannot read '{p.name}': python-docx is not installed. "
            "Install it with: pip install python-docx"
        )
    try:
        doc = Document(str(p))
    except Exception as exc:
        return f"Error opening {p.name}: {exc}"

    parts: list[str] = []
    for para in doc.paragraphs:
        text = para.text.strip()
        if text:
            parts.append(text)
    for table in doc.tables:
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            if any(cells):
                parts.append(" | ".join(cells))

    if not parts:
        return f"'{p.name}' is empty (no text content found)."

    out = "\n".join(parts)
    if len(out) > MAX_FILE_BYTES:
        out = (
            out[:MAX_FILE_BYTES]
            + f"\n... [truncated at {MAX_FILE_BYTES} chars — for full "
            f"coverage call summarize_file(path) instead]"
        )
    return out


@tool(
    name="write_file",
    description=(
        "Write text content to a file. Path must be absolute. "
        "Overwrites the file if it exists. Creates parent directories as needed. "
        "Use this for plain text — does not produce Word/PDF/Excel files."
    ),
    risk="medium",
    parameters={
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Absolute file path."},
            "content": {"type": "string", "description": "Text content to write (UTF-8)."},
        },
        "required": ["path", "content"],
    },
)
def write_file(path: str, content: str) -> str:
    p = Path(path)
    if not p.is_absolute():
        return f"Error: path must be absolute: {path}"
    if p.suffix.lower() in _BINARY_EXTS or p.suffix.lower() == ".docx":
        return (
            f"Cannot write '{p.name}': '{p.suffix}' is a binary format. "
            "write_file only produces plain text. Use .txt or .md."
        )
    try:
        from navi._io import atomic_write_text
        atomic_write_text(p, content)
    except OSError as exc:
        return f"Error writing {path}: {exc}"
    return f"Wrote {len(content)} chars to {p}."


@tool(
    name="list_dir",
    description="List the immediate contents of a directory (files + subdirectories). Path must be absolute.",
    risk="safe",
    parameters={
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Absolute directory path."},
        },
        "required": ["path"],
    },
)
def list_dir(path: str) -> str:
    p = Path(path)
    if not p.is_absolute():
        return f"Error: path must be absolute: {path}"
    if not p.exists():
        return f"Error: directory does not exist: {path}"
    if not p.is_dir():
        return f"Error: not a directory: {path}"
    try:
        entries = sorted(p.iterdir(), key=lambda e: (not e.is_dir(), e.name.lower()))
    except OSError as exc:
        return f"Error listing {path}: {exc}"
    if not entries:
        return "(empty)"
    return "\n".join(f"{'<DIR> ' if e.is_dir() else '      '}{e.name}" for e in entries)
