"""Image-generation tool.

Risk = ``medium`` so the permission system asks before each call (with
the prompt visible in the dialog). Returns the saved file path; chat
panel renders it inline.

When ``diffusers`` / model isn't installed, returns a multi-line help
message with the exact pip + downloader commands. The architecture
ships even if the model doesn't.
"""

from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

from navi.tools._registry import tool


def _build_install_help() -> str:
    """Render install help dynamically from the model registry so adding
    a new model in ``navi.image.models`` automatically updates the docs
    the user sees."""
    from navi.image.models import DEFAULT_MODEL_ID, list_models

    lines = [
        "🖼️ Image generation isn't set up yet. To enable:",
        "",
        "1) Install the diffusion stack:",
        "   .venv/Scripts/python.exe -m pip install diffusers transformers "
        "accelerate safetensors torch",
        "",
        "2) Download a model (default is the first one shown):",
    ]
    for mid, spec in list_models():
        marker = " (default)" if mid == DEFAULT_MODEL_ID else ""
        lines.append(
            f"   • {mid}{marker} — {spec.size_gb:g} GB, {spec.license}, "
            f"{spec.notes}"
        )
    lines += [
        "",
        "   .venv/Scripts/python.exe scripts/install_image_model.py "
        f"{DEFAULT_MODEL_ID}",
        "",
        "3) Try the same request again.",
    ]
    return "\n".join(lines)


def _default_output_path() -> Path:
    """Where to save when caller didn't specify. ``%APPDATA%/Navi/generated/``
    with a timestamped filename. Created on demand."""
    appdata = os.environ.get("APPDATA")
    base = Path(appdata) if appdata else Path.home() / ".local" / "share"
    out_dir = base / "Navi" / "generated"
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    return out_dir / f"navi_{stamp}.png"


@tool(
    name="generate_image",
    description=(
        "Generate an image from a text prompt using a local diffusion "
        "model. Returns the saved PNG file path. Be specific in the "
        "prompt: name the subject (concrete nouns), style or medium, "
        "lighting, composition or camera angle, and color palette. "
        "Picks a default output location under "
        "%APPDATA%/Navi/generated/ if output_path isn't given."
    ),
    risk="medium",  # asks for permission with the prompt previewed
    category="image",
    parameters={
        "type": "object",
        "properties": {
            "prompt": {
                "type": "string",
                "description": "What to draw. Expand short user requests "
                               "into a dense prompt with subject + style + "
                               "lighting + composition + palette.",
            },
            "negative_prompt": {
                "type": "string",
                "description": "Optional. Things to avoid in the image "
                               "(e.g. 'blurry, deformed, low quality'). "
                               "Ignored by FLUX schnell.",
            },
            "output_path": {
                "type": "string",
                "description": "Optional absolute .png path. Defaults to "
                               "%APPDATA%/Navi/generated/navi_<timestamp>.png.",
            },
            "steps": {
                "type": "integer",
                "description": "Diffusion steps. FLUX schnell needs only "
                               "1-4; Sana ~18. Higher = marginally better "
                               "but proportionally slower. Default is the "
                               "model's tuned value.",
            },
            "width": {
                "type": "integer",
                "description": "Output width in pixels. Default 1024. "
                               "Multiples of 64 work best.",
            },
            "height": {
                "type": "integer",
                "description": "Output height in pixels. Default 1024.",
            },
        },
        "required": ["prompt"],
    },
)
def generate_image(
    prompt: str,
    negative_prompt: str = "",
    output_path: str = "",
    steps: int = 0,
    width: int = 1024,
    height: int = 1024,
) -> str:
    if not prompt or not prompt.strip():
        return "Error: prompt is required."
    out = Path(output_path) if output_path else _default_output_path()
    if not out.is_absolute():
        return f"Error: output_path must be absolute, got: {out}"

    # Lazy import — keeps tool registration cheap even when the image
    # subsystem is unused.
    from navi.image.client import ImageError, get_image_client
    from navi.image.models import get_spec

    # Resolve current model spec so the rewriter knows whether to bother
    # producing a negative_prompt and so the default step count tracks
    # the model.
    try:
        from navi.settings.store import load as load_settings
        settings = load_settings()
        image_cfg = settings.get("image") or {}
    except Exception:  # noqa: BLE001
        image_cfg = {}
    spec = get_spec(image_cfg.get("model_id"))
    rewrite_enabled = bool(image_cfg.get("prompt_rewrite", True))

    if steps <= 0:
        cfg_steps = image_cfg.get("default_steps")
        steps = int(cfg_steps) if cfg_steps else spec.default_steps

    final_prompt = prompt
    final_negative: str | None = negative_prompt.strip() or None

    if rewrite_enabled:
        # LLM enrichment. Best-effort; falls back to raw prompt on any error.
        from navi.brain import shared
        from navi.image.prompt_rewriter import rewrite as rewrite_prompt
        shared.emit_progress("🖼️ enriching prompt…")
        enriched, neg = rewrite_prompt(prompt, spec.supports_negative_prompt)
        final_prompt = enriched
        if neg and not final_negative:
            final_negative = neg
        if enriched != prompt:
            preview = enriched if len(enriched) <= 120 else enriched[:117] + "…"
            shared.emit_progress(f"🖼️ enriched: {preview}")

    try:
        client = get_image_client()
        # Push progress through the brain.shared progress channel so the
        # chat status bar can show "step 2/4…" while we wait.
        from navi.brain import shared

        def _progress(step: int, total: int) -> None:
            shared.emit_progress(f"🖼️ generating image… step {step}/{total}")

        shared.emit_progress(f"🖼️ generating image ({steps} steps)…")
        path = client.generate(
            prompt=final_prompt,
            negative_prompt=final_negative,
            output_path=out,
            steps=int(steps),
            width=int(width),
            height=int(height),
            progress_cb=_progress,
        )
        return f"Image generated: file:///{path.replace(chr(92), '/')}"
    except ImageError as exc:
        if exc.kind in ("diffusers_missing", "model_not_found"):
            return f"{_build_install_help()}\n\n(Underlying error: {exc.message})"
        return f"Image generation failed ({exc.kind}): {exc.message}"
    except Exception as exc:  # noqa: BLE001
        return f"Image generation failed: {exc}"
