"""Image-generation tool.

Risk = ``medium`` so the permission system asks before each call (with
the prompt visible in the dialog). Returns the saved file path; chat
panel renders it inline.

When ``diffusers`` / model isn't installed, returns a multi-line help
message with the exact pip + huggingface-hub commands. The architecture
ships even if the model doesn't.
"""

from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

from navi.tools._registry import tool


_INSTALL_HELP = (
    "🖼️ Image generation isn't set up yet. To enable:\n\n"
    "1) Install the diffusion stack:\n"
    "   .venv/Scripts/python.exe -m pip install diffusers transformers "
    "accelerate safetensors torch\n\n"
    "2) Download FLUX.1 Schnell (Apache 2.0, ~12 GB):\n"
    "   .venv/Scripts/python.exe -c \"from huggingface_hub import "
    "snapshot_download; snapshot_download("
    "'black-forest-labs/FLUX.1-schnell', "
    "local_dir='models/FLUX.1-schnell')\"\n\n"
    "3) Try the same request again."
)


def _default_output_path() -> Path:
    """Where to save when caller didn't specify. ``%APPDATA%/Navi/generated/``
    with a timestamped filename. Created on demand."""
    appdata = os.environ.get("APPDATA")
    base = Path(appdata) if appdata else Path.home() / ".local" / "share"
    out_dir = base / "Navi" / "generated"
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    return out_dir / f"navi_{stamp}.png"


@tool(
    name="generate_image",
    description=(
        "Generate an image from a text prompt using a local diffusion "
        "model (FLUX.1 Schnell). Returns the saved PNG file path. "
        "Slow on CPU (5-15 min) — only use when the user explicitly asks "
        "for an image. Picks a default output location under "
        "%APPDATA%/Navi/generated/ if output_path isn't given."
    ),
    risk="medium",  # asks for permission with the prompt previewed
    parameters={
        "type": "object",
        "properties": {
            "prompt": {
                "type": "string",
                "description": "What to draw. Be specific — diffusion "
                               "models reward concrete nouns + style adjectives.",
            },
            "output_path": {
                "type": "string",
                "description": "Optional absolute .png path. Defaults to "
                               "%APPDATA%/Navi/generated/navi_<timestamp>.png.",
            },
            "steps": {
                "type": "integer",
                "description": "Diffusion steps. FLUX Schnell needs only "
                               "1-4. Higher is marginally better quality "
                               "but proportionally slower. Default 4.",
            },
            "width": {
                "type": "integer",
                "description": "Output width in pixels. Default 1024. "
                               "Multiples of 64 work best.",
            },
            "height": {
                "type": "integer",
                "description": "Output height in pixels. Default 1024.",
            },
        },
        "required": ["prompt"],
    },
)
def generate_image(
    prompt: str,
    output_path: str = "",
    steps: int = 4,
    width: int = 1024,
    height: int = 1024,
) -> str:
    if not prompt or not prompt.strip():
        return "Error: prompt is required."
    out = Path(output_path) if output_path else _default_output_path()
    if not out.is_absolute():
        return f"Error: output_path must be absolute, got: {out}"

    # Lazy import — keeps tool registration cheap even when the image
    # subsystem is unused.
    from navi.image.client import ImageError, get_image_client

    try:
        client = get_image_client()
        # Push progress through the brain.shared progress channel so the
        # chat status bar can show "step 2/4…" while we wait.
        from navi.brain import shared

        def _progress(step: int, total: int) -> None:
            shared.emit_progress(f"🖼️ generating image… step {step}/{total}")

        shared.emit_progress(f"🖼️ generating image ({steps} steps)…")
        path = client.generate(
            prompt=prompt,
            output_path=out,
            steps=int(steps),
            width=int(width),
            height=int(height),
            progress_cb=_progress,
        )
        return f"Image generated: file:///{path.replace(chr(92), '/')}"
    except ImageError as exc:
        if exc.kind in ("diffusers_missing", "model_not_found"):
            return f"{_INSTALL_HELP}\n\n(Underlying error: {exc.message})"
        return f"Image generation failed ({exc.kind}): {exc.message}"
    except Exception as exc:  # noqa: BLE001
        return f"Image generation failed: {exc}"
