"""Text-to-speech via pyttsx3 (Windows SAPI).

Runs synthesis on a dedicated thread because pyttsx3's ``runAndWait`` blocks
and is finicky if shared across threads. Public API is signal-driven so the
GUI thread never blocks.
"""

from __future__ import annotations

import queue
import threading
from dataclasses import dataclass

from PySide6.QtCore import QObject, QThread, Signal, Slot


@dataclass
class _Utterance:
    text: str
    voice_id: str | None
    rate: int | None
    volume: float | None


class _TTSWorker(QObject):
    """Lives on a QThread; consumes utterances from a queue.

    The pyttsx3 engine is initialized **inside** ``run_loop`` (on the worker
    thread) — pyttsx3 is not thread-safe, the engine must be created on the
    same thread that calls it. Initializing on the GUI thread and using on
    the worker thread silently produces no audio.
    """

    started_speaking = Signal()
    finished_speaking = Signal()
    error = Signal(str)

    def __init__(self) -> None:
        super().__init__()
        self._queue: queue.Queue = queue.Queue()
        self._stop = threading.Event()
        self._engine = None
        self._available = False
        self._init_done = threading.Event()
        self._lock = threading.Lock()

    def _init_engine(self) -> None:
        try:
            import pyttsx3
            self._engine = pyttsx3.init()
            self._available = True
        except Exception as exc:
            self.error.emit(f"TTS init failed: {exc}")
        finally:
            self._init_done.set()

    @property
    def available(self) -> bool:
        # Wait briefly for init if it's still in flight (first frame after start)
        self._init_done.wait(timeout=2.0)
        return self._available

    def list_voices(self) -> list[tuple[str, str]]:
        # Block briefly for init so settings UI sees real voice list
        self._init_done.wait(timeout=2.0)
        if not self._engine:
            return []
        try:
            return [(v.id, v.name) for v in self._engine.getProperty("voices")]
        except Exception:
            return []

    @Slot()
    def run_loop(self) -> None:
        """Pull utterances from the queue and synthesize them."""
        # Init the engine on THIS thread — pyttsx3 must be used from the
        # thread that created it.
        self._init_engine()
        if not self._available:
            return

        while not self._stop.is_set():
            try:
                item = self._queue.get(timeout=0.1)
            except queue.Empty:
                continue
            if item is None:  # sentinel
                break
            self._speak_one(item)

    def _speak_one(self, utt: _Utterance) -> None:
        if self._engine is None:
            return
        # Apply voice properties under the lock (protects against a
        # concurrent cancel() poking at the engine), but emit signals and
        # call runAndWait OUTSIDE the lock — runAndWait blocks for seconds,
        # and a started_speaking handler that calls enqueue() / cancel()
        # would deadlock if it tried to take the lock during that window.
        with self._lock:
            try:
                if utt.voice_id:
                    self._engine.setProperty("voice", utt.voice_id)
                if utt.rate is not None:
                    self._engine.setProperty("rate", utt.rate)
                if utt.volume is not None:
                    self._engine.setProperty("volume", utt.volume)
                self._engine.say(utt.text)
            except Exception as exc:
                self.error.emit(f"TTS error: {exc}")
                self.finished_speaking.emit()
                return
        self.started_speaking.emit()
        try:
            self._engine.runAndWait()
        except Exception as exc:
            self.error.emit(f"TTS error: {exc}")
        finally:
            self.finished_speaking.emit()

    def enqueue(self, utt: _Utterance) -> None:
        # Drop any pending utterance: replies should always be the latest one
        with self._lock:
            try:
                while True:
                    self._queue.get_nowait()
            except queue.Empty:
                pass
        self._queue.put(utt)

    def cancel(self) -> None:
        # Drain queue and stop current speech
        try:
            while True:
                self._queue.get_nowait()
        except queue.Empty:
            pass
        if self._engine is not None:
            try:
                self._engine.stop()
            except Exception:
                pass

    def shutdown(self) -> None:
        self.cancel()
        self._stop.set()
        self._queue.put(None)


class TTSEngine(QObject):
    """Public TTS facade — owns a worker thread, exposes simple slots."""

    started_speaking = Signal()
    finished_speaking = Signal()
    error = Signal(str)

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._worker = _TTSWorker()
        self._thread = QThread(self)
        self._worker.moveToThread(self._thread)
        self._thread.started.connect(self._worker.run_loop)
        self._worker.started_speaking.connect(self.started_speaking)
        self._worker.finished_speaking.connect(self.finished_speaking)
        self._worker.error.connect(self.error)
        self._thread.start()

    @property
    def available(self) -> bool:
        return self._worker.available

    def list_voices(self) -> list[tuple[str, str]]:
        return self._worker.list_voices()

    @Slot(str)
    def speak(
        self,
        text: str,
        voice_id: str | None = None,
        rate: int | None = None,
        volume: float | None = None,
    ) -> None:
        if not self._worker.available:
            return
        text = (text or "").strip()
        if not text:
            return
        self._worker.enqueue(
            _Utterance(text=text, voice_id=voice_id, rate=rate, volume=volume)
        )

    @Slot()
    def cancel(self) -> None:
        self._worker.cancel()

    def shutdown(self) -> None:
        self._worker.shutdown()
        self._thread.quit()
        self._thread.wait(2000)
