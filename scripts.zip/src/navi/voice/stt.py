"""Speech-to-text via WinRT ``SpeechRecognizer`` (built into Windows 10/11).

One-shot recognition: call :meth:`transcribe_once`, it listens until the
user stops speaking, returns the transcribed text. No model downloads
required (Windows Speech Recognition uses local engines).

If WinRT is unavailable (older Windows, Speech Recognition disabled), the
engine reports ``available == False`` and ``transcribe_once`` returns an
empty string.
"""

from __future__ import annotations

import asyncio

from PySide6.QtCore import QObject, QThread, Signal, Slot


class _STTWorker(QObject):
    """Runs WinRT recognition on a worker thread (each call is async)."""

    started = Signal()
    transcribed = Signal(str)
    failed = Signal(str)
    finished = Signal()

    def __init__(self) -> None:
        super().__init__()
        self._available = False
        self._SpeechRecognizer = None
        try:
            from winsdk.windows.media.speechrecognition import SpeechRecognizer
            self._SpeechRecognizer = SpeechRecognizer
            self._available = True
        except Exception:
            self._available = False

    @property
    def available(self) -> bool:
        return self._available

    @Slot()
    def transcribe(self) -> None:
        if not self._available:
            self.failed.emit("WinRT speech recognition unavailable")
            self.finished.emit()
            return
        try:
            self.started.emit()
            text = asyncio.run(self._recognize())
            self.transcribed.emit(text)
        except Exception as exc:
            self.failed.emit(str(exc))
        finally:
            self.finished.emit()

    async def _recognize(self) -> str:
        recognizer = self._SpeechRecognizer()
        # Set language to en-US explicitly when available
        try:
            from winsdk.windows.globalization import Language
            recognizer = self._SpeechRecognizer(Language("en-US"))
        except Exception:
            recognizer = self._SpeechRecognizer()

        # Compile default web-search-like grammar (recognizes free dictation).
        await recognizer.compile_constraints_async()
        result = await recognizer.recognize_async()
        return (result.text or "").strip()


class STTEngine(QObject):
    """Public STT facade — push-to-talk one-shot recognition."""

    started = Signal()
    transcribed = Signal(str)
    failed = Signal(str)
    finished = Signal()

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._worker = _STTWorker()
        self._thread = QThread(self)
        self._worker.moveToThread(self._thread)

        self._worker.started.connect(self.started)
        self._worker.transcribed.connect(self.transcribed)
        self._worker.failed.connect(self.failed)
        self._worker.finished.connect(self.finished)

        self._thread.start()

    @property
    def available(self) -> bool:
        return self._worker.available

    @Slot()
    def transcribe_once(self) -> None:
        """Kick off a single recognition pass. Result comes back via signals."""
        # Trigger via queued connection so it runs on the worker thread
        from PySide6.QtCore import QMetaObject, Qt
        QMetaObject.invokeMethod(
            self._worker,
            "transcribe",
            Qt.ConnectionType.QueuedConnection,
        )

    def shutdown(self) -> None:
        self._thread.quit()
        self._thread.wait(2000)
