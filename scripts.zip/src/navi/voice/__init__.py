"""Voice subsystem: TTS via Windows SAPI (pyttsx3), STT via WinRT.

Public API:
- :class:`navi.voice.manager.VoiceManager` — wires TTS + STT + push-to-talk hotkey
- :class:`navi.voice.tts.TTSEngine` — non-blocking text-to-speech
- :class:`navi.voice.stt.STTEngine` — one-shot speech-to-text
"""

from navi.voice.manager import VoiceManager
from navi.voice.stt import STTEngine
from navi.voice.tts import TTSEngine

__all__ = ["VoiceManager", "STTEngine", "TTSEngine"]
