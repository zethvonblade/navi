"""High-level voice manager: TTS + STT + push-to-talk hotkey."""

from __future__ import annotations

from PySide6.QtCore import QObject, Signal

from navi.voice.stt import STTEngine
from navi.voice.tts import TTSEngine

# Cap TTS to a sane length — don't read multi-page summaries aloud.
MAX_SPEAK_CHARS = 800


class VoiceManager(QObject):
    """Thin coordinator over TTS + STT + an optional push-to-talk hotkey."""

    # User finished speaking — the transcribed text is ready to send to the brain
    transcribed = Signal(str)

    # Forwarded TTS state
    speaking_started = Signal()
    speaking_finished = Signal()

    # Forwarded STT state
    listening_started = Signal()
    listening_failed = Signal(str)

    # PTT hotkey installation result. Emitted once after _install_ptt
    # finishes — payload is the user-facing message ("PTT installed on
    # X" or "PTT install failed: Y"). PetWindow can surface as a chat
    # note so the user knows whether voice push-to-talk actually works.
    ptt_install_status = Signal(str)

    def __init__(
        self,
        *,
        enabled: bool = True,
        voice_id: str | None = None,
        rate: int | None = None,
        volume: float | None = None,
        ptt_hotkey: str = "ctrl+alt+space",
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self._enabled = enabled
        self._voice_id = voice_id
        self._rate = rate
        self._volume = volume

        self._tts = TTSEngine(self)
        self._stt = STTEngine(self)

        self._tts.started_speaking.connect(self.speaking_started)
        self._tts.finished_speaking.connect(self.speaking_finished)
        self._stt.started.connect(self.listening_started)
        self._stt.transcribed.connect(self._on_transcribed)
        self._stt.failed.connect(self.listening_failed)

        # Push-to-talk hotkey
        self._ptt_hotkey = ptt_hotkey
        self._ptt_handle = None
        self._last_ptt_status: str | None = None
        if enabled:
            self._install_ptt(ptt_hotkey)

    # --- public API --------------------------------------------------------
    @property
    def enabled(self) -> bool:
        return self._enabled

    @property
    def tts_available(self) -> bool:
        return self._tts.available

    @property
    def stt_available(self) -> bool:
        return self._stt.available

    def list_voices(self) -> list[tuple[str, str]]:
        return self._tts.list_voices()

    def set_enabled(self, enabled: bool) -> None:
        self._enabled = enabled
        if enabled:
            self._install_ptt(self._ptt_hotkey)
        else:
            self._uninstall_ptt()
            self._tts.cancel()

    def configure(
        self,
        *,
        voice_id: str | None = None,
        rate: int | None = None,
        volume: float | None = None,
        ptt_hotkey: str | None = None,
    ) -> None:
        if voice_id is not None:
            self._voice_id = voice_id
        if rate is not None:
            self._rate = rate
        if volume is not None:
            self._volume = volume
        if ptt_hotkey is not None and ptt_hotkey != self._ptt_hotkey:
            self._ptt_hotkey = ptt_hotkey
            if self._enabled:
                self._uninstall_ptt()
                self._install_ptt(ptt_hotkey)

    def speak(self, text: str) -> None:
        if not self._enabled or not text.strip():
            return
        clipped = text.strip()
        if len(clipped) > MAX_SPEAK_CHARS:
            clipped = clipped[:MAX_SPEAK_CHARS] + "… (response truncated for speech)"
        self._tts.speak(
            clipped,
            voice_id=self._voice_id,
            rate=self._rate,
            volume=self._volume,
        )

    def cancel_speech(self) -> None:
        self._tts.cancel()

    def transcribe_once(self) -> None:
        if not self._enabled:
            return
        self._stt.transcribe_once()

    def shutdown(self) -> None:
        self._uninstall_ptt()
        self._tts.shutdown()
        self._stt.shutdown()

    # --- internals ---------------------------------------------------------
    def _install_ptt(self, hotkey: str) -> None:
        try:
            import keyboard
            self._ptt_handle = keyboard.add_hotkey(hotkey, self.transcribe_once)
            self._last_ptt_status = f"🎙 push-to-talk armed on '{hotkey}'"
        except Exception as exc:  # noqa: BLE001
            self._ptt_handle = None
            # Surface the actual reason — admin requirement, AV blocking
            # the keyboard hook, or `keyboard` package missing all show up
            # the same way and the user otherwise has no clue PTT is dead.
            self._last_ptt_status = (
                f"⚠ push-to-talk install failed for '{hotkey}': "
                f"{exc.__class__.__name__}: {exc}"
            )
        self.ptt_install_status.emit(self._last_ptt_status)

    def report_ptt_status(self) -> None:
        """Re-emit the most recent install status. Useful when the
        ``ptt_install_status`` signal was connected AFTER ``__init__``
        already fired it during the initial install."""
        if self._last_ptt_status:
            self.ptt_install_status.emit(self._last_ptt_status)

    @property
    def ptt_installed(self) -> bool:
        """True when the PTT hotkey is currently active."""
        return self._ptt_handle is not None

    def _uninstall_ptt(self) -> None:
        if self._ptt_handle is None:
            return
        try:
            import keyboard
            keyboard.remove_hotkey(self._ptt_handle)
        except Exception:
            pass
        self._ptt_handle = None

    def _on_transcribed(self, text: str) -> None:
        if text.strip():
            self.transcribed.emit(text.strip())
