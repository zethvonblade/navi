"""LLM-driven enrichment of image-generation prompts.

The user (or the agent on behalf of the user) often passes terse prompts
like "draw a cat" to ``generate_image``. Diffusion models reward dense,
concrete prompts — subject + style + lighting + composition + palette.
This module asks the already-loaded LLM to rewrite a short prompt into
that richer form, returning ``(prompt, negative_prompt)``.

Reentrancy: the agent loop is single-threaded — when a tool runs, no
other completion is in flight. We reuse ``shared.get_llm()`` the same
way :mod:`navi.tools.summarize` does (see ``_stream_completion``).

Failure mode: any error → fall back to the raw prompt. Image generation
is the user's actual goal; rewriting is a quality bonus, not a gate.
"""

from __future__ import annotations

import json
import re

from navi.brain import shared


_REWRITE_SYSTEM = (
    "You are a prompt engineer for a text-to-image diffusion model. "
    "Rewrite the user's request as a single dense English prompt that "
    "names the subject (concrete nouns), style or medium, lighting, "
    "composition or camera angle, and color palette. Keep it under 60 "
    "words. Do NOT add commentary, do NOT ask questions, do NOT refuse. "
    "Respond with a single JSON object and nothing else, in this exact "
    "shape:\n"
    '  {"prompt": "...", "negative_prompt": "..."}\n'
    "If negative prompts are not useful for this image, set "
    '"negative_prompt" to an empty string.'
)


def _stream_to_text(llm, messages: list[dict[str, str]], max_tokens: int) -> str:
    """Same streaming-accumulate trick as summarize.py — keep the GIL
    yielding so the orb stays animated while we wait."""
    parts: list[str] = []
    stream = llm.create_chat_completion(
        messages=messages,
        max_tokens=max_tokens,
        temperature=0.4,
        stream=True,
    )
    for chunk in stream:
        if shared.is_cancelled():
            break
        choices = chunk.get("choices") or []
        if not choices:
            continue
        delta = choices[0].get("delta", {})
        content = delta.get("content")
        if content:
            parts.append(content)
    return "".join(parts).strip()


def _extract_json(text: str) -> dict | None:
    """Pull the first JSON object out of LLM output.

    Granite-family models sometimes emit ``<think>...</think>`` blocks
    or stray prose around the JSON; tolerate both.
    """
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()
    # Strip code fences.
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.MULTILINE)
    # Find the first {...} block (greedy so we capture nested braces).
    m = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if not m:
        return None
    try:
        obj = json.loads(m.group(0))
    except json.JSONDecodeError:
        return None
    return obj if isinstance(obj, dict) else None


def rewrite(
    user_prompt: str,
    supports_negative: bool,
) -> tuple[str, str | None]:
    """Return ``(enriched_prompt, negative_prompt_or_None)``.

    Falls back to ``(user_prompt, None)`` on any failure. ``supports_negative``
    is False for FLUX.1-schnell (CFG=0, negative prompts are ignored), True
    for SD/SDXL/Sana.
    """
    user_prompt = (user_prompt or "").strip()
    if not user_prompt:
        return user_prompt, None

    llm = shared.get_llm()
    if llm is None:
        return user_prompt, None

    messages = [
        {"role": "system", "content": _REWRITE_SYSTEM},
        {"role": "user", "content": user_prompt},
    ]
    try:
        raw = _stream_to_text(llm, messages, max_tokens=200)
    except Exception:  # noqa: BLE001
        return user_prompt, None

    obj = _extract_json(raw)
    if not obj:
        return user_prompt, None

    enriched = (obj.get("prompt") or "").strip()
    if not enriched:
        return user_prompt, None

    neg = (obj.get("negative_prompt") or "").strip() or None
    if not supports_negative:
        neg = None
    return enriched, neg
