"""Image generation subsystem.

Same architectural shape as :mod:`navi.brain` — a subprocess hosts the
heavy diffusion pipeline (loaded via ``diffusers``) and the main process
talks to it over JSON on stdin/stdout. This isolates the GIL hold of the
diffusion forward pass from the GUI thread, exactly the lesson we learned
with the LLM.

The subprocess is spawned **lazily** — only when the user first asks for
an image — so the 6-12 GB model isn't loaded into RAM for users who never
generate. After spawn it's kept warm for the rest of the session.

Public API:
* :class:`navi.image.client.ImageClient`
* :class:`navi.image.client.ImageError`
* :func:`navi.image.client.get_image_client`
"""
