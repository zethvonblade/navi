"""Main-process client for the image-generation subprocess.

Lazy spawn: the subprocess (and the 6-12 GB diffusion model it loads) is
only created on first :meth:`ImageClient.generate` call. After spawn it's
kept warm for the rest of the session.

A module-level singleton :func:`get_image_client` is the entrypoint for
tools — it builds the client from current settings, lazily. Subsequent
calls return the same instance.

Errors surface as :class:`ImageError` with a ``.kind`` field
(``"diffusers_missing" | "model_not_found" | "model_load_failed" |
"generate_failed" | "subprocess_error"``) so the caller can format
user-friendly messages.
"""

from __future__ import annotations

import json
import queue
import subprocess
import sys
import threading
from collections.abc import Iterator
from pathlib import Path
from typing import Any


def _emit(msg: str) -> None:
    """Best-effort progress emit. Imports lazily so this module stays
    usable from contexts where brain.shared isn't initialised (tests)."""
    try:
        from navi.brain import shared
        shared.emit_progress(msg)
    except Exception:  # noqa: BLE001
        pass


class ImageError(RuntimeError):
    """Raised by :class:`ImageClient` on any image-generation failure.

    ``kind`` is one of the subprocess error codes; ``message`` is the
    human-readable text suitable for showing in chat.
    """

    def __init__(self, kind: str, message: str) -> None:
        super().__init__(message)
        self.kind = kind
        self.message = message


class ImageClient:
    """Thin wrapper around the image subprocess.

    Init is deferred — the subprocess is spawned on first ``generate()``.
    """

    def __init__(
        self,
        model_path: Path | str,
        model_id: str | None = None,
        device_pref: str = "auto",
        ready_timeout_s: float = 300.0,
        generate_timeout_s: float = 600.0,
    ) -> None:
        self._model_path = Path(model_path)
        self._model_id = model_id
        self._device_pref = device_pref
        self._ready_timeout_s = ready_timeout_s
        self._generate_timeout_s = generate_timeout_s
        self._proc: subprocess.Popen | None = None
        self._events: queue.Queue[dict[str, Any] | None] = queue.Queue()
        self._writer_lock = threading.Lock()
        self._closed = False

    # --- subprocess lifecycle ----------------------------------------------
    def _ensure_spawned(self) -> None:
        if self._proc is not None and self._proc.poll() is None:
            return  # already alive
        if self._closed:
            raise ImageError("subprocess_error", "ImageClient is closed")
        self._proc = subprocess.Popen(
            [sys.executable, "-u", "-m", "navi.image.subprocess"],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=sys.stderr,
            text=True,
            bufsize=1,
            encoding="utf-8",
        )
        threading.Thread(
            target=self._read_events, daemon=True,
            name="image-stdout-reader",
        ).start()
        # init the model
        self._send({
            "op": "init",
            "model_path": str(self._model_path),
            "model_id": self._model_id,
            "device_pref": self._device_pref,
        })
        # The subprocess may emit non-fatal device_info events before
        # `ready` (e.g. "CUDA not available — running on CPU"). Surface
        # them via the shared progress channel and keep waiting.
        while True:
            try:
                evt = self._events.get(timeout=self._ready_timeout_s)
            except queue.Empty as exc:
                self._kill()
                raise ImageError(
                    "subprocess_error",
                    f"image subprocess didn't init within "
                    f"{self._ready_timeout_s}s",
                ) from exc
            if evt is None:
                raise ImageError("subprocess_error",
                                 "image subprocess died before ready")
            ev = evt.get("event")
            if ev == "device_info":
                _emit(f"🖼️ {evt.get('message', '')}")
                continue
            if ev == "error":
                kind = evt.get("code", "model_load_failed")
                self._kill()
                raise ImageError(kind, evt.get("message", "init failed"))
            if ev != "ready":
                raise ImageError("subprocess_error",
                                 f"unexpected init event: {evt}")
            # Ready. Surface model + device so the user sees it.
            device = evt.get("device", "?")
            vram = evt.get("vram_gb")
            vram_str = f", {vram} GB VRAM" if vram else ""
            _emit(
                f"🖼️ image model {evt.get('model', '')} loaded on "
                f"{device}{vram_str}"
            )
            break

    def _read_events(self) -> None:
        assert self._proc is not None and self._proc.stdout is not None
        for line in self._proc.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                evt = json.loads(line)
            except json.JSONDecodeError:
                continue
            self._events.put(evt)
        self._events.put(None)

    def _send(self, req: dict[str, Any]) -> None:
        # Take the writer lock for the WHOLE check — close() can flip
        # _closed and shut stdin between our pre-flight and write otherwise.
        line = json.dumps(req) + "\n"
        with self._writer_lock:
            if self._closed:
                raise ImageError("subprocess_error", "ImageClient is closed")
            if self._proc is None or self._proc.poll() is not None:
                raise ImageError("subprocess_error", "image subprocess not running")
            if self._proc.stdin is None:
                raise ImageError("subprocess_error", "image subprocess stdin is closed")
            self._proc.stdin.write(line)
            self._proc.stdin.flush()

    def _kill(self) -> None:
        if self._proc is None:
            return
        try:
            self._proc.kill()
        except Exception:  # noqa: BLE001
            pass
        try:
            self._proc.wait(timeout=2)
        except Exception:  # noqa: BLE001
            pass

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._proc is None:
            return
        try:
            with self._writer_lock:
                if self._proc.stdin and self._proc.poll() is None:
                    self._proc.stdin.write(json.dumps({"op": "shutdown"}) + "\n")
                    self._proc.stdin.flush()
                    self._proc.stdin.close()
        except Exception:  # noqa: BLE001
            pass
        try:
            self._proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            self._kill()

    def __del__(self) -> None:  # best-effort
        try:
            self.close()
        except Exception:  # noqa: BLE001
            pass

    # --- generate ----------------------------------------------------------
    def generate(
        self,
        prompt: str,
        output_path: Path | str,
        steps: int = 4,
        width: int = 1024,
        height: int = 1024,
        seed: int | None = None,
        negative_prompt: str | None = None,
        progress_cb: Any = None,
    ) -> str:
        """Block until an image is generated and saved.

        ``progress_cb(step, total)`` is called from this thread on each
        diffusion step. Returns the absolute file path of the saved image.
        Raises :class:`ImageError` on any failure.
        """
        self._ensure_spawned()
        self._send({
            "op": "generate",
            "prompt": prompt,
            "negative_prompt": negative_prompt,
            "output_path": str(output_path),
            "steps": int(steps),
            "width": int(width),
            "height": int(height),
            "seed": seed,
        })
        while True:
            try:
                evt = self._events.get(timeout=self._generate_timeout_s)
            except queue.Empty as exc:
                raise ImageError(
                    "generate_failed",
                    f"image generation timed out after "
                    f"{self._generate_timeout_s}s",
                ) from exc
            if evt is None:
                raise ImageError("subprocess_error",
                                 "image subprocess died mid-generate")
            ev = evt.get("event")
            if ev == "progress":
                if progress_cb:
                    try:
                        progress_cb(evt.get("step", 0), evt.get("total", 0))
                    except Exception:  # noqa: BLE001
                        pass
            elif ev == "saved":
                return evt["path"]
            elif ev == "cancelled":
                raise ImageError("cancelled", "image generation cancelled")
            elif ev == "error":
                raise ImageError(
                    evt.get("code", "generate_failed"),
                    evt.get("message", "image generation failed"),
                )
            # other events ignored

    def cancel(self) -> None:
        proc = self._proc
        if proc is None or proc.stdin is None or proc.poll() is not None:
            return
        try:
            with self._writer_lock:
                proc.stdin.write(json.dumps({"op": "cancel"}) + "\n")
                proc.stdin.flush()
        except Exception:  # noqa: BLE001
            pass


# ---------------------------------------------------------------------------
# Singleton accessor for tools
# ---------------------------------------------------------------------------

_client: ImageClient | None = None
_client_lock = threading.Lock()


def get_image_client() -> ImageClient:
    """Return the lazily-created singleton ImageClient.

    Pulls model id, path, and device preference from settings. The
    subprocess isn't spawned until you actually call ``generate()``.
    """
    global _client
    with _client_lock:
        if _client is not None:
            return _client
        try:
            from navi.settings.store import load as load_settings
            settings = load_settings()
            image_cfg = settings.get("image") or {}
        except Exception:  # noqa: BLE001
            image_cfg = {}
        model_id = image_cfg.get("model_id")
        device_pref = image_cfg.get("device", "auto")
        _client = ImageClient(
            model_path=_resolve_model_path(),
            model_id=model_id,
            device_pref=device_pref,
        )
        return _client


def reset_image_client() -> None:
    """Close + drop the singleton (used on app shutdown / model swap)."""
    global _client
    with _client_lock:
        if _client is not None:
            try:
                _client.close()
            except Exception:  # noqa: BLE001
                pass
            _client = None


def _resolve_model_path() -> Path:
    """Resolve the model directory.

    Priority: explicit ``image.model_path`` override → ``models/<spec.local_dir>``
    derived from the configured ``image.model_id`` → registry default.
    """
    try:
        from navi.settings.store import load as load_settings
        settings = load_settings()
        image_cfg = settings.get("image") or {}
    except Exception:  # noqa: BLE001
        image_cfg = {}
    configured = image_cfg.get("model_path")
    if configured:
        return Path(configured)
    from navi.brain.config import project_root
    from navi.image.models import get_spec
    spec = get_spec(image_cfg.get("model_id"))
    return project_root() / "models" / spec.local_dir
