"""Image-generation subprocess.

Spawned with ``python -m navi.image.subprocess``. Loads the diffusion
pipeline on init, then services generate requests until told to shut down.

Protocol mirrors :mod:`navi.brain.llm_subprocess` so the patterns stay
recognisable:

Stdin (main → subprocess):
    {"op": "init", "model_path": "...", "model_id": "...",
     "device_pref": "auto"}
    {"op": "generate", "prompt": "...", "negative_prompt": "...",
     "output_path": "...", "steps": 4, "width": 1024, "height": 1024,
     "seed": 42}
    {"op": "cancel"}
    {"op": "shutdown"}

Stdout (subprocess → main):
    {"event": "ready", "model": "...", "device": "cuda:0", "vram_gb": 32}
    {"event": "device_info", "message": "..."}
    {"event": "progress", "step": N, "total": M}
    {"event": "saved", "path": "..."}
    {"event": "cancelled"}
    {"event": "error", "code": "...", "message": "..."}

Error codes the client cares about:
* ``diffusers_missing`` — ``diffusers``/``torch`` aren't installed
* ``model_not_found``  — the model directory doesn't exist
* ``model_load_failed``— diffusers raised during pipeline load
* ``generate_failed``  — diffusion forward pass raised
"""

from __future__ import annotations

import json
import queue
import sys
import threading
import traceback
from pathlib import Path
from typing import Any

from navi.image.models import ModelSpec, get_spec


# ---------------------------------------------------------------------------
# Subprocess state
# ---------------------------------------------------------------------------
_pipeline: Any = None          # diffusers pipeline (lazy)
_spec: ModelSpec | None = None
_device: str = "cpu"           # actual device the pipeline lives on
_request_queue: queue.Queue[dict[str, Any]] = queue.Queue()
_cancel_flag = threading.Event()
_io_lock = threading.Lock()


def _send(obj: dict[str, Any]) -> None:
    line = json.dumps(obj, default=str) + "\n"
    with _io_lock:
        sys.stdout.write(line)
        sys.stdout.flush()


# ---------------------------------------------------------------------------
# Device placement
# ---------------------------------------------------------------------------


def _place_pipeline(pipeline: Any, device_pref: str) -> tuple[str, float | None]:
    """Decide where the pipeline lives. Returns (device_str, vram_gb).

    Policy:
    * ``cpu``           → leave on CPU.
    * ``cuda_offload``  → enable_model_cpu_offload regardless of VRAM
                          (escape hatch for OOM on big models).
    * ``cuda`` / ``auto`` →
        - no CUDA available: fall back to CPU + warn.
        - VRAM ≥ 16 GB: full GPU placement (.to("cuda")) — fastest.
        - VRAM 8-16 GB: model_cpu_offload (one submodel at a time on GPU).
        - VRAM < 8 GB:  sequential_cpu_offload (most aggressive).
    """
    import torch

    if device_pref == "cpu":
        return "cpu", None

    if not torch.cuda.is_available():
        _send({
            "event": "device_info",
            "message": "CUDA not available — running on CPU (slow).",
        })
        return "cpu", None

    vram_bytes = torch.cuda.get_device_properties(0).total_memory
    vram_gb = vram_bytes / (1024 ** 3)

    if device_pref == "cuda_offload":
        pipeline.enable_model_cpu_offload()
        return "cuda:0 (offload)", vram_gb

    # device_pref == "cuda" or "auto" — pick by VRAM tier.
    if vram_gb >= 16:
        pipeline.to("cuda")
        return "cuda:0", vram_gb
    if vram_gb >= 8:
        pipeline.enable_model_cpu_offload()
        return "cuda:0 (offload)", vram_gb
    pipeline.enable_sequential_cpu_offload()
    return "cuda:0 (sequential offload)", vram_gb


# ---------------------------------------------------------------------------
# Init / generate handlers
# ---------------------------------------------------------------------------


def _do_init(req: dict[str, Any]) -> None:
    """Load the diffusion pipeline. Lazy-import diffusers so a missing
    install yields a clean error instead of an import-time crash."""
    global _pipeline, _spec, _device
    model_path = Path(req["model_path"])
    spec = get_spec(req.get("model_id"))

    if not model_path.exists():
        _send({
            "event": "error",
            "code": "model_not_found",
            "message": (
                f"Image model not found at {model_path}. Install with:\n"
                f"  .venv/Scripts/python.exe scripts/install_image_model.py "
                f"{req.get('model_id') or spec.hf_id}\n"
                f"(or run --list to see all available models)"
            ),
        })
        return

    try:
        import torch  # noqa: F401  (verify installed)
        import diffusers  # type: ignore[import-not-found]
    except ImportError as exc:
        _send({
            "event": "error",
            "code": "diffusers_missing",
            "message": (
                "Image generation needs `diffusers`, `transformers`, "
                "`accelerate`, `safetensors`, and `torch`. Install with:\n"
                "  .venv/Scripts/python.exe -m pip install diffusers "
                "transformers accelerate safetensors torch\n"
                f"(import error: {exc})"
            ),
        })
        return

    pipeline_cls = getattr(diffusers, spec.pipeline_cls, None)
    if pipeline_cls is None:
        _send({
            "event": "error",
            "code": "model_load_failed",
            "message": (
                f"diffusers has no class '{spec.pipeline_cls}' for model "
                f"'{spec.hf_id}'. Upgrade diffusers: "
                "pip install -U diffusers"
            ),
        })
        return

    try:
        # bfloat16 is the recommended dtype for FLUX/Sana on consumer GPUs.
        # Falls back to default precision if torch can't expose bfloat16.
        kwargs: dict[str, Any] = {}
        try:
            kwargs["torch_dtype"] = torch.bfloat16
        except AttributeError:
            pass
        _pipeline = pipeline_cls.from_pretrained(str(model_path), **kwargs)

        device_pref = req.get("device_pref", "auto")
        _device, vram_gb = _place_pipeline(_pipeline, device_pref)
        _spec = spec
    except Exception as exc:  # noqa: BLE001
        _send({
            "event": "error",
            "code": "model_load_failed",
            "message": f"Failed to load model from {model_path}: {exc}\n"
                       f"{traceback.format_exc()}",
        })
        return

    _send({
        "event": "ready",
        "model": model_path.name,
        "device": _device,
        "vram_gb": round(vram_gb, 1) if vram_gb is not None else None,
    })


def _do_generate(req: dict[str, Any]) -> None:
    """Run a single diffusion generation, save to disk, send saved event."""
    if _pipeline is None or _spec is None:
        _send({
            "event": "error",
            "code": "not_initialized",
            "message": "generate called before successful init",
        })
        return

    prompt = req.get("prompt", "")
    negative_prompt = req.get("negative_prompt") or None
    output_path = Path(req["output_path"])
    output_path.parent.mkdir(parents=True, exist_ok=True)
    steps = int(req.get("steps") or _spec.default_steps)
    width = int(req.get("width", 1024))
    height = int(req.get("height", 1024))
    seed = req.get("seed")
    _cancel_flag.clear()

    try:
        import torch
        generator = None
        if seed is not None:
            generator = torch.Generator().manual_seed(int(seed))

        # callback_on_step_end gives us a yield point per diffusion step
        # so we can stream progress AND check the cancel flag.
        def _on_step_end(pipe, step: int, timestep, callback_kwargs):
            _send({"event": "progress", "step": step + 1, "total": steps})
            if _cancel_flag.is_set():
                pipe._interrupt = True  # diffusers private flag — the
                # supported way to abort mid-generation
            return callback_kwargs

        call_kwargs: dict[str, Any] = {
            "prompt": prompt,
            "num_inference_steps": steps,
            "guidance_scale": _spec.guidance_scale,
            "width": width,
            "height": height,
            "generator": generator,
            "callback_on_step_end": _on_step_end,
        }
        if _spec.supports_negative_prompt and negative_prompt:
            call_kwargs["negative_prompt"] = negative_prompt

        result = _pipeline(**call_kwargs)

        if _cancel_flag.is_set():
            _send({"event": "cancelled"})
            return

        if not getattr(result, "images", None):
            _send({
                "event": "error",
                "code": "generate_failed",
                "message": "diffusion pipeline returned no images",
            })
            return
        image = result.images[0]
        image.save(str(output_path))
        _send({"event": "saved", "path": str(output_path)})
    except Exception as exc:  # noqa: BLE001
        _send({
            "event": "error",
            "code": "generate_failed",
            "message": f"{exc}\n{traceback.format_exc()}",
        })


# ---------------------------------------------------------------------------
# Reader / worker threads (same shape as the LLM subprocess)
# ---------------------------------------------------------------------------


def _reader_loop() -> None:
    while True:
        line = sys.stdin.readline()
        if not line:
            sys.exit(0)
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            _send({"event": "error", "code": "bad_json",
                   "message": f"bad json from main: {line!r}"})
            continue
        op = req.get("op")
        if op == "cancel":
            _cancel_flag.set()
            continue
        if op == "shutdown":
            sys.exit(0)
        _request_queue.put(req)


def _worker_loop() -> None:
    while True:
        req = _request_queue.get()
        op = req.get("op")
        if op == "init":
            try:
                _do_init(req)
            except Exception:
                _send({"event": "error", "code": "init_crashed",
                       "message": traceback.format_exc()})
        elif op == "generate":
            _do_generate(req)
        else:
            _send({"event": "error", "code": "unknown_op",
                   "message": f"unknown op: {op!r}"})


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", line_buffering=True)  # type: ignore[attr-defined]
    except Exception:
        pass
    # Same Windows DLL-loader-on-non-main-thread gotcha as the LLM
    # subprocess. Pre-import (best-effort) so the worker thread's later
    # import is a no-op cache hit. Skipped if not installed — the init
    # handler will surface a clean error then.
    try:
        import diffusers  # noqa: F401
    except ImportError:
        pass

    reader = threading.Thread(target=_reader_loop, daemon=True,
                              name="image-subproc-reader")
    worker = threading.Thread(target=_worker_loop, daemon=True,
                              name="image-subproc-worker")
    reader.start()
    worker.start()
    try:
        reader.join()
    except KeyboardInterrupt:
        sys.exit(0)


if __name__ == "__main__":
    main()
