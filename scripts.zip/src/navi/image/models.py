"""Image-generation model registry.

Adding a new model = appending a ``ModelSpec`` entry. The subprocess
worker dispatches on ``pipeline_cls`` (looked up dynamically on the
``diffusers`` module), so no other code changes are needed for typical
single-pipeline diffusers models.

Licensing posture: only Apache 2.0 / MIT entries belong here. OpenRAIL-M
and "community" licenses don't qualify even though they permit commercial
use — see feedback_tech_preferences.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ModelSpec:
    """Everything the subprocess and installer need to know about a model.

    ``pipeline_cls`` is the *class name* on the ``diffusers`` module
    (e.g. ``"FluxPipeline"``, ``"SanaPipeline"``). Resolved at runtime
    via ``getattr(diffusers, ...)`` so we don't import diffusers at
    registry-load time.
    """

    hf_id: str                       # huggingface repo id for snapshot_download
    local_dir: str                   # under <project>/models/<local_dir>
    pipeline_cls: str                # class name on diffusers module
    size_gb: float                   # approximate on-disk size (download budget)
    default_steps: int               # diffusion steps tuned for this model
    guidance_scale: float            # CFG scale; FLUX schnell ignores this
    supports_negative_prompt: bool   # SD/SDXL/Sana yes; FLUX schnell no
    license: str                     # human-readable license string
    notes: str                       # one-liner shown in install help


MODELS: dict[str, ModelSpec] = {
    "flux-schnell": ModelSpec(
        hf_id="black-forest-labs/FLUX.1-schnell",
        local_dir="FLUX.1-schnell",
        pipeline_cls="FluxPipeline",
        size_gb=12.0,
        default_steps=4,
        guidance_scale=0.0,
        supports_negative_prompt=False,
        license="Apache 2.0",
        notes="Best quality, large download.",
    ),
    "sana-1.6b": ModelSpec(
        hf_id="Efficient-Large-Model/Sana_1600M_1024px_diffusers",
        local_dir="Sana_1.6B",
        pipeline_cls="SanaPipeline",
        size_gb=3.0,
        default_steps=18,
        guidance_scale=5.0,
        supports_negative_prompt=True,
        license="Apache 2.0",
        notes="Small + fast. NVIDIA, US-origin.",
    ),
}

DEFAULT_MODEL_ID = "flux-schnell"


def get_spec(model_id: str | None) -> ModelSpec:
    """Look up a spec by id, falling back to the default on miss."""
    if model_id and model_id in MODELS:
        return MODELS[model_id]
    return MODELS[DEFAULT_MODEL_ID]


def list_models() -> list[tuple[str, ModelSpec]]:
    """Stable-ordered (id, spec) pairs for help text and the installer."""
    return list(MODELS.items())
