"""Natural-language → datetime parser for scheduled jobs.

Why a shim around ``dateparser``
--------------------------------
``dateparser`` handles "tomorrow at 5pm" / "monday at 9am" / "in 2 hours"
out of the box but returns ``None`` for common scheduling phrasings:
``"every X"`` prefixes, bare ``"hourly"/"daily"``, and shorthand
intervals like ``"15m"``. This module:

1. Strips ``"every "`` / ``"each "`` / ``"next "`` / ``"this "`` prefixes
   that confuse dateparser.
2. Recognises bare interval words (``hourly``, ``daily``, ``weekly``).
3. Recognises shorthand intervals (``15m``, ``2h``, ``3d``, ``1w``)
   and English forms (``5 minutes``, ``2 hours``).
4. Falls back to ``dateparser.parse`` with ``PREFER_DATES_FROM=future``
   so "monday at 9am" lands on the *next* Monday, not the past one.

Returns timezone-naive local datetimes for now (matches dateparser's
default and the rest of the codebase, which uses ``datetime.now()``).
"""

from __future__ import annotations

import re
from datetime import datetime, timedelta

import dateparser


_INTERVAL_KEYWORDS: dict[str, timedelta] = {
    # Adverb forms ("hourly").
    "minutely": timedelta(minutes=1),
    "hourly": timedelta(hours=1),
    "daily": timedelta(days=1),
    "weekly": timedelta(weeks=1),
    # Bare unit ("every hour" → "hour" after prefix-strip).
    "minute": timedelta(minutes=1),
    "hour": timedelta(hours=1),
    "day": timedelta(days=1),
    "week": timedelta(weeks=1),
}

# 5m | 5 min | 5 minutes | 2h | 2 hr | 2 hours | 3d | 3 days | 1w | 1 week
_INTERVAL_RE = re.compile(
    r"^(\d+)\s*(m|min|mins|minute|minutes|h|hr|hrs|hour|hours|d|day|days|w|week|weeks)$",
    re.IGNORECASE,
)

_PREFIX_STRIPS = ("every ", "each ", "next ", "this ", "in ")


def _interval_to_timedelta(n: int, unit: str) -> timedelta | None:
    u = unit.lower()
    if u.startswith("m"):  # m, min, minutes
        return timedelta(minutes=n)
    if u.startswith("h"):  # h, hr, hours
        return timedelta(hours=n)
    if u.startswith("d"):  # d, day, days
        return timedelta(days=n)
    if u.startswith("w"):  # w, week, weeks
        return timedelta(weeks=n)
    return None


def parse_when(text: str, base: datetime | None = None) -> datetime | None:
    """Parse ``text`` into a future datetime, or None if unrecognised.

    ``base`` is the reference time for relative parsing (defaults to
    ``datetime.now()``).
    """
    if not text:
        return None
    text = text.strip()
    if not text:
        return None
    base = base or datetime.now()

    # Strip recurring/temporal prefixes that confuse dateparser. Note
    # we DON'T strip "in " because dateparser handles "in 2 hours" fine
    # but choking is a recursive parse. Actually test confirms strip is
    # safe; dateparser handles "2 hours" too.
    lowered = text.lower()
    for prefix in _PREFIX_STRIPS:
        if lowered.startswith(prefix):
            lowered = lowered[len(prefix):].strip()
            break

    # Bare interval keywords.
    if lowered in _INTERVAL_KEYWORDS:
        return base + _INTERVAL_KEYWORDS[lowered]

    # "N units" shorthand or English.
    m = _INTERVAL_RE.match(lowered)
    if m:
        td = _interval_to_timedelta(int(m.group(1)), m.group(2))
        if td is not None:
            return base + td

    # Fallback: dateparser. PREFER_DATES_FROM=future means "monday at 9am"
    # resolves to the NEXT Monday, not the previous one. RELATIVE_BASE
    # anchors relative phrases ("in 5 minutes") to ``base`` rather than
    # the wall clock — important for test determinism.
    try:
        return dateparser.parse(
            lowered,
            settings={
                "PREFER_DATES_FROM": "future",
                "RELATIVE_BASE": base,
            },
        )
    except Exception:  # noqa: BLE001
        return None


def next_fire_for_pattern(pattern: str, after: datetime | None = None) -> datetime | None:
    """Compute the next future fire time for a recurring ``pattern``.

    Identical to ``parse_when`` but always anchored to ``after`` (the
    last fire, or ``now`` for first computation). Caller uses this to
    advance ``next_fire`` after each fire.
    """
    return parse_when(pattern, base=after)
