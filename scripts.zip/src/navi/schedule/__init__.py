"""Background scheduler for natural-language reminders.

Three modules:

* ``parse.py`` — turn user-friendly strings ("in 2 minutes", "every
  Tuesday at 3pm", "hourly") into datetimes via a small shim around
  ``dateparser``.
* ``store.py`` — persist scheduled jobs to ``%APPDATA%/Navi/scheduled.json``
  via atomic writes.
* ``runner.py`` — QTimer that polls the store, fires due jobs by
  injecting them into the brain via ``BrainWorker.submit``, and
  reschedules recurring entries.

Tools live in ``navi.tools.schedule_tools``.
"""
