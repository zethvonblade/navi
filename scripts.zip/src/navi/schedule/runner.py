"""Background scheduler runner.

A QTimer ticking every ``settings.schedule.tick_seconds`` (default 30)
that polls the persistent store and fires due jobs. Owned by
``PetWindow`` and started after the brain is loaded.

Firing semantics:

* **One-shot job, due**: emit a chat note, optionally pop a toast,
  inject ``prompt`` into the brain via ``BrainWorker.submit``, delete
  from store.
* **Recurring job, due**: same as above PLUS recompute ``next_fire`` by
  re-parsing ``pattern`` relative to NOW, then save.
* **Missed-while-offline (next_fire was in the past on startup)**:
  - One-shot: emit a chat note ("⏰ missed scheduled task: …") and
    delete. We do NOT fire it — the user wasn't there.
  - Recurring: silently advance ``next_fire`` to the first future
    occurrence (don't fire 7 missed daily commits at startup).

Brain busy: ``BrainWorker.submit`` is a Qt Slot on a moved-to-thread
worker — calling it from the GUI thread queues the call. If the brain
is mid-stream, the queued submit lands after the current turn ends.
That's the right behavior here — interrupting mid-response would
strand the user.
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from PySide6.QtCore import QObject, QTimer

from navi.schedule import store as sched_store
from navi.schedule.parse import next_fire_for_pattern


if TYPE_CHECKING:  # avoid circular at runtime
    from navi.brain.worker import BrainWorker


def _iso(dt: datetime) -> str:
    return dt.replace(microsecond=0).isoformat()


class ScheduleRunner(QObject):
    """QTimer-driven scheduler. Owned by PetWindow.

    ``brain`` is the live BrainWorker; we call its ``submit`` Slot
    when a job fires. ``chat_note_cb`` is called for missed-fire
    announcements (typically wired to ChatWindow.show_system_note).
    """

    def __init__(
        self,
        brain: "BrainWorker",
        chat_note_cb=None,
        tick_seconds: int = 30,
        notify_on_fire: bool = True,
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self._brain = brain
        self._chat_note_cb = chat_note_cb
        self._notify_on_fire = notify_on_fire
        self._timer = QTimer(self)
        self._timer.setInterval(max(5, int(tick_seconds)) * 1000)
        self._timer.timeout.connect(self._tick)

    def start(self) -> None:
        """Catch up on missed jobs first, then start ticking."""
        self._handle_missed_at_startup()
        self._timer.start()

    def stop(self) -> None:
        self._timer.stop()

    # ------------------------------------------------------------------ tick
    def _tick(self) -> None:
        jl = sched_store.load()
        if not jl.jobs:
            return
        now = datetime.now()
        keep: list = []
        changed = False
        for job in jl.jobs:
            try:
                next_fire = job.next_fire_dt
            except ValueError:
                # Corrupt entry — drop it loudly.
                self._note(f"⏰ skipped malformed scheduled job {job.id}")
                changed = True
                continue
            if next_fire > now:
                keep.append(job)
                continue
            # Due: fire it.
            self._fire(job)
            if job.recurring:
                new_next = next_fire_for_pattern(job.pattern, after=now)
                if new_next is None or new_next <= now:
                    # Pattern stopped resolving (rare; e.g. if the user
                    # hand-edited to garbage). Drop.
                    self._note(
                        f"⏰ recurring job {job.id} pattern stopped resolving "
                        f"({job.pattern!r}); dropping"
                    )
                    changed = True
                    continue
                job.next_fire = _iso(new_next)
                keep.append(job)
                changed = True
            else:
                # One-shot: drop after firing.
                changed = True
        if changed:
            from navi.schedule.store import JobList
            sched_store.save(JobList(jobs=keep))

    # -------------------------------------------------------------- startup
    def _handle_missed_at_startup(self) -> None:
        """Sweep past-due jobs once at start. One-shots get a note +
        delete; recurring jobs silently advance to next future fire."""
        jl = sched_store.load()
        if not jl.jobs:
            return
        now = datetime.now()
        keep: list = []
        changed = False
        for job in jl.jobs:
            try:
                next_fire = job.next_fire_dt
            except ValueError:
                self._note(f"⏰ skipped malformed scheduled job {job.id}")
                changed = True
                continue
            if next_fire > now:
                keep.append(job)
                continue
            if job.recurring:
                # Skip past occurrences; advance until we find the first
                # future one. Also defensively cap to one re-parse — the
                # parser anchors on `now` so a single call gives us the
                # next future fire.
                new_next = next_fire_for_pattern(job.pattern, after=now)
                if new_next is None or new_next <= now:
                    self._note(
                        f"⏰ recurring job {job.id} pattern no longer "
                        f"resolves to a future time ({job.pattern!r}); dropping"
                    )
                    changed = True
                    continue
                job.next_fire = _iso(new_next)
                keep.append(job)
                changed = True
            else:
                # Missed one-shot — tell the user, delete.
                self._note(
                    f"⏰ missed scheduled task ({_iso(next_fire)}): "
                    f"{job.prompt}"
                )
                changed = True
        if changed:
            from navi.schedule.store import JobList
            sched_store.save(JobList(jobs=keep))

    # ----------------------------------------------------------------- fire
    def _fire(self, job) -> None:
        """Inject the prompt into the brain. Notify if enabled."""
        if self._notify_on_fire:
            try:
                from navi.brain import shared
                title = "⏰ Scheduled task"
                body = job.prompt[:200]
                shared.emit_notification(title, body)
            except Exception:  # noqa: BLE001
                pass
        # BrainWorker.submit is a @Slot on a moved-to-thread QObject —
        # calling from the GUI thread queues across the thread boundary.
        try:
            self._brain.submit(job.prompt)
        except Exception as exc:  # noqa: BLE001
            self._note(f"⏰ scheduled job {job.id} submit failed: {exc}")

    def _note(self, msg: str) -> None:
        if self._chat_note_cb is not None:
            try:
                self._chat_note_cb(msg)
            except Exception:  # noqa: BLE001
                pass
