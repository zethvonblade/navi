"""Persistent store for scheduled jobs.

JSON file at ``%APPDATA%/Navi/scheduled.json``. Atomic writes via the
existing ``navi._io.atomic_write_text`` so a crash mid-write doesn't
corrupt the schedule.

Schema (one line per job, pretty-printed):
    {
      "jobs": [
        {
          "id": "abc123",
          "pattern": "every monday at 9am",
          "recurring": true,
          "next_fire": "2026-05-11T09:00:00",
          "prompt": "weekly summary",
          "created": "2026-05-04T10:00:00"
        }
      ]
    }
"""

from __future__ import annotations

import json
import os
import secrets
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from navi._io import atomic_write_text


def schedule_path() -> Path:
    """Match the convention of brain_history_path / settings_path —
    ``%APPDATA%/Navi/scheduled.json`` on Windows, fallback to
    ``~/.local/share/Navi/`` elsewhere."""
    appdata = os.environ.get("APPDATA")
    base = Path(appdata) if appdata else Path.home() / ".local" / "share"
    return base / "Navi" / "scheduled.json"


@dataclass
class Job:
    """One scheduled entry."""

    id: str
    pattern: str            # original natural-language string from the user
    recurring: bool
    next_fire: str          # ISO datetime
    prompt: str
    created: str            # ISO datetime

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Job":
        return cls(
            id=str(d["id"]),
            pattern=str(d.get("pattern", "")),
            recurring=bool(d.get("recurring", False)),
            next_fire=str(d["next_fire"]),
            prompt=str(d.get("prompt", "")),
            created=str(d.get("created", "")),
        )

    @property
    def next_fire_dt(self) -> datetime:
        return datetime.fromisoformat(self.next_fire)


@dataclass
class JobList:
    jobs: list[Job] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {"jobs": [j.to_dict() for j in self.jobs]}


def new_id() -> str:
    """Short URL-safe id; 6 hex chars is plenty for ~thousands of jobs."""
    return secrets.token_hex(3)


def load() -> JobList:
    """Load the store. Missing file → empty list. Corrupt file →
    empty list (loud error would block the scheduler from ticking)."""
    path = schedule_path()
    if not path.exists():
        return JobList()
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return JobList()
    if not isinstance(raw, dict):
        return JobList()
    jobs_raw = raw.get("jobs", [])
    if not isinstance(jobs_raw, list):
        return JobList()
    jobs: list[Job] = []
    for j in jobs_raw:
        if not isinstance(j, dict):
            continue
        try:
            jobs.append(Job.from_dict(j))
        except (KeyError, ValueError):
            continue  # skip malformed entry, don't fail the whole load
    return JobList(jobs=jobs)


def save(jl: JobList) -> Path:
    path = schedule_path()
    atomic_write_text(path, json.dumps(jl.to_dict(), indent=2, ensure_ascii=False))
    return path


def add(job: Job) -> JobList:
    jl = load()
    jl.jobs.append(job)
    save(jl)
    return jl


def remove(job_id: str) -> bool:
    """Return True if a job was removed; False if not found."""
    jl = load()
    before = len(jl.jobs)
    jl.jobs = [j for j in jl.jobs if j.id != job_id]
    if len(jl.jobs) == before:
        return False
    save(jl)
    return True


def update_next_fire(job_id: str, new_iso: str) -> bool:
    """Used by the runner after a recurring job fires."""
    jl = load()
    for j in jl.jobs:
        if j.id == job_id:
            j.next_fire = new_iso
            save(jl)
            return True
    return False
