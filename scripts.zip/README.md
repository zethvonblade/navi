# Navi

A local-AI desktop companion for Windows. Animated orb that lives on your
desktop, runs a local LLM, accepts natural-language tasks, and executes them
via Windows automation tools — asking permission before any risky action,
modeled on Claude Code's tiered permission system.

> **Status:** functional. Brain + tool calling + permissions + skins + voice
> are working end-to-end. Pre-1.0; APIs and settings schema may still shift.

## Quick start

Project-local `.venv` with Python 3.12. One command from a fresh clone:

```bash
python setup.py
```

`setup.py` is dual-purpose — direct invocation bootstraps the venv (creates
`.venv/`, installs pinned versions from `requirements.txt`, installs `navi`
in editable mode); pip/setuptools invocation reads `pyproject.toml`. Safe to
re-run.

There's also `scripts/setup.ps1` for PowerShell users:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/setup.ps1
```

Run + test:

```bash
.venv/Scripts/python.exe -m navi
.venv/Scripts/python.exe -m pytest -q
```

> **Why a custom pip index in requirements.txt?** `llama-cpp-python` doesn't
> publish prebuilt wheels on PyPI. Without
> `--extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu` pip
> falls back to compiling from source, which fails on locked-down enterprise
> machines (no MSVC + group-policy-blocked subprocess builds).

### Model file

Navi loads `models/granite-3.1-2b-instruct-Q4_K_M.gguf` (~1.5 GB) by default:

```bash
python scripts/download_model.py
```

If `huggingface.co` is blocked on your network (common on enterprise/.mil),
download from a personal device and drop the file at
`models/granite-3.1-2b-instruct-Q4_K_M.gguf`. Source:
[ibm-granite/granite-3.1-2b-instruct-GGUF · Q4_K_M](https://huggingface.co/ibm-granite/granite-3.1-2b-instruct-GGUF/blob/main/granite-3.1-2b-instruct-Q4_K_M.gguf).

Override with the `NAVI_MODEL_PATH` env var, or pick a different GGUF via
**Settings → Model path** in the running app.

## Supported models

Navi ships with 15 model adapters and auto-routes by inspecting the GGUF's
chat template. Drop in any of these GGUFs and tool calling should fire on
first launch (calibration probes the model and persists the right adapter):

| Family | Notes |
|---|---|
| **IBM Granite 3.x** | Native target. `<\|tool_call\|>` + JSON array. Recommended. |
| **IBM Granite 4.0** | XML `<tool_call>...</tool_call>` plus `<tool_response>` wrapper. |
| **OpenAI gpt-oss-120b / 20b** | Harmony channel format (`<\|channel\|>commentary to=functions...`). |
| **Meta Llama 4** (Scout / Maverick) | Pythonic `[func(arg=val)]` between new `<\|header_start\|>` headers. |
| **Meta Llama 3.3 / 3.2-large** | Pythonic call format. |
| **Meta Llama 3.1 / 3.2-small** | Bare JSON `{"name", "parameters"}`. |
| **DeepSeek V3 / R1 / R1-Distill** | Full-width-pipe wrapper. R1 emits `<think>` blocks (auto-stripped). |
| **Microsoft Phi-4 / Phi-4-mini** | Bare JSON array. RLHF-stubborn on file system tools — use Granite for those. |
| **Alibaba Qwen 2.5 / 3 / QwQ / Hermes 3-4 / SmolLM2-3** | Hermes XML `<tool_call>{json}</tool_call>`. |
| **Alibaba Qwen3-Coder** | Distinct XML `<function=...><parameter=...>...</function>`. |
| **Zhipu GLM-4 / 4.5 / 4.7** | XML key/value body inside `<tool_call>`. Interleaved thinking auto-stripped. |
| **Mistral / Mixtral / Nemo** | `[TOOL_CALLS]` token. |
| **Google Gemma 2 / 3** | Markdown ` ```tool_code ` blocks (no native tool tokens). |
| **TinyLlama 1.1B** | Bare JSON. Listed for completeness; tool-call accuracy is low at this size. |

Calibration auto-fix rotates adapters when the initial pick fails the
tool-call probe and persists the working choice in
`%APPDATA%/Navi/settings.json` so subsequent launches skip the probe.

## What it does

- **Streaming chat** with the local LLM via a draggable always-on-top orb.
- **Tool calling** with a tiered permission engine (allow / ask / deny rules,
  modes `default` / `plan` / `acceptEdits` / `bypass`). Tools include:
  read/write files (txt, docx, pdf, xlsx, pptx, csv), clipboard read/write,
  screenshot + on-device OCR, list/focus windows, open apps and URLs,
  PowerShell, web search, image generation, summarize-large-document,
  long-term memory.
- **Pre-LLM tool-use hints** — a regex pre-filter detects file paths, URLs,
  and keyword phrases in user input and prepends a `⚙ hint: ...` line so
  weaker models make the implicit-tool-use leap. Toggle visibility in chat
  with `/hints on|off`.
- **Voice** — push-to-talk STT (Windows speech recognition) + auto-TTS
  (SAPI). Disabled by default, enable in Settings.
- **Long-term memory** — Markdown files in `%APPDATA%/Navi/memory/`, indexed
  into the system prompt. Use the `remember` and `recall` tools.
- **Audit log** — JSONL at `%APPDATA%/Navi/audit.jsonl`, viewable from the
  tray menu.
- **Skins** — six built-in plus the `navi-figure` embedded-sprite skin
  (anime hero from `images/navi.png`). Add your own via `%APPDATA%/Navi/skins/`.
- **Calibration** — first launch with a new model runs a 9-probe battery
  (math, coherence, tool-call, parallel-call, etc.) and persists the result.
  Cached forever once tool-call passes; re-run any time with `/calibrate`.

## Slash commands

In the chat panel:

| Command | Effect |
|---|---|
| `/help` | List commands |
| `/clear` | Clear the chat panel |
| `/skin <name>` | Switch skin (try `classic`, `cortana`, `jarvis`, `kit`, `plasma`, `tactical`, `navi-figure`) |
| `/skin reload` | Re-scan built-in + user skins from disk |
| `/skin new` | Open the skin authoring dialog |
| `/model <name>` | Switch model (substring of GGUF filename in `models/`) |
| `/memory` | Open the memories viewer |
| `/lock` / `/unlock` | Toggle plan-mode (no tools execute) |
| `/forget all` | Clear long-term memory (asks for confirmation) |
| `/calibrate [verbose]` | Re-run the model probe battery |
| `/hints on\|off\|toggle\|status` | Show / hide auto-detected tool hints in chat |

## Project layout

```
src/navi/
  __main__.py         Entry point
  app.py              QApplication wiring
  _io.py              Atomic file write helper (settings, history, memory)
  brain/              LLM subprocess client + worker thread
    adapters.py         Per-family adapters (15 entries) + universal detector
    parsers.py          Tool-call format parsers + reasoning-block stripper
    calibration.py      Probe battery (math, tool_call, no_roleplay, ...)
    hints.py            Pre-LLM tool-use hint detector
    persona.py          Navi persona + per-adapter system prompt composition
    llm_client.py       Subprocess wrapper around llama-cpp-python (GIL fix)
    llm_subprocess.py   The hosted LLM process
    wheel_installer.py  In-app llama-cpp-python CUDA-wheel installer
    worker.py           Brain thread, agent loop, calibration cache
  pet/                Animated orb window + tray + chat panel
    window.py           Owns brain thread, tray, chat, voice
    chat_window.py      Floating chat panel + slash dispatcher
    skins/              Skin renderers (one per .py)
  tools/              Tool implementations
  perms/              Permission engine + dispatcher + audit log
  memory/             Long-term memory store
  settings/           Settings UI + JSON store with deep-merge
  voice/              TTS (SAPI) + STT (WinRT) + push-to-talk
  image/              Diffusion image-gen subprocess + client
```

## Configuration

Settings live at `%APPDATA%/Navi/settings.json`. Key fields:

```jsonc
{
  "defaultMode": "default",          // default | plan | acceptEdits | bypass
  "permissions": { "allow": [...], "ask": [...], "deny": [...] },
  "ui": {
    "orbSize": 240,                  // px, 160-400
    "skin": "classic",
    "personaPrompt": null,           // null = use built-in
    "showHints": false,              // surface ⚙ hint: lines in chat
    "hotkey": "ctrl+shift+space"
  },
  "model": {
    "path": null,                    // null = NAVI_MODEL_PATH env or default
    "n_ctx": 16384,
    "n_gpu_layers": 0                // 0 = CPU; -1 = all on GPU (needs CUDA wheel)
  },
  "voice": {
    "enabled": false,
    "voiceId": null,
    "rate": 200,
    "volume": 0.85,
    "pttHotkey": "ctrl+alt+space"
  },
  "model_overrides": {               // per-GGUF calibration cache + adapter pin
    "<filename>.gguf": {
      "adapter_id": "granite_3",
      "calibration_cache": { "tool_call_passed": true, ... }
    }
  }
}
```

Most fields editable through **Settings** (tray right-click → Settings…).
The settings reader is forgiving: corrupt values fall back to defaults
rather than crashing startup.

### CPU vs GPU

`model.n_gpu_layers` switches the brain between CPU and GPU. `0` = CPU only;
`-1` = offload everything to GPU. GPU requires the CUDA build of
`llama-cpp-python` AND the CUDA Toolkit (12.x, ~3 GB). Settings →
**Compute device** dropdown handles this: it preflights for the toolkit,
downloads the CUDA wheel, validates the new DLL loads, and auto-rolls back
to CPU if anything fails.

## Architecture notes

- The LLM runs in a **subprocess** (`brain/llm_subprocess.py`). llama-cpp's
  C call holds the Python GIL during prompt eval; hosting it in a separate
  process keeps the GUI thread responsive. Communication is line-delimited
  JSON over stdin/stdout.
- Adapter routing uses a **chat-template fingerprint** as the highest-
  priority signal: substring-match the GGUF's `tokenizer.chat_template`
  metadata against each adapter's `template_tokens`. Catches Bartowski-style
  renamed quants that filename matching alone would miss.
- The **permission engine** evaluates `deny → allow → ask → risk-fallback`,
  with explicit modes for plan (deny everything), acceptEdits (auto-allow
  writes under `~`), and bypass (allow everything — dev only). Cross-thread
  permission prompts use a `queue.Queue` with timeout polling so the brain
  thread can't deadlock if the user closes the chat mid-prompt.
- All persistent files (`settings.json`, brain history, memory index, chat
  history, generated skins) are written via `navi/_io.atomic_write_text`
  (tempfile + `os.replace`) so a kill mid-write can never corrupt them.

## Adding things

**A new tool**: write a function in `src/navi/tools/`, decorate with
`@tool(name=..., description=..., risk=..., parameters=...)` from
`tools/_registry.py`. Auto-registered on import. Add an `import` in
`src/navi/tools/__init__.py` if it's a new file.

**A new adapter** (model family): add a `ModelAdapter(...)` entry to the
`ADAPTERS` tuple in `src/navi/brain/adapters.py`. The most-load-bearing
field is `template_tokens` — substrings to look for in the GGUF's
`tokenizer.chat_template` metadata. Add a corresponding parser to
`src/navi/brain/parsers.py` if the model uses a format we don't already
catch. See the in-file comments + the agent reports in
`scripts/smoke_universal_adapters.py` for the full pattern.

**A new skin**: write a `MySkin(Skin)` class in either
`src/navi/pet/skins/` (built-in) or `%APPDATA%/Navi/skins/` (user). The
`/skin reload` command picks it up without restart. The `navi-figure`
skin demonstrates how to embed a PNG sprite as a base64 literal so the
skin is fully self-contained (no asset directory dependency) — see
`scripts/_build_embedded_skin.py` for the toolchain.

## Troubleshooting

- **Tool calls "don't fire" with a higher-param Granite (3.2 / 3.3) or any
  thinking-mode model:** likely Granite 3.2+ emitting `<think>...</think>`
  before the actual tool call. The `strip_reasoning_blocks` post-processor
  handles this; if you see raw `<think>` text in chat, the adapter probably
  isn't matching the model — check the chat-template fingerprint.
- **Phi-4-mini refuses to read files:** known model limitation. Phi's RLHF
  refuses file system access regardless of system prompt. Use Granite for
  file workflows; Phi for short conversational tasks.
- **`/calibrate` runs every launch:** check
  `%APPDATA%/Navi/settings.json` → `model_overrides[<file>].calibration_cache`.
  If `tool_call_passed: false`, the previous calibration's tool-call probe
  failed and a re-run is scheduled (auto-retries every 6 h until it
  passes). If `tool_call_passed: true`, calibration is skipped indefinitely
  until you run `/calibrate`.
- **Two Navi processes on launch (one venv, one anaconda):** known
  open issue — the anaconda Python is auto-spawning a duplicate.
  Workaround: `taskkill /PID <anaconda-pid> /F` after launch. The venv
  instance is the canonical one.

## License

MIT (see `LICENSE`). Third-party notices in `THIRD_PARTY_NOTICES.md`.
