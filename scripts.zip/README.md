# Navi

A professional local-AI desktop companion for Windows.

Navi is a JARVIS-style animated AI orb that lives on your desktop, runs a
small US-origin local LLM (IBM Granite 3.1 2B Instruct), accepts
natural-language tasks, and executes them via Windows automation tools —
asking your permission before any risky action, modeled on Claude Code's
tiered permission system.

> **Status:** pre-alpha, MVP in progress. See `.claude/plans/playful-petting-eagle.md`
> for the approved phased build plan.

## Quick start (development)

This project uses a project-local **`.venv`** with Python 3.12. One command
from a fresh clone sets everything up:

```bash
python setup.py
```

`setup.py` is a dual-purpose script — when you run it directly with no args
it bootstraps the venv (creates `.venv/`, installs the pinned versions from
`requirements.txt`, installs `navi` in editable mode). When pip/setuptools
invokes it during a build, it delegates to `setuptools.setup()` which reads
`pyproject.toml`. Safe to re-run any time to refresh deps.

There is also a PowerShell version at `scripts/setup.ps1` if you'd rather:
```powershell
powershell -ExecutionPolicy Bypass -File scripts/setup.ps1
```

```bash
# run
.venv/Scripts/python.exe -m navi

# tests
.venv/Scripts/python.exe -m pytest -q
```

> **Why a custom index in requirements.txt?** `llama-cpp-python` does not
> publish prebuilt wheels on PyPI. Without `--extra-index-url
> https://abetlen.github.io/llama-cpp-python/whl/cpu` (which `requirements.txt`
> declares at the top) pip falls back to compiling from source, which fails on
> locked-down enterprise machines (no MSVC + group-policy-blocked subprocess).

### Model file (Phase 2+)

Navi loads `models/granite-3.1-2b-instruct-Q4_K_M.gguf` (~1.5 GB) at startup. Two ways to get it:

```bash
python scripts/download_model.py        # fetches from HuggingFace
```

If `huggingface.co` is blocked on your network (common on enterprise/.mil networks), download the file from a personal device and drop it at `models/granite-3.1-2b-instruct-Q4_K_M.gguf`. Source: [ibm-granite/granite-3.1-2b-instruct-GGUF · Q4_K_M](https://huggingface.co/ibm-granite/granite-3.1-2b-instruct-GGUF/blob/main/granite-3.1-2b-instruct-Q4_K_M.gguf).

Override the path with the `NAVI_MODEL_PATH` env var if you'd rather store it elsewhere.

## Project layout

```
src/navi/
  __main__.py         entry point
  app.py              QApplication wiring
  pet/                Animated orb window + state machine
  brain/              llama-cpp-python LLM worker (Phase 2+)
  tools/              Tool implementations (Phase 3+)
  perms/              Permission engine (Phase 3+)
  memory/             Markdown + sqlite-vec memory (Phase 5)
  settings/           Settings UI + schema
  assets/             Bundled icons
```

## Phases

| Phase | Goal |
|---|---|
| 0 | Project skeleton, empty transparent window |
| 1 | Animated AI orb on desktop, draggable, context menu |
| 2 | Phi-4-mini brain online, streaming chat |
| 3 | Read-only tools + permission engine |
| 4 | Write/exec tools + risk classification + audit log |
| 5 | Markdown + vector memory |
| 6 | Settings UI + persona polish |
| 7 | Packaging (single .exe) |
| 8 | Hardening pass |

## License

MIT (see `LICENSE`). Third-party notices in `THIRD_PARTY_NOTICES.md`.
