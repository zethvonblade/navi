# Navi

A local-AI desktop companion for Windows. Animated orb that lives on your
desktop, runs a local LLM, accepts natural-language tasks, and executes them
via Windows automation tools — asking permission before any risky action,
modeled on Claude Code's tiered permission system.

> **Status:** functional. 55 tools across 9 categories, scaffolding +
> AST-safe code edits + git + scheduling + image gen + voice are all
> wired end-to-end. Pre-1.0; APIs and settings schema may still shift.

## Quick start

Project-local `.venv` with Python 3.12. One command from a fresh clone:

```bash
python setup.py
```

`setup.py` is dual-purpose — direct invocation bootstraps the venv (creates
`.venv/`, installs pinned versions from `requirements.txt`, installs `navi`
in editable mode); pip/setuptools invocation reads `pyproject.toml`. Safe to
re-run.

There's also `scripts/setup.ps1` for PowerShell users:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/setup.ps1
```

After bootstrap:

```bash
.venv/Scripts/python.exe scripts/download_model.py    # ~1.5 GB brain LLM
.venv/Scripts/python.exe -m navi                      # run
.venv/Scripts/python.exe -m pytest -q                 # tests
```

> **Why a custom pip index in requirements.txt?** `llama-cpp-python` doesn't
> publish prebuilt wheels on PyPI. Without
> `--extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu` pip
> falls back to compiling from source, which fails on locked-down enterprise
> machines (no MSVC + group-policy-blocked subprocess builds).

### Brain model

Navi loads `models/granite-3.1-2b-instruct-Q4_K_M.gguf` (~1.5 GB) by default:

```bash
python scripts/download_model.py
```

If `huggingface.co` is blocked on your network (common on enterprise/.mil),
download from a personal device and drop the file at
`models/granite-3.1-2b-instruct-Q4_K_M.gguf`. Source:
[ibm-granite/granite-3.1-2b-instruct-GGUF · Q4_K_M](https://huggingface.co/ibm-granite/granite-3.1-2b-instruct-GGUF/blob/main/granite-3.1-2b-instruct-Q4_K_M.gguf).

Override with the `NAVI_MODEL_PATH` env var, or pick a different GGUF via
**Settings → Model path** in the running app.

### Image-gen model (optional)

The image-gen subsystem is opt-in — generation needs a multi-GB diffusion
model on disk. Two are bundled in the registry:

```bash
python scripts/install_image_model.py --list                  # see options
python scripts/install_image_model.py flux-schnell            # 12 GB, default
python scripts/install_image_model.py sana-1.6b               # 3 GB, faster
```

Both Apache 2.0. Switch active model via `settings.image.model_id`.
The `image` tool category is **off by default** — enable with
`/tools enable image` once a model is on disk.

## Supported brain models

Navi ships with 15 model adapters and auto-routes by inspecting the GGUF's
chat template. Drop in any of these GGUFs and tool calling should fire on
first launch (calibration probes the model and persists the right adapter):

| Family | Notes |
|---|---|
| **IBM Granite 3.x** | Native target. `<\|tool_call\|>` + JSON array. Recommended. |
| **IBM Granite 4.0** | XML `<tool_call>...</tool_call>` plus `<tool_response>` wrapper. |
| **OpenAI gpt-oss-120b / 20b** | Harmony channel format (`<\|channel\|>commentary to=functions...`). |
| **Meta Llama 4** (Scout / Maverick) | Pythonic `[func(arg=val)]` between new `<\|header_start\|>` headers. |
| **Meta Llama 3.3 / 3.2-large** | Pythonic call format. |
| **Meta Llama 3.1 / 3.2-small** | Bare JSON `{"name", "parameters"}`. |
| **DeepSeek V3 / R1 / R1-Distill** | Full-width-pipe wrapper. R1 emits `<think>` blocks (auto-stripped). |
| **Microsoft Phi-4 / Phi-4-mini** | Bare JSON array. RLHF-stubborn on file system tools — use Granite for those. |
| **Alibaba Qwen 2.5 / 3 / QwQ / Hermes 3-4 / SmolLM2-3** | Hermes XML `<tool_call>{json}</tool_call>`. |
| **Alibaba Qwen3-Coder** | Distinct XML `<function=...><parameter=...>...</function>`. |
| **Zhipu GLM-4 / 4.5 / 4.7** | XML key/value body inside `<tool_call>`. Interleaved thinking auto-stripped. |
| **Mistral / Mixtral / Nemo** | `[TOOL_CALLS]` token. |
| **Google Gemma 2 / 3** | Markdown ` ```tool_code ` blocks (no native tool tokens). |
| **TinyLlama 1.1B** | Bare JSON. Listed for completeness; tool-call accuracy is low at this size. |

Calibration auto-fix rotates adapters when the initial pick fails the
tool-call probe and persists the working choice in
`%APPDATA%/Navi/settings.json` so subsequent launches skip the probe.

## What it does

- **Streaming chat** with the local LLM via a draggable always-on-top orb.
- **Tool calling** with a tiered permission engine (`allow` / `ask` / `deny`
  rules; modes `default` / `plan` / `acceptEdits` / `bypass`). 55 tools
  organized into 9 categories — see [Tool categories](#tool-categories).
- **Scaffolding + code edits** — `/new` opens a project wizard (Python CLI
  or pytest library); the LLM can `add_python_function`, `add_python_class`,
  `add_python_import`, and `replace_lines` on existing files with AST
  validation (no comment-clobbering `ast.unparse` round-trips). Auto-init's
  a git repo on scaffold so changes are checkpointable from byte 1.
- **Local git** — 9 tools (`git_status` / `git_diff` / `git_log` /
  `git_branch_create` / `git_checkout` / `git_add` / `git_commit` / etc.)
  so the LLM can wrap edits in branches and commit checkpoints. No remote
  ops (push/pull/fetch) — credential UX is out of scope.
- **Run + lint Python** — `run_python(code, cwd)` runs in the project's
  `.venv` if present; `lint_python` / `format_python` shell out to ruff.
- **Image generation** — local diffusion (FLUX.1 Schnell or NVIDIA Sana
  1.6B) with LLM-driven prompt enrichment. GPU auto-detected (full
  placement on cards with ≥16 GB VRAM, model offload below).
- **Scheduling + notifications** — natural-language `schedule_once` /
  `schedule_recurring` ("every Tuesday at 3pm", "in 2 hours"), background
  scheduler ticks and submits the prompt to chat at fire time. Native
  Windows toast via tray.
- **Pre-LLM tool-use hints** — a regex pre-filter detects file paths, URLs,
  and keyword phrases in user input and prepends a `⚙ hint: ...` line so
  weaker models make the implicit-tool-use leap. Toggle visibility in chat
  with `/hints on|off`.
- **Voice** — push-to-talk STT (Windows speech recognition) + auto-TTS
  (SAPI). Disabled by default, enable in Settings.
- **Long-term memory** — Markdown files in `%APPDATA%/Navi/memory/`, indexed
  into the system prompt. Use the `remember` and `recall` tools.
- **Audit log** — JSONL at `%APPDATA%/Navi/audit.jsonl`, viewable from the
  tray menu.
- **Skins** — six built-in plus the `navi-figure` embedded-sprite skin
  (anime hero from `images/navi.png`). Add your own via `%APPDATA%/Navi/skins/`.
- **Calibration** — first launch with a new model runs a 9-probe battery
  (math, coherence, tool-call, parallel-call, etc.) and persists the result.
  Cached forever once tool-call passes; re-run any time with `/calibrate`.

## Tool categories

Tools are grouped into 9 categories. Default exposes only `core` (12 tools)
so prompt-eval stays fast on CPU; everything else is opt-in via
`/tools enable <category>`.

| Category | On by default? | Tools | Purpose |
|---|---|---|---|
| **core** | **yes** (always-on floor) | 12 — read_file, list_dir, calc, get_datetime, check_url, web_search, recall, remember, read_clipboard, write_clipboard, take_screenshot, notify | Conversational essentials |
| **files** | no | 8 — write_file, create_dir, delete_file, delete_dir, move_path, copy_path, find_files, file_info | Filesystem mutations |
| **documents** | no | 5 — read_pdf, read_excel, read_pptx, read_csv, summarize_file | Heavy doc readers + map-reduce summarizer |
| **desktop** | no | 6 — open_app, open_url, focus_window, list_windows, ocr_image, type_text | App + window control + OCR + keystrokes |
| **shell** | no | 1 — run_powershell | Arbitrary PowerShell commands |
| **code** | no | 9 — list_stacks, scaffold_project, lint_python, format_python, add_python_import/function/class, replace_lines, run_python | Project scaffolding + AST edits + execution |
| **git** | no | 9 — git_status, git_diff, git_log, git_branch_list/create, git_checkout, git_init, git_add, git_commit | Local git only (no remote ops) |
| **image** | no | 1 — generate_image | Local diffusion via FLUX or Sana |
| **automation** | no | 4 — schedule_once, schedule_recurring, list_scheduled, cancel_scheduled | Background reminders / recurring prompts |

**Why off by default?** Every tool's JSON schema is sent in the system
prompt every turn. With all 55, the schema is ~30 KB ≈ 7,500 tokens, and
Granite 2B on CPU spent **162 seconds** evaluating it before answering
"hello". The lean default (`core`-only, ~6 KB / ~1,500 tokens of schema)
keeps cold prompt eval under ~20 s on the same hardware. Enable categories
as you need them; settings persist across restarts.

The system prompt includes a "Disabled tool categories: …" line so the
LLM tells the user exactly which `/tools enable <cat>` would unlock a
given request rather than fabricating a refusal.

## Slash commands

In the chat panel:

| Command | Effect |
|---|---|
| `/help` | List commands |
| `/clear` | Clear the chat panel |
| `/skin <name>` | Switch skin (`classic`, `cortana`, `jarvis`, `kit`, `plasma`, `tactical`, `navi-figure`) |
| `/skin reload` / `/skin new` | Re-scan disk / open the skin authoring dialog |
| `/model <name>` | Switch model (substring of GGUF filename in `models/`) |
| `/memory` | Open the memories viewer |
| `/soul list \| use <name> \| reset \| restore \| edit \| reload` | Manage the persona "soul.md" working copy |
| `/lock` / `/unlock` | Toggle plan-mode (no tools execute) |
| `/forget all` | Clear long-term memory (asks for confirmation) |
| `/calibrate [verbose]` | Re-run the model probe battery |
| `/hints on\|off\|toggle\|status` | Show / hide auto-detected tool hints in chat |
| **`/tools`** | List categories with on/off + counts |
| **`/tools enable <cat>`** | Turn on a category (`files`, `code`, `git`, `image`, …) |
| **`/tools disable <cat>`** | Turn off a category (can't disable `core`) |
| **`/tools all`** | Enable every category — slow on CPU, opt-in knowingly |
| **`/tools reset`** | Back to lean default (just `core`) |
| **`/stack list \| use <id> \| clear`** | Project stack ('python-cli' / 'python-pytest-lib') — injects style guide into persona |
| **`/new`** | Open the New Project wizard (modal: stack + name + dest) |
| **`/schedule`** / **`/schedule clear`** | List / wipe scheduled jobs |

## Workflows

A few patterns the tool stack now supports:

**Scaffold + iterate on a Python project**

```
you:    /tools enable code
you:    /tools enable git
you:    /new
        → wizard → python-cli → "widget pal" → ~/Desktop
        → git auto-inits + initial commit
you:    /stack use python-cli
        → next message gets type-hint + argparse style guide injected

you:    add a function called greet(name) that returns f"hi {name}"
navi:   add_python_function(file_path=..., source="def greet(name: str) -> str: ...")
        → AST-validates the snippet + appends; comments + formatting preserved
navi:   lint_python(...) → 0 issues
navi:   git_branch_create("feat/greet")
navi:   git_add(["."])
navi:   git_commit("Add greet()")
```

**Run + verify generated code**

```
you:    /tools enable code
you:    test that the greet function returns the right thing
navi:   run_python(code='from widget_pal import greet; print(greet("Navi"))', cwd=...)
        → "hi Navi"
```

**Schedule a reminder**

```
you:    /tools enable automation
you:    remind me to take a break every 45 minutes
navi:   schedule_recurring(pattern="every 45 minutes", prompt="take a break")
        → at the next 45-min mark, a tray toast pops AND the prompt
          is injected into chat as if you'd typed it
```

**Switch CPU → GPU brain**

Settings → **Compute device** → GPU. Navi preflights for the CUDA
Toolkit, downloads the CUDA wheel of `llama-cpp-python` (validates DLL
load on the worker thread so the GUI never freezes), auto-rolls back to
CPU if anything fails. No restart needed.

## Project layout

```
src/navi/
  __main__.py         Entry point
  app.py              QApplication wiring
  _io.py              Atomic file write helper (settings, history, memory)
  brain/              LLM subprocess client + worker thread
    adapters.py         Per-family adapters (15 entries) + universal detector
    parsers.py          Tool-call format parsers + reasoning-block stripper
    calibration.py      Probe battery (math, tool_call, no_roleplay, ...)
    hints.py            Pre-LLM tool-use hint detector
    persona.py          Navi persona + stack-context + tool-availability composition
    llm_client.py       Subprocess wrapper around llama-cpp-python (GIL fix)
    llm_subprocess.py   The hosted LLM process
    wheel_installer.py  In-app llama-cpp-python CUDA-wheel installer (cached gpu_offload check)
    worker.py           Brain thread, agent loop, calibration cache
    shared.py           Module-level singletons (LLM, progress + notify callbacks)
  pet/                Animated orb window + tray + chat panel
    window.py           Owns brain thread, tray, chat, voice, scheduler
    chat_window.py      Floating chat panel + slash dispatcher
    new_project_dialog.py  /new modal (calls scaffold_project tool)
    skins/              Skin renderers (one per .py)
  tools/              Tool implementations (55 across 9 categories)
    _registry.py        @tool decorator + category filter
    apps.py, clipboard.py, code_edit.py, compute.py, filesystem.py,
    git_ops.py, image_gen.py, keyboard.py, memory.py, notify_tool.py,
    runtime.py, scaffold.py, schedule_tools.py, screen.py, shell.py,
    summarize.py, system.py, web.py, windows.py
  scaffold/           Project scaffolding
    stacks.py           StackSpec registry (python-cli, python-pytest-lib)
    render.py           Jinja2 template walker + atomic writes
    templates/          Bundled per-stack template trees
  schedule/           Background scheduler
    parse.py            Natural-language → datetime (dateparser shim)
    store.py            Persistent job list (%APPDATA%/Navi/scheduled.json)
    runner.py           QTimer that fires due jobs into the brain
  image/              Diffusion image-gen subprocess + client
    models.py           ModelSpec registry (FLUX.1-schnell, Sana 1.6B)
    prompt_rewriter.py  LLM-driven prompt enrichment
  perms/              Permission engine + dispatcher + audit log
  memory/             Long-term memory store
  settings/           Settings UI + JSON store with deep-merge
  voice/              TTS (SAPI) + STT (WinRT) + push-to-talk
```

## Configuration

Settings live at `%APPDATA%/Navi/settings.json`. Key fields:

```jsonc
{
  "defaultMode": "default",          // default | plan | acceptEdits | bypass
  "permissions": { "allow": [...], "ask": [...], "deny": [...] },
  "ui": {
    "orbSize": 240,                  // px, 160-400
    "skin": "classic",
    "personaPrompt": null,           // null = use built-in
    "showHints": false,              // surface ⚙ hint: lines in chat
    "hotkey": "ctrl+shift+space"
  },
  "model": {
    "path": null,                    // null = NAVI_MODEL_PATH env or default
    "n_ctx": 16384,
    "n_gpu_layers": 0                // 0 = CPU; -1 = all on GPU (needs CUDA wheel)
  },
  "voice": {
    "enabled": false,
    "voiceId": null,
    "rate": 200,
    "volume": 0.85,
    "pttHotkey": "ctrl+alt+space"
  },
  "tools": {
    "enabled_categories": ["core"]   // /tools enable <cat> persists here
  },
  "image": {
    "model_id": "flux-schnell",      // flux-schnell | sana-1.6b
    "model_path": null,              // explicit override; null = derive from model_id
    "device": "auto",                // auto | cuda | cpu | cuda_offload
    "default_steps": null,           // null = use the model spec's default
    "default_size": [1024, 1024],
    "prompt_rewrite": true           // LLM-rewrites short prompts before diffusion
  },
  "scaffold": {
    "active_stack": null,            // null | python-cli | python-pytest-lib
    "default_dest": null,            // null = ~/Desktop
    "auto_lint_after_scaffold": true,
    "git_init_on_scaffold": true     // git init + initial commit after scaffold
  },
  "schedule": {
    "enabled": true,
    "notify_on_fire": true,          // pop a toast when a scheduled job fires
    "tick_seconds": 30
  },
  "notify": {
    "enabled": true                  // global on/off for the notify tool
  },
  "model_overrides": {               // per-GGUF calibration cache + adapter pin
    "<filename>.gguf": {
      "adapter_id": "granite_3",
      "calibration_cache": { "tool_call_passed": true, ... }
    }
  }
}
```

Most fields editable through **Settings** (tray right-click → Settings…).
The settings reader is forgiving: corrupt values fall back to defaults
rather than crashing startup.

### CPU vs GPU

`model.n_gpu_layers` switches the brain between CPU and GPU. `0` = CPU only;
`-1` = offload everything to GPU. GPU requires the CUDA build of
`llama-cpp-python` AND the CUDA Toolkit (12.x, ~3 GB). Settings →
**Compute device** dropdown handles this: it preflights for the toolkit,
downloads the CUDA wheel, validates the new DLL loads on a worker thread
(so the GUI never freezes), and auto-rolls back to CPU if anything fails.

### Performance: schema size dominates CPU prompt eval

Every tool's JSON schema gets serialized into the system prompt every
turn. Measured on Granite 3.1 2B Q4_K_M, n_ctx=16384, CPU:

| Active tools | Schema size | "hello" cold response |
|---|---|---|
| 0 (no schema) | 0 KB | **0.7 s** |
| 12 (lean default — `core`) | ~6 KB | **~19 s** |
| 55 (`/tools all`) | ~30 KB | **~162 s** |

Use `/tools` to see what's active, `/tools enable <cat>` only when you
need a category, and consider switching to GPU (Settings → Compute
device) for any sustained heavy use.

## Architecture notes

- The LLM runs in a **subprocess** (`brain/llm_subprocess.py`). llama-cpp's
  C call holds the Python GIL during prompt eval; hosting it in a separate
  process keeps the GUI thread responsive. Communication is line-delimited
  JSON over stdin/stdout.
- Adapter routing uses a **chat-template fingerprint** as the highest-
  priority signal: substring-match the GGUF's `tokenizer.chat_template`
  metadata against each adapter's `template_tokens`. Catches Bartowski-style
  renamed quants that filename matching alone would miss.
- The **permission engine** evaluates `deny → allow → ask → risk-fallback`,
  with explicit modes for plan (deny everything), acceptEdits (auto-allow
  writes under `~`), and bypass (allow everything — dev only). Cross-thread
  permission prompts use a `queue.Queue` with timeout polling so the brain
  thread can't deadlock if the user closes the chat mid-prompt.
- **Code edits never use `ast.unparse`** — the stdlib round-trip strips
  comments, normalizes string quotes, and reflows long lines, which would
  diff-bomb every untouched line on first use. The `code_edit` tools parse
  to validate + locate insertion line numbers, then splice textually, then
  re-parse to confirm the result is valid Python.
- **Background scheduler** is a QTimer in the GUI thread that polls the
  store and submits prompts via the brain's Slot (Qt auto-queues across
  threads). On startup, missed one-shot jobs surface as a chat note rather
  than firing late; missed recurring jobs silently advance to the next
  future occurrence.
- All persistent files (`settings.json`, brain history, memory index, chat
  history, scheduled jobs, generated skins) are written via
  `navi/_io.atomic_write_text` (tempfile + `os.replace`) so a kill mid-write
  can never corrupt them.

## Adding things

**A new tool**: write a function in `src/navi/tools/`, decorate with
`@tool(name=..., description=..., risk=..., parameters=..., category=...)`
from `tools/_registry.py`. Auto-registered on import. Add an `import` in
`src/navi/tools/__init__.py` if it's a new file. Pick a category from the
[Tool categories](#tool-categories) table — the decorator raises
`ValueError` at import time if you typo it. Update `EXPECTED_COUNTS` in
`tests/test_tool_categories.py` so the count test stays honest.

**A new project stack**: add a `StackSpec(...)` entry to `STACKS` in
`src/navi/scaffold/stacks.py` and bundle a `templates/<your-stack-id>/`
tree of Jinja2 `.j2` files. Same shape as the bundled python-cli stack.

**A new image-gen model**: add a `ModelSpec(...)` to `MODELS` in
`src/navi/image/models.py` (works for any diffusers-compatible pipeline
class). The installer script picks it up automatically via
`scripts/install_image_model.py --list`.

**A new adapter** (model family): add a `ModelAdapter(...)` entry to the
`ADAPTERS` tuple in `src/navi/brain/adapters.py`. The most-load-bearing
field is `template_tokens` — substrings to look for in the GGUF's
`tokenizer.chat_template` metadata. Add a corresponding parser to
`src/navi/brain/parsers.py` if the model uses a format we don't already
catch. See the in-file comments + the agent reports in
`scripts/smoke_universal_adapters.py` for the full pattern.

**A new skin**: write a `MySkin(Skin)` class in either
`src/navi/pet/skins/` (built-in) or `%APPDATA%/Navi/skins/` (user). The
`/skin reload` command picks it up without restart. The `navi-figure`
skin demonstrates how to embed a PNG sprite as a base64 literal so the
skin is fully self-contained (no asset directory dependency) — see
`scripts/_build_embedded_skin.py` for the toolchain.

## Troubleshooting

- **"Hello" takes a minute or more to respond on CPU**: the tool schema
  is too big for the model. Run `/tools` to see what's active; reset to
  the lean default with `/tools reset`. Or switch to GPU via Settings →
  Compute device.
- **Tool calls "don't fire" with a higher-param Granite (3.2 / 3.3) or any
  thinking-mode model**: likely Granite 3.2+ emitting `<think>...</think>`
  before the actual tool call. The `strip_reasoning_blocks` post-processor
  handles this; if you see raw `<think>` text in chat, the adapter probably
  isn't matching the model — check the chat-template fingerprint.
- **Phi-4-mini refuses to read files**: known model limitation. Phi's RLHF
  refuses file system access regardless of system prompt. Use Granite for
  file workflows; Phi for short conversational tasks.
- **`/calibrate` runs every launch**: check
  `%APPDATA%/Navi/settings.json` → `model_overrides[<file>].calibration_cache`.
  If `tool_call_passed: false`, the previous calibration's tool-call probe
  failed and a re-run is scheduled (auto-retries every 6 h until it
  passes). If `tool_call_passed: true`, calibration is skipped indefinitely
  until you run `/calibrate`.
- **Image generation is laggy even on a beefy GPU**: confirm
  `settings.image.device = "auto"` and the toast on launch shows
  `loaded on cuda:0, <N> GB VRAM`. The pipeline auto-uses full GPU
  placement when VRAM ≥ 16 GB; below that it uses model-cpu-offload (which
  IS slower because of PCIe transfer — that's expected on smaller cards).
- **Two Navi processes on launch (one venv, one anaconda)**: known
  open issue — the anaconda Python is auto-spawning a duplicate.
  Workaround: `taskkill /PID <anaconda-pid> /F` after launch. The venv
  instance is the canonical one.

## License

MIT (see `LICENSE`). Third-party notices in `THIRD_PARTY_NOTICES.md`.
