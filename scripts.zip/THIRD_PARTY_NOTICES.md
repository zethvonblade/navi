# Third-party notices

Navi bundles or depends on the following components. License terms apply.

## Direct dependencies

| Component | Version | License | Notes |
|---|---|---|---|
| PySide6 | ^6.8 | LGPL-3.0 | Qt for Python. We dynamically link; users may swap their own Qt build per LGPL. |

## Planned dependencies (added in later phases)

| Component | License | Phase |
|---|---|---|
| llama-cpp-python | MIT | 2 |
| Microsoft Phi-4-mini-instruct (GGUF weights) | MIT | 2 |
| smolagents | Apache-2.0 | 3 |
| pydantic | MIT | 3 |
| pywinauto | BSD-3-Clause | 3 |
| uiautomation (yinkaisheng) | Apache-2.0 | 4 |
| pyautogui | BSD-3-Clause | 4 |
| mss | MIT | 3 |
| winsdk (Windows.Media.Ocr) | MIT | 3 |
| RapidOCR | Apache-2.0 | 3 |
| pyperclip | BSD-3-Clause | 3 |
| Windows-Toasts | MIT | 3 |
| sqlite-vec | Apache-2.0 / MIT | 5 |
| BAAI/bge-small-en-v1.5 (embedding model) | MIT | 5 |
| mcp (Model Context Protocol Python SDK) | MIT | post-MVP |

## LLM weights

Default model: IBM Granite 3.1 2B Instruct, © IBM Corporation, released
under the Apache 2.0 License. Bundled GGUF quantizations are derived
works distributed under the same terms.

Microsoft Phi-4-mini-instruct (MIT) is the documented alternative;
override via the `NAVI_MODEL_PATH` env var or by replacing the file in
`models/`.
