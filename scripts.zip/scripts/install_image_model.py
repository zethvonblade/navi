"""Download a registered image-generation model into ./models/.

Usage:
    python scripts/install_image_model.py [model-id]
    python scripts/install_image_model.py --list
    python scripts/install_image_model.py --out ./models flux-schnell

Models live in ``navi.image.models.MODELS``. Add an entry there to make
it installable here automatically.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


# Make ``src/`` importable when invoked as ``python scripts/...``.
_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT / "src"))

from navi.image.models import DEFAULT_MODEL_ID, MODELS, list_models  # noqa: E402


DEFAULT_OUT = _REPO_ROOT / "models"


def _print_list() -> None:
    print("Available image-gen models:\n")
    for mid, spec in list_models():
        marker = " (default)" if mid == DEFAULT_MODEL_ID else ""
        print(f"  {mid}{marker}")
        print(f"      hf:        {spec.hf_id}")
        print(f"      size:      ~{spec.size_gb:g} GB")
        print(f"      license:   {spec.license}")
        print(f"      pipeline:  {spec.pipeline_cls}")
        print(f"      notes:     {spec.notes}")
        print()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "model_id",
        nargs="?",
        default=DEFAULT_MODEL_ID,
        help=f"Model id from the registry (default: {DEFAULT_MODEL_ID}).",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=DEFAULT_OUT,
        help="Parent directory for model folders (default: ./models).",
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="Show all registered models and exit.",
    )
    args = parser.parse_args(argv)

    if args.list:
        _print_list()
        return 0

    if args.model_id not in MODELS:
        print(f"Unknown model id: {args.model_id!r}", file=sys.stderr)
        print("Run with --list to see available models.", file=sys.stderr)
        return 2

    spec = MODELS[args.model_id]
    target_dir = args.out / spec.local_dir
    if target_dir.exists() and any(target_dir.iterdir()):
        print(f"Model already present: {target_dir}")
        print("(delete the directory to re-download)")
        return 0

    try:
        from huggingface_hub import snapshot_download
    except ImportError:
        print(
            "huggingface_hub is required. `pip install huggingface_hub`.",
            file=sys.stderr,
        )
        return 1

    args.out.mkdir(parents=True, exist_ok=True)
    print(
        f"Downloading {spec.hf_id} (~{spec.size_gb:g} GB) → {target_dir}\n"
        "This is resumable — re-run if it gets interrupted."
    )
    snapshot_download(
        repo_id=spec.hf_id,
        local_dir=str(target_dir),
    )
    print(f"\nOK  installed to {target_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
