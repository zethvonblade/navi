"""Download the IBM Granite 3.1 2B Instruct GGUF for local inference.

Usage:
    python scripts/download_model.py [--repo ibm-granite/granite-3.1-2b-instruct-GGUF]
                                     [--file granite-3.1-2b-instruct-Q4_K_M.gguf]
                                     [--out  ./models]

Default model is IBM Granite 3.1 2B Instruct (Apache 2.0, US-origin, native
tool calling). ~1.5 GB download, resumable. Override --repo/--file for any
other GGUF on HuggingFace.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

DEFAULT_REPO = "ibm-granite/granite-3.1-2b-instruct-GGUF"
DEFAULT_FILE = "granite-3.1-2b-instruct-Q4_K_M.gguf"
DEFAULT_OUT = Path(__file__).resolve().parent.parent / "models"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", default=DEFAULT_REPO)
    parser.add_argument("--file", default=DEFAULT_FILE)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args(argv)

    args.out.mkdir(parents=True, exist_ok=True)
    target = args.out / args.file
    if target.exists():
        size_mb = target.stat().st_size / (1024 * 1024)
        print(f"Model already present: {target}  ({size_mb:.1f} MB)")
        return 0

    try:
        from huggingface_hub import hf_hub_download
    except ImportError:
        print("huggingface_hub is required. `pip install huggingface_hub`.", file=sys.stderr)
        return 1

    print(f"Downloading {args.repo}/{args.file} -> {args.out}")
    path = hf_hub_download(
        repo_id=args.repo,
        filename=args.file,
        local_dir=str(args.out),
    )
    size_mb = Path(path).stat().st_size / (1024 * 1024)
    print(f"OK  {path}  ({size_mb:.1f} MB)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
