"""A/B test different system prompts to find one Granite reliably honors."""

from __future__ import annotations

import json

from llama_cpp import Llama

from navi.brain.config import BrainConfig
from navi.tools import tools_schema

cfg = BrainConfig.default()
llm = Llama(
    model_path=str(cfg.model_path),
    n_ctx=4096,
    n_threads=cfg.n_threads,
    verbose=False,
)
schema = tools_schema()


PROMPTS = {
    "A_short": (
        "You are Navi, a Windows desktop assistant. When the user asks about "
        "their clipboard, screen, files, directories, or open windows, call "
        "the appropriate tool. Never refuse a request that a tool could "
        "satisfy."
    ),
    "B_with_format": (
        "You are Navi, a Windows desktop assistant with access to the tools "
        "listed above. When the user asks about clipboard, screen, files, "
        "directories, or open windows, you MUST respond with <|tool_call|> "
        "followed by a JSON list. Do not say you cannot read files; use the "
        "read_file tool."
    ),
    "C_terse_directive": (
        "You are Navi. Use the provided tools to answer questions about the "
        "user's clipboard, screen, files, and windows. Output only "
        "<|tool_call|>[{...}] when calling a tool — no prose before it."
    ),
    "D_official_first_then_navi": (
        "You are a helpful AI assistant with access to the following tools. "
        "When a tool is required to answer the user's query, respond with "
        "<|tool_call|> followed by a JSON list of tools used. If a tool does "
        "not exist in the provided list of tools, notify the user that you "
        "do not have the ability to fulfill the request.\n\n"
        "Your name is Navi. Be concise. For any question about clipboard, "
        "screen, files, directories, or open windows, you have a tool — use it."
    ),
    "E_no_narration": (
        "You are a helpful AI assistant with access to the following tools. "
        "When a tool is required to answer the user's query, respond with "
        "<|tool_call|> followed by a JSON list of tools used. If a tool does "
        "not exist in the provided list of tools, notify the user that you "
        "do not have the ability to fulfill the request.\n\n"
        "Your name is Navi. Be concise. Use tools instead of describing them. "
        "Do not explain your plan or output JSON code blocks. For multi-step "
        "tasks, call ONE tool, wait for the result, then call the next."
    ),
    "F_explicit_no_chain": (
        "You are a helpful AI assistant with access to the following tools. "
        "When a tool is required to answer the user's query, respond with "
        "<|tool_call|> followed by a JSON list of tools used. If a tool does "
        "not exist in the provided list of tools, notify the user that you "
        "do not have the ability to fulfill the request.\n\n"
        "Your name is Navi. RULES:\n"
        "1. To use a tool, your ENTIRE response must be: <|tool_call|>[{\"name\":...,\"arguments\":...}]\n"
        "2. Never write 'Here's the plan' or fenced code blocks.\n"
        "3. For multi-step requests, output only the FIRST tool call. The next call comes after you see its result."
    ),
}

QUERIES = [
    "Read C:\\Users\\SinghMa\\OneDrive - US Army\\Documents\\MANDEEP SINGH Resume.docx",
    "What's on my clipboard?",
    "What windows do I have open?",
    # Multi-step prompt that triggers narrate-the-plan drift
    "Open Notepad and type my todos: eat, sleep, work",
]


def did_tool_call(content: str) -> bool:
    return "<|tool_call|>" in content or "<tool_call>" in content


def run(temp: float) -> None:
    print(f"\n========= temperature = {temp} =========")
    for pname, prompt in PROMPTS.items():
        wins = 0
        for q in QUERIES:
            resp = llm.create_chat_completion(
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": q},
                ],
                tools=schema,
                tool_choice="auto",
                max_tokens=160,
                temperature=temp,
            )
            content = resp["choices"][0]["message"].get("content") or ""
            ok = did_tool_call(content)
            wins += 1 if ok else 0
            mark = "OK " if ok else "NO "
            print(f"  {pname:24s} {mark} q={q[:40]!r}")
            if not ok:
                snippet = content.replace("\n", " ")[:120]
                print(f"      -> {snippet}")
        print(f"  {pname:24s} score: {wins}/{len(QUERIES)}")


if __name__ == "__main__":
    for t in (0.1, 0.4, 0.7):
        run(t)
