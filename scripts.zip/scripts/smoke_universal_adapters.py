"""Smoke test for the universal-adapter coverage refactor.

Run after touching parsers.py / adapters.py to confirm:
  - each new parser handles its expected payload
  - parse_any_tool_call dispatches correctly across all formats
  - chat-template fingerprint detection routes to the right adapter
  - filename fallback still works
  - post_process is wired on the adapters that need it

Not part of a formal pytest suite — this is a one-shot sanity script per
the project's "inline assertions" verification convention.
"""

from __future__ import annotations

import json
from pathlib import Path

from navi.brain.parsers import (
    parse_any_tool_call,
    parse_deepseek_v3,
    parse_glm_xml,
    parse_harmony,
    parse_pythonic_call,
    parse_qwen3_coder_xml,
    strip_reasoning_blocks,
    text_starts_tool_call,
)
from navi.brain.adapters import (
    ADAPTERS,
    adapter_by_id,
    detect_adapter_universal,
)


# ---------------------------------------------------------------------------
# 1. Harmony / GPT-OSS
# ---------------------------------------------------------------------------
hsample = (
    "<|channel|>commentary to=functions.read_clipboard "
    "<|constrain|>json<|message|>{}<|call|>"
)
got = parse_harmony(hsample)
assert got and got[0]["function"]["name"] == "read_clipboard", f"harmony 1: {got}"
assert got[0]["function"]["arguments"] == "{}"

hmulti = (
    '<|channel|>commentary to=functions.search<|message|>{"q": "cats"}<|call|>'
    '<|channel|>commentary to=functions.read_file<|message|>{"path": "/x"}<|call|>'
)
got = parse_harmony(hmulti)
assert len(got) == 2
assert got[0]["function"]["name"] == "search"
assert got[1]["function"]["name"] == "read_file"
assert json.loads(got[0]["function"]["arguments"])["q"] == "cats"

assert parse_harmony("hello world") is None
assert parse_harmony("") is None


# ---------------------------------------------------------------------------
# 2. DeepSeek V3 / R1 (full-width Unicode pipes)
# ---------------------------------------------------------------------------
PIPE = "｜"  # U+FF5C FULLWIDTH VERTICAL LINE
LB = "▁"   # U+2581 LOWER ONE EIGHTH BLOCK (sentencepiece word-marker)


def _ds_block(name: str, args_json: str) -> str:
    return (
        f"<{PIPE}tool{LB}calls{LB}begin{PIPE}>\n"
        f"<{PIPE}tool{LB}call{LB}begin{PIPE}>function"
        f"<{PIPE}tool{LB}sep{PIPE}>{name}\n"
        f"```json\n{args_json}\n```"
        f"<{PIPE}tool{LB}call{LB}end{PIPE}>\n"
        f"<{PIPE}tool{LB}calls{LB}end{PIPE}>"
    )


ds = _ds_block("read_clipboard", '{"x": 1}')
got = parse_deepseek_v3(ds)
assert got and got[0]["function"]["name"] == "read_clipboard", f"deepseek: {got}"
assert json.loads(got[0]["function"]["arguments"])["x"] == 1

# R1 always emits <think> first — strip then parse
r1 = "<think>I should look up x.</think>\n" + ds
cleaned = strip_reasoning_blocks(r1)
got = parse_deepseek_v3(cleaned)
assert got and got[0]["function"]["name"] == "read_clipboard"

assert parse_deepseek_v3("nothing here") is None


# ---------------------------------------------------------------------------
# 3. GLM-4 XML body
# ---------------------------------------------------------------------------
glm = (
    "<tool_call>read_file\n"
    "<arg_key>path</arg_key>\n"
    "<arg_value>/tmp/x.txt</arg_value>\n"
    "<arg_key>max_lines</arg_key>\n"
    "<arg_value>50</arg_value>\n"
    "</tool_call>"
)
got = parse_glm_xml(glm)
assert got and got[0]["function"]["name"] == "read_file", f"glm: {got}"
args = json.loads(got[0]["function"]["arguments"])
assert args == {"path": "/tmp/x.txt", "max_lines": "50"}, f"glm args: {args}"

glm_two = (
    glm + "\n<tool_call>search\n"
    "<arg_key>q</arg_key>\n<arg_value>cats</arg_value>\n</tool_call>"
)
got = parse_glm_xml(glm_two)
assert len(got) == 2

# GLM should NOT match a JSON-body <tool_call> (that's Granite 4 / Qwen)
got = parse_glm_xml('<tool_call>{"name": "x", "arguments": {}}</tool_call>')
assert got is None or got == [], f"glm should skip JSON body, got {got}"


# ---------------------------------------------------------------------------
# 4. Qwen3-Coder XML
# ---------------------------------------------------------------------------
qcoder = (
    "<function=read_file>"
    "<parameter=path>/etc/hosts</parameter>"
    "<parameter=lines>10</parameter>"
    "</function>"
)
got = parse_qwen3_coder_xml(qcoder)
assert got and got[0]["function"]["name"] == "read_file", f"qcoder: {got}"
args = json.loads(got[0]["function"]["arguments"])
assert args == {"path": "/etc/hosts", "lines": "10"}

qmulti = qcoder + "\n<function=search><parameter=q>cats</parameter></function>"
got = parse_qwen3_coder_xml(qmulti)
assert len(got) == 2

assert parse_qwen3_coder_xml("plain text") is None


# ---------------------------------------------------------------------------
# 5. Pythonic for Llama 4
# ---------------------------------------------------------------------------
l4 = '[take_screenshot(), read_file(path="/x")]'
got = parse_pythonic_call(l4)
assert got and len(got) == 2
assert got[0]["function"]["name"] == "take_screenshot"
assert got[1]["function"]["name"] == "read_file"


# ---------------------------------------------------------------------------
# 6. parse_any_tool_call dispatches each format correctly
# ---------------------------------------------------------------------------
dispatch_cases = [
    ("harmony", hsample, "read_clipboard"),
    ("deepseek", cleaned, "read_clipboard"),
    ("glm", glm, "read_file"),
    ("qcoder", qcoder, "read_file"),
    ("llama4", l4, "take_screenshot"),
]
for label, sample, expected_fn in dispatch_cases:
    got = parse_any_tool_call(sample)
    assert got and got[0]["function"]["name"] == expected_fn, f"{label}: {got}"


# ---------------------------------------------------------------------------
# 7. Adapter detection via chat_template fingerprint
# ---------------------------------------------------------------------------
template_cases = [
    ("gpt_oss",     {"tokenizer.chat_template": "system <|channel|>commentary to=functions.X stuff"}),
    ("deepseek",    {"tokenizer.chat_template": f"header <{PIPE}tool{LB}calls{LB}begin{PIPE}> body"}),
    ("llama_4",     {"tokenizer.chat_template": "before <|header_start|>assistant<|header_end|> after"}),
    ("glm_4",       {"tokenizer.chat_template": "tmpl <arg_key>k</arg_key> body"}),
    ("qwen3_coder", {"tokenizer.chat_template": "tmpl <function=NAME> body"}),
    ("granite_3",   {"tokenizer.chat_template": "tmpl <|tool_call|> body"}),
    ("granite_4",   {"tokenizer.chat_template": "tmpl <tool_response>...</tool_response>"}),
    ("phi",         {"tokenizer.chat_template": "tmpl <|tool|>tools<|/tool|> ... <|tool_response|>"}),
    ("qwen_hermes", {"tokenizer.chat_template": "tmpl <tool_call> body"}),
    ("mistral",     {"tokenizer.chat_template": "tmpl [TOOL_CALLS] body"}),
]
for adapter_id, meta in template_cases:
    got = detect_adapter_universal(Path("mystery.gguf"), meta)
    assert got.id == adapter_id, f"template -> expected {adapter_id}; got {got.id}"


# ---------------------------------------------------------------------------
# 8. Filename detection still works
# ---------------------------------------------------------------------------
filename_cases = [
    ("gpt_oss",     "openai-gpt-oss-120b-Q4.gguf"),
    ("deepseek",    "deepseek-v3-Q4.gguf"),
    ("llama_4",     "llama-4-scout-Q4.gguf"),
    ("glm_4",       "glm-4-9b-chat.gguf"),
    ("qwen3_coder", "qwen3-coder-30b-instruct.gguf"),
    ("granite_3",   "granite-3.1-8b-instruct-Q4_K_M.gguf"),
    ("granite_4",   "granite-4.0-h-tiny-Q4.gguf"),
]
for adapter_id, fname in filename_cases:
    got = detect_adapter_universal(Path(fname), None)
    assert got.id == adapter_id, f"filename {fname} -> expected {adapter_id}; got {got.id}"


# ---------------------------------------------------------------------------
# 9. post_process correctly assigned
# ---------------------------------------------------------------------------
think_adapters = ("granite_3", "granite_4", "deepseek", "qwen_hermes", "glm_4")
for aid in think_adapters:
    a = adapter_by_id(aid)
    assert a is not None and a.post_process is strip_reasoning_blocks, \
        f"{aid} should have post_process=strip_reasoning_blocks"

no_think = (
    "gpt_oss", "phi", "qwen3_coder", "llama_4", "llama_3_pythonic",
    "llama_3_json", "mistral", "gemma_3", "tinyllama", "default",
)
for aid in no_think:
    a = adapter_by_id(aid)
    assert a is not None, f"{aid} adapter missing"
    assert a.post_process is None, f"{aid} unexpectedly has post_process"


# ---------------------------------------------------------------------------
# 10. Sniff markers picked up by text_starts_tool_call
# ---------------------------------------------------------------------------
assert text_starts_tool_call("<|channel|>commentary to=functions.x")
assert text_starts_tool_call(f"<{PIPE}tool{LB}calls{LB}begin{PIPE}>")
assert text_starts_tool_call("<function=read_file>")
# <think> still treated as wait-for-it
assert text_starts_tool_call("<think>reasoning...")


# ---------------------------------------------------------------------------
# 11. Cohere / InternLM "parameters" alias still works in bare_json
# ---------------------------------------------------------------------------
cohere = '{"name": "top_song", "parameters": {"sign": "WZPZ"}}'
got = parse_any_tool_call(cohere)
assert got and got[0]["function"]["name"] == "top_song"
assert json.loads(got[0]["function"]["arguments"]) == {"sign": "WZPZ"}


# ---------------------------------------------------------------------------
# 12. Full app imports clean
# ---------------------------------------------------------------------------
from navi.app import run  # noqa: E402, F401
from navi.pet.window import PetWindow  # noqa: E402, F401
from navi.brain.worker import BrainWorker  # noqa: E402, F401

print(f"ALL ASSERTIONS PASSED — {len(ADAPTERS)} adapters registered")
