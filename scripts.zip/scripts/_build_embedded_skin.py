"""Generate the final navi_figure.py with the PNG bytes inlined.

Reads scripts/_figure_embedded.py (produced by _embed_figure.py) for the
base64 literal, splices it into the skin template, and writes the result
to src/navi/pet/skins/navi_figure.py.

After running this, the skin file is fully self-contained — no
dependency on images/navi-figure.png at runtime.
"""

from __future__ import annotations

from pathlib import Path

EMBED_PATH = Path("scripts/_figure_embedded.py")
OUT_PATH = Path("src/navi/pet/skins/navi_figure.py")

TEMPLATE = '''"""Navi-figure skin — full character sprite, embedded.

Renders the spiky-haired hero from the reference art as the floating
companion. The PNG is base64-embedded directly in this module — no
external asset dependency. Drop this .py anywhere and it works.

State-driven effects layered around the sprite:

- **Aura**: soft colored glow BEHIND the figure that pulses with state
  (subtle on idle, fast on speaking, hard strobe on error).
- **Idle bobbing**: figure sways up/down on a slow sine so it doesn't
  feel like a static paper-doll.
- **Energy-ball glow**: animated yellow/orange glow OVER the figure's
  right hand. Hue shifts to cyan on LISTENING, red on ERROR.
- **Cursor-tracking pupils**: tiny black dots overlaid near the eyes
  that nudge toward the cursor.

The embedded PNG is a 128-color quantized version of the original
2.5 MB cutout — visually indistinguishable at the small render sizes
the orb uses, but ~95 percent smaller. To regenerate after editing
images/navi-figure.png, run scripts/_build_embedded_skin.py.
"""

from __future__ import annotations

import base64
import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import (
    QBrush,
    QColor,
    QImage,
    QPen,
    QPixmap,
    QRadialGradient,
)

from navi.pet.skins._base import PaintContext, Skin
from navi.pet.skins._colors import rgba
from navi.pet.state import NaviState

# --- Embedded sprite -------------------------------------------------------
# Base64-encoded PNG (128-color quantized cutout of images/navi.png).
# Decoded once at first paint and cached as a QPixmap.
{EMBED_BLOCK}

_FIGURE_PIX: QPixmap | None = None
_FIGURE_LOAD_ERROR: str | None = None


def _decode_figure() -> QPixmap | None:
    """Lazy-decode the embedded PNG. Returns None on any decode failure."""
    global _FIGURE_PIX, _FIGURE_LOAD_ERROR
    if _FIGURE_PIX is not None:
        return _FIGURE_PIX
    if _FIGURE_LOAD_ERROR is not None:
        return None
    try:
        data = base64.b64decode(_FIGURE_BYTES_B64)
        img = QImage.fromData(data, _FIGURE_FORMAT)
        if img.isNull():
            _FIGURE_LOAD_ERROR = "QImage.fromData returned null"
            return None
        _FIGURE_PIX = QPixmap.fromImage(img)
        return _FIGURE_PIX
    except Exception as exc:  # noqa: BLE001
        _FIGURE_LOAD_ERROR = f"{{exc.__class__.__name__}}: {{exc}}"
        return None


# --- Anchor coordinates in the source 600x600 image ------------------------
# Eyeballed from the reference art. Scaled at paint time.
_SRC_W = 600.0
_SRC_H = 600.0
_EYE_LEFT = (260.0, 165.0)
_EYE_RIGHT = (320.0, 165.0)
_ENERGY_HAND = (475.0, 290.0)


# --- Per-state palette -----------------------------------------------------
NAVI_TEAL = QColor("#2DD4D4")
NAVI_RED = QColor("#E53947")
NAVI_GOLD = QColor("#FFE066")
NAVI_AMBER = QColor("#F5A623")
NAVI_ORANGE = QColor("#FF7A1A")
NAVI_VIOLET = QColor("#A98BFF")
NAVI_RED_DEEP = QColor("#7A1922")

# state -> (aura_color, energy_ball_color)
_PALETTE: dict[NaviState, tuple[QColor, QColor]] = {{
    NaviState.IDLE:      (NAVI_TEAL,   NAVI_GOLD),
    NaviState.LISTENING: (NAVI_TEAL,   QColor("#7FE0FF")),
    NaviState.THINKING:  (NAVI_VIOLET, NAVI_AMBER),
    NaviState.SPEAKING:  (NAVI_AMBER,  NAVI_ORANGE),
    NaviState.ASKING:    (NAVI_GOLD,   QColor("#FFD0A0")),
    NaviState.ERROR:     (NAVI_RED,    NAVI_RED_DEEP),
}}


class NaviFigureSkin(Skin):
    name = "navi-figure"
    description = (
        "Anime hero figure (embedded sprite) with state-driven aura, "
        "energy-ball glow, idle bob, and cursor-tracking eyes."
    )

    def paint(self, ctx: PaintContext) -> None:
        p = ctx.painter
        rect = ctx.rect
        cx = rect.width() / 2.0
        cy = rect.height() / 2.0
        max_r = min(cx, cy) - 4.0
        state = ctx.state
        aura_color, energy_color = _PALETTE[state]

        # Per-state intensity + bob speed.
        intensity = 0.95
        bob_speed = 0.45
        if state is NaviState.SPEAKING:
            intensity = 0.85 + 0.15 * (
                0.5 + 0.5 * math.sin(ctx.t * 2 * math.pi * 2.4)
            )
            bob_speed = 0.9
        elif state is NaviState.THINKING:
            intensity = 0.90
            bob_speed = 0.7
        elif state is NaviState.LISTENING:
            intensity = 0.85 + 0.15 * math.sin(ctx.t * 2 * math.pi / 1.6)
        elif state is NaviState.ASKING:
            intensity = 0.70 + 0.30 * math.sin(ctx.t * 2 * math.pi * 0.9)
            bob_speed = 0.3
        elif state is NaviState.ERROR:
            intensity = 0.50 + 0.50 * math.sin(ctx.t * 2 * math.pi * 4.0)
            bob_speed = 1.6

        bob_amplitude = max_r * 0.025
        bob_y = math.sin(ctx.t * 2 * math.pi * bob_speed / 2.0) * bob_amplitude

        # ---- 1. Aura behind the figure -------------------------------
        aura_grad = QRadialGradient(QPointF(cx, cy), max_r * 1.05)
        aura_grad.setColorAt(0.00, rgba(aura_color, int(110 * intensity)))
        aura_grad.setColorAt(0.55, rgba(aura_color, int(45 * intensity)))
        aura_grad.setColorAt(1.00, rgba(aura_color, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(aura_grad))
        p.drawEllipse(QPointF(cx, cy + bob_y * 0.5), max_r * 1.05, max_r * 1.05)

        # ---- 2. Listening ripples behind the sprite ------------------
        if state is NaviState.LISTENING:
            for birth in ctx.ripples:
                progress = min((ctx.t - birth) / 1.2, 1.0)
                r = max_r * (0.85 + 0.18 * progress)
                alpha = int(180 * (1.0 - progress) * intensity)
                pen = QPen(rgba(aura_color, alpha), 1.3)
                p.setPen(pen)
                p.setBrush(Qt.BrushStyle.NoBrush)
                p.drawEllipse(QPointF(cx, cy + bob_y * 0.5), r, r)

        # ---- 3. Figure sprite ---------------------------------------
        pix = _decode_figure()
        if pix is None:
            self._draw_missing_asset(p, cx, cy, max_r, intensity)
            return

        target = max_r * 2.0
        sprite_x = cx - target / 2.0
        sprite_y = cy - target / 2.0 + bob_y
        target_rect = QRectF(sprite_x, sprite_y, target, target)
        prev_op = p.opacity()
        p.setOpacity(min(1.0, 0.6 + 0.4 * intensity))
        p.drawPixmap(target_rect, pix, QRectF(pix.rect()))
        p.setOpacity(prev_op)

        sx = target / _SRC_W
        sy = target / _SRC_H

        def src_to_screen(x: float, y: float) -> QPointF:
            return QPointF(sprite_x + x * sx, sprite_y + y * sy)

        # ---- 4. Energy-ball glow over the right hand ----------------
        ball_center = src_to_screen(*_ENERGY_HAND)
        ball_r = max_r * (0.18 + 0.025 * math.sin(ctx.t * 2 * math.pi * 1.5))
        ball_grad = QRadialGradient(ball_center, ball_r)
        ball_grad.setColorAt(0.0, rgba(QColor(255, 255, 255), int(200 * intensity)))
        ball_grad.setColorAt(0.30, rgba(energy_color, int(220 * intensity)))
        ball_grad.setColorAt(0.70, rgba(energy_color, int(80 * intensity)))
        ball_grad.setColorAt(1.0, rgba(energy_color, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(ball_grad))
        p.drawEllipse(ball_center, ball_r, ball_r)
        p.setBrush(QBrush(rgba(QColor(255, 255, 255), int(235 * intensity))))
        p.drawEllipse(ball_center, ball_r * 0.18, ball_r * 0.18)

        # ---- 5. Cursor-tracking pupil dots --------------------------
        if state is not NaviState.ERROR:
            pupil_dx = ctx.pupil_x * 0.04
            pupil_dy = ctx.pupil_y * 0.04
            for ex, ey in (_EYE_LEFT, _EYE_RIGHT):
                eye_pt = src_to_screen(ex, ey)
                pupil_pt = QPointF(
                    eye_pt.x() + pupil_dx,
                    eye_pt.y() + pupil_dy,
                )
                pupil_r = max_r * 0.012
                p.setBrush(QBrush(QColor(0, 0, 0, int(220 * intensity))))
                p.setPen(Qt.PenStyle.NoPen)
                p.drawEllipse(pupil_pt, pupil_r, pupil_r)

    def _draw_missing_asset(
        self, p, cx: float, cy: float, max_r: float, intensity: float,
    ) -> None:
        """Fallback render if the embedded data fails to decode."""
        p.setPen(QPen(rgba(NAVI_RED, 220), 2.0))
        p.setBrush(QBrush(rgba(NAVI_RED_DEEP, 180)))
        p.drawEllipse(QPointF(cx, cy), max_r * 0.7, max_r * 0.7)
        p.setPen(QPen(QColor(255, 255, 255, 220), 1.0))
        p.drawText(
            QRectF(cx - max_r, cy - 8, max_r * 2, 16),
            int(Qt.AlignmentFlag.AlignCenter),
            f"figure decode failed:\\n{{_FIGURE_LOAD_ERROR or '?'}}",
        )
'''


def main() -> int:
    if not EMBED_PATH.exists():
        print(f"missing {EMBED_PATH}; run scripts/_embed_figure.py first")
        return 1
    embed_text = EMBED_PATH.read_text(encoding="utf-8")
    # Strip the auto-generated header line from the embed file; we want
    # just the _FIGURE_FORMAT and _FIGURE_BYTES_B64 declarations.
    embed_block = "\n".join(
        ln for ln in embed_text.splitlines()
        if not ln.startswith('"""')
    ).strip()
    out = TEMPLATE.format(EMBED_BLOCK=embed_block)
    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUT_PATH.write_text(out, encoding="utf-8")
    print(f"wrote {OUT_PATH}  ({OUT_PATH.stat().st_size // 1024} KB)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
