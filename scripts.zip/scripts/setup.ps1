# Navi dev-environment bootstrap.
#
# Creates a project-local .venv, installs pinned dependencies from
# requirements.txt, and installs the project itself in editable mode.
#
# Usage (from project root):
#   powershell -ExecutionPolicy Bypass -File scripts/setup.ps1
#   # or, if your policy already allows local scripts:
#   ./scripts/setup.ps1
#
# Re-run any time to upgrade deps to the pinned versions.

$ErrorActionPreference = "Stop"

# --- Locate project root (parent of scripts/) -------------------------------
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectRoot = Split-Path -Parent $ScriptRoot
Set-Location $ProjectRoot

$VenvDir = Join-Path $ProjectRoot ".venv"
$VenvPython = Join-Path $VenvDir "Scripts\python.exe"

# --- Pick a system Python ---------------------------------------------------
function Find-SystemPython {
    # Prefer 3.12 (project requires >=3.12,<3.13). Fall back to whatever
    # `python` resolves to and let the venv creation fail loudly if wrong.
    $candidates = @(
        "C:\ProgramData\anaconda3\python.exe",
        "py -3.12",
        "python3.12",
        "python"
    )
    foreach ($c in $candidates) {
        $exe, $args = $c -split " ", 2
        $resolved = (Get-Command $exe -ErrorAction SilentlyContinue).Source
        if ($resolved) {
            if ($args) { return @($resolved, $args) } else { return @($resolved) }
        }
    }
    throw "No Python interpreter found on PATH. Install Python 3.12 first."
}

# --- Create venv if missing -------------------------------------------------
if (-not (Test-Path $VenvPython)) {
    Write-Host "[setup] Creating .venv ..." -ForegroundColor Cyan
    $py = Find-SystemPython
    & $py[0] $py[1..($py.Length-1)] -m venv $VenvDir
    if ($LASTEXITCODE -ne 0) { throw "venv creation failed" }
} else {
    Write-Host "[setup] .venv already exists, reusing." -ForegroundColor DarkGray
}

# --- Verify Python version --------------------------------------------------
$pyVersion = & $VenvPython -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"
if ($pyVersion -ne "3.12") {
    Write-Warning "[setup] .venv is on Python $pyVersion; project requires 3.12.x. Continuing, but expect issues."
}

# --- Upgrade pip ------------------------------------------------------------
Write-Host "[setup] Upgrading pip ..." -ForegroundColor Cyan
& $VenvPython -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw "pip upgrade failed" }

# --- Install pinned deps ----------------------------------------------------
Write-Host "[setup] Installing pinned dependencies from requirements.txt ..." -ForegroundColor Cyan
& $VenvPython -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw "requirements.txt install failed" }

# --- Install navi itself in editable mode (no-deps; reqs are already pinned)
Write-Host "[setup] Installing navi in editable mode ..." -ForegroundColor Cyan
& $VenvPython -m pip install --no-deps -e .
if ($LASTEXITCODE -ne 0) { throw "editable install failed" }

# --- Smoke test -------------------------------------------------------------
Write-Host "[setup] Smoke test: importing navi ..." -ForegroundColor Cyan
& $VenvPython -c "import navi; print('  navi at', navi.__file__)"
if ($LASTEXITCODE -ne 0) { throw "navi import failed" }

Write-Host ""
Write-Host "[setup] Done. To use:" -ForegroundColor Green
Write-Host "  .venv\Scripts\python.exe -m navi"
Write-Host "  .venv\Scripts\python.exe -m pytest -q"
