"""Headless preview: render every state of a skin to a PNG mosaic.

Usage:
    python scripts/_preview_skin.py [skin_name] [out.png]
Default: render `navi-hero` to `images/navi-hero-preview.png`.
"""

from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import QRect, Qt
from PySide6.QtGui import QImage, QPainter
from PySide6.QtWidgets import QApplication

from navi.pet.skins import PaintContext, get_skin, reload_skins
from navi.pet.state import NaviState


def render_state(skin, state: NaviState, t: float, size: int = 256) -> QImage:
    img = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(0x00000000)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    ctx = PaintContext(
        painter=p,
        rect=QRect(0, 0, size, size),
        state=state,
        t=t,
        pupil_x=0.0,
        pupil_y=0.0,
        ripples=[t - 0.3] if state is NaviState.LISTENING else [],
    )
    skin.paint(ctx)
    p.end()
    return img


def main() -> int:
    skin_name = sys.argv[1] if len(sys.argv) > 1 else "navi-hero"
    out_path = Path(sys.argv[2] if len(sys.argv) > 2 else f"images/{skin_name}-preview.png")
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # Qt needs a QApplication for QImage / QPainter.
    app = QApplication.instance() or QApplication(sys.argv)  # noqa: F841
    reload_skins()
    skin = get_skin(skin_name)
    print(f"rendering {skin_name} -> {out_path}")

    states = [
        (NaviState.IDLE,      "idle",      0.5),
        (NaviState.LISTENING, "listening", 1.0),
        (NaviState.THINKING,  "thinking",  1.2),
        (NaviState.SPEAKING,  "speaking",  0.8),
        (NaviState.ASKING,    "asking",    0.6),
        (NaviState.ERROR,     "error",     0.4),
    ]
    cell = 256
    cols = 3
    rows = 2
    pad = 8
    label_h = 18
    grid_w = cols * cell + (cols + 1) * pad
    grid_h = rows * (cell + label_h) + (rows + 1) * pad
    grid = QImage(grid_w, grid_h, QImage.Format.Format_ARGB32_Premultiplied)
    grid.fill(0xFF101010)
    gp = QPainter(grid)
    gp.setRenderHint(QPainter.RenderHint.Antialiasing)
    gp.setPen(Qt.GlobalColor.white)
    for i, (state, label, t) in enumerate(states):
        col = i % cols
        row = i // cols
        x = pad + col * (cell + pad)
        y = pad + row * (cell + label_h + pad)
        cell_img = render_state(skin, state, t, cell)
        gp.drawImage(x, y, cell_img)
        gp.drawText(x, y + cell + label_h - 4, label)
    gp.end()
    grid.save(str(out_path))
    print(f"saved {out_path}  ({out_path.stat().st_size // 1024} KB)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
