from pathlib import Path
from navi.settings.store import load
from navi.brain.adapters import detect_adapter_universal

s = load()
print("current model:", Path(s.get("model", {}).get("path", "")).name)
for fname, entry in (s.get("model_overrides") or {}).items():
    print(f"\n  {fname}:")
    print(f"    entry.adapter_id (auto-fix winner): {entry.get('adapter_id')}")
    print(f"    legacy.system_prompt_variant: {entry.get('system_prompt_variant')}")
    cache = entry.get("calibration_cache", {})
    if cache:
        print(f"    cache.adapter_id:        {cache.get('adapter_id')}")
        print(f"    cache.tool_call_passed:  {cache.get('tool_call_passed')}")
        print(f"    cache.all_passed:        {cache.get('all_passed')}")
        print(f"    cache.at_unix:           {cache.get('at_unix')}")
    detected = detect_adapter_universal(Path(s["model"]["path"]) if fname in (s.get("model", {}).get("path", "")) else Path(fname), None)
    print(f"    detect_adapter_universal: {detected.id}")
