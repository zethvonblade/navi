"""Diagnostic: does Granite emit tool_calls via llama-cpp-python?"""

from __future__ import annotations

import json
import sys

from llama_cpp import Llama

from navi.brain.config import BrainConfig
from navi.tools import tools_schema

cfg = BrainConfig.default()
print("Loading", cfg.model_path)

llm = Llama(
    model_path=str(cfg.model_path),
    n_ctx=2048,
    n_threads=cfg.n_threads,
    verbose=False,
)

print("\n=== chat metadata ===")
meta = getattr(llm, "metadata", {}) or {}
chat_template = meta.get("tokenizer.chat_template", "")
print(f"chat_template length: {len(chat_template)}")
if chat_template:
    print(f"FULL TEMPLATE:\n{chat_template}\n--- end template ---")
print(f"chat_format: {getattr(llm, 'chat_format', None)}")
print(f"chat_handler: {type(getattr(llm, 'chat_handler', None)).__name__}")

print("\n=== tools schema being sent ===")
schema = tools_schema()
print(json.dumps(schema, indent=2)[:1200])

print("\n=== test call (no stream) ===")
messages = [
    {
        "role": "system",
        "content": "You are a helpful assistant with access to tools. Use them when the user asks for information about their environment.",
    },
    {"role": "user", "content": "Read the file at C:/Users/SinghMa/Documents/test.txt"},
]
try:
    resp = llm.create_chat_completion(
        messages=messages,
        tools=schema,
        tool_choice="auto",
        max_tokens=256,
        temperature=0.1,
    )
    print(json.dumps(resp, indent=2, default=str)[:2000])
except Exception as exc:
    print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
