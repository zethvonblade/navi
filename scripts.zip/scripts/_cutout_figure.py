"""Auto-cutout the navi figure from images/navi.png against its cityscape.

Approach (pure PIL + numpy, no scipy/cv2):

1. Sample colors at the four corners (the cityscape edges).
2. For each pixel, mark it as "background-similar" if its RGB is within
   ``COLOR_TOL`` of ANY corner sample.
3. Flood-fill the background-similar region starting from the corner
   pixels using iterative dilation (4-connected). Pixels reached this
   way become alpha=0; everything else is the figure.
4. Apply a small Gaussian-ish blur to the alpha channel to soften the
   silhouette edge so the cutout doesn't read as a sharp paper-doll.

Output: images/navi-figure.png with transparent background.

This is a best-effort algorithmic cutout. For perfect results, replace
with a hand-cleaned version using GIMP / Photoshop / rembg.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

SRC = Path("images/navi.png")
DST = Path("images/navi-figure.png")
COLOR_TOL = 70          # max Euclidean RGB distance to count as background-similar
EDGE_FEATHER_PX = 1.5   # alpha-channel blur radius for soft silhouette edge
MAX_ITERS = 1000        # safety bound on flood-fill iterations


def main() -> int:
    src = SRC.resolve()
    if not src.exists():
        print(f"missing source: {src}", file=sys.stderr)
        return 1
    img = Image.open(src).convert("RGBA")
    arr = np.asarray(img, dtype=np.int16)  # (H, W, 4)
    h, w = arr.shape[:2]
    rgb = arr[..., :3]

    # 1. Corner samples (small 3x3 average per corner so a single noisy
    # pixel doesn't throw the threshold off).
    def avg(y0: int, x0: int) -> np.ndarray:
        return rgb[y0 : y0 + 3, x0 : x0 + 3].reshape(-1, 3).mean(axis=0)

    corners = np.array([
        avg(0, 0),
        avg(0, w - 3),
        avg(h - 3, 0),
        avg(h - 3, w - 3),
    ])  # (4, 3)
    print(f"corner colors: {corners.astype(int).tolist()}")

    # 2. Distance to nearest corner color, for every pixel.
    # rgb shape (H,W,3); corners (4,3). Result (H,W,4) -> min over axis=2.
    diff = rgb[:, :, None, :] - corners[None, None, :, :]  # (H, W, 4, 3)
    dist2 = (diff * diff).sum(axis=-1)                      # (H, W, 4)
    min_dist2 = dist2.min(axis=-1)                          # (H, W)
    bg_similar = min_dist2 < (COLOR_TOL * COLOR_TOL)        # (H, W) bool

    # 3. Flood from corners through bg_similar mask via iterative dilation.
    bg = np.zeros((h, w), dtype=bool)
    bg[0, 0] = True
    bg[0, -1] = True
    bg[-1, 0] = True
    bg[-1, -1] = True

    iters = 0
    for iters in range(MAX_ITERS):
        # 4-connected dilation: shift up/down/left/right and OR.
        u = np.zeros_like(bg); u[:-1] = bg[1:]
        d = np.zeros_like(bg); d[1:] = bg[:-1]
        l = np.zeros_like(bg); l[:, :-1] = bg[:, 1:]
        r = np.zeros_like(bg); r[:, 1:] = bg[:, :-1]
        new_bg = (bg | u | d | l | r) & bg_similar
        if np.array_equal(new_bg, bg):
            break
        bg = new_bg
    print(f"flood fill converged after {iters} iterations")

    # 4. Build alpha and feather edges.
    alpha = np.where(bg, 0, 255).astype(np.uint8)
    alpha_img = Image.fromarray(alpha, mode="L")
    if EDGE_FEATHER_PX > 0:
        alpha_img = alpha_img.filter(ImageFilter.GaussianBlur(EDGE_FEATHER_PX))

    # 5. Radial vignette: anything the flood-fill missed (saturated
    # cityscape buildings whose colors don't match the corners) still
    # fades to transparent at the image edges. Center stays opaque so
    # the figure itself is unaffected. Combines multiplicatively with
    # the flood-fill alpha.
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    cx_, cy_ = w / 2.0, h / 2.0
    # Anisotropic ellipse — figures are taller than wide. Stretch X to
    # fit the figure's torso width, leave Y closer to image height.
    rx = w * 0.42
    ry = h * 0.50
    norm = np.sqrt(((xx - cx_) / rx) ** 2 + ((yy - cy_) / ry) ** 2)
    # Inside ellipse (norm < 1.0): alpha = 255. Then fade to 0 by
    # norm = 1.25 (soft falloff outside the ellipse boundary).
    vignette = np.clip(255 * (1.25 - norm) / 0.25, 0, 255).astype(np.uint8)
    vignette_img = Image.fromarray(vignette, mode="L")

    # Combine flood-fill mask AND radial vignette: alpha = min(both)
    # so a pixel needs to survive BOTH passes to be visible.
    combined = np.minimum(
        np.asarray(alpha_img, dtype=np.uint16),
        np.asarray(vignette_img, dtype=np.uint16),
    ).astype(np.uint8)
    alpha_img = Image.fromarray(combined, mode="L")

    # Re-attach alpha to the original RGB.
    out_arr = np.zeros((h, w, 4), dtype=np.uint8)
    out_arr[..., :3] = arr[..., :3].astype(np.uint8)
    out_arr[..., 3] = np.asarray(alpha_img, dtype=np.uint8)
    out = Image.fromarray(out_arr, mode="RGBA")

    DST.parent.mkdir(parents=True, exist_ok=True)
    out.save(DST)
    transparent_pct = 100.0 * float(bg.sum()) / (h * w)
    print(f"saved {DST}  ({DST.stat().st_size // 1024} KB, "
          f"{transparent_pct:.1f}% transparent)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
