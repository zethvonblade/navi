"""Drive a real calibration run with a printing progress callback.

Proves the on_progress wiring fires per-probe against the actual model
(no GUI involved). Mirrors what BrainWorker._run_calibration does, minus
the Qt signal layer.
"""

from __future__ import annotations

import sys
import time
from dataclasses import replace
from pathlib import Path

from navi.brain.config import BrainConfig
from navi.brain.llm_client import LLMClient
from navi.brain.calibration import format_report_for_chat, run_calibration
from navi.tools import tools_schema


def main() -> int:
    # Windows console defaults to cp1252; the report contains emoji.
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    except Exception:
        pass
    cfg = BrainConfig.default()
    # Optional override: `python scripts/test_calibration_progress.py <model.gguf>`
    # bypasses settings.json and the bundled-model default.
    if len(sys.argv) > 1:
        cfg = replace(cfg, model_path=Path(sys.argv[1]))
    print(f"loading model: {cfg.model_path.name}")
    print(f"  n_ctx={cfg.n_ctx} n_threads={cfg.n_threads} n_batch={cfg.n_batch} "
          f"n_gpu_layers={cfg.n_gpu_layers}")
    t0 = time.time()
    llm = LLMClient(
        model_path=cfg.model_path,
        n_ctx=cfg.n_ctx,
        n_threads=cfg.n_threads,
        n_batch=cfg.n_batch,
        n_gpu_layers=cfg.n_gpu_layers,
    )
    print(f"model ready in {time.time() - t0:.1f}s")

    last_t = [time.time()]

    def on_progress(current: int, total: int, label: str) -> None:
        now = time.time()
        elapsed = now - last_t[0]
        last_t[0] = now
        print(f"  [{current}/{total}] {label}  (+{elapsed:.1f}s since last)",
              flush=True)

    print("\n=== running calibration ===")
    cal_t0 = time.time()
    report = run_calibration(
        llm,
        tools_schema(),
        cfg.model_path,
        initial_adapter_id=None,
        auto_fix=True,
        on_progress=on_progress,
    )
    print(f"\n=== calibration finished in {time.time() - cal_t0:.1f}s ===")
    print(format_report_for_chat(report, verbose=False))

    print("\nshutting down model…")
    llm.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
