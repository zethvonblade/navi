"""End-to-end test of the agent loop on the real resume file (no GUI).

Reproduces the user's flow:
  1. user message asking to read+summarize the resume
  2. agent loop calls tools, executes, feeds result back, generates summary
"""

from __future__ import annotations

import json

from llama_cpp import Llama

from navi.brain.config import BrainConfig
from navi.brain.persona import SYSTEM_PROMPT
from navi.brain.worker import _parse_granite_tool_calls
from navi.tools import get_tool, tools_schema
from navi.tools._paths import normalize_windows_path

import sys
USER_MSG = sys.argv[1] if len(sys.argv) > 1 else (
    "Open Notepad and type my todos: eat, sleep, work."
)


def main() -> None:
    cfg = BrainConfig.default()
    llm = Llama(
        model_path=str(cfg.model_path),
        n_ctx=cfg.n_ctx,
        n_threads=cfg.n_threads,
        n_batch=cfg.n_batch,
        verbose=False,
    )
    schema = tools_schema()

    history = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": USER_MSG},
    ]

    for iteration in range(3):
        print(f"\n========== iteration {iteration} ==========")
        resp = llm.create_chat_completion(
            messages=history,
            tools=schema,
            tool_choice="auto",
            max_tokens=cfg.max_tokens,
            temperature=cfg.temperature,
            top_p=cfg.top_p,
        )
        msg = resp["choices"][0]["message"]
        content = msg.get("content") or ""
        print(f"--- assistant emitted ({len(content)} chars) ---")
        print(content[:800])

        # Parse tool calls (Granite style)
        tool_calls = []
        if "<|tool_call|>" in content or "<tool_call>" in content:
            tool_calls = _parse_granite_tool_calls(content) or []

        if not tool_calls:
            print("--- DONE (no tool calls) ---")
            break

        # Cap to one tool call per turn — same as BrainWorker._run_agent_loop.
        call = tool_calls[0]
        name = call["function"]["name"]
        args = json.loads(call["function"]["arguments"] or "{}")
        if "path" in args and isinstance(args["path"], str):
            args["path"] = normalize_windows_path(args["path"])
        # Rewrite assistant content to reflect just the executed call
        single_call_content = (
            "<|tool_call|>["
            + json.dumps({"name": name, "arguments": args})
            + "]"
        )
        history.append({"role": "assistant", "content": single_call_content})

        t = get_tool(name)
        if t is None:
            result = f"Error: unknown tool {name}"
        else:
            try:
                result = t.func(**args)
            except Exception as exc:
                result = f"Error: {exc}"
        print(f"--- tool {name}({args}) returned ({len(str(result))} chars) ---")
        print(str(result)[:300])
        history.append(
            {
                "role": "tool",
                "tool_call_id": call["id"],
                "name": name,
                "content": str(result),
            }
        )


if __name__ == "__main__":
    main()
