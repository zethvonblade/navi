"""Test what Granite does after receiving a tool result.

Tries multiple ways to feed the result back, prints what the model emits next.
The "good" outcome is: Granite reads the result and produces a summary
(no further tool calls).
"""

from __future__ import annotations

import json

from llama_cpp import Llama

from navi.brain.config import BrainConfig
from navi.brain.persona import SYSTEM_PROMPT
from navi.tools import tools_schema

cfg = BrainConfig.default()
llm = Llama(
    model_path=str(cfg.model_path),
    n_ctx=8192,
    n_threads=cfg.n_threads,
    verbose=False,
)
schema = tools_schema()

USER = "Read and summarize C:\\Users\\SinghMa\\OneDrive - US Army\\Documents\\MANDEEP SINGH Resume.docx"
ASSISTANT_TOOL_CALL = (
    '<|tool_call|>[{"name": "read_file", "arguments": {"path": '
    '"C:\\\\Users\\\\SinghMa\\\\OneDrive - US Army\\\\Documents\\\\MANDEEP SINGH Resume.docx"}}]'
)

# Pretend the tool returned this resume snippet
TOOL_RESULT = (
    "MANDEEP SINGH\n303 Gaston Dr. Madison, AL 35756\nOffice Phone: (256) 336-1882\n"
    "Email: msingh0029@gmail.com\n\nOBJECTIVE\nTo secure a position leveraging "
    "Systems Engineering expertise...\n\nPROFESSIONAL EXPERIENCE\nBrockwell "
    "Technologies — Huntsville, AL — System Engineer (Civilian) — June 2023 to Present\n"
    "- Technical Monitor: Oversaw technical aspects of projects\n"
    "- Project Lead: Managed cross-functional teams\n"
    "- SIV&V Dynamic Analysis\n- SIV&V Firmware Analysis\n\n"
    "EDUCATION\nUniversity of Alabama in Huntsville — B.S. in Systems Engineering"
)


CASES: dict[str, list[dict]] = {
    "A_role_tool": [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": USER},
        {"role": "assistant", "content": ASSISTANT_TOOL_CALL},
        {"role": "tool", "content": TOOL_RESULT, "name": "read_file"},
    ],
    "B_user_tool_response_marker": [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": USER},
        {"role": "assistant", "content": ASSISTANT_TOOL_CALL},
        {"role": "user", "content": f"<|tool_response|>{TOOL_RESULT}"},
    ],
    "C_role_tool_with_id": [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": USER},
        {
            "role": "assistant",
            "content": "",
            "tool_calls": [
                {
                    "id": "call_0",
                    "type": "function",
                    "function": {
                        "name": "read_file",
                        "arguments": json.dumps({"path": "..."}),
                    },
                }
            ],
        },
        {"role": "tool", "tool_call_id": "call_0", "name": "read_file", "content": TOOL_RESULT},
    ],
    "D_user_plain_result": [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": USER},
        {"role": "assistant", "content": ASSISTANT_TOOL_CALL},
        {
            "role": "user",
            "content": f"Tool read_file returned:\n{TOOL_RESULT}",
        },
    ],
}


def main() -> None:
    for name, messages in CASES.items():
        print(f"\n========== {name} ==========")
        try:
            resp = llm.create_chat_completion(
                messages=messages,
                tools=schema,
                tool_choice="auto",
                max_tokens=300,
                temperature=0.4,
            )
        except Exception as exc:
            print(f"ERROR: {exc}")
            continue
        msg = resp["choices"][0]["message"]
        content = msg.get("content") or ""
        called_more = "<|tool_call|>" in content or "<tool_call>" in content
        print(f"called_another_tool: {called_more}")
        print("response (first 600 chars):")
        print(content[:600])


if __name__ == "__main__":
    main()
