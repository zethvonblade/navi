"""Direct TTS smoke test — should produce audible speech."""

from __future__ import annotations

import sys
import time

from PySide6.QtCore import QCoreApplication

from navi.voice.tts import TTSEngine

app = QCoreApplication(sys.argv)
e = TTSEngine()

# Wait for worker thread to init engine
time.sleep(1.5)

print("available:", e.available)
voices = e.list_voices()
print(f"voices: {len(voices)}")
for v_id, v_name in voices:
    print(f"  {v_name}")

print("speaking now …")
e.speak("Hello from Navi. This is a test of the text-to-speech engine.")

# Pump events so TTS signals can fire; wait long enough for ~5s of speech
for _ in range(80):
    app.processEvents()
    time.sleep(0.1)

print("done")
e.shutdown()
