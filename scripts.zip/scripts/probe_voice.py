"""Probe voice stack — what's available on this machine."""

from __future__ import annotations


def probe_tts() -> None:
    print("=== TTS (pyttsx3 / Windows SAPI) ===")
    try:
        import pyttsx3
        e = pyttsx3.init()
        voices = e.getProperty("voices")
        print(f"OK — {len(voices)} voices available")
        for v in voices:
            print(f"  - {v.id}\n    {v.name}")
        rate = e.getProperty("rate")
        vol = e.getProperty("volume")
        print(f"default rate: {rate}, volume: {vol}")
        e.stop()
    except Exception as exc:
        print(f"FAIL: {exc}")


def probe_stt() -> None:
    print("\n=== STT (SpeechRecognition + PyAudio) ===")
    try:
        import speech_recognition as sr
        mics = sr.Microphone.list_microphone_names()
        print(f"mics: {len(mics)}")
        for m in mics[:6]:
            print(f"  {m}")
        r = sr.Recognizer()
        print(f"recognizer ready (energy threshold: {r.energy_threshold})")

        # Test which engines are available
        for name in (
            "recognize_google",
            "recognize_whisper",
            "recognize_sphinx",
            "recognize_vosk",
        ):
            available = hasattr(r, name)
            print(f"  {name}: {'yes' if available else 'no'}")

        # Try Windows built-in via WinRT
        try:
            from winsdk.windows.media.speechrecognition import SpeechRecognizer  # type: ignore
            print("  winsdk SpeechRecognizer: importable")
        except Exception as exc:
            print(f"  winsdk SpeechRecognizer: NO ({exc})")
    except Exception as exc:
        print(f"FAIL: {exc}")


if __name__ == "__main__":
    probe_tts()
    probe_stt()
