"""One-shot installer + configurator for Navi image generation.

Run this once from the project root after deciding to enable image
generation. It installs the diffusion stack, downloads a model, verifies
the import path, and updates ``settings.json`` so Navi finds the model.

Usage::

    .venv/Scripts/python.exe scripts/image_generation_chip.py

Optional flags::

    --model <hf-repo>            HuggingFace repo id (default: FLUX.1-schnell)
    --target <dir>               Where to download the model
                                 (default: <project>/models/<repo-name>)
    --skip-deps                  Don't pip install — assume diffusers is set up
    --skip-download              Don't download — assume model already on disk
    --skip-settings              Don't write to settings.json
    --cpu                        Force CPU torch wheel (skip CUDA detection)
    --no-update-settings         Same as --skip-settings (alias)
    --yes                        Don't ask for confirmation on big downloads

Idempotent: safe to re-run. Detects what's already done and skips.

What it does step by step:
  1. Verify python version (3.12)
  2. Detect NVIDIA GPU via ``nvidia-smi`` (informs torch wheel choice)
  3. Check ~15 GB free disk space
  4. Pip install: diffusers, transformers, accelerate, safetensors,
     huggingface_hub, torch (CUDA wheel if GPU detected)
  5. Download the model with ``huggingface_hub.snapshot_download``
  6. Smoke-test: import diffusers, point at the model dir, walk the
     pipeline class init enough to verify the files are intact
  7. Write the model path to %APPDATA%/Navi/settings.json under
     ``image.model_path`` so Navi auto-detects it on next launch

This script is self-contained — uses only stdlib + subprocess — so it can
run before the diffusion stack is installed.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths + constants
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent
VENV_PYTHON = PROJECT_ROOT / ".venv" / "Scripts" / "python.exe"

DEFAULT_MODEL = "black-forest-labs/FLUX.1-schnell"
DEFAULT_MODEL_DIR_NAME = "FLUX.1-schnell"

# CUDA wheel to use when GPU is detected. cu124 = CUDA 12.4 stable for
# torch 2.x in 2026. Adjust if a future torch release changes the default.
TORCH_CUDA_INDEX = "https://download.pytorch.org/whl/cu124"

# Diffusers + transformers + accelerate are the core stack for FLUX.
# safetensors is the on-disk format for FLUX weights.
# huggingface_hub gives us snapshot_download for the model files.
DEPS_CORE = (
    "diffusers",
    "transformers",
    "accelerate",
    "safetensors",
    "huggingface_hub",
    "sentencepiece",  # FLUX text encoder needs it
    "protobuf",       # transformers depends transitively
)

# Disk budget: ~3 GB Python deps + ~12 GB model with overhead.
MIN_FREE_GB = 18

# ANSI colors (Windows 10+ terminals support these).
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
DIM = "\033[2m"
RESET = "\033[0m"


# ---------------------------------------------------------------------------
# Logging helpers
# ---------------------------------------------------------------------------
def step(msg: str) -> None:
    print(f"{CYAN}[chip]{RESET} {msg}")


def ok(msg: str) -> None:
    print(f"{GREEN}[chip]{RESET} {msg}")


def warn(msg: str) -> None:
    print(f"{YELLOW}[chip] warn:{RESET} {msg}")


def die(msg: str) -> None:
    print(f"{RED}[chip] error:{RESET} {msg}", file=sys.stderr)
    sys.exit(1)


def run(cmd: list[str], check: bool = True) -> int:
    """Run a subprocess with the command echoed. Returns exit code."""
    print(f"{DIM}    $ {' '.join(cmd)}{RESET}")
    result = subprocess.run(cmd)
    if check and result.returncode != 0:
        die(f"command failed (exit {result.returncode}): {' '.join(cmd)}")
    return result.returncode


# ---------------------------------------------------------------------------
# Environment checks
# ---------------------------------------------------------------------------
def python_for_install() -> str:
    """Pick the python interpreter to use for pip + import checks.

    Prefers the project's ``.venv`` so installs land in the right place;
    falls back to the current interpreter (with a warning) if no venv.
    """
    if VENV_PYTHON.exists():
        return str(VENV_PYTHON)
    warn(
        f"no .venv found at {VENV_PYTHON}; using current Python "
        f"({sys.executable}). Run `python setup.py` first if you want a "
        "project-local environment."
    )
    return sys.executable


def check_python_version(py: str) -> None:
    out = subprocess.run(
        [py, "-c",
         "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"],
        capture_output=True, text=True, check=True,
    )
    ver = out.stdout.strip()
    if ver != "3.12":
        warn(f"Python {ver} detected (expected 3.12). Continuing anyway.")
    else:
        ok(f"Python {ver}")


def detect_nvidia_gpu() -> bool:
    """True if ``nvidia-smi`` runs successfully — implies CUDA-capable GPU."""
    smi = shutil.which("nvidia-smi")
    if not smi:
        return False
    try:
        result = subprocess.run(
            [smi], capture_output=True, text=True, timeout=5,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False


def check_disk_space(target_dir: Path) -> None:
    """Refuse to start if less than MIN_FREE_GB free."""
    target_dir.parent.mkdir(parents=True, exist_ok=True)
    total, used, free = shutil.disk_usage(target_dir.parent)
    free_gb = free / (1024 ** 3)
    if free_gb < MIN_FREE_GB:
        die(
            f"only {free_gb:.1f} GB free at {target_dir.parent}; "
            f"need ~{MIN_FREE_GB} GB for deps + model"
        )
    ok(f"disk: {free_gb:.1f} GB free at {target_dir.parent}")


# ---------------------------------------------------------------------------
# Pip install
# ---------------------------------------------------------------------------
def already_installed(py: str, pkg: str) -> bool:
    """Cheap presence check — `python -m pip show <pkg>` succeeds when
    installed. Faster than calling pip install with --quiet for every dep."""
    result = subprocess.run(
        [py, "-m", "pip", "show", pkg],
        capture_output=True,
    )
    return result.returncode == 0


def install_torch(py: str, use_cuda: bool) -> None:
    """Install torch separately because the CUDA wheel needs an extra index."""
    if already_installed(py, "torch"):
        ok("torch already installed")
        return
    if use_cuda:
        step(f"installing torch with CUDA support ({TORCH_CUDA_INDEX})")
        run([py, "-m", "pip", "install", "--upgrade",
             "--index-url", TORCH_CUDA_INDEX, "torch"])
    else:
        step("installing torch (CPU build)")
        run([py, "-m", "pip", "install", "--upgrade", "torch"])


def install_deps(py: str, use_cuda: bool) -> None:
    install_torch(py, use_cuda)
    missing = [p for p in DEPS_CORE if not already_installed(py, p)]
    if not missing:
        ok("diffusion stack already installed")
        return
    step(f"installing {len(missing)} package(s): {', '.join(missing)}")
    run([py, "-m", "pip", "install", "--upgrade", *missing])


# ---------------------------------------------------------------------------
# Model download
# ---------------------------------------------------------------------------
def model_already_present(target: Path) -> bool:
    """A FLUX model dir is 'present' if it has the canonical files."""
    if not target.is_dir():
        return False
    # FluxPipeline expects model_index.json + several subfolders. If
    # model_index.json exists we assume the rest is too (snapshot_download
    # is atomic — partial downloads are unusual).
    return (target / "model_index.json").exists()


def download_model(py: str, repo: str, target: Path, force: bool) -> None:
    if model_already_present(target) and not force:
        ok(f"model already present at {target}")
        return
    step(f"downloading {repo} → {target} (this is large; "
         "be patient)")
    target.mkdir(parents=True, exist_ok=True)
    code = (
        "from huggingface_hub import snapshot_download\n"
        f"snapshot_download(repo_id={repo!r}, "
        f"local_dir=r'{target}', "
        "local_dir_use_symlinks=False)\n"
    )
    run([py, "-c", code])
    if not model_already_present(target):
        die(
            f"download finished but {target/'model_index.json'} is missing. "
            "The model files may be incomplete — re-run with --skip-deps to retry."
        )
    ok(f"model downloaded to {target}")


# ---------------------------------------------------------------------------
# Verification
# ---------------------------------------------------------------------------
def verify_pipeline_loads(py: str, target: Path) -> None:
    """Smoke-test: import diffusers, point at the model dir. Doesn't run
    inference (would require GPU + lots of time) — just verifies the
    files load cleanly."""
    step("verifying diffusers can read the model")
    code = (
        "import sys, os\n"
        "os.environ.setdefault('TRANSFORMERS_VERBOSITY', 'error')\n"
        "from diffusers import FluxPipeline\n"
        "pipe = FluxPipeline.from_pretrained(r'"
        + str(target).replace('\\', '\\\\')
        + "')\n"
        "print('OK: pipeline class', type(pipe).__name__)\n"
    )
    run([py, "-c", code])
    ok("pipeline loads cleanly")


# ---------------------------------------------------------------------------
# Settings update
# ---------------------------------------------------------------------------
def settings_path() -> Path:
    appdata = os.environ.get("APPDATA")
    base = Path(appdata) if appdata else Path.home() / ".config"
    return base / "Navi" / "settings.json"


def update_settings(target: Path) -> None:
    sp = settings_path()
    if not sp.exists():
        warn(f"no settings.json at {sp} — skipping settings update")
        return
    try:
        s = json.loads(sp.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        warn(f"couldn't read {sp}: {exc} — skipping settings update")
        return
    s.setdefault("image", {})["model_path"] = str(target)
    sp.write_text(json.dumps(s, indent=2), encoding="utf-8")
    ok(f"updated {sp}: image.model_path = {target}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    if os.name == "nt":
        os.system("")  # enable ANSI on legacy consoles

    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--model", default=DEFAULT_MODEL,
                        help=f"HuggingFace repo id (default: {DEFAULT_MODEL})")
    parser.add_argument("--target", default=None,
                        help="model destination directory")
    parser.add_argument("--skip-deps", action="store_true",
                        help="skip pip install step")
    parser.add_argument("--skip-download", action="store_true",
                        help="skip model download")
    parser.add_argument("--skip-settings", action="store_true",
                        help="don't write to settings.json")
    parser.add_argument("--no-update-settings", dest="skip_settings",
                        action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--cpu", action="store_true",
                        help="force CPU torch wheel (skip CUDA detection)")
    parser.add_argument("--yes", "-y", action="store_true",
                        help="don't prompt for confirmation")
    args = parser.parse_args()

    target = Path(args.target).resolve() if args.target else (
        PROJECT_ROOT / "models" / DEFAULT_MODEL_DIR_NAME
    )

    print(f"{CYAN}=== Navi image-generation chip ==={RESET}")
    print(f"    project root : {PROJECT_ROOT}")
    print(f"    model        : {args.model}")
    print(f"    target dir   : {target}")

    py = python_for_install()
    check_python_version(py)
    use_cuda = (not args.cpu) and detect_nvidia_gpu()
    if use_cuda:
        ok("NVIDIA GPU detected — will install CUDA torch")
    else:
        if args.cpu:
            warn("--cpu given — installing CPU torch")
        else:
            warn("no NVIDIA GPU detected — installing CPU torch (slow)")

    check_disk_space(target)

    if not args.yes:
        print(
            f"\n{YELLOW}About to install ~3 GB of Python deps and "
            f"download ~12 GB of model weights to {target}.{RESET}"
        )
        ans = input("Proceed? [y/N] ").strip().lower()
        if ans not in ("y", "yes"):
            die("aborted by user")

    if args.skip_deps:
        warn("--skip-deps given; skipping pip install")
    else:
        install_deps(py, use_cuda)

    if args.skip_download:
        warn("--skip-download given; skipping snapshot_download")
    else:
        download_model(py, args.model, target, force=False)

    # Verify only if both pieces are in place
    if not args.skip_deps and not args.skip_download:
        try:
            verify_pipeline_loads(py, target)
        except SystemExit:
            warn("verification failed — but model files exist. Try "
                 "`generate_image` from chat to see the actual error.")

    if args.skip_settings:
        warn("--skip-settings given; settings.json not updated")
    else:
        update_settings(target)

    print()
    ok("done.")
    print(f"\nTry it from chat:")
    print(f'  "generate an image of a glowing AI orb floating above a desk"')
    print(f"\nOr from Python:")
    print(f"  {py} -c \"from navi.tools.image_gen import generate_image; "
          f"print(generate_image('a cat in a spacesuit', steps=4))\"")


if __name__ == "__main__":
    main()
