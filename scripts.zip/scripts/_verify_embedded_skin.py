"""Verify the embedded skin is self-contained and renders correctly."""
import sys
sys.stdout.reconfigure(encoding="utf-8")

import re
from navi.pet.skins import reload_skins, REGISTRY, get_skin

count, names = reload_skins()
print(f"{count} skins: {names}")
assert "navi-figure" in names, "navi-figure missing from registry"

import navi.pet.skins.navi_figure as nf
src = open(nf.__file__, encoding="utf-8").read()

# Self-containedness checks: no actual file-loading code paths.
# Docstring/comment mentions of "images/" are fine (just documentation).
forbidden_apis = [
    "Path(__file__)",
    "_PROJECT_ROOT",
    "_FIGURE_PATH",
    ".read_bytes()",
    "open(",
]
for needle in forbidden_apis:
    if needle in src:
        # Filter to non-comment lines only
        for ln in src.splitlines():
            stripped = ln.strip()
            if stripped.startswith("#") or stripped.startswith('"""'):
                continue
            if needle in ln:
                raise AssertionError(f"forbidden file-API still present: {needle!r} in line: {ln.strip()}")
assert "_FIGURE_BYTES_B64" in src, "embedded literal missing"
assert "QImage.fromData" in src, "missing in-memory decode"

print(f"navi_figure.py size: {len(src) // 1024} KB")
print("self-contained: YES (no images/ references)")

# Instantiation
skin = get_skin("navi-figure")
print(f"instantiated: {type(skin).__name__}")

# Decode test (don't render — just verify decode works)
pix = nf._decode_figure()
if pix is None:
    print(f"DECODE FAILED: {nf._FIGURE_LOAD_ERROR}")
    sys.exit(1)
print(f"decoded sprite: {pix.width()}x{pix.height()} px")
print("ALL CHECKS PASS")
